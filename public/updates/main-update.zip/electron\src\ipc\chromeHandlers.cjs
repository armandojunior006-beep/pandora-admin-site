// ============================================================================
// IPC: chrome:* (grupo geral) — proxy on/off, abrir múltiplos links, fechar,
// seleção de janelas controladas, modo espelho, lista de domínios bloqueados,
// overlay "Dados da Conta", velocidade (speedhack) e reload.
// ============================================================================
const state = require("../state.cjs");
const { setSettingSync } = require("../settings/settingsStore.cjs");
const { setProxyEnabledForWindows } = require("../proxy/proxyManager.cjs");
const { applyBlockedDomainsToSession } = require("../proxy/domainBlocker.cjs");
const { applyControlIndicator } = require("../window/windowManager.cjs");
const { openChromiumMulti, closeChromiumWindows, getSelectedChromeWins } = require("../window/chromiumWindows.cjs");
const { applyMirrorState } = require("../window/mirrorMode.cjs");
const { setPopupCloserEnabledLive } = require("../window/autoLogin.cjs");
const {
  applyAccountOverlayToTargets, setAccountOverlayState, setSpeedMultiplier, __setSpeedInAllFrames,
} = require("../injections/browserInjections.cjs");

function registerChromeHandlers(ipcMain) {
  ipcMain.handle("chrome:setProxyEnabled", async (_e, enabled) => {
    const target = !!enabled;
    const result = await setProxyEnabledForWindows(target);
    const acao = target ? "ATIVADA" : "DESATIVADA";
    console.log(`[proxy] ${acao} em ${result.affected} janela(s) [${result.indexes.join(",")}]`);
    return result;
  });
  ipcMain.handle("chrome:openMulti", async (_e, links, count, accounts, delaySec, headless) => await openChromiumMulti(links || [], count || 1, accounts || [], delaySec || 0, !!headless));
  ipcMain.handle("chrome:close", () => { closeChromiumWindows(); return true; });
  ipcMain.handle("chrome:refreshControlSelection", (_e, spec) => {
    try {
      const prev = state.janelasOverride;
      if (typeof spec === "string") state.janelasOverride = spec;
      const trimmed = String(spec ?? "").trim();
      const all = state.chromeWins.filter((w) => w && !w.isDestroyed());
      const list = getSelectedChromeWins();
      if (!trimmed) {
        // Campo vazio → garante remoção de TODOS os overlays, mesmo em janelas
        // que por algum motivo perderam o estado interno (navegação, race, etc.).
        for (const w of all) {
          try { w.__pandoraCtrlSelected = false; } catch {}
          applyControlIndicator(w, false);
        }
        console.log(`[janelas] campo limpo (anterior="${prev ?? ""}") · overlays removidos de ${all.length} tela(s)`);
      } else {
        console.log(`[janelas] seleção "${trimmed}" · ${list.length}/${all.length} tela(s) controlada(s)`);
      }
      try { applyMirrorState(); } catch {}
      return list.length;
    } catch { return 0; }
  });
  ipcMain.handle("chrome:setMirrorEnabled", async (_e, enabled) => {
    state.mirrorEnabled = !!enabled;
    await applyMirrorState();
    const sel = getSelectedChromeWins();
    const all = state.chromeWins.filter((w) => w && !w.isDestroyed());
    const masterIdx = state.mirrorMaster ? (all.indexOf(state.mirrorMaster) + 1) : 0;
    const followerIdx = sel.filter((w) => w !== state.mirrorMaster).map((w) => all.indexOf(w) + 1);
    console.log(`[mirror] ${state.mirrorEnabled ? "ATIVADO" : "DESATIVADO"} master=#${masterIdx} followers=[${followerIdx.join(",")}]`);
    return { ok: true, enabled: state.mirrorEnabled, master: masterIdx, followers: followerIdx };
  });
  ipcMain.handle("chrome:setPopupCloserEnabled", (_e, enabled) => {
    setPopupCloserEnabledLive(!!enabled);
    return true;
  });
  ipcMain.handle("chrome:setBlockedDomains", async (_e, list) => {
    const arr = Array.isArray(list) ? list : [];
    state.blockedDomains = arr.map((s) => String(s || "").trim().toLowerCase()).filter(Boolean);
    try { await setSettingSync("op_blocked_domains", JSON.stringify(state.blockedDomains)); } catch {}
    // Garante que toda janela aberta tem o filtro registrado (idempotente).
    for (const win of state.chromeWins) {
      try {
        if (!win || win.isDestroyed()) continue;
        applyBlockedDomainsToSession(win.webContents.session);
      } catch {}
    }
    console.log(`[block] lista atualizada (${state.blockedDomains.length}): ${state.blockedDomains.join(", ")}`);
    return { ok: true, count: state.blockedDomains.length };
  });
  ipcMain.handle("chrome:setAccountOverlay", async (_e, payload) => {
    try {
      const s = payload || {};
      const st = setAccountOverlayState(s);
      applyAccountOverlayToTargets();
      const all = state.chromeWins.filter((w) => w && !w.isDestroyed());
      const sel = getSelectedChromeWins();
      const scope = st.enabled
        ? (sel.length ? `seleção (${sel.length}/${all.length})` : `todas (${all.length})`)
        : "removido";
      console.log(`[overlay-dados] ${st.enabled ? "ATIVADO" : "DESATIVADO"} · ${scope}`);
      return { ok: true, enabled: st.enabled, applied: all.length };
    } catch (e) {
      return { ok: false, error: String(e && e.message || e) };
    }
  });
  ipcMain.handle("chrome:setSpeedMultiplier", (_e, value) => {
    const m = Math.max(1, Math.min(25, parseFloat(value) || 1));
    setSpeedMultiplier(m);
    let n = 0;
    for (const win of state.chromeWins) {
      try {
        if (!win || win.isDestroyed()) continue;
        __setSpeedInAllFrames(win.webContents, m);
        n++;
      } catch {}
    }
    console.log(`[speedhack] multiplicador atualizado para ${m}x em ${n} janela(s).`);
    return { ok: true, multiplier: m, applied: n };
  });
  ipcMain.handle("chrome:reload", () => {
    let n = 0;
    for (const win of getSelectedChromeWins()) {
      try {
        if (!win || win.isDestroyed()) continue;
        win.webContents.reload();
        n++;
      } catch {}
    }
    return n;
  });
}

module.exports = { registerChromeHandlers };
