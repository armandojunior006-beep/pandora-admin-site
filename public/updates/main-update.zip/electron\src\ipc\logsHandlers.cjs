// ============================================================================
// IPC: logs:* / accounts:backup — exportação de logs do sistema, contas e do
// arquivo DIAG (auto-register) para .txt, com abertura no editor padrão.
// ============================================================================
const { app, shell, clipboard } = require("electron");
const fs = require("fs");
const path = require("path");
const state = require("../state.cjs");
const { getDiagFilePath } = require("../../auto-register.cjs");

function registerLogsHandlers(ipcMain) {
  ipcMain.handle("logs:openFile", async (_e, opts) => {
    try {
      const filter = (opts && opts.source) ? String(opts.source) : null;
      const limit = Math.min(Math.max(parseInt(String((opts && opts.limit) || "2000"), 10) || 2000, 1), 20000);
      let where = "";
      if (filter) {
        const safe = filter.replace(/'/g, "''");
        where = `WHERE source LIKE '${safe}%' OR source IS NULL`;
      }
      const sql = `SELECT id, level, source, message, created_at FROM logs ${where} ORDER BY id DESC LIMIT ${limit}`;
      const stmt = state.db.prepare(sql);
      const rows = [];
      while (stmt.step()) rows.push(stmt.getAsObject());
      stmt.free();
      // Também inclui contas registradas para o usuário identificar tudo
      const accStmt = state.db.prepare("SELECT id, label, username, password, notes, status, created_at FROM accounts ORDER BY id DESC LIMIT 500");
      const accRows = [];
      while (accStmt.step()) accRows.push(accStmt.getAsObject());
      accStmt.free();

      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      const dir = path.join(app.getPath("userData"), "logs-export");
      try { fs.mkdirSync(dir, { recursive: true }); } catch {}
      const filePath = path.join(dir, `pandora-logs-${stamp}.txt`);
      const headerSep = "=".repeat(72);
      const lines = [];
      lines.push(`Spider BOT — Exportacao de Logs`);
      lines.push(`Gerado em: ${new Date().toLocaleString()}`);
      lines.push(`Versao: ${app.getVersion()}`);
      lines.push(headerSep);
      lines.push("");
      lines.push(`CONTAS REGISTRADAS (${accRows.length})`);
      lines.push(headerSep);
      for (const a of accRows) {
        let saque = "-";
        try { const j = JSON.parse(a.notes || "{}"); if (j && j.saque != null) saque = String(j.saque); } catch {}
        lines.push(`#${a.id} | ${a.created_at} | ${a.label} | login=${a.username} | senha=${a.password} | saque=${saque} | status=${a.status}`);
      }
      lines.push("");
      lines.push(`LOGS (${rows.length}${filter ? ", filtro: " + filter : ""})`);
      lines.push(headerSep);
      for (const r of rows.reverse()) {
        lines.push(`[${r.created_at}] [${(r.level || "").toUpperCase()}] (${r.source || "-"}) ${r.message}`);
      }
      fs.writeFileSync(filePath, lines.join("\r\n"), "utf8");
      const err = await shell.openPath(filePath);
      if (err) return { ok: false, error: err, path: filePath };
      return { ok: true, path: filePath, lines: lines.length };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  // Backup completo das contas em arquivo .txt (bloco de notas).
  // Inclui obrigatoriamente: login, senha e senha de saque.
  ipcMain.handle("accounts:backup", async () => {
    try {
      const accStmt = state.db.prepare("SELECT id, label, username, password, notes, status, created_at FROM accounts ORDER BY id DESC");
      const accRows = [];
      while (accStmt.step()) accRows.push(accStmt.getAsObject());
      accStmt.free();

      let globalPin = "";
      try {
        const s = state.db.prepare("SELECT value FROM settings WHERE key='senha_saque' LIMIT 1");
        if (s.step()) globalPin = String(s.getAsObject().value || "");
        s.free();
      } catch {}

      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      const dir = path.join(app.getPath("userData"), "accounts-backup");
      try { fs.mkdirSync(dir, { recursive: true }); } catch {}
      const filePath = path.join(dir, `pandora-contas-backup-${stamp}.txt`);
      const sep = "=".repeat(72);
      const lines = [];
      lines.push("Spider BOT - Backup de Contas");
      lines.push(`Gerado em: ${new Date().toLocaleString()}`);
      lines.push(`Versao: ${app.getVersion()}`);
      lines.push(`Total de contas: ${accRows.length}`);
      lines.push(sep);
      lines.push("");
      for (const a of accRows) {
        let pin = "";
        try {
          const j = JSON.parse(a.notes || "{}");
          pin = String(j.saque_pin || j.pin || "");
        } catch {}
        if (!pin) pin = globalPin || "-";
        lines.push(`#${a.id} | ${a.created_at} | ${a.label || "-"}`);
        lines.push(`   Login         : ${a.username || "-"}`);
        lines.push(`   Senha         : ${a.password || "-"}`);
        lines.push(`   Senha de saque: ${pin}`);
        lines.push("");
      }
      fs.writeFileSync(filePath, lines.join("\r\n"), "utf8");
      const err = await shell.openPath(filePath);
      if (err) {
        try { shell.showItemInFolder(filePath); } catch {}
        return { ok: false, error: err, path: filePath, count: accRows.length };
      }
      return { ok: true, path: filePath, count: accRows.length };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  // Exportação dedicada do log DIAG (auto-register) em arquivo TXT contínuo.
  ipcMain.handle("logs:openDiag", async (_e, opts) => {
    try {
      const filePath = getDiagFilePath();
      // Garante que o arquivo exista (Windows openPath falha em arquivos inexistentes).
      try {
        if (!fs.existsSync(filePath)) {
          fs.writeFileSync(filePath, `Spider BOT — DIAG auto-register\r\nGerado em: ${new Date().toLocaleString()}\r\n(arquivo vazio — execute um cadastro para popular)\r\n`, "utf8");
        }
      } catch {}
      let content = "";
      try { content = fs.readFileSync(filePath, "utf8"); } catch { content = ""; }
      try { clipboard.writeText(content); } catch {}
      let openErr = "";
      try {
        if (opts && opts.openFolder) shell.showItemInFolder(filePath);
        else {
          openErr = await shell.openPath(filePath);
          // Fallback: se openPath falhar (sem app associado), revela no Explorer.
          if (openErr) { try { shell.showItemInFolder(filePath); openErr = ""; } catch {} }
        }
      } catch (e) { openErr = e?.message || String(e); }
      return { ok: !openErr, path: filePath, bytes: content.length, copied: true, error: openErr || undefined };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  ipcMain.handle("logs:readDiag", async () => {
    try {
      const filePath = getDiagFilePath();
      let content = "";
      try { content = fs.readFileSync(filePath, "utf8"); } catch {}
      return { ok: true, path: filePath, content };
    } catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });

  ipcMain.handle("logs:clearDiag", async () => {
    try { fs.writeFileSync(getDiagFilePath(), "", "utf8"); return { ok: true }; }
    catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
}

module.exports = { registerLogsHandlers };
