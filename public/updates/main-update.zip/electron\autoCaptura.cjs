// ============================================================
// autoCaptura.js
// Vigia automático: detecta quando uma conta nova é criada/logada
// e salva login + senha + ID sozinho, sem chamada manual.
// Roda no PROCESSO MAIN do Electron.
//
// Uso (depois que a janela do site carregar):
//   const { iniciarAutoCaptura } = require('./autoCaptura');
//   const parar = iniciarAutoCaptura(win.webContents, 'https://91-handsetpg.com', win);
//   // ... parar() quando quiser desligar o vigia
// ============================================================

const { salvarConta, listarContas } = require('./contasStore.cjs');
let _getDiag = null;
let _queueDiagLine = null;
try {
  const ar = require('./auto-register.cjs');
  _getDiag = ar.getDiagFilePath;
  _queueDiagLine = ar.queueDiagLine;
} catch {}
function diag(msg, extra) {
  const line = `[${new Date().toISOString()}] [AUTO] ${msg}` + (extra !== undefined ? ' ' + JSON.stringify(extra) : '') + '\r\n';
  try { console.log(line.trim()); } catch {}
  // Enfileirado/assíncrono (ver auto-register.cjs) — esse "vigia de contas"
  // roda a cada ~1.5s POR JANELA continuamente; gravar em disco de forma
  // síncrona aqui, multiplicado por várias janelas ao mesmo tempo, era uma
  // fonte constante de travadinha na thread principal.
  try { if (_getDiag && _queueDiagLine) { _getDiag(); _queueDiagLine(line); } } catch {}
}

// Script injetado na página: lembra o ÚLTIMO login/senha digitados,
// mesmo que os campos sejam limpos após o cadastro.
const SCRIPT_MEMORIA = `
(() => {
  if (window.__capturaInstalada) return true;
  window.__capturaInstalada = true;
  window.__ultimoLogin = window.__ultimoLogin || null;
  window.__ultimaSenha = window.__ultimaSenha || null;
  function ehLoginValido(v) {
    // Login do site é alfanumérico (ex: "solararthu"). Ignora valores
    // puramente numéricos (ex: "50" do campo de depósito) e curtos demais.
    if (!v || typeof v !== 'string') return false;
    if (v.length < 4) return false;
    if (!/[A-Za-z]/.test(v)) return false;
    return true;
  }
  function ehSenhaValida(v) {
    return !!(v && typeof v === 'string' && v.length >= 4);
  }
  function lembrar() {
    const a = document.querySelector('[data-input-name="account"]');
    const p = document.querySelector('[data-input-name="userpass"]');
    if (a && a.value) {
      const val = a.value.trim();
      if (ehLoginValido(val)) window.__ultimoLogin = val;
    }
    if (p && p.value) {
      const val = p.value.trim();
      if (ehSenhaValida(val)) window.__ultimaSenha = val;
    }
  }
  document.addEventListener('input', lembrar, true);
  setInterval(lembrar, 500);
  lembrar();
  return true;
})();
`;

// Script que lê o estado atual: ID (do JWT) + login/senha lembrados.
const SCRIPT_ESTADO = `
(() => {
  function dec(s){s=s.replace(/-/g,'+').replace(/_/g,'/');while(s.length%4)s+='=';return decodeURIComponent(escape(atob(s)));}
  function idAtual(){
    let blob='';
    try{for(let i=0;i<localStorage.length;i++)blob+='\\n'+localStorage.getItem(localStorage.key(i));}catch(e){}
    try{for(let i=0;i<sessionStorage.length;i++)blob+='\\n'+sessionStorage.getItem(sessionStorage.key(i));}catch(e){}
    try{blob+='\\n'+document.cookie;}catch(e){}
    const jwts=blob.match(/eyJ[A-Za-z0-9_-]+\\.eyJ[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+/g)||[];
    for(const j of jwts){try{const c=JSON.parse(dec(j.split('.')[1]));const v=c.u??c.uid??c.userId;if(v&&/^[0-9]{6,12}$/.test(String(v)))return String(v);}catch(e){}}
    const m=blob.match(/"(?:uid|user_?id|userid)"\\s*:\\s*"?([0-9]{6,12})"?/i);
    return m?m[1]:null;
  }
  return { id: idAtual(), login: window.__ultimoLogin||null, senha: window.__ultimaSenha||null };
})();
`;

function iniciarAutoCaptura(webContents, casaUrl, janelaContas = null, opts = {}) {
  const intervalo = opts.intervalo || 1500;
  const chromeWin = opts.chromeWin || null;
  const salvos = new Set();
  let rodando = true;

  function calcSenhaSaque() {
    try {
      const get = global.__pandoraGetWithdrawPin;
      if (typeof get === 'function') return get(chromeWin);
    } catch {}
    try {
      const gs = global.__pandoraGetSetting;
      const raw = (typeof gs === 'function' ? String(gs('senha_saque', '') || '') : '').replace(/\D/g, '').slice(0, 6);
      if (raw.length === 6) return raw;
    } catch {}
    if (chromeWin && !chromeWin.isDestroyed?.() && /^\d{6}$/.test(chromeWin._withdrawPin || '')) {
      return chromeWin._withdrawPin;
    }
    let s = '';
    for (let i = 0; i < 6; i++) s += Math.floor(Math.random() * 10);
    if (chromeWin && !chromeWin.isDestroyed?.()) chromeWin._withdrawPin = s;
    return s;
  }

  // não re-salvar contas que já estão no arquivo
  listarContas().then((cs) => cs.forEach((c) => c.conta_id && salvos.add(c.conta_id)))
                .catch(() => {});

  // (re)instala o "memorizador" a cada carregamento/navegação
  const instalar = () => webContents.executeJavaScript(SCRIPT_MEMORIA).catch(() => {});
  webContents.on('did-finish-load', instalar);
  webContents.on('did-navigate-in-page', instalar);
  instalar();

  diag('Vigia de contas ligado.', { casaUrl });

  const timer = setInterval(async () => {
    if (!rodando) return;
    try {
      const est = await webContents.executeJavaScript(SCRIPT_ESTADO);
      if (!est) return;
      // log periódico só quando algo muda
      const sig = `${est.id||''}|${est.login||''}|${est.senha?'S':'-'}`;
      if (sig !== iniciarAutoCaptura._lastSig) {
        iniciarAutoCaptura._lastSig = sig;
        diag('estado', { id: est.id, login: est.login, temSenha: !!est.senha, jaSalvo: est.id ? salvos.has(est.id) : false });
      }
      if (est.id && est.login && est.senha && !salvos.has(est.id)) {
        salvos.add(est.id);
        diag('Nova conta detectada — salvando', { id: est.id, login: est.login });
        try {
          const senhaSaque = calcSenhaSaque();
          const row = await salvarConta({ casa: casaUrl, login: est.login, senha: est.senha, senhaSaque, id: est.id });
          diag('✔ Conta salva', { rowId: row.id });
          // Log visível na aba Início (login/senha/dispositivo)
          try {
            const dispositivo =
              (chromeWin && chromeWin._pandoraMobileProfile)
                ? `${chromeWin._pandoraMobileProfile.name} (${chromeWin._pandoraMobileProfile.os === 'ios' ? 'iOS' : 'Android'})`
                : 'Desktop padrão';
            const ord = (chromeWin && chromeWin._pandoraOrder) || '?';
            if (typeof global.__pandoraLogSystem === 'function') {
              global.__pandoraLogSystem(
                `Conta criada — Tela #${ord} | Login: ${est.login} | Senha: ${est.senha} | Senha Saque: ${senhaSaque || '-'} | ID: ${est.id || '-'} | Dispositivo: ${dispositivo}`,
                { tela: ord, login: est.login, senha: est.senha, senhaSaque, id: est.id, dispositivo, casa: casaUrl },
                'info', 'contas'
              );
            }
          } catch {}
          // Vincula credenciais à janela para o overlay "Exibir Dados" ler por janela
          try {
            if (chromeWin && !chromeWin.isDestroyed?.()) {
              chromeWin._contaAutoLogin = Object.assign({}, chromeWin._contaAutoLogin || {}, {
                login: String(est.login || ''),
                senha: String(est.senha || ''),
                senhaSaque: String(senhaSaque || ''),
                id: String(est.id || ''),
              });
              try { if (typeof global.__pandoraApplyOverlay === 'function') global.__pandoraApplyOverlay(chromeWin); } catch {}
            }
          } catch {}
          if (janelaContas && !janelaContas.isDestroyed()) {
            janelaContas.webContents.send('contas:atualizou');
            diag('evento contas:atualizou enviado');
          }
          await webContents.executeJavaScript('window.__ultimoLogin=null;window.__ultimaSenha=null;true;').catch(() => {});
        } catch (eSave) {
          diag('ERRO ao salvar conta', { msg: eSave && eSave.message });
        }
      }
    } catch (e) {
      // página trocando de URL etc.
    }
  }, intervalo);

  return function parar() {
    rodando = false;
    clearInterval(timer);
    diag('Vigia de contas desligado.');
  };
}

module.exports = { iniciarAutoCaptura };
