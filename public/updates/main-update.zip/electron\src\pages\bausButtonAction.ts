// ============================================================================
// Ação do botão "Página de Baús" (aba Operação). Arquivo PRÓPRIO, separado
// do navMap genérico de Operacao.tsx — regra do usuário 2026-08-09: cada
// botão/ação nova entra em arquivo dedicado.
//
// Chama window.api.bausChromium() (preload.cjs -> "chrome:baus" ->
// src/ipc/bausHandler.cjs). RECONSTRUÍDO 2026-08-10 (pedido do usuário) —
// não navega por URL nenhuma: clica em "Ofertas" (nav inferior do site) e
// depois no 2º banner da lista ("ATIVIDADES DA PLATAFORMA"), tudo via
// clique real dentro da própria página atual de cada janela selecionada.
// ============================================================================
export async function clicarPaginaDeBaus(): Promise<number> {
  const n = await (window as any).api?.bausChromium?.();
  return n || 0;
}
