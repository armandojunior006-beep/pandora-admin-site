import { useEffect, useRef, useState } from "react";
import { q, run, getSetting, setSetting, log, getApi } from "@/lib/api";
import { clicarRelatorioDeApostas } from "./reportButtonAction";
import { clicarPaginaDeBaus } from "./bausButtonAction";
import { clicarPreencherDados } from "./preencherDadosButtonAction";
import { useAuth } from "@/stores/auth";
import { useUI } from "@/stores/ui";
import type { LogEntry, Account } from "@/types";
import {
  FolderOpen, Trash2, Home, BarChart3, Archive, RotateCw,
  FileEdit, Target, Tag, MessageSquare, KeyRound,
  Settings, Ban, Zap, Search, Download, ChevronDown, Check, X, Plus,
} from "lucide-react";

const DEFAULT_BLOCKED_DOMAINS = [
  "global.esport001.com",
  "global.esport002.com",
  "esport001.com",
  "esport002.com",
  "googlesyndication.com",
  "google-analytics.com",
  "clarity.ms",
];

type Toggle = { key: string; label: string };
const TOOLS: Toggle[] = [
  { key: "op_modo_espelho", label: "[F2] Modo Espelho" },
  { key: "op_exibir_dados", label: "[F3] Exibir Dados" },
  { key: "op_extensao_ativa", label: "Extensão" },
];

const TIPOS_PIX = ["Selecione o tipo de chave", "CPF", "CNPJ", "Email", "Telefone", "Aleatória (EVP)"];

// AUTO SLOT: nome curto pra caber na grade, nome completo é o que
// efetivamente vai pro campo de busca (igual a busca manual já faz).
const AUTO_SLOT_GAMES = [
  { short: "Emperor", full: "Emperor's Favour" },
  { short: "Santa", full: "Santa's Gift Rush" },
  { short: "Halloween", full: "Mr Hallow-Jackpot!" },
  { short: "Fortune Ox", full: "Fortune Ox" },
  // WG (motor Cocos, não PG) — giro via window.__pandoraWgBet() achado no
  // código-fonte real do jogo (2026-08-07), não via cs/ml como os de cima.
  // cardIndex:1 pula o 1º resultado da busca ("Lucky Doggy", que também bate
  // com a busca por "Lucky Dog" por ser substring — ver slotHandler.cjs).
  { short: "Lucky Dog", full: "Lucky Dog", cardIndex: 1 },
  // PP (Pragmatic Play) — protocolo HTTP puro (form-urlencoded), bem mais
  // simples que WG (sem WebSocket/binário nem árvore de cena — ver
  // runPpSpinChain em realChromeManager.cjs, investigação 2026-08-07).
  { short: "Plushie Wins", full: "Plushie Wins" },
];

// Jogos WG (motor diferente da PG) — giram via chrome:wgSpinRun em vez de
// chrome:apiSpinRun, e não usam denominação cs/ml (a aposta é a que já
// estiver selecionada na tela do jogo, não a configurada aqui).
const WG_AUTO_SLOT_GAMES = new Set(["Lucky Dog"]);

// Jogos PP (Pragmatic Play) — giram via chrome:ppSpinRun. Igual WG, a
// denominação configurada aqui é forçada (validada contra a lista de
// apostas que o próprio jogo aceita), não usa cs/ml.
const PP_AUTO_SLOT_GAMES = new Set(["Plushie Wins"]);

// Denominações de aposta fixas por jogo (cs fixo x ml 1-6/1-10, ver
// investigação de API 2026-08-07) — cada jogo tem seu próprio passo.
const AUTO_SLOT_BET_STEP: Record<string, number> = {
  Emperor: 0.30,
  Santa: 0.30,
  Halloween: 0.30,
  "Fortune Ox": 0.50,
};
function betPresetsFor(short: string): string[] {
  const step = AUTO_SLOT_BET_STEP[short];
  if (!step) return [];
  const out: string[] = [];
  for (let i = 1; i <= 10; i++) {
    const v = step * i;
    if (v > 3.0001) break;
    out.push(v.toFixed(2).replace(".", ","));
  }
  return out;
}
const AUTO_SLOT_BET_PRESET_GAMES = new Set(Object.keys(AUTO_SLOT_BET_STEP));

export function Operacao() {
  const [vals, setVals] = useState<Record<string, string>>({});
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [dep1, setDep1] = useState("10");
  const [dep2, setDep2] = useState("30");
  const [tipoChave, setTipoChave] = useState(TIPOS_PIX[0]);
  const [mesmasChaves, setMesmasChaves] = useState(false);
  const [slot, setSlot] = useState("");
  const [janelas, setJanelas] = useState("");
  const janelasSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const cadastrandoPixRef = useRef(false); // trava clique duplo no "Cadastrar Chaves PIX" — recarregar a página libera um clique novo no Confirmar, então clicar de novo no meio do processo gerava cliques reais repetidos
  const [cadastrandoPix, setCadastrandoPix] = useState(false);
  const sacandoRef = useRef(false); // mesma trava contra clique duplo, agora pro "Sacar" (V2)
  const [sacando, setSacando] = useState(false);
  const logBoxRef = useRef<HTMLDivElement | null>(null);
  const editingRef = useRef<Set<string>>(new Set());
  const isEditing = (k: string) => editingRef.current.has(k);
  const editProps = (key: string) => ({
    onFocus: () => { editingRef.current.add(key); },
    onBlurCapture: () => {
      // remove after persist's onBlur handler completes
      setTimeout(() => editingRef.current.delete(key), 0);
    },
  });
  const [speed, setSpeed] = useState(1);
  // Texto da caixinha de digitação do Speed Hack — separado do `speed` pra não
  // brigar com o usuário enquanto ele digita (só commita no Enter/blur).
  const [speedText, setSpeedText] = useState("1");
  useEffect(() => { setSpeedText(String(speed)); }, [speed]);
  function commitSpeed(txt: string) {
    const v = Math.max(1, Math.min(20, parseInt(txt, 10) || 1));
    setSpeed(v); persist("op_speed", String(v)); setSpeedText(String(v));
  }
  const [blockedList, setBlockedList] = useState<string[]>([]);
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [showExtModal, setShowExtModal] = useState(false);
  const [extInfo, setExtInfo] = useState<{ name: string; active: boolean }>({ name: "", active: false });
  const [extBusy, setExtBusy] = useState(false);
  const [newDomain, setNewDomain] = useState("");
  const [accountInfo, setAccountInfo] = useState<{ login: string; senha: string; senhaSaque: string }>({ login: "", senha: "", senhaSaque: "" });
  const [autoSlotSelected, setAutoSlotSelected] = useState<Set<string>>(new Set());
  const [autoSlotBusy, setAutoSlotBusy] = useState(false);
  const [autoSlotConfigOpen, setAutoSlotConfigOpen] = useState(false);
  const [autoSlotConfig, setAutoSlotConfig] = useState<Record<string, { bet: string; giros: string }>>({});
  const { user } = useAuth();
  const { showToast } = useUI();

  async function load() {
    const keys = TOOLS.map((t) => t.key).concat([
      "op_bloquear_proxy", "op_mesmas_chaves",
      "op_auto_slot",
    ]);
    // Otimização 2026-08-18 (reportado pelo usuário: "sinto o bot pesado ao
    // abrir telas e algumas funções") — mesma causa/fix do load() de
    // Inicio.tsx: ~12 round-trips de IPC em sequência viram paralelos.
    const [
      settingsOut, dep1Val, dep2Val, tipoChaveVal, mesmasChavesVal, slotVal,
      autoSlotRaw, janelasVal, speedVal, logsRows, contaRows, senhaSaqueVal,
    ] = await Promise.all([
      Promise.all(keys.map((k) => getSetting(k, "0"))),
      getSetting("op_dep_1", "10"),
      getSetting("op_dep_2", "30"),
      getSetting("op_pix_tipo", TIPOS_PIX[0]),
      getSetting("op_mesmas_chaves", "0"),
      getSetting("op_slot", ""),
      getSetting("op_auto_slot_games", ""),
      getSetting("op_janelas", ""),
      getSetting("op_speed", "1"),
      q<LogEntry>("SELECT * FROM logs WHERE source='contas' AND message LIKE 'Conta criada%' ORDER BY id DESC LIMIT 200"),
      q<Account>("SELECT * FROM accounts WHERE status='active' ORDER BY id LIMIT 1"),
      getSetting("senha_saque", ""),
    ]);
    const out: Record<string, string> = {};
    keys.forEach((k, i) => { out[k] = settingsOut[i]; });
    setVals(out);
    // Não substitui o que o usuário digitou/apagou — só usa o fallback quando
    // a setting nunca foi salva (null). Permite valor vazio enquanto edita.
    if (!isEditing("op_dep_1")) setDep1(dep1Val);
    if (!isEditing("op_dep_2")) setDep2(dep2Val);
    setTipoChave(tipoChaveVal);
    setMesmasChaves(mesmasChavesVal === "1");
    if (!isEditing("op_slot")) setSlot(slotVal);
    try {
      const arr = autoSlotRaw ? JSON.parse(autoSlotRaw) : [];
      if (Array.isArray(arr)) setAutoSlotSelected(new Set(arr));
    } catch {}
    setJanelas(janelasVal);
    setSpeed(parseInt(speedVal, 10) || 1);
    setLogs(logsRows);
    // Conta atual (primeira ativa) + senha de saque global
    try {
      const acc = contaRows[0];
      setAccountInfo({
        login: acc?.username || "",
        senha: acc?.password || "",
        senhaSaque: senhaSaqueVal || "",
      });
    } catch {}
  }
  // Inicializa bloqueios (sementes na primeira execução) e sincroniza com o main.
  async function loadBlocked() {
    const raw = await getSetting("op_blocked_domains", "");
    let list: string[] = [];
    if (!raw) {
      list = DEFAULT_BLOCKED_DOMAINS.slice();
      await setSetting("op_blocked_domains", JSON.stringify(list));
    } else {
      try { const p = JSON.parse(raw); if (Array.isArray(p)) list = p.map((s) => String(s || "").trim()).filter(Boolean); } catch {}
      // Garante que defaults novos sejam incluídos automaticamente em listas existentes
      const lower = new Set(list.map((s) => s.toLowerCase()));
      let changed = false;
      for (const d of DEFAULT_BLOCKED_DOMAINS) {
        if (!lower.has(d.toLowerCase())) { list.push(d); changed = true; }
      }
      if (changed) await setSetting("op_blocked_domains", JSON.stringify(list));
    }
    setBlockedList(list);
    try { await (window as any).api?.setBlockedDomains?.(list); } catch {}
  }
  async function saveBlocked(list: string[]) {
    setBlockedList(list);
    await setSetting("op_blocked_domains", JSON.stringify(list));
    try { await (window as any).api?.setBlockedDomains?.(list); } catch {}
  }
  async function loadExtInfo() {
    try {
      const r = await (window as any).api?.getExtensionInfo?.();
      if (r?.ok) setExtInfo({ name: r.name || "", active: !!r.active });
    } catch {}
  }
  async function importarExtensao() {
    setExtBusy(true);
    try {
      const r = await (window as any).api?.importExtension?.();
      if (r?.canceled) return;
      if (r?.ok) {
        showToast(`Extensão importada: ${r.name}`, "success");
        doAction("Extensão", `Importada: ${r.name}`);
        await loadExtInfo();
      } else {
        showToast(r?.error || "Falha ao importar extensão", "error");
      }
    } finally {
      setExtBusy(false);
    }
  }
  async function removerExtensao() {
    if (!confirm("Remover a extensão importada?")) return;
    setExtBusy(true);
    try {
      const r = await (window as any).api?.removeExtension?.();
      if (r?.ok) {
        showToast("Extensão removida", "info");
        doAction("Extensão", "Removida");
        await loadExtInfo();
      }
    } finally {
      setExtBusy(false);
    }
  }
  useEffect(() => { load(); loadBlocked(); loadExtInfo(); const t = setInterval(load, 4000); return () => clearInterval(t); }, []);

  // Log de Operações: mantém o scroll sempre no final (log mais recente
  // embaixo, igual terminal) — sem isso ficava preso no topo a cada reload.
  useEffect(() => {
    const el = logBoxRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs]);

  // Speedhack: sincroniza o multiplicador com todas as janelas Chromium em tempo real.
  useEffect(() => {
    try { (window as any).api?.setChromiumSpeedMultiplier?.(speed); } catch {}
  }, [speed]);

  // Quando o usuário sair da página do slot, o main process avisa e
  // o multiplicador volta para o padrão (1x).
  useEffect(() => {
    const off = (window as any).api?.onChromiumSpeedReset?.(() => {
      setSpeed(1);
      try { persist("op_speed", "1"); } catch {}
    });
    return () => { try { off?.(); } catch {} };
  }, []);

  useEffect(() => {
    const off = (window as any).api?.onChromiumProxyToggled?.((data: any) => {
      setVals((v) => ({ ...v, op_bloquear_proxy: data?.blocked ? "1" : "0" }));
      const n = data?.affected ?? 0;
      const idxs = (data?.indexes || []).join(",") || "todas";
      doAction("Proxy", data?.blocked
        ? `Proxy DESATIVADA em ${n} tela(s) [${idxs}]`
        : `Proxy ATIVADA em ${n} tela(s) [${idxs}]`);
    });
    return () => { try { off?.(); } catch {} };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Mantém o overlay "Dados da Conta" das janelas Chromium sincronizado com
  // o estado atual (enabled + dados). Reaplica em qualquer mudança.
  useEffect(() => {
    try {
      (window as any).api?.setAccountOverlay?.({
        enabled: vals.op_exibir_dados === "1",
        login: accountInfo.login,
        senha: accountInfo.senha,
        senhaSaque: accountInfo.senhaSaque,
      });
    } catch {}
  }, [vals.op_exibir_dados, accountInfo.login, accountInfo.senha, accountInfo.senhaSaque, janelas]);

  // Atalhos de teclado: F2 alterna Modo Espelho, F3 alterna Exibir Dados.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "F2") { e.preventDefault(); toggle("op_modo_espelho"); }
      else if (e.key === "F3") { e.preventDefault(); toggle("op_exibir_dados"); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vals]);

  async function toggle(key: string) {
    const next = vals[key] === "1" ? "0" : "1";
    setVals((v) => ({ ...v, [key]: next }));
    await setSetting(key, next);
    if (key === "op_modo_espelho") {
      try {
        const r = await (window as any).api?.setChromiumMirrorEnabled?.(next === "1");
        if (r?.enabled) doAction("Espelho", `ATIVADO — mestre: janela #${r.master || "?"} · followers: [${(r.followers || []).join(",") || "-"}]`);
        else doAction("Espelho", "DESATIVADO");
      } catch (e: any) {
        doAction("Espelho", `Falha: ${e?.message || e}`);
      }
    }
  }
  async function persist(key: string, value: string) { await setSetting(key, value); }
  async function persistDeposit(key: "op_dep_1" | "op_dep_2", value: string) {
    const fallback = key === "op_dep_1" ? "10" : "30";
    const n = parseFloat(String(value || "").replace(",", "."));
    const safeValue = Number.isFinite(n) && n > 0 ? String(value).trim() : fallback;
    await setSetting(key, safeValue);
    if (key === "op_dep_1") setDep1(safeValue); else setDep2(safeValue);
  }

  async function handleProxyToggle() {
    // Toggle em tempo real: "1" = proxy DESATIVADA.
    const wasBlocked = vals.op_bloquear_proxy === "1";
    const nextBlocked = !wasBlocked;
    const enableProxy = !nextBlocked;
    setVals((v) => ({ ...v, op_bloquear_proxy: nextBlocked ? "1" : "0" }));
    await persist("op_bloquear_proxy", nextBlocked ? "1" : "0");
    try {
      const r = await (window as any).api?.setChromiumProxyEnabled?.(enableProxy);
      const n = r?.affected ?? 0;
      const idxs = (r?.indexes || []).join(",") || "todas";
      doAction("Proxy", enableProxy
        ? `Proxy ATIVADA em ${n} tela(s) [${idxs}]`
        : `Proxy DESATIVADA em ${n} tela(s) [${idxs}]`);
    } catch (e: any) {
      doAction("Proxy", `Falha ao alternar: ${e?.message || e}`);
    }
  }

  async function clearLogs() {
    if (!confirm("Limpar logs de operação?")) return;
    await run("DELETE FROM logs", []);
    await log("warn", "operacao", "Logs limpos", null, user?.id);
    load();
  }

  async function abrirArquivo() {
    const api = await getApi();
    if (api && typeof (api as any).openLogsFile === "function") {
      const r = await (api as any).openLogsFile({ source: "operacao" });
      if (r && r.ok) showToast(`Logs abertos: ${r.path}`, "success");
      else showToast(`Falha ao abrir logs: ${r?.error || "desconhecida"}`, "error");
      return;
    }
    const f = await api.openFile?.({});
    if (f) showToast(`Arquivo: ${f.name}`, "info");
  }

  function toggleAutoSlotGame(short: string) {
    // Seleção única (pedido do usuário 2026-08-09): marcar um jogo
    // desmarca qualquer outro que estivesse marcado — antes era um Set
    // multi-seleção, agora só um fica ativo por vez (clicar no já
    // selecionado desmarca ele, ficando nenhum selecionado).
    setAutoSlotSelected((prev) => {
      const next = prev.has(short) ? new Set<string>() : new Set([short]);
      persist("op_auto_slot_games", JSON.stringify([...next])).catch(() => {});
      return next;
    });
  }

  async function irAutoSlot() {
    const escolhidos = AUTO_SLOT_GAMES.filter((g) => autoSlotSelected.has(g.short));
    if (!escolhidos.length) { showToast("Selecione ao menos um jogo", "warning"); return; }
    // Com mais de um marcado, escolhe um aleatório a cada clique em IR —
    // mesma busca/entrada automática que já funciona no campo manual.
    const jogo = escolhidos[Math.floor(Math.random() * escolhidos.length)];
    setAutoSlotBusy(true);
    let entrou = 0;
    try {
      entrou = await (window as any).api?.searchSlotChromium?.(jogo.full, (jogo as any).cardIndex || 0);
      doAction("Auto Slot", `Buscar "${jogo.full}" → ${entrou || 0} tela(s)`);
    } catch (e: any) {
      doAction("Auto Slot", `Buscar "${jogo.full}" — erro: ${e?.message || e}`);
    } finally {
      setAutoSlotBusy(false);
    }
    if (!entrou) return;
    // Dispara o giro via API sozinho, usando bet/giros configurados em
    // "Configurar" pra esse jogo — não bloqueia o botão IR (roda em segundo
    // plano; acompanhamento fica no Log de Operações (aba Início — logs
    // "operacao*" foram movidos pra lá em 2026-08-08).
    const giros = parseInt((await getSetting(`slot_cfg_rodadas_${jogo.short}`, "350")) || "350", 10) || 350;

    if (WG_AUTO_SLOT_GAMES.has(jogo.short)) {
      // WG (Lucky Dog): motor diferente da PG (ver window.__pandoraWgBet,
      // achado em 2026-08-07). Não usa cs/ml — em vez disso, força o valor
      // configurado em "Configurar" (window.__pandoraWgBet aceita o valor
      // e checa contra _betInformations, o Map de apostas válidas desse
      // jogo específico, antes de girar).
      // Diferente da PG (que é 100% headless/API, sem nada visual rodando),
      // a WG toca a animação de verdade dos rolos a cada giro — o speedhack
      // (já corrigido/funcional pra WG, ver investigação 2026-08-07) acelera
      // essa animação. Liga em 4x automaticamente ao entrar, sem precisar
      // selecionar manualmente antes.
      try { (window as any).api?.setChromiumSpeedMultiplier?.(4); } catch {}
      const betStr = await getSetting(`slot_cfg_valor_${jogo.short}`, "0,10");
      const betAmount = parseFloat(String(betStr).replace(",", ".")) || 0.10;
      // Sem log de falha aqui de propósito (pedido do usuário 2026-08-08):
      // o retry (chrome:wgSpinRun) pode legitimamente ainda estar esperando
      // o jogo carregar quando outra tela já terminou — mostrar "não
      // iniciou" ao lado de "GIROS COMPLETOS" confundia mais do que ajudava.
      // Falha real de giro já aparece na própria linha de progresso (Log de
      // Operações) via logSystemProgress dentro de runWgSpinChain.
      (window as any).api?.wgSpinRun?.(giros, { delayMs: 900, betAmount });
      return;
    }

    if (PP_AUTO_SLOT_GAMES.has(jogo.short)) {
      // PP (Plushie Wins): protocolo HTTP puro, encadeado por index/counter
      // (ver runPpSpinChain, investigação 2026-08-07). O estado é semeado
      // sozinho quando o jogo carrega (doInit dispara sem precisar clicar em
      // nada) — o retry no processo principal já cobre esperar isso pronto.
      // Igual WG: a resposta de cada giro ainda toca a animação visual dos
      // rolos de verdade — liga o speedhack em 12x automaticamente ao entrar.
      try { (window as any).api?.setChromiumSpeedMultiplier?.(12); } catch {}
      const betStr = await getSetting(`slot_cfg_valor_${jogo.short}`, "0,20");
      const betAmount = parseFloat(String(betStr).replace(",", ".")) || 0.20;
      // Mesmo motivo do WG acima — sem log de "não iniciou" aqui, só
      // "GIROS COMPLETOS" quando dá certo (falha real já aparece na linha
      // de progresso via logSystemProgress dentro de runPpSpinChain).
      (window as any).api?.ppSpinRun?.(giros, { delayMs: 150, betAmount });
      return;
    }

    const betStr = await getSetting(`slot_cfg_valor_${jogo.short}`, "0,30");
    const opts: Record<string, number | string> = { slotLabel: jogo.short };
    const step = AUTO_SLOT_BET_STEP[jogo.short];
    if (step) {
      const betNum = parseFloat(String(betStr).replace(",", "."));
      if (betNum > 0) opts.ml = Math.max(1, Math.round(betNum / step));
    }
    // Auto Slot sempre entra a 8x nativo — não depende do seletor Speed Hack
    // (esse é usado pelos outros slots/manual). Testado: 2x e 4x confirmados
    // ok pelo usuário; 8x é o próximo degrau, com o mesmo piso de segurança.
    opts.delayMs = Math.max(40, Math.round(350 / 8));
    // Retry E paralelismo entre janelas já ficam por conta do processo
    // principal (ver chrome:apiSpinRun) — não bloqueia aqui, só reporta.
    (window as any).api?.apiSpinRun?.(giros, opts).then((results: any[]) => {
      const falhas = (results || []).filter((r) => !r?.ok);
      if (falhas.length) {
        falhas.forEach((r) => doAction("Auto Slot", `${jogo.short}: giro via API não iniciou — ${r.reason || "erro desconhecido"}`));
      }
    });
  }

  // Modal "Configurar" do AUTO SLOT — bet e giros por jogo, salvos em
  // settings (slot_cfg_valor_<short> / slot_cfg_rodadas_<short>).
  async function abrirConfigAutoSlot() {
    const entries = await Promise.all(
      AUTO_SLOT_GAMES.map(async (g) => {
        const betDefault = WG_AUTO_SLOT_GAMES.has(g.short) ? "0,10" : PP_AUTO_SLOT_GAMES.has(g.short) ? "0,20" : (betPresetsFor(g.short)[0] || "0,30");
        const bet = (await getSetting(`slot_cfg_valor_${g.short}`)) || betDefault;
        const giros = (await getSetting(`slot_cfg_rodadas_${g.short}`)) || "350";
        return [g.short, { bet, giros }] as const;
      })
    );
    setAutoSlotConfig(Object.fromEntries(entries));
    setAutoSlotConfigOpen(true);
  }

  async function salvarConfigAutoSlot() {
    // Todas em paralelo — em sequência (8 awaits, um esperando o outro)
    // dava um atraso perceptível no clique de Salvar.
    setAutoSlotConfigOpen(false);
    const tasks: Promise<any>[] = [];
    for (const g of AUTO_SLOT_GAMES) {
      const cfg = autoSlotConfig[g.short];
      if (!cfg) continue;
      tasks.push(setSetting(`slot_cfg_valor_${g.short}`, cfg.bet));
      tasks.push(setSetting(`slot_cfg_rodadas_${g.short}`, cfg.giros));
    }
    await Promise.all(tasks);
    doAction("Auto Slot", "Configuração salva");
    showToast("Configuração salva", "success");
  }

  function doAction(src: string, msg: string) {
    log("info", "operacao", `${src}: ${msg}`, null, user?.id).then(load);
    showToast(msg, "info");
  }

  return (
    <div className="h-full flex flex-col p-2 space-y-2 max-w-[1280px] mx-auto">
      <div className="grid grid-cols-12 gap-2 flex-1 min-h-0">
        {/* ===== Coluna esquerda: Log + cards ===== */}
        <div className="col-span-12 lg:col-span-9 flex flex-col h-full min-h-0 space-y-2">
          {/* ===== Log do Sistema (criação de contas) ===== */}
          <section className="card overflow-hidden">
            <div className="bg-black text-white text-xs font-semibold py-1.5 px-3 border-b border-border flex items-center justify-between">
              <span>Log do Sistema</span>
              <div className="flex gap-2">
                <button onClick={abrirArquivo}
                  className="flex items-center gap-1 px-2 py-1 rounded bg-panel2 border border-border text-white text-xs hover:bg-panel2/70">
                  <FolderOpen className="w-3 h-3" /> Abrir
                </button>
                <button onClick={clearLogs}
                  className="flex items-center gap-1 px-2 py-1 rounded bg-danger text-white text-xs hover:bg-danger/90">
                  <Trash2 className="w-3 h-3" /> Clear
                </button>
              </div>
            </div>
            <div ref={logBoxRef} className="p-1.5 font-mono text-[10px] leading-tight space-y-0.5 overflow-auto h-[140px] bg-panel">
              {logs.length === 0 ? (
                <p className="text-muted">Sem registros.</p>
              ) : [...logs].reverse().map((l: any) => {
                let ctx: any = {};
                try { ctx = l.context_json ? JSON.parse(l.context_json) : {}; } catch {}
                const login = ctx.login || "-";
                const senha = ctx.senha || "-";
                // Senha de saque é global (setting senha_saque, carregada em
                // accountInfo.senhaSaque). Dispositivo vem do context do log.
                const senhaSaque = accountInfo.senhaSaque || "-";
                const dispositivo = ctx.dispositivo || "-";
                return (
                  <div key={l.id} className="flex flex-nowrap gap-x-2.5 whitespace-nowrap">
                    <span className="text-white"><span className="text-muted">Login:</span> {login}</span>
                    <span className="text-white"><span className="text-muted">Senha:</span> {senha}</span>
                    <span className="text-white"><span className="text-muted">Saque:</span> {senhaSaque}</span>
                    <span className="text-white"><span className="text-muted">Disp.:</span> {dispositivo}</span>
                  </div>
                );
              })}
            </div>
          </section>

          {/* ===== Cards inferiores movidos pra cá pra subirem sob o log =====
              flex-1 pra ocupar o espaço sobrando embaixo (janela ficou mais
              alta) — cada card estica (h-full) e centraliza os botões
              verticalmente, em vez de deixar vão em branco embaixo. */}
          <div className="grid grid-cols-12 gap-3 flex-1 min-h-0">
            {/* ===== Navegação ===== */}
            <section className="card overflow-hidden col-span-12 md:col-span-3 h-full flex flex-col">
              <div className="bg-black text-white text-xs font-semibold text-center py-1.5 border-b border-border">Navegação</div>
              <div className="p-2 space-y-1.5 flex-1 flex flex-col justify-center">
                {[
                  { i: Home, l: "Página Inicial" },
                  { i: BarChart3, l: "Relatório de Apostas" },
                  { i: Archive, l: "Página de Baús" },
                  { i: RotateCw, l: "Atualizar Página" },
                ].map((b) => (
                  <button key={b.l} onClick={async () => {
                      // "Relatório de Apostas" tem arquivo próprio (regra do
                      // usuário 2026-08-09) — ver reportButtonAction.ts +
                      // src/ipc/reportHandler.cjs. Fluxo (3ª tentativa,
                      // definido pelo usuário): loadURL pra /home/mine, depois
                      // clique real em "Meus Registros" — sem mais nenhuma
                      // navegação por URL. Não entra no navMap genérico abaixo.
                      if (b.l === "Relatório de Apostas") {
                        try {
                          const results = await clicarRelatorioDeApostas();
                          // Pedido do usuário 2026-08-19: mostrar a quantidade de
                          // "Apostas Válidas" de cada tela no Log do Sistema —
                          // principal utilidade em Operação Oculta, onde não dá
                          // pra ver a janela.
                          const partes = results.map((r) =>
                            r.ok && r.apostasValidas != null ? `Tela ${r.telaNum}: ${r.apostasValidas} válidas` : `Tela ${r.telaNum}: não lido`
                          );
                          doAction("Navegação", `Relatório de Apostas → ${results.length} tela(s)${partes.length ? " — " + partes.join(" | ") : ""}`);
                        } catch (e: any) {
                          doAction("Navegação", `Relatório de Apostas — erro: ${e?.message || e}`);
                        }
                        return;
                      }
                      // "Página de Baús" também tem arquivo próprio (regra do
                      // usuário 2026-08-09) — ver bausButtonAction.ts +
                      // src/ipc/bausHandler.cjs. Só navegação, nada mais.
                      if (b.l === "Página de Baús") {
                        try {
                          const n = await clicarPaginaDeBaus();
                          doAction("Navegação", `Página de Baús → ${n} tela(s)`);
                        } catch (e: any) {
                          doAction("Navegação", `Página de Baús — erro: ${e?.message || e}`);
                        }
                        return;
                      }
                      const navMap: Record<string, string> = {
                        "Página Inicial": "/",
                      };
                      if (b.l === "Atualizar Página") {
                        try {
                          const n = await (window as any).api?.reloadChromium?.();
                          doAction("Navegação", `Atualizar Página → ${n || 0} tela(s)`);
                        } catch (e: any) {
                          doAction("Navegação", `Atualizar Página — erro: ${e?.message || e}`);
                        }
                        return;
                      }
                      const path = navMap[b.l];
                      if (path) {
                        try {
                          const n = await (window as any).api?.navigateChromium?.(path);
                          doAction("Navegação", `${b.l} → ${n || 0} tela(s)`);
                        } catch (e: any) {
                          doAction("Navegação", `${b.l} — erro: ${e?.message || e}`);
                        }
                        return;
                      }
                      doAction("Navegação", b.l);
                    }}
                    className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md bg-panel2 border border-border text-white text-[12px] font-medium whitespace-nowrap leading-none hover:bg-panel2/70">
                    <b.i className="w-3.5 h-3.5" /> {b.l}
                  </button>
                ))}
              </div>
            </section>

            {/* ===== Bônus ===== */}
            <section className="card overflow-hidden col-span-12 md:col-span-3 h-full flex flex-col">
              <div className="bg-black text-white text-xs font-semibold text-center py-1.5 border-b border-border">Bônus</div>
              <div className="p-2 space-y-1.5 flex-1 flex flex-col justify-center">
                {[
                  { i: FileEdit, l: "Preencher Dados" },
                  { i: Target, l: "Coletar Missões" },
                  { i: Tag, l: "Página Promoções" },
                  { i: MessageSquare, l: "Cadastrar SMS" },
                ].map((b) => (
                  <button key={b.l} onClick={async () => {
                      // "Preencher Dados" tem arquivo próprio (regra do
                      // usuário 2026-08-09) — ver preencherDadosButtonAction.ts
                      // + src/ipc/preencherDadosHandler.cjs. Navega pra
                      // /home/setting e preenche todos os campos com dados
                      // aleatórios, incluindo data de nascimento.
                      if (b.l === "Preencher Dados") {
                        try {
                          const n = await clicarPreencherDados();
                          doAction("Bônus", `Preencher Dados → ${n} tela(s)`);
                        } catch (e: any) {
                          doAction("Bônus", `Preencher Dados — erro: ${e?.message || e}`);
                        }
                        return;
                      }
                      doAction("Bônus", b.l);
                    }}
                    className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md bg-panel2 border border-border text-white text-[12px] font-medium whitespace-nowrap leading-none hover:bg-panel2/70">
                    <b.i className="w-3.5 h-3.5" /> {b.l}
                  </button>
                ))}
              </div>
            </section>

            {/* ===== Depósito ===== */}
            <section className="card overflow-hidden col-span-12 md:col-span-3 h-full flex flex-col">
              <div className="bg-black text-white text-xs font-semibold text-center py-1.5 border-b border-border">Depósito</div>
              <div className="p-2 space-y-1.5 flex-1 flex flex-col justify-center overflow-y-auto">
                <div className="grid grid-cols-2 gap-2">
                  <input className="input text-center" value={dep1} {...editProps("op_dep_1")} onChange={(e) => setDep1(e.target.value)} onBlur={() => persist("op_dep_1", dep1)} />
                  <input className="input text-center" value={dep2} {...editProps("op_dep_2")} onChange={(e) => setDep2(e.target.value)} onBlur={() => persist("op_dep_2", dep2)} />

                </div>
                <button
                  onClick={async () => {
                    try {
                      const toNum = (value: string, fallback: number) => {
                        const n = parseFloat(String(value || "").replace(",", "."));
                        return Number.isFinite(n) && n > 0 ? n : fallback;
                      };
                      const minN = toNum(dep1, toNum(await getSetting("op_dep_1", "10"), 10));
                      const maxN = toNum(dep2, toNum(await getSetting("op_dep_2", "30"), 30));
                      const lo = Math.min(minN, maxN);
                      const hi = Math.max(minN, maxN);
                      await persist("op_dep_1", String(minN));
                      await persist("op_dep_2", String(maxN));
                      // BUG real 2026-08-09 (reportado pelo usuário: faixa
                      // 10-30 colocou 13 em TODAS as telas) — o valor era
                      // sorteado uma vez aqui e reaplicado igual em toda
                      // janela selecionada. Agora manda a FAIXA
                      // (min/max), e o próprio depositHandler.cjs sorteia
                      // um valor novo pra CADA janela dentro do loop.
                      const n = await (window as any).api?.depositarChromium?.({ min: lo, max: hi });
                      doAction("Depósito", `Depositar faixa ${lo}-${hi} (valor sorteado por tela) → ${n || 0} tela(s)`);
                    } catch (e: any) {
                      doAction("Depósito", `Depositar — erro: ${e?.message || e}`);
                    }
                  }}
                  className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md bg-success text-black font-bold text-[12px] whitespace-nowrap leading-none hover:bg-success/90">
                  <Download className="w-3.5 h-3.5" /> Depositar
                </button>
              </div>
            </section>

            {/* ===== Chaves PIX ===== */}
            <section className="card overflow-hidden col-span-12 md:col-span-3 h-full flex flex-col">
              <div className="bg-black text-white text-xs font-semibold text-center py-1.5 border-b border-border">Chaves PIX</div>
              <div className="p-2 space-y-1.5 flex-1 flex flex-col justify-center overflow-y-auto">
                <div className="relative">
                  <select
                    value={tipoChave}
                    onChange={(e) => { setTipoChave(e.target.value); persist("op_pix_tipo", e.target.value); }}
                    className="input w-full appearance-none pr-8"
                  >
                    {TIPOS_PIX.map((t) => <option key={t}>{t}</option>)}
                  </select>
                  <ChevronDown className="w-4 h-4 absolute right-2 top-1/2 -translate-y-1/2 text-muted pointer-events-none" />
                </div>
                <button onClick={async () => {
                    // Trava contra clique duplo — recarregar/navegar no meio do
                    // processo libera novas tentativas, então clicar de novo
                    // enquanto a anterior ainda roda gerava ações duplicadas.
                    if (cadastrandoPixRef.current) return;
                    cadastrandoPixRef.current = true;
                    setCadastrandoPix(true);
                    setTimeout(() => { cadastrandoPixRef.current = false; setCadastrandoPix(false); }, 35000);
                    // Pedido do usuário 2026-08-09: clicar em Cadastrar Chaves PIX
                    // não mostrava nada no log enquanto rodava, só o resultado final.
                    doAction("PIX", "Cadastrando chave Pix...");
                    const res = await (window as any).api?.cadastrarPixV2?.();
                    doAction("PIX", `Concluído — ${res?.sucesso || 0}/${res?.windows || 0} tela(s)`);
                  }}
                  disabled={cadastrandoPix}
                  className="w-full py-1.5 px-2 rounded-md bg-warning text-black font-bold text-[12px] whitespace-nowrap leading-none hover:bg-warning/90 disabled:opacity-50 disabled:cursor-not-allowed">
                  Cadastrar Chaves PIX
                </button>
                <label className="flex items-center gap-2 text-sm text-white cursor-pointer">
                  <input type="checkbox" className="accent-success"
                    checked={mesmasChaves}
                    onChange={(e) => { setMesmasChaves(e.target.checked); persist("op_mesmas_chaves", e.target.checked ? "1" : "0"); }} />
                  Mesmas chaves para links diferentes
                </label>
                <button
                  disabled={sacando}
                  onClick={async () => {
                    // Mesma trava contra clique duplo do "Cadastrar Chaves PIX".
                    if (sacandoRef.current) return;
                    sacandoRef.current = true;
                    setSacando(true);
                    setTimeout(() => { sacandoRef.current = false; setSacando(false); }, 35000);
                    // Pedido do usuário 2026-08-09: clicar em Sacar não mostrava
                    // nada no log enquanto rodava, só o resultado final.
                    doAction("Saque", "Sacando...");
                    const res = await (window as any).api?.sacarV2?.();
                    const sucesso = res?.sucesso || 0;
                    const total = res?.windows || 0;
                    // Pedido do usuário 2026-08-09: "Concluído — 0/1" sem
                    // motivo não dava pra saber o que deu errado — agora
                    // mostra o motivo de cada tela que falhou, se veio algum.
                    const falhas: Array<{ tela: number | string; motivo: string }> = res?.falhas || [];
                    if (sucesso === total && total > 0) {
                      doAction("Saque", `Concluído — ${sucesso}/${total} tela(s)`);
                    } else if (falhas.length) {
                      const detalhe = falhas.map((f) => `Tela ${f.tela}: ${f.motivo}`).join(" | ");
                      doAction("Saque", `Concluído — ${sucesso}/${total} tela(s) — ${detalhe}`);
                    } else {
                      doAction("Saque", `Concluído — ${sucesso}/${total} tela(s) — motivo não identificado, confira manualmente`);
                    }
                  }}
                  className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md bg-success text-black font-bold text-[12px] whitespace-nowrap leading-none hover:bg-success/90 disabled:opacity-50 disabled:cursor-not-allowed">
                  <KeyRound className="w-3.5 h-3.5" /> Sacar
                </button>
              </div>
            </section>
          </div>
        </div>


        {/* ===== Ferramentas ===== */}
        <section className="card overflow-hidden col-span-12 lg:col-span-3 self-start">
          <div className="bg-black text-white text-xs font-semibold text-center py-1.5 border-b border-border">Ferramentas</div>
          <div className="p-2 space-y-1.5">
            {TOOLS.map((t) => {
              const on = vals[t.key] === "1";
              return (
                <label key={t.key} className="flex items-center gap-2 text-sm text-white cursor-pointer select-none">
                  <span onClick={() => toggle(t.key)}
                    className={`w-4 h-4 rounded-sm border flex items-center justify-center ${on ? "border-success bg-success" : "border-neutral-600 bg-panel2"}`}>
                    {on && <Check className="w-3 h-3 text-black" />}
                  </span>
                  <span>{t.label}</span>
                </label>
              );
            })}
            <button onClick={() => setShowExtModal(true)}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md bg-panel2 border border-border text-white text-[12px] font-medium whitespace-nowrap leading-none hover:bg-panel2/70">
              <Settings className="w-3.5 h-3.5" /> Extensão
            </button>
            <button onClick={() => setShowBlockModal(true)}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md bg-panel2 border border-border text-white text-[12px] font-medium whitespace-nowrap leading-none hover:bg-panel2/70">
              <Ban className="w-3.5 h-3.5" /> Bloqueios
            </button>
            <div className="pt-1">
              <div className="text-center text-xs text-success flex items-center justify-center gap-1 mb-1">
                <Zap className="w-3 h-3" /> Speed Hack <Zap className="w-3 h-3" />
              </div>
              {/* Slider deitado (1x–20x) — o cliente escolhe qualquer valor,
                  não só os degraus fixos de antes. Mesmo setSpeed/persist, então
                  a funcionalidade do speedhack não muda, só a UI do seletor. */}
              <div className="flex items-center gap-2 px-1">
                <input
                  type="range"
                  min={1}
                  max={20}
                  step={1}
                  value={speed}
                  onChange={(e) => { const v = parseInt(e.target.value, 10) || 1; setSpeed(v); persist("op_speed", String(v)); }}
                  className="flex-1 accent-success cursor-pointer"
                />
                <div className="flex items-center gap-0.5">
                  <input
                    type="number"
                    min={1}
                    max={20}
                    value={speedText}
                    onChange={(e) => setSpeedText(e.target.value)}
                    onBlur={(e) => commitSpeed(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { commitSpeed((e.target as HTMLInputElement).value); (e.target as HTMLInputElement).blur(); } }}
                    className="w-9 bg-panel border border-success/50 rounded text-center text-xs font-bold text-success tabular-nums outline-none focus:border-success [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none"
                    aria-label="Multiplicador do Speed Hack"
                  />
                  <span className="text-xs font-bold text-success">x</span>
                </div>
              </div>
            </div>

            {/* ===== AUTO SLOT ===== */}
            <div className="pt-2 border-t border-border mt-2">
              <div className="flex items-center justify-between gap-1 mb-2">
                <span className="text-xs font-semibold text-white whitespace-nowrap shrink-0">AUTO SLOT</span>
                <button onClick={handleProxyToggle}
                  className={`w-[112px] shrink-0 py-1 rounded-md border-2 text-[10px] font-bold whitespace-nowrap leading-none text-center ${
                    vals.op_bloquear_proxy === "1"
                      ? "bg-success border-success text-black"
                      : "bg-transparent border-danger text-danger hover:bg-danger/10"
                  }`}>
                  {vals.op_bloquear_proxy === "1" ? "[F8] Ativar Proxy" : "[F8] Desativar Proxy"}
                </button>
              </div>
              <div className="grid grid-cols-2 gap-1 mb-1.5">
                {AUTO_SLOT_GAMES.map((g) => {
                  const on = autoSlotSelected.has(g.short);
                  return (
                    <label key={g.short} onClick={() => toggleAutoSlotGame(g.short)}
                      className="flex items-center gap-1.5 text-[11px] text-white cursor-pointer select-none bg-panel2 border border-border rounded-md px-1.5 py-1 hover:bg-panel2/70">
                      <span className={`w-3.5 h-3.5 shrink-0 rounded-sm border flex items-center justify-center ${on ? "border-success bg-success" : "border-neutral-600 bg-panel"}`}>
                        {on && <Check className="w-2.5 h-2.5 text-black" />}
                      </span>
                      <span className="truncate" title={g.full}>{g.short}</span>
                    </label>
                  );
                })}
              </div>
              <button onClick={abrirConfigAutoSlot}
                className="w-full flex items-center justify-center gap-1.5 py-1 px-2 mb-1 rounded-md bg-panel2 border border-border text-white font-bold text-[12px] whitespace-nowrap leading-none hover:bg-panel2/70">
                <Settings className="w-3.5 h-3.5" /> Configurar
              </button>
              <button onClick={irAutoSlot} disabled={autoSlotBusy}
                className="w-full flex items-center justify-center gap-1.5 py-1 px-2 rounded-md bg-success text-black font-bold text-[12px] whitespace-nowrap leading-none hover:bg-success/90 disabled:opacity-50">
                <Search className="w-3.5 h-3.5" /> {autoSlotBusy ? "Buscando..." : "IR"}
              </button>
            </div>
          </div>
        </section>
      </div>




      {/* ===== Rodapé: Slot / Buscar / Janelas ===== */}
      <section className="grid grid-cols-12 gap-2">
        <div className="col-span-12 md:col-span-7 card p-1.5">
          <label className="text-[10px] uppercase tracking-wider text-success block text-center mb-0.5">Slot para Buscar:</label>
          <div className="flex gap-1.5">
            <input
              className="input flex-1 !py-1 !text-xs"
              value={slot}
              onChange={(e) => setSlot(e.target.value)}
              onBlur={() => persist("op_slot", slot)}
              {...editProps("op_slot")}
              placeholder="mayan destiny"
            />
            <button onClick={async () => {
              const name = (slot || "").trim();
              if (!name) { doAction("Slot", "Buscar: nome vazio"); return; }
              try {
                // "Lucky Dog" também acha "Lucky Doggy" (é substring) — pega o
                // segundo resultado nesse caso específico, igual o Auto Slot fazia.
                const cardIndex = /^lucky dog$/i.test(name) ? 1 : 0;
                const n = await (window as any).api?.searchSlotChromium?.(name, cardIndex);
                doAction("Slot", `Buscar "${name}" → ${n || 0} tela(s)`);
              } catch (e: any) {
                doAction("Slot", `Buscar "${name}" → erro: ${e?.message || e}`);
              }
            }}
              className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-panel2 border border-border text-white text-xs font-semibold hover:bg-panel2/70">
              <Search className="w-3.5 h-3.5" /> BUSCAR
            </button>
          </div>
        </div>
        <div className="col-span-12 md:col-span-5 card p-1.5">
          <label className="text-[10px] uppercase tracking-wider text-success block text-center mb-0.5">Janelas Para Controlar:</label>
          <input
            className="input w-full text-center !py-1 !text-xs"
            value={janelas}
            onChange={(e) => {
              const v = e.target.value;
              setJanelas(v);
              // Atualização em tempo real do overlay verde — não bloqueia
              // a digitação e roda em paralelo a qualquer operação do bot.
              try {
                (window as any).api?.refreshChromiumSelection?.(v);
              } catch {}
              // Persiste com debounce curto pra não martelar o DB.
              if (janelasSaveTimer.current) clearTimeout(janelasSaveTimer.current);
              janelasSaveTimer.current = setTimeout(() => {
                persist("op_janelas", v).catch(() => {});
              }, 250);
            }}
            onBlur={async () => {
              await persist("op_janelas", janelas);
              try {
                const n = await (window as any).api?.refreshChromiumSelection?.(janelas);
                if (typeof n === "number") doAction("Janelas", `Controlando ${n} tela(s) (filtro: "${janelas || "todas"}")`);
              } catch {}
            }}
            placeholder="Ex: 1, 2-4 ou 1,3"
          />
        </div>
      </section>

      {/* Overlay "Dados da Conta" é renderizado NAS janelas do Chromium (camada externa),
          não dentro da UI do app. Veja applyAccountOverlay no main.cjs. */}


      {/* ===== Modal: Bloqueios ===== */}
      {showBlockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={() => setShowBlockModal(false)}>
          <div className="bg-panel border border-border rounded-md w-[420px] max-w-[92vw] shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="bg-black text-white text-xs font-semibold py-2 px-3 border-b border-border flex items-center justify-between">
              <span className="flex items-center gap-1.5"><Ban className="w-3.5 h-3.5" /> Bloqueios</span>
              <button onClick={() => setShowBlockModal(false)} className="text-muted hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            <div className="p-3 space-y-2">
              <p className="text-[11px] text-muted">Domínios bloqueados em todas as janelas controladas. Toda requisição para eles é cancelada (não consome proxy).</p>
              <form
                className="flex gap-1.5"
                onSubmit={(e) => {
                  e.preventDefault();
                  const d = newDomain.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
                  if (!d) return;
                  if (blockedList.includes(d)) { showToast("Domínio já cadastrado", "warning"); return; }
                  saveBlocked([...blockedList, d]);
                  setNewDomain("");
                }}
              >
                <input
                  className="input flex-1 !py-1 !text-xs"
                  value={newDomain}
                  onChange={(e) => setNewDomain(e.target.value)}
                  placeholder="exemplo.com ou sub.exemplo.com"
                />
                <button type="submit"
                  className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-success text-black text-xs font-semibold hover:bg-success/90">
                  <Plus className="w-3.5 h-3.5" /> Adicionar
                </button>
              </form>
              <div className="border border-border rounded-md max-h-[260px] overflow-y-auto divide-y divide-border">
                {blockedList.length === 0 ? (
                  <div className="text-muted text-xs text-center py-4">Nenhum domínio bloqueado.</div>
                ) : blockedList.map((d) => (
                  <div key={d} className="flex items-center justify-between px-2 py-1.5 text-xs text-white">
                    <span className="font-mono truncate">{d}</span>
                    <button
                      onClick={() => saveBlocked(blockedList.filter((x) => x !== d))}
                      className="ml-2 inline-flex items-center gap-1 px-2 py-0.5 rounded bg-danger/80 text-white text-[11px] hover:bg-danger"
                      title="Remover"
                    ><Trash2 className="w-3 h-3" /></button>
                  </div>
                ))}
              </div>
              <div className="flex justify-end pt-1">
                <button
                  onClick={() => { saveBlocked(DEFAULT_BLOCKED_DOMAINS.slice()); showToast("Lista restaurada", "info"); }}
                  className="text-[11px] text-muted hover:text-white underline"
                >Restaurar padrão</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Modal: Extensão ===== */}
      {showExtModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={() => setShowExtModal(false)}>
          <div className="bg-panel border border-border rounded-md w-[420px] max-w-[92vw] shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="bg-black text-white text-xs font-semibold py-2 px-3 border-b border-border flex items-center justify-between">
              <span className="flex items-center gap-1.5"><Settings className="w-3.5 h-3.5" /> Extensão</span>
              <button onClick={() => setShowExtModal(false)} className="text-muted hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            <div className="p-3 space-y-3">
              <p className="text-[11px] text-muted">
                Importe uma extensão do Chrome (.zip). Enquanto o checkbox "Extensão" em
                Ferramentas estiver marcado, ela é carregada automaticamente em
                TODAS as janelas Chromium abertas (open, multi-links e por conta).
              </p>
              <div className="border border-border rounded-md p-3 text-center">
                {extInfo.name ? (
                  <>
                    <p className="text-sm text-white font-semibold truncate">{extInfo.name}</p>
                    <p className="text-[11px] text-muted mt-0.5">
                      {extInfo.active ? "Ativa — em uso nas próximas janelas" : "Importada, mas desativada (marque o checkbox Extensão)"}
                    </p>
                  </>
                ) : (
                  <p className="text-xs text-muted">Nenhuma extensão importada.</p>
                )}
              </div>
              <div className="flex gap-1.5">
                <button
                  onClick={importarExtensao}
                  disabled={extBusy}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-2 py-1.5 rounded-md bg-success text-black text-xs font-semibold hover:bg-success/90 disabled:opacity-50">
                  <Download className="w-3.5 h-3.5" /> {extBusy ? "Importando..." : "Importar .zip"}
                </button>
                {extInfo.name && (
                  <button
                    onClick={removerExtensao}
                    disabled={extBusy}
                    className="inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-md bg-danger/80 text-white text-xs font-semibold hover:bg-danger disabled:opacity-50"
                    title="Remover extensão importada"
                  ><Trash2 className="w-3.5 h-3.5" /></button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {autoSlotConfigOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={() => setAutoSlotConfigOpen(false)}>
          <div className="bg-panel border border-border rounded-lg p-5 w-[360px] shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white">Configurar AUTO SLOT</h3>
              <button onClick={() => setAutoSlotConfigOpen(false)} className="text-muted hover:text-white"><X size={16} /></button>
            </div>
            <div className="space-y-3">
              {AUTO_SLOT_GAMES.map((g) => {
                const cfg = autoSlotConfig[g.short] || { bet: "0,30", giros: "350" };
                const setCfg = (patch: Partial<{ bet: string; giros: string }>) =>
                  setAutoSlotConfig((prev) => ({ ...prev, [g.short]: { ...cfg, ...patch } }));
                const hasPresets = AUTO_SLOT_BET_PRESET_GAMES.has(g.short);
                return (
                  <div key={g.short} className="flex items-center gap-2">
                    <span className="text-sm text-white w-[84px] truncate" title={g.full}>{g.short}</span>
                    {hasPresets ? (
                      <select value={cfg.bet} onChange={(e) => setCfg({ bet: e.target.value })}
                        className="w-20 bg-panel2 border border-border rounded px-1 py-1 text-sm text-white">
                        {betPresetsFor(g.short).map((v) => <option key={v} value={v}>{v}</option>)}
                      </select>
                    ) : (
                      <input value={cfg.bet} onChange={(e) => setCfg({ bet: e.target.value })}
                        placeholder="Bet"
                        className="w-20 bg-panel2 border border-border rounded px-2 py-1 text-sm text-white" />
                    )}
                    <input value={cfg.giros} onChange={(e) => setCfg({ giros: e.target.value })}
                      placeholder="Giros"
                      className="w-16 bg-panel2 border border-border rounded px-2 py-1 text-sm text-white" />
                  </div>
                );
              })}
            </div>
            <div className="flex justify-end pt-4">
              <button onClick={salvarConfigAutoSlot}
                className="px-4 py-1.5 rounded bg-success text-white text-sm font-bold hover:opacity-90"
              >Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

