// ============================================================================
// Stealth flags (anti-detecção bot) + otimização CPU/RAM + modo GPU/CPU
// ----------------------------------------------------------------------------
// Este módulo tem EFEITO COLATERAL ao ser importado: registra as flags de
// linha de comando do Chromium. Precisa ser exigido (require) o mais cedo
// possível no processo principal, ANTES de `app.whenReady()` — exatamente
// como no main.cjs original, onde essas chamadas ficavam soltas no topo do
// arquivo.
// ============================================================================
const { app } = require("electron");
const path = require("path");
const fs = require("fs");

app.commandLine.appendSwitch("disable-blink-features", "AutomationControlled");
// (disable-features é definido em bloco único mais abaixo para não sobrescrever)
app.commandLine.appendSwitch("disable-infobars");
app.commandLine.appendSwitch("no-default-browser-check");
app.commandLine.appendSwitch("no-first-run");
app.commandLine.appendSwitch("disable-automation");
// Remove a flag padrão de automação que o Electron expõe ao Chromium.
try { app.commandLine.removeSwitch && app.commandLine.removeSwitch("enable-automation"); } catch {}
// Anti-fingerprint extra (Geetest/geeGuard): esconde flags nativas de automação.
app.commandLine.appendSwitch("excludeSwitches", "enable-automation");
app.commandLine.appendSwitch("no-sandbox");
// Libera escrita do SQLite/IndexedDB usado pelo geeGuard nas partições Chromium.
app.commandLine.appendSwitch("disable-gpu-sandbox");

// ============ Otimização CPU/RAM (sem alterar funções/abas) ============
// Desliga serviços de fundo do Chromium que NÃO afetam a navegação nem
// as automações do bot, mas consomem CPU/RAM constantemente.
// Mantém intactos: timers, throttling de aba, captcha, proxy, webview.
app.commandLine.appendSwitch("disable-features", [
  "IsolateOrigins",
  "site-per-process",
  "Translate",
  "MediaRouter",
  "DialMediaRouteProvider",
  "OptimizationHints",
  "OptimizationHintsFetching",
  "InterestFeedContentSuggestions",
  "CalculateNativeWinOcclusion",
  "HardwareMediaKeyHandling",
  "GlobalMediaControls",
  "ImprovedCookieControls",
  // "LazyFrameLoading" removido — desligar força iframes a carregar tudo de uma vez e atrasa o load.
  "AutofillServerCommunication",
  "CertificateTransparencyComponentUpdater",
  // "AcceptCHFrame" removido — desligar quebra Client Hints em TLS e força renegociação em alguns sites.
  "PrivacySandboxSettings4",
  "FedCm",
  "Reporting",
  "CrashReporting",
].join(","));
app.commandLine.appendSwitch("disable-component-update");
app.commandLine.appendSwitch("disable-domain-reliability");
app.commandLine.appendSwitch("disable-sync");
app.commandLine.appendSwitch("disable-breakpad");
app.commandLine.appendSwitch("disable-crash-reporter");
app.commandLine.appendSwitch("disable-client-side-phishing-detection");
// disable-background-networking removido — bloqueia DNS prefetch/preconnect e atrasa a primeira navegação.
app.commandLine.appendSwitch("disable-default-apps");
app.commandLine.appendSwitch("disable-print-preview");
app.commandLine.appendSwitch("disable-speech-api");
app.commandLine.appendSwitch("disable-hang-monitor");
app.commandLine.appendSwitch("disable-prompt-on-repost");
app.commandLine.appendSwitch("metrics-recording-only");
app.commandLine.appendSwitch("no-pings");
app.commandLine.appendSwitch("no-default-browser-check");
app.commandLine.appendSwitch("password-store", "basic");
app.commandLine.appendSwitch("use-mock-keychain");
// Libera memória de imagens/cache mais agressivamente quando o SO sinaliza pressão.
app.commandLine.appendSwitch("enable-features", "MemoryPressureBasedSourceBufferGC");
// Limita o heap V8 por renderer (cada janela). 512MB é suficiente para os
// sites operados pelo bot e evita picos de RAM em grids de 6-10 janelas.
app.commandLine.appendSwitch("js-flags", "--max-old-space-size=512 --expose-gc");

// ============ GPU/CPU mode (lido de um sidecar para rodar ANTES de app.ready) ============
try {
  const _gpuFile = path.join(app.getPath("userData"), "gpu_mode.txt");
  const _mode = fs.existsSync(_gpuFile) ? (fs.readFileSync(_gpuFile, "utf8") || "").trim().toUpperCase() : "GPU";
  if (_mode === "CPU") {
    app.disableHardwareAcceleration();
    app.commandLine.appendSwitch("disable-gpu");
    app.commandLine.appendSwitch("disable-gpu-compositing");
    app.commandLine.appendSwitch("disable-software-rasterizer");
    console.log("[gpu] modo CPU ativo (hardware acceleration desabilitado)");
  } else {
    app.commandLine.appendSwitch("ignore-gpu-blocklist");
    app.commandLine.appendSwitch("enable-gpu-rasterization");
    app.commandLine.appendSwitch("enable-zero-copy");
    app.commandLine.appendSwitch("enable-accelerated-video-decode");
    console.log("[gpu] modo GPU ativo (aceleração total)");
  }
} catch (e) { console.log("[gpu] falha ao aplicar modo:", e?.message); }

module.exports = {};
