// ============================================================================
// SMS24HR — API de compra de número/consulta de código SMS (documentação
// colada pelo usuário 2026-08-11 no chat, protocolo estilo sms-activate/
// smshub: handler_api?action=...). Usado por "Criar Chaves PIX"
// (mercadoPagoWindow.cjs) pra conseguir um número de celular via API pra
// cadastrar como chave PIX no Mercado Pago, e depois pegar o código SMS de
// verificação que o próprio Mercado Pago manda pra esse número.
//
// IMPORTANTE: o serviço "cq" (chamado "Mercado" na lista de serviços do
// provedor) foi assumido como o correto pra Mercado Pago — é o único item
// da lista que bate com o nome. Se o 1º teste real vier "WRONG_SERVICE",
// avisa que eu ajusto esse código pro certo.
// ============================================================================
const BASE = "https://api.sms24h.org/stubs/handler_api";
const SERVICO_MERCADO_PAGO = "cq";
const PAIS_BRASIL = "73";

function log(msg) {
  try {
    const { queueDiagLine } = require("../../auto-register.cjs");
    queueDiagLine(`[${new Date().toISOString()}] [SMS24H] ${msg}\r\n`);
  } catch {}
}

async function chamarApi(params) {
  const url = `${BASE}?${new URLSearchParams(params).toString()}`;
  const res = await fetch(url);
  const texto = (await res.text()).trim();
  log(`GET action=${params.action} -> ${texto}`);
  return texto;
}

// Formata o número que a API devolve (geralmente com código do país, ex.:
// "5511987654321") pro formato que o campo do Mercado Pago espera
// ("(11) 98765-4321", ver placeholder real confirmado pelo usuário:
// "Exemplo: (00) 12345-6789").
function formatarNumeroBR(numeroCompleto) {
  let d = String(numeroCompleto || "").replace(/\D/g, "");
  if (d.startsWith("55") && d.length > 11) d = d.slice(2);
  const ddd = d.slice(0, 2);
  const resto = d.slice(2);
  if (resto.length === 9) return `(${ddd}) ${resto.slice(0, 5)}-${resto.slice(5)}`;
  if (resto.length === 8) return `(${ddd}) ${resto.slice(0, 4)}-${resto.slice(4)}`;
  return `(${ddd}) ${resto}`;
}

async function comprarNumero({ apiKey, operador = "any", ddd }) {
  if (!apiKey) return { ok: false, error: "API Key do Spider SMS não configurada (aba Mercado Pago → engrenagem do provedor)" };
  const params = { api_key: apiKey, action: "getNumber", service: SERVICO_MERCADO_PAGO, country: PAIS_BRASIL, operator: operador };
  if (ddd) params.ddd = ddd;
  const resp = await chamarApi(params);
  if (resp.startsWith("ACCESS_NUMBER:")) {
    const [, id, numero] = resp.split(":");
    return { ok: true, id, numero, numeroFormatado: formatarNumeroBR(numero) };
  }
  const erros = {
    NO_NUMBERS: "Não há números disponíveis agora — tente de novo em alguns minutos.",
    NO_BALANCE: "Sem saldo na conta do Spider SMS.",
    WRONG_SERVICE: "Código de serviço \"cq\" (Mercado) não foi aceito pelo provedor — avisa que eu ajusto.",
    BAD_KEY: "API Key do Spider SMS inválida.",
  };
  return { ok: false, error: erros[resp] || `Falha ao comprar número: ${resp}` };
}

async function consultarCodigo({ apiKey, id }) {
  const resp = await chamarApi({ api_key: apiKey, action: "getStatus", id });
  if (resp.startsWith("STATUS_OK:")) return { ok: true, pronto: true, codigo: resp.slice("STATUS_OK:".length) };
  if (resp === "STATUS_WAIT_CODE") return { ok: true, pronto: false };
  if (resp.startsWith("STATUS_WAIT_RETRY:")) return { ok: true, pronto: false, ultimoCodigo: resp.split(":")[1] };
  if (resp === "STATUS_CANCEL") return { ok: false, error: "Ativação cancelada no provedor" };
  return { ok: false, error: `Falha ao consultar código: ${resp}` };
}

// Poll até chegar o código ou estourar o tempo — o Mercado Pago manda o SMS
// de verdade pro número comprado, e o sms24h.org repassa isso pra essa
// consulta de status.
async function esperarCodigo({ apiKey, id, timeoutMs = 90000, intervaloMs = 3000, deveCancelar }) {
  const inicio = Date.now();
  while (Date.now() - inicio < timeoutMs) {
    // Pedido do usuário 2026-08-11 ("quero parar a hora que eu quiser") —
    // checa a cada volta do polling (não só antes/depois) se o usuário
    // cancelou, já que essa espera pode durar até 90s sozinha.
    if (deveCancelar && deveCancelar()) return { ok: false, error: "Cancelado pelo usuário", cancelado: true };
    const r = await consultarCodigo({ apiKey, id });
    if (!r.ok) return r;
    if (r.pronto) return r;
    await new Promise((res) => setTimeout(res, intervaloMs));
  }
  return { ok: false, error: "Tempo esgotado esperando o código SMS chegar (90s)" };
}

// status 6 = "Confirme o código SMS e conclua a ativação" (documentação do
// provedor) — chamado depois que o Mercado Pago aceitar o código de verdade.
async function marcarConcluido({ apiKey, id }) {
  return chamarApi({ api_key: apiKey, action: "setStatus", status: "6", id });
}

// status 8 = cancelar ativação — usado se algo falhar no meio do fluxo, pra
// não pagar por um número que não foi usado.
async function cancelarNumero({ apiKey, id }) {
  try { return await chamarApi({ api_key: apiKey, action: "setStatus", status: "8", id }); } catch { return null; }
}

module.exports = { comprarNumero, consultarCodigo, esperarCodigo, marcarConcluido, cancelarNumero, formatarNumeroBR, SERVICO_MERCADO_PAGO };
