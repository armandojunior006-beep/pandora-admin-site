// ============================================================================
// IPC: sessão "Mercado Pago" (aba Operação) — arquivo próprio, separado do
// resto (regra do usuário 2026-08-09: cada botão/ação nova entra em arquivo
// dedicado — ver [[pandorabot-one-file-per-feature]]). Automação real fica em
// src/window/mercadoPagoWindow.cjs; aqui é só o fio IPC.
// ============================================================================
const { abrirConta, fecharConta, copiarChaves, deletarChaves, contaEstaAberta, salvarLogin, criarChavePix, cancelarCriarChavePix } = require("../window/mercadoPagoWindow.cjs");

function registerMercadoPagoHandler(ipcMain) {
  ipcMain.handle("mp:abrirConta", async (_e, conta) => abrirConta(conta || {}));
  ipcMain.handle("mp:fecharConta", async (_e, conta) => fecharConta(conta || {}));
  ipcMain.handle("mp:copiarChaves", async (_e, conta) => copiarChaves(conta || {}));
  ipcMain.handle("mp:deletarChaves", async (_e, conta) => deletarChaves(conta || {}));
  ipcMain.handle("mp:contaEstaAberta", async (_e, conta) => contaEstaAberta(conta || {}));
  ipcMain.handle("mp:salvarLogin", async (_e, conta) => salvarLogin(conta || {}));
  ipcMain.handle("mp:criarChavePix", async (_e, conta) => criarChavePix(conta || {}));
  ipcMain.handle("mp:cancelarCriarChavePix", async (_e, conta) => cancelarCriarChavePix(conta || {}));
}

module.exports = { registerMercadoPagoHandler };
