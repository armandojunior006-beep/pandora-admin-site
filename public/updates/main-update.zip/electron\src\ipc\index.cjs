// ============================================================================
// Ponto único de registro de todos os canais IPC (ipcMain.handle) do app.
// Cada arquivo deste diretório cobre um grupo de canais relacionados —
// mantém o main.cjs enxuto e facilita achar/alterar um fluxo específico.
// ============================================================================
const { ipcMain } = require("electron");

const { registerDbHandlers } = require("./dbHandlers.cjs");
const { registerDialogHandlers } = require("./dialogHandlers.cjs");
const { registerWorkerHandlers } = require("./workerHandlers.cjs");
const { registerPandoraHandlers } = require("./pandoraHandlers.cjs");
const { registerContasHandlers } = require("./contasHandlers.cjs");
const { registerChromeHandlers } = require("./chromeHandlers.cjs");
const { registerNavigateHandler } = require("./navigateHandler.cjs");
const { registerReportHandler } = require("./reportHandler.cjs");
const { registerBausHandler } = require("./bausHandler.cjs");
const { registerPreencherDadosHandler } = require("./preencherDadosHandler.cjs");
const { registerSaquesHandlers } = require("./saquesHandler.cjs");
const { registerSlotHandler } = require("./slotHandler.cjs");
const { registerDepositHandler } = require("./depositHandler.cjs");
const { registerPixHandler } = require("./pixHandler.cjs");
const { registerPixFlowV2Handler } = require("./pixFlowV2.cjs");
const { registerSaqueFlowV2Handler } = require("./saqueFlowV2.cjs");
const { registerAppHandlers } = require("./appHandlers.cjs");
const { registerLogsHandlers } = require("./logsHandlers.cjs");
const { registerMultibotHandlers } = require("./multibotHandlers.cjs");
const { registerAdminHandlers } = require("./adminHandlers.cjs");
const { registerExtensionHandlers } = require("./extensionHandlers.cjs");
const { registerMercadoPagoHandler } = require("./mercadoPagoHandler.cjs");

function registerIpc() {
  registerDbHandlers(ipcMain);
  registerDialogHandlers(ipcMain);
  registerWorkerHandlers(ipcMain);
  registerPandoraHandlers(ipcMain);
  registerContasHandlers(ipcMain);
  registerChromeHandlers(ipcMain);
  registerNavigateHandler(ipcMain);
  registerReportHandler(ipcMain);
  registerBausHandler(ipcMain);
  registerPreencherDadosHandler(ipcMain);
  registerSaquesHandlers(ipcMain);
  registerSlotHandler(ipcMain);
  registerDepositHandler(ipcMain);
  registerPixHandler(ipcMain);
  registerPixFlowV2Handler(ipcMain);
  registerSaqueFlowV2Handler(ipcMain);
  registerAppHandlers(ipcMain);
  registerLogsHandlers(ipcMain);
  registerMultibotHandlers(ipcMain);
  registerAdminHandlers(ipcMain);
  registerExtensionHandlers(ipcMain);
  registerMercadoPagoHandler(ipcMain);
}

module.exports = { registerIpc };
