// ============================================================================
// Numeração nativa das janelas de Chrome real (Win32/koffi).
//
// A numeração (#1, #2...) vai no TÍTULO da janela (visível na barra de
// tarefas/Alt+Tab). Como o Chrome reescreve o título sozinho a cada
// navegação (segue o <title> da página), reaplicamos o prefixo "[#N]" em
// loop leve pra ele não sumir.
//
// O ÍCONE customizado (WM_SETICON com nosso logo) foi removido a pedido do
// usuário (2026-08-06) — cada chamada envolvia carregar um .ico via Win32 e
// mandar mensagem pro HWND; a pedido, voltou a usar o ícone padrão do
// Chrome (mais leve, uma chamada nativa a menos por janela).
// ============================================================================
let _fns = null;
let _koffiFailed = false;
function loadNative() {
  if (_fns) return _fns;
  if (_koffiFailed) return null;
  try {
    const koffi = require("koffi");
    const user32 = koffi.load("user32.dll");
    const RECT = koffi.struct("RECT", { left: "int32_t", top: "int32_t", right: "int32_t", bottom: "int32_t" });
    _fns = {
      koffi,
      RECT,
      GetWindowThreadProcessId: user32.func("uint32_t __stdcall GetWindowThreadProcessId(void* hwnd, _Out_ uint32_t *pid)"),
      IsWindowVisible: user32.func("bool __stdcall IsWindowVisible(void* hwnd)"),
      GetClassNameW: user32.func("int __stdcall GetClassNameW(void* hwnd, _Out_ uint16_t *out, int max)"),
      GetWindowTextW: user32.func("int __stdcall GetWindowTextW(void* hwnd, _Out_ uint16_t *out, int max)"),
      SetWindowTextW: user32.func("bool __stdcall SetWindowTextW(void* hwnd, const uint16_t *text)"),
      EnumWindows: user32.func("bool __stdcall EnumWindows(void* lpEnumFunc, void* lParam)"),
      GetWindowRect: user32.func("bool __stdcall GetWindowRect(void* hwnd, _Out_ RECT *rect)"),
    };
    return _fns;
  } catch (e) {
    _koffiFailed = true;
    console.warn("[nativeIcon] koffi indisponível — numeração nativa desativada:", e?.message);
    return null;
  }
}

// EnumWindows pra achar o HWND top-level de verdade do processo (a maior
// janela visível de classe Chrome_WidgetWin_1 — descarta popups/bubbles
// menores tipo "Traduzir esta página?", que têm a mesma classe).
function findMainHwndForPid(fns, pid) {
  let best = null, bestArea = 0;
  const protoName = "PandoraEnumIdent" + Date.now() + Math.random().toString(36).slice(2);
  const cb = fns.koffi.register((hwnd) => {
    try {
      const pidBuf = fns.koffi.alloc("uint32_t", 1);
      fns.GetWindowThreadProcessId(hwnd, pidBuf);
      const wpid = fns.koffi.decode(pidBuf, "uint32_t");
      if (wpid === pid && fns.IsWindowVisible(hwnd)) {
        const nameBuf = Buffer.alloc(512);
        const len = fns.GetClassNameW(hwnd, nameBuf, 256);
        const cls = nameBuf.toString("utf16le", 0, len * 2);
        if (cls === "Chrome_WidgetWin_1") {
          const rect = fns.koffi.alloc("RECT", 1);
          fns.GetWindowRect(hwnd, rect);
          const r = fns.koffi.decode(rect, fns.RECT);
          const area = Math.max(0, r.right - r.left) * Math.max(0, r.bottom - r.top);
          if (area > bestArea) { bestArea = area; best = hwnd; }
        }
      }
    } catch {}
    return true;
  }, fns.koffi.pointer(fns.koffi.proto(`bool __stdcall ${protoName}(void *hwnd, void *lParam)`)));
  try { fns.EnumWindows(cb, null); } catch {}
  fns.koffi.unregister(cb);
  return best;
}

const TAG_RE = /^\[#\d+\]\s*/;
function reapplyTitle(fns, hwnd, order) {
  try {
    const buf = Buffer.alloc(1024);
    const len = fns.GetWindowTextW(hwnd, buf, 512);
    const current = buf.toString("utf16le", 0, len * 2);
    const clean = current.replace(TAG_RE, "");
    const wanted = `[#${order}] ${clean}`;
    if (current !== wanted) {
      fns.SetWindowTextW(hwnd, Buffer.from(wanted + "\0", "utf16le"));
    }
  } catch {}
}

// Chamado uma vez por janela de Chrome real, logo depois de aberta. Liga um
// loop leve que mantém o "[#N]" no título (Chrome reescreve o título
// sozinho a cada navegação/troca de página). Retorna uma função pra parar o
// loop (chamar no "closed" da janela).
async function applyNativeIdentity(pid, order) {
  const fns = loadNative();
  if (!fns) return () => {};
  let hwnd = null;
  for (let i = 0; i < 15 && !hwnd; i++) {
    hwnd = findMainHwndForPid(fns, pid);
    if (!hwnd) await new Promise((r) => setTimeout(r, 200));
  }
  if (!hwnd) return () => {};

  reapplyTitle(fns, hwnd, order);
  const timer = setInterval(() => reapplyTitle(fns, hwnd, order), 2500);
  return () => clearInterval(timer);
}

module.exports = { applyNativeIdentity };
