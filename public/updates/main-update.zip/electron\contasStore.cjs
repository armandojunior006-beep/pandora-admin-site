// ============================================================
// contasStore.js  (VERSÃO LOCAL — sem Supabase, sem nuvem)
// Salva as contas num arquivo no disco, criptografando senha e
// senha de saque com o safeStorage do Electron (chaveiro do SO).
// Mantém um backup TXT sincronizado automaticamente a cada
// mudança (criar/remover/remover em massa).
//
// Roda no PROCESSO MAIN do Electron.
// ============================================================

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { app, safeStorage } = require('electron');

// Arquivo principal (criptografado) + arquivo de backup TXT.
const ARQUIVO = path.join(app.getPath('userData'), 'contas.json');
const BACKUP_DIR = path.join(app.getPath('userData'), 'accounts-backup');
const BACKUP_TXT = path.join(BACKUP_DIR, 'contas-backup.txt');

// ---- leitura/escrita do arquivo ----------------------------
function lerArquivo() {
  try {
    if (!fs.existsSync(ARQUIVO)) return [];
    const raw = fs.readFileSync(ARQUIVO, 'utf8').trim();
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('[STORE] erro ao ler', ARQUIVO, e);
    return [];
  }
}

function escreverArquivo(lista) {
  fs.writeFileSync(ARQUIVO, JSON.stringify(lista, null, 2), 'utf8');
  // Mantém o backup TXT sempre em dia (operação rápida e idempotente).
  try { regenerarBackupTxt(lista); } catch (e) { console.warn('[STORE] backup txt falhou:', e?.message); }
}

// ---- criptografia (safeStorage = chaveiro do SO) -----------
function cifrar(texto) {
  if (texto == null || texto === '') return null;
  if (safeStorage.isEncryptionAvailable()) {
    return 'enc:' + safeStorage.encryptString(String(texto)).toString('base64');
  }
  console.warn('[STORE] safeStorage indisponível — usando codificação simples.');
  return 'b64:' + Buffer.from(String(texto), 'utf8').toString('base64');
}

function decifrar(payload) {
  if (!payload) return null;
  if (payload.startsWith('enc:')) {
    return safeStorage.decryptString(Buffer.from(payload.slice(4), 'base64'));
  }
  if (payload.startsWith('b64:')) {
    return Buffer.from(payload.slice(4), 'base64').toString('utf8');
  }
  return payload;
}

// BUG CRÍTICO real 2026-08-10 (reportado pelo usuário: aba Contas ficou
// vazia — mesmo com as contas de verdade intactas no contas.json — E o
// botão Backup deu erro, os dois ao mesmo tempo) — decifrar() usa
// safeStorage.decryptString (chaveiro do SO via DPAPI no Windows), que
// PODE lançar exceção pra uma entrada específica (ex.: chave do SO mudou,
// entrada foi criptografada num contexto diferente, corrompida etc.).
// listarContas()/regenerarBackupTxt() chamavam decifrar() dentro de um
// .map() sem nenhum try/catch por item — UMA ÚNICA entrada com problema
// de descriptografia derrubava a lista INTEIRA (e o backup inteiro), não
// só aquela entrada. Daí os dois sintomas juntos: Contas vazia (a exceção
// subia até o catch do load() no React, que zera a lista toda) e Backup
// com erro (mesma exceção, handler diferente). Agora decifrar() nunca
// lança — se falhar pra uma entrada específica, essa entrada mostra um
// aviso no lugar da senha, mas todas as OUTRAS continuam aparecendo
// normalmente.
function decifrarSeguro(payload) {
  try { return decifrar(payload); }
  catch (e) {
    console.warn('[contasStore] falha ao descriptografar uma entrada:', e?.message);
    return '[erro ao descriptografar]';
  }
}

// ---- backup TXT (sempre sincronizado) ----------------------
function regenerarBackupTxt(listaRaw) {
  try { fs.mkdirSync(BACKUP_DIR, { recursive: true }); } catch {}
  const lista = (listaRaw || lerArquivo()).map((r) => ({
    ...r,
    senha: decifrarSeguro(r.senha),
    senha_saque: decifrarSeguro(r.senha_saque),
  }));
  const sep = '='.repeat(72);
  const lines = [];
  lines.push('Pandora BOT - Backup de Contas');
  lines.push(`Gerado em: ${new Date().toLocaleString()}`);
  try { lines.push(`Versao: ${app.getVersion()}`); } catch {}
  lines.push(`Total de contas: ${lista.length}`);
  lines.push(sep);
  lines.push('');
  for (const c of lista) {
    lines.push(`ID: ${c.id}`);
    lines.push(`   Data/Hora     : ${c.data_hora || '-'}`);
    lines.push(`   Casa (URL)    : ${c.casa_url || '-'}`);
    lines.push(`   Login         : ${c.login || '-'}`);
    lines.push(`   Senha         : ${c.senha || '-'}`);
    lines.push(`   Senha de saque: ${c.senha_saque || '-'}`);
    lines.push(`   ID da conta   : ${c.conta_id || '-'}`);
    lines.push('');
  }
  fs.writeFileSync(BACKUP_TXT, lines.join('\r\n'), 'utf8');
  return BACKUP_TXT;
}

// ---- API ---------------------------------------------------
async function salvarConta({ casa, login, senha, senhaSaque, id, dataHora }) {
  const lista = lerArquivo();
  const registro = {
    id:          crypto.randomUUID(),
    data_hora:   dataHora || new Date().toISOString(),
    casa_url:    casa || null,
    login:       login || null,
    senha:       cifrar(senha),
    senha_saque: cifrar(senhaSaque),
    conta_id:    id || null,
    proxy:       null, // proxy próprio da conta (host:port:user:pass), definido depois na aba Contas
  };
  lista.unshift(registro);
  escreverArquivo(lista);
  return registro;
}

async function listarContas() {
  return lerArquivo().map((r) => ({
    ...r,
    senha:       decifrarSeguro(r.senha),
    senha_saque: decifrarSeguro(r.senha_saque),
    proxy:       r.proxy ? decifrarSeguro(r.proxy) : "",
  }));
}

// Define/limpa o proxy próprio de UMA conta (host:port:user:pass). String
// vazia remove o proxy da conta (volta a usar o pool global, se houver).
// Cifrado como a senha (contém a senha do proxy).
async function definirProxy(id, proxyStr) {
  const lista = lerArquivo();
  const idx = lista.findIndex((r) => String(r.id) === String(id));
  if (idx === -1) return false;
  const clean = String(proxyStr || "").trim();
  lista[idx] = { ...lista[idx], proxy: clean ? cifrar(clean) : null };
  escreverArquivo(lista);
  return true;
}

// Atualiza o saldo de uma conta já salva, buscando pelo login (case-
// insensitive — é como as janelas identificam a conta, não tem outro jeito
// de casar). Atualiza a entrada mais recente com esse login (lista já vem
// com a mais nova primeiro, via unshift em salvarConta) — se por acaso
// existir mais de uma linha com o mesmo login (conta recriada), só a mais
// recente importa pra saldo em tempo real.
async function atualizarSaldo(login, saldo) {
  if (!login || saldo == null || !isFinite(saldo)) return false;
  const lista = lerArquivo();
  const alvo = String(login).trim().toLowerCase();
  const idx = lista.findIndex((r) => String(r.login || "").trim().toLowerCase() === alvo);
  if (idx === -1) return false;
  lista[idx] = { ...lista[idx], saldo: Number(saldo), saldo_at: new Date().toISOString() };
  escreverArquivo(lista);
  return true;
}

async function removerConta(id) {
  escreverArquivo(lerArquivo().filter((r) => r.id !== id));
}

async function removerVarios(ids) {
  const set = new Set((Array.isArray(ids) ? ids : []).map(String));
  if (set.size === 0) return 0;
  const antes = lerArquivo();
  const depois = antes.filter((r) => !set.has(String(r.id)));
  escreverArquivo(depois);
  return antes.length - depois.length;
}

async function removerTodos() {
  const n = lerArquivo().length;
  escreverArquivo([]);
  return n;
}

module.exports = {
  salvarConta, listarContas, removerConta,
  removerVarios, removerTodos,
  atualizarSaldo, definirProxy,
  regenerarBackupTxt,
  ARQUIVO, BACKUP_TXT,
};
