// ============================================================================
// IPC: chrome:clickSaques / chrome:preencherSaque — automação da tela de
// Saques: localizar+clicar o ícone "Saques" na Home, e clicar "Tudo" +
// preencher a senha de segurança na tela /home/withdraw?active=20.
// ============================================================================
const fs = require("fs");
const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");
const { getWithdrawPin, buildSecurityPinScript, sendSecurityPinNative } = require("../security/securityPin.cjs");
const { getDiagFilePath } = require("../../auto-register.cjs");

function registerSaquesHandlers(ipcMain) {
  ipcMain.handle("chrome:clickSaques", async () => {
    // Localiza o item "Saques" e retorna coordenadas + href (se houver).
    const locateScript = `(() => {
      try {
        const isVisible = (el) => {
          if (!el || !el.isConnected) return false;
          const r = el.getBoundingClientRect();
          if (r.width < 4 || r.height < 4) return false;
          const s = getComputedStyle(el);
          if (s.display === 'none' || s.visibility === 'hidden' || parseFloat(s.opacity || '1') < 0.05) return false;
          return true;
        };
        let img = null;
        const imgs = Array.from(document.querySelectorAll('img'));
        for (const el of imgs) {
          const src = el.getAttribute('src') || el.getAttribute('data-src') || '';
          if (/style_7_icon_mid_tx/i.test(src) && isVisible(el)) { img = el; break; }
        }
        if (!img) {
          const byId = document.querySelector('img[data-id="56decf6e-38c6-43d4-9708-d9a98a7a2814"]');
          if (byId && isVisible(byId)) img = byId;
        }
        if (!img) {
          const nodes = Array.from(document.querySelectorAll('a, button, div, li, span, p'));
          const hit = nodes.find((n) => isVisible(n) && /^\\s*Saques?\\s*$/i.test((n.textContent || '').trim()));
          if (hit) img = hit;
        }
        if (!img) {
          // procura por SVG href com 'withdraw' ou 'saque' nos sprites
          const uses = Array.from(document.querySelectorAll('svg use'));
          const hit = uses.find((u) => {
            const h = u.getAttribute('xlink:href') || u.getAttribute('href') || '';
            return /withdraw|saque/i.test(h) && isVisible(u.closest('svg') || u);
          });
          if (hit) img = hit.closest('svg') || hit;
        }
        if (!img) return { ok: false, reason: 'not_found' };
        try { img.scrollIntoView({ block: 'center', inline: 'center' }); } catch (e) {}
        // tenta achar âncora <a href> mais próxima — site é SPA com router
        let anchor = img.closest('a[href]');
        let href = anchor ? anchor.getAttribute('href') : '';
        // Mantém o ponto do clique no ícone/texto encontrado. Antes o loop podia
        // subir até um container grande e clicar no centro errado da página.
        let target = img;
        let p = img.parentElement;
        for (let i = 0; i < 8 && p; i++, p = p.parentElement) {
          const cls = String(p.className || '');
          const pr = p.getBoundingClientRect();
          const clickable = p.tagName === 'A' || p.tagName === 'BUTTON' || p.getAttribute('role') === 'button' || /item|nav|menu|cell|btn|link|tab|entry|profile|withdraw|saque/i.test(cls);
          // Só troca o alvo se for realmente um item pequeno; evita body/cards grandes.
          if (clickable && pr.width > 4 && pr.height > 4 && pr.width <= 260 && pr.height <= 120) { target = p; break; }
        }
        const ir = img.getBoundingClientRect();
        const tr = target.getBoundingClientRect();
        const r = (tr.width <= 260 && tr.height <= 120) ? tr : ir;
        const tag = (target.tagName || '') + ' ' + String(target.className || '').slice(0,80);
        return { ok: true, x: Math.round(ir.left + ir.width / 2), y: Math.round(ir.top + ir.height / 2), tx: Math.round(r.left + r.width / 2), ty: Math.round(r.top + r.height / 2), w: Math.round(ir.width), h: Math.round(ir.height), href: href || '', tag };
      } catch (e) { return { ok: false, reason: String(e && e.message || e) }; }
    })();`;

    // Script que executa clique completo no DOM (pointer + touch + mouse + .click)
    // a partir das coordenadas. Roda dentro da própria página.
    const buildDomClickScript = (x, y) => `(() => {
      try {
        const cx = ${x}, cy = ${y};
        const el = document.elementFromPoint(cx, cy);
        if (!el) return { ok: false, reason: 'no_element_at_point' };
        const opts = { bubbles: true, cancelable: true, composed: true, clientX: cx, clientY: cy, view: window };
        const fire = (node, type, Ctor, extra) => {
          try { node.dispatchEvent(new Ctor(type, Object.assign({}, opts, extra || {}))); } catch (e) {}
        };
        // foco
        try { el.focus && el.focus(); } catch (e) {}
        // pointer/touch (mobile)
        const touch = (typeof Touch !== 'undefined') ? new Touch({ identifier: 1, target: el, clientX: cx, clientY: cy, pageX: cx, pageY: cy }) : null;
        const tOpts = { bubbles: true, cancelable: true, composed: true, touches: touch ? [touch] : [], targetTouches: touch ? [touch] : [], changedTouches: touch ? [touch] : [] };
        try { el.dispatchEvent(new PointerEvent('pointerdown', Object.assign({}, opts, { pointerType: 'touch', isPrimary: true, button: 0 }))); } catch (e) {}
        try { if (typeof TouchEvent !== 'undefined') el.dispatchEvent(new TouchEvent('touchstart', tOpts)); } catch (e) {}
        try { el.dispatchEvent(new PointerEvent('pointerup', Object.assign({}, opts, { pointerType: 'touch', isPrimary: true, button: 0 }))); } catch (e) {}
        try { if (typeof TouchEvent !== 'undefined') el.dispatchEvent(new TouchEvent('touchend', tOpts)); } catch (e) {}
        // mouse
        fire(el, 'mousedown', MouseEvent, { button: 0 });
        fire(el, 'mouseup', MouseEvent, { button: 0 });
        fire(el, 'click', MouseEvent, { button: 0 });
        // fallback .click() no elemento e ancestrais até <a> ou [role=button]
        try { el.click && el.click(); } catch (e) {}
        let p = el;
        for (let i = 0; i < 6 && p; i++) {
          if (p.tagName === 'A' || (p.getAttribute && p.getAttribute('role') === 'button')) { try { p.click(); } catch (e) {} break; }
          p = p.parentElement;
        }
        return { ok: true, tag: (el.tagName || '') + ' ' + String(el.className || '').slice(0,80) };
      } catch (e) { return { ok: false, reason: String(e && e.message || e) }; }
    })();`;

    const sendNativeClick = (wc, x, y) => {
      try {
        wc.sendInputEvent({ type: 'mouseMove', x, y });
        wc.sendInputEvent({ type: 'mouseDown', x, y, button: 'left', clickCount: 1 });
        wc.sendInputEvent({ type: 'mouseUp',   x, y, button: 'left', clickCount: 1 });
        return true;
      } catch { return false; }
    };

    let n = 0;
    for (const win of getSelectedChromeWins()) {
      try {
        if (!win || win.isDestroyed()) continue;
        const wc = win.webContents;
        let coords = null;
        const deadline = Date.now() + 15000;
        while (Date.now() < deadline) {
          try {
            const r = await wc.executeJavaScript(locateScript, true);
            if (r && r.ok) { coords = r; break; }
          } catch {}
          await new Promise((res) => setTimeout(res, 400));
        }
        if (!coords) {
          try { console.log('[clickSaques] não localizou ícone na janela'); } catch {}
          try { fs.appendFileSync(getDiagFilePath(), `[${new Date().toISOString()}] [clickSaques] não localizou ícone na janela\r\n`, 'utf8'); } catch {}
          continue;
        }
        try { console.log('[clickSaques] alvo', coords); } catch {}
        try { fs.appendFileSync(getDiagFilePath(), `[${new Date().toISOString()}] [clickSaques] alvo ${JSON.stringify(coords)}\r\n`, 'utf8'); } catch {}
        // 1) Se temos href de âncora SPA, navega via location.href (mais confiável que clicar)
        if (coords.href && /^(\/|https?:|#)/.test(coords.href)) {
          try {
            await wc.executeJavaScript(`(() => { try { const h = ${JSON.stringify(coords.href)}; if (h.startsWith('http')) location.href = h; else location.href = new URL(h, location.origin).toString(); return true; } catch(e) { return false; } })();`, true);
            n++;
            continue;
          } catch {}
        }
        // 2) Clique DOM completo (pointer/touch/mouse/.click)
        try { await wc.executeJavaScript(buildDomClickScript(coords.x, coords.y), true); } catch {}
        // 3) Clique nativo via sendInputEvent (reforço)
        sendNativeClick(wc, coords.x, coords.y);
        if (coords.tx && coords.ty && (coords.tx !== coords.x || coords.ty !== coords.y)) {
          setTimeout(() => sendNativeClick(wc, coords.tx, coords.ty), 180);
        }
        n++;
      } catch {}
    }
    return n;
  });
  ipcMain.handle("chrome:preencherSaque", () => {
    const pathPart = "/home/withdraw?active=20";
    const clickTudoScript = `(() => {
      if (window.__pandoraSaqueTudoBusy) return;
      window.__pandoraSaqueTudoBusy = true;
      const log = (m) => console.log('__PANDORA_SAQUE__', m);
      const sleep = (ms) => new Promise(r => setTimeout(r, ms));
      const visible = (el) => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        const s = getComputedStyle(el);
        return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
      };
      const realClick = (el) => {
        if (!el) return;
        try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
        const r = el.getBoundingClientRect();
        const x = r.left + Math.max(2, r.width / 2), y = r.top + Math.max(2, r.height / 2);
        try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles:true, cancelable:true, pointerType:'mouse', clientX:x, clientY:y, button:0, buttons:1 })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0 })); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles:true, cancelable:true, pointerType:'mouse', clientX:x, clientY:y, button:0, buttons:0 })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseup', { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0 })); } catch {}
        try { el.dispatchEvent(new MouseEvent('click', { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0 })); } catch {}
        try { el.click(); } catch {}
      };
      const findTudo = () => {
        // Match por classe (CSS modules: _allAmount_*) ou por texto exato "Tudo"
        const byClass = Array.from(document.querySelectorAll('span[class*="allAmount"], [class*="allAmount"]')).filter(visible);
        if (byClass.length) return byClass[0];
        const spans = Array.from(document.querySelectorAll('span, a, button, [role="button"]')).filter(visible);
        return spans.find(el => ((el.innerText || el.textContent || '') + '').trim() === 'Tudo');
      };
      (async () => {
        const dl = Date.now() + 30000;
        let el = null;
        while (Date.now() < dl) {
          el = findTudo();
          if (el) break;
          await sleep(200);
        }
        if (!el) { log('Tudo não encontrado'); window.__pandoraSaqueTudoBusy = false; return; }
        realClick(el);
        // Reforça clique caso o primeiro não tenha registrado
        await sleep(250);
        try { realClick(el); } catch {}
        log('clicou Tudo');
        window.__pandoraSaqueTudoBusy = false;
      })();
    })();`;

    let n = 0;
    for (const win of getSelectedChromeWins()) {
      try {
        if (!win || win.isDestroyed() || win._proxyReady === false) continue;
        // Mesmo bug de navigateHandler.cjs (ver comentário lá, 2026-08-09):
        // origin de uma página de erro do Chrome (chrome-error://...) vira a
        // STRING "null" (não vazia, não lança) — passava batido pelo
        // `if (!origin)` e nunca cai no fallback hardcoded abaixo.
        let origin = "";
        try {
          const o = new URL(win.webContents.getURL()).origin;
          if (/^https?:\/\//i.test(o)) origin = o;
        } catch {}
        if (!origin) {
          try {
            const o = new URL(win._targetUrl || "").origin;
            if (/^https?:\/\//i.test(o)) origin = o;
          } catch {}
        }
        if (!origin) origin = "https://91-handsetpg.com";
        const wc = win.webContents;
        const senhaSaque = getWithdrawPin(win);
        const runTudoThenPin = () => {
          try { wc.executeJavaScript(clickTudoScript, true).catch(() => {}); } catch {}
          // Pequeno atraso para o valor ser aplicado antes da senha
          setTimeout(() => {
            try { wc.executeJavaScript(buildSecurityPinScript(senhaSaque), true).catch(() => {}); } catch {}
            // Ver comentário equivalente em securityPin.cjs/scheduleSecurityPinFill:
            // sendSecurityPinNative digitava "no vazio" em Chrome real (sendInputEvent
            // de teclado era no-op) e virou reforço real que agora conflita com o
            // buildSecurityPinScript acima — restrito ao Electron antigo.
            if (!win._realChrome) {
              setTimeout(() => sendSecurityPinNative(wc, senhaSaque), 600);
              setTimeout(() => sendSecurityPinNative(wc, senhaSaque), 1500);
            }
          }, 900);
        };
        wc.once("did-finish-load", () => {
          setTimeout(runTudoThenPin, 400);
          setTimeout(runTudoThenPin, 3000);
          setTimeout(runTudoThenPin, 9000);
          setTimeout(runTudoThenPin, 18000);
        });
        win.loadURL(origin + pathPart);
        n++;
      } catch {}
    }
    return n;
  });
}

module.exports = { registerSaquesHandlers };
