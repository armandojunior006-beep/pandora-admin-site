import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { useUI } from "./stores/ui";
import "./styles.css";

// Rede de segurança global (bug crítico 2026-08-21): vários handlers async
// (salvar proxy, salvar chave PIX...) deixavam a exceção escapar sem catch —
// pro usuário era "clico e nada acontece". Qualquer erro não tratado agora
// vira toast visível. Handlers com catch próprio continuam mostrando a
// mensagem específica deles; isto só pega o que escaparia em silêncio.
window.addEventListener("unhandledrejection", (e) => {
  const msg = (e.reason && (e.reason.message || String(e.reason))) || "Erro inesperado";
  useUI.getState().showToast(`Erro: ${msg}`, "error");
});
window.addEventListener("error", (e) => {
  if (e.message) useUI.getState().showToast(`Erro: ${e.message}`, "error");
});

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
