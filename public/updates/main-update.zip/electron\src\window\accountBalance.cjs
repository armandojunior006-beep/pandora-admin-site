// ============================================================================
// Rastreio de saldo por conta (aba Contas — coluna "Saldo") — 2026-08-08,
// pedido do usuário. Passa por TODA janela Chromium aberta periodicamente,
// lê o "Saldo" mostrado na tela (mesma heurística de texto já usada em
// qrCapture.cjs/saqueFlowV2.cjs — "Saldo" seguido de um valor em R$ com
// centavos) e salva no registro da conta em contas.json (contasStore.cjs),
// pelo login — é como identificamos qual conta é qual janela (win._regCred/
// win._contaAutoLogin, mesmo campo que o overlay "Exibir Dados" usa).
// ============================================================================
const state = require("../state.cjs");

// BUG real 2026-08-09 (reportado pelo usuário: cadastrou conta + depositou
// R$30, mas o Saldo na aba Contas nunca atualizou) — o regex só aceitava até
// 6 caracteres NÃO-numéricos entre a palavra "saldo" e o valor. Qualquer
// rótulo um pouco mais longo do que isso ("Saldo disponível: R$ 30,00",
// "Saldo da conta:", "Meu saldo —") já estourava o limite e o regex nunca
// batia — silenciosamente, sem erro nenhum (scanOne só faz `if (saldo ==
// null) return`). Ampliado bastante (até 40 caracteres, aceita quebra de
// linha) + adicionado "carteira"/"wallet" como rótulos alternativos (sites
// desse nicho variam a palavra usada). Mantém best-effort: se não achar,
// segue sem travar nada (mesmo comportamento de antes).
const BALANCE_SCRIPT = `(() => {
  try {
    const txt = ((document.body && document.body.innerText) || '');
    const RX = /(?:saldo|carteira|wallet)[\\s\\S]{0,40}?(?:R\\$\\s*)?(\\d{1,3}(?:\\.\\d{3})*,\\d{2})/i;
    const m = txt.match(RX);
    if (!m) return null;
    const n = parseFloat(m[1].replace(/\\./g, '').replace(',', '.'));
    return isFinite(n) ? n : null;
  } catch (e) { return null; }
})();`;

function getWinLogin(win) {
  try {
    const regCred = win._regCred || {};
    const perWin = win._contaAutoLogin || {};
    return String(regCred.login || perWin.login || "").trim();
  } catch { return ""; }
}

async function scanOne(win) {
  try {
    if (!win || win.isDestroyed()) return;
    const login = getWinLogin(win);
    if (!login) return;
    const wc = win.webContents;
    if (!wc) return;
    const saldo = await wc.executeJavaScript(BALANCE_SCRIPT, true).catch(() => null);
    if (saldo == null) return;
    const { atualizarSaldo } = require("../../contasStore.cjs");
    const changed = win._lastSaldoSeen !== saldo;
    win._lastSaldoSeen = saldo;
    if (!changed) return; // evita escrever em disco toda vez sem necessidade
    await atualizarSaldo(login, saldo);
    try {
      if (state.mainWin && !state.mainWin.isDestroyed()) state.mainWin.webContents.send("contas:atualizou");
    } catch {}
  } catch {}
}

let started = false;
function startBalanceTracking() {
  if (started) return;
  started = true;
  // 20s: frequente o bastante pra ficar "ao vivo" na prática, sem gerar
  // tráfego/CPU perceptível mesmo com várias janelas abertas ao mesmo tempo
  // (é só innerText + regex, bem barato).
  setInterval(() => {
    try {
      for (const win of state.chromeWins || []) scanOne(win);
    } catch {}
  }, 20000);
}

module.exports = { startBalanceTracking };
