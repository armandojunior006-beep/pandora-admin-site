// ============================================================================
// MODO ESPELHO — captura cliques/teclas/scroll/wheel na janela mestre via CDP
// (Runtime.addBinding) e replica nas demais janelas selecionadas usando
// sendInputEvent. Nunca propaga navegação (cada janela mantém sua própria URL).
// ============================================================================
const state = require("../state.cjs");
const { getSelectedChromeWins } = require("./chromiumWindows.cjs");

const __MIRROR_SCRIPT = `
(function(){
  if (window.__pandoraMirrorOn) return;
  window.__pandoraMirrorOn = true;
  function send(p){ try { window.__pandoraMirror(JSON.stringify(p)); } catch(e){} }
  // Captura SOMENTE quando a janela mestre está focada e o evento é confiável
  // (interação real do usuário dentro da página). Eventos sintéticos,
  // disparados fora da janela ou enquanto ela está em background são ignorados.
  function active(e){
    try {
      if (e && e.isTrusted === false) return false;
      if (typeof document.hasFocus === 'function' && !document.hasFocus()) return false;
      if (document.visibilityState && document.visibilityState !== 'visible') return false;
    } catch(_){}
    return true;
  }
  function nrm(e){
    var w = Math.max(1, window.innerWidth), h = Math.max(1, window.innerHeight);
    return { nx: (e.clientX||0)/w, ny: (e.clientY||0)/h };
  }
  function inViewport(e){
    var x = e.clientX, y = e.clientY;
    return x >= 0 && y >= 0 && x <= window.innerWidth && y <= window.innerHeight;
  }
  addEventListener('pointerdown', function(e){ if(!active(e)||!inViewport(e)) return; var p=nrm(e); send({t:'md',nx:p.nx,ny:p.ny,btn:e.button}); }, true);
  addEventListener('pointerup',   function(e){ if(!active(e)||!inViewport(e)) return; var p=nrm(e); send({t:'mu',nx:p.nx,ny:p.ny,btn:e.button}); }, true);
  addEventListener('dblclick',    function(e){ if(!active(e)||!inViewport(e)) return; var p=nrm(e); send({t:'dbl',nx:p.nx,ny:p.ny,btn:e.button}); }, true);
  addEventListener('keydown', function(e){ if(!active(e)) return; send({t:'kd',k:e.key,code:e.code,sh:e.shiftKey,ct:e.ctrlKey,al:e.altKey,me:e.metaKey}); }, true);
  addEventListener('keyup',   function(e){ if(!active(e)) return; send({t:'ku',k:e.key,code:e.code,sh:e.shiftKey,ct:e.ctrlKey,al:e.altKey,me:e.metaKey}); }, true);
  addEventListener('wheel', function(e){ if(!active(e)||!inViewport(e)) return; var p=nrm(e); send({t:'wh',nx:p.nx,ny:p.ny,dx:e.deltaX,dy:e.deltaY}); }, true);
  // NOTA: chegou a existir aqui um segundo canal de scroll ('sc'), que
  // reforçava a posição absoluta (window.scrollX/Y em proporção do
  // scrollWidth/Height) ~30ms depois de cada scroll, pra cobrir casos de
  // scroll sem wheel (teclado/toque). Foi REMOVIDO: como master e follower
  // quase sempre têm páginas com alturas de conteúdo levemente diferentes
  // (cada janela tem seu próprio estado/anúncios/etc.), a correção por
  // PROPORÇÃO calculava uma posição diferente da que o replay por DELTA de
  // wheel já tinha aplicado — os dois brigavam, causando direção errada e
  // "pulos" do nada alguns instantes depois de rolar. Scroll por teclado
  // (setas/PageDown/Espaço) já é coberto de forma nativa e sem conflito
  // pelos eventos de teclado replicados abaixo (kd/ku) — o navegador do
  // follower rola sozinho ao receber a MESMA tecla que a mestre recebeu.
})();
`;


function __mirrorBtnName(b) {
  return b === 1 ? "middle" : b === 2 ? "right" : "left";
}
function __mirrorMods(p) {
  const m = [];
  if (p.sh) m.push("shift");
  if (p.ct) m.push("control");
  if (p.al) m.push("alt");
  if (p.me) m.push("meta");
  return m;
}
// Caracteres imprimíveis (1 char) viram um sendInputEvent('char') após o keyDown
// pra preencher inputs em texto. Teclas como Enter/Tab/Backspace já são tratadas
// nativamente pelo keyDown com keyCode nomeado.
function __mirrorReplayKey(wc, p, isDown) {
  try {
    const mods = __mirrorMods(p);
    const key = p.k && p.k.length === 1 ? p.k : (p.code || p.k);
    wc.sendInputEvent({ type: isDown ? "keyDown" : "keyUp", keyCode: key, modifiers: mods });
    if (isDown && p.k && p.k.length === 1) {
      wc.sendInputEvent({ type: "char", keyCode: p.k, modifiers: mods });
    }
  } catch {}
}
function __mirrorReplay(win, p) {
  if (!win || win.isDestroyed()) return;
  try {
    const wc = win.webContents;
    const [W, H] = win.getContentSize();
    const x = Math.round((p.nx || 0) * W);
    const y = Math.round((p.ny || 0) * H);
    if (p.t === "md") wc.sendInputEvent({ type: "mouseDown", x, y, button: __mirrorBtnName(p.btn), clickCount: 1 });
    else if (p.t === "mu") wc.sendInputEvent({ type: "mouseUp", x, y, button: __mirrorBtnName(p.btn), clickCount: 1 });
    else if (p.t === "dbl") {
      wc.sendInputEvent({ type: "mouseDown", x, y, button: __mirrorBtnName(p.btn), clickCount: 2 });
      wc.sendInputEvent({ type: "mouseUp",   x, y, button: __mirrorBtnName(p.btn), clickCount: 2 });
    }
    // BUG real 2026-08-18 (reportado pelo usuário: "na tela mestre desce, nas
    // demais sobe ao contrário") — deltaX/deltaY do WheelEvent do DOM e do
    // sendInputEvent('mouseWheel') do Electron seguem a MESMA convenção de
    // sinal (positivo = rola pra baixo/direita); estava sendo invertido
    // (-dx/-dy) por engano, fazendo o follower rolar sempre ao contrário da
    // mestre.
    else if (p.t === "wh") wc.sendInputEvent({ type: "mouseWheel", x, y, deltaX: p.dx || 0, deltaY: p.dy || 0, canScroll: true });
    else if (p.t === "kd") __mirrorReplayKey(wc, p, true);
    else if (p.t === "ku") __mirrorReplayKey(wc, p, false);
    // ('sc' — correção de posição absoluta — removida, ver comentário em
    // __MIRROR_SCRIPT: brigava com o replay de wheel acima.)
  } catch {}
}
function __mirrorFollowers() {
  const sel = getSelectedChromeWins();
  return sel.filter((w) => w && !w.isDestroyed() && w !== state.mirrorMaster);
}
async function __mirrorAttach(win) {
  if (!win || win.isDestroyed() || win._mirrorAttached) return;
  const wc = win.webContents;
  try { if (!wc.debugger.isAttached()) wc.debugger.attach("1.3"); } catch (e) { console.warn("[mirror] attach falhou:", e?.message || e); return; }
  win._mirrorAttached = true;
  try {
    await wc.debugger.sendCommand("Runtime.enable");
    await wc.debugger.sendCommand("Page.enable");
    await wc.debugger.sendCommand("Runtime.addBinding", { name: "__pandoraMirror" });
    await wc.debugger.sendCommand("Page.addScriptToEvaluateOnNewDocument", { source: __MIRROR_SCRIPT });
    await wc.debugger.sendCommand("Runtime.evaluate", { expression: __MIRROR_SCRIPT });
    const onMsg = (_e, method, params) => {
      if (method === "Runtime.bindingCalled" && params && params.name === "__pandoraMirror") {
        try {
          // BUG real 2026-08-10 (reportado pelo usuário: "depois de ativar o
          // modo espelho, precisa dar 1 clique primeiro" antes de passar a
          // espelhar) — o gate extra "win.isFocused()" (nível Electron/SO)
          // causava exatamente isso: o PRIMEIRO clique do usuário na janela
          // mestre depois de ativar é, na maioria das vezes, o MESMO clique
          // que dá foco de verdade a essa janela (ela não estava em foco
          // antes — o usuário estava na janela principal do app clicando em
          // "ativar espelho"). O foco a nível de SISTEMA (win.isFocused(),
          // que chega via evento nativo do gerenciador de janelas, através
          // do processo principal) atualiza numa corrida separada e mais
          // lenta do que o evento de clique em si, que chega direto pela
          // CDP (Runtime.bindingCalled) — nesse primeiro clique,
          // win.isFocused() ainda dizia "false" quando o evento chegava,
          // descartando ESSE clique especificamente. Os checks já feitos
          // DENTRO da página injetada (document.hasFocus() e
          // visibilityState, ver __MIRROR_SCRIPT) já cobrem o mesmo
          // propósito (ignorar eventos espúrios/fora da janela) sem essa
          // corrida, porque são avaliados pelo próprio renderer no momento
          // exato do evento — bastam eles, o gate redundante é removido.
          if (!state.mirrorEnabled || state.mirrorMaster !== win) return;
          const p = JSON.parse(params.payload);
          for (const f of __mirrorFollowers()) __mirrorReplay(f, p);
        } catch {}
      } else if (method === "Page.frameNavigated" && params?.frame && !params.frame.parentId) {
        try { wc.debugger.sendCommand("Runtime.evaluate", { expression: __MIRROR_SCRIPT }).catch(()=>{}); } catch {}
      }
    };
    win._mirrorListener = onMsg;
    wc.debugger.on("message", onMsg);
    // IMPORTANTE: NÃO propagamos navegação (URL) para os followers.
    // Cada janela tem sua própria URL/casa e deve navegar individualmente.
    // O modo espelho replica APENAS inputs (mouse/teclado), nunca loadURL.
    win._mirrorNavListener = null;

    console.log("[mirror] capturando janela mestre");
  } catch (e) {
    console.warn("[mirror] setup falhou:", e?.message || e);
  }
}
function __mirrorDetach(win) {
  if (!win || !win._mirrorAttached) return;
  try {
    const wc = win.webContents;
    if (win._mirrorListener) wc.debugger.off("message", win._mirrorListener);
    if (win._mirrorNavListener) wc.off("did-navigate", win._mirrorNavListener);
    if (wc.debugger.isAttached()) wc.debugger.detach();
  } catch {}
  win._mirrorAttached = false;
  win._mirrorListener = null;
  win._mirrorNavListener = null;
  try { win.webContents.executeJavaScript("try{window.__pandoraMirrorOn=false}catch(e){}").catch(()=>{}); } catch {}
}

// CSS extra para destacar a janela MESTRE (borda dourada por cima da neon verde)
const __PANDORA_MASTER_CSS = `
  html::after {
    content: 'MESTRE';
    position: fixed;
    top: 6px; left: 50%;
    transform: translateX(-50%);
    background: #ffcc00;
    color: #000;
    font: bold 11px/1 system-ui, sans-serif;
    padding: 3px 10px;
    border-radius: 999px;
    z-index: 2147483647;
    pointer-events: none;
    box-shadow: 0 0 12px rgba(255,204,0,.7);
  }
`;
function applyMasterIndicator(win, isMaster) {
  if (!win || win.isDestroyed()) return;
  const wc = win.webContents;
  try {
    if (isMaster) {
      if (win._pandoraMasterCssKey) return;
      wc.insertCSS(__PANDORA_MASTER_CSS).then((k) => { win._pandoraMasterCssKey = k; }).catch(() => {});
    } else if (win._pandoraMasterCssKey) {
      try { wc.removeInsertedCSS(win._pandoraMasterCssKey); } catch {}
      win._pandoraMasterCssKey = null;
    }
  } catch {}
}

async function applyMirrorState() {
  const sel = getSelectedChromeWins();
  // Preserva o mestre atual se ainda estiver vivo E continuar na seleção,
  // para não reindexar/embaralhar a ordem das janelas. Só elege novo mestre
  // quando o anterior sumiu (foi fechado) ou saiu da seleção.
  let newMaster = null;
  if (state.mirrorEnabled) {
    if (state.mirrorMaster && !state.mirrorMaster.isDestroyed() && sel.includes(state.mirrorMaster)) {
      newMaster = state.mirrorMaster;
    } else {
      newMaster = sel[0] || null;
    }
  }
  if (state.mirrorMaster && state.mirrorMaster !== newMaster) {
    applyMasterIndicator(state.mirrorMaster, false);
    __mirrorDetach(state.mirrorMaster);
  }
  state.mirrorMaster = newMaster;
  for (const w of state.chromeWins) applyMasterIndicator(w, state.mirrorEnabled && w === newMaster);
  if (state.mirrorEnabled && newMaster) await __mirrorAttach(newMaster);
}

module.exports = {
  applyMasterIndicator,
  applyMirrorState,
  __mirrorAttach,
  __mirrorDetach,
};
