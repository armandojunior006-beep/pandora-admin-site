// ============================================================================
// IPC: app:* — monitores, link externo, reload da UI, checagem/instalação de
// atualização, info do app e foco da janela principal.
// ============================================================================
const { app, screen, shell, dialog } = require("electron");
const state = require("../state.cjs");
const { getSettingSync } = require("../settings/settingsStore.cjs");
const { loadMain } = require("../window/windowManager.cjs");
const {
  requestJson, getManifestUrl, getUpdateId, compareBaseVersion, installLatestUpdate,
  getEffectiveVersion, getEffectiveUpdateId,
} = require("../updater/updater.cjs");

function registerAppHandlers(ipcMain) {
  ipcMain.handle("app:listMonitors", () => {
    const primary = screen.getPrimaryDisplay();
    return screen.getAllDisplays().map((d, i) => ({
      index: i,
      id: d.id,
      label: `Monitor ${i + 1}${d.id === primary.id ? " (Principal)" : ""}: ${d.size.width}x${d.size.height}`,
      width: d.size.width,
      height: d.size.height,
      scaleFactor: d.scaleFactor,
      primary: d.id === primary.id,
    }));
  });
  ipcMain.handle("app:openExternal", (_e, url) => { shell.openExternal(url); return true; });
  ipcMain.handle("app:reload", () => {
    if (state.mainWin) { loadMain(state.mainWin); }
    return true;
  });
  ipcMain.handle("app:checkUpdate", async () => {
    try {
      const manifest = await requestJson(getManifestUrl());
      const updateId = getUpdateId(manifest);
      const currentId = getEffectiveUpdateId();
      const manifestBase = String(manifest.version || "").split("+")[0];
      const currentBase = String(getEffectiveVersion() || "").split("+")[0];
      const baseIsNewer = manifestBase && compareBaseVersion(manifestBase, currentBase) > 0;
      const hasUpdate = baseIsNewer || Boolean(updateId && updateId !== currentId);
      return { ok: true, hasUpdate, version: manifest.version, url: manifest.url || manifest.packageUrl || manifest.rendererUrl };
    } catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
  ipcMain.handle("app:installUpdate", async () => {
    const openChrome = state.chromeWins.filter((w) => w && !w.isDestroyed()).length;
    const openWorkers = state.workerWins.filter((w) => w && !w.isDestroyed()).length;
    const openCount = openChrome + openWorkers;
    if (openCount > 0) {
      const msg = `Existem ${openCount} janela(s) abertas em execução.\n\nFeche todas as janelas antes de aplicar a atualização.\n\nApós o fechamento das janelas, tente novamente.`;
      try { console.log(`[pandora] [update] bloqueado — ${openChrome} Chromium + ${openWorkers} worker(s) abertas`); } catch {}
      try {
        if (state.mainWin && !state.mainWin.isDestroyed()) {
          dialog.showMessageBox(state.mainWin, { type: "warning", title: "Atualização bloqueada", message: "Feche as janelas antes de atualizar", detail: msg, buttons: ["OK"] });
        }
      } catch {}
      return { ok: false, error: msg, blocked: true, openWindows: openCount };
    }
    return installLatestUpdate();
  });
  ipcMain.handle("app:info", () => ({
    version: getEffectiveVersion(), platform: process.platform, userData: app.getPath("userData"), dbPath: state.dbPath,
  }));
  ipcMain.handle("app:focusMain", () => {
    try {
      if (state.mainWin && !state.mainWin.isDestroyed()) {
        if (state.mainWin.isMinimized()) state.mainWin.restore();
        state.mainWin.show();
        state.mainWin.focus();
        try { state.mainWin.webContents.focus(); } catch {}
      }
    } catch {}
    return true;
  });

  // ===== Controles de janela (barra de título custom / modo compacto) =====
  const mainW = () => (state.mainWin && !state.mainWin.isDestroyed() ? state.mainWin : null);
  ipcMain.handle("win:minimize", () => { const w = mainW(); if (w) w.minimize(); return true; });
  ipcMain.handle("win:toggleMaximize", () => {
    const w = mainW(); if (!w) return false;
    if (w.isMaximized()) w.unmaximize(); else w.maximize();
    return w.isMaximized();
  });
  ipcMain.handle("win:close", () => { const w = mainW(); if (w) w.close(); return true; });
  ipcMain.handle("win:setAlwaysOnTop", (_e, on) => {
    const w = mainW(); if (!w) return false;
    w.setAlwaysOnTop(!!on, "floating");
    return w.isAlwaysOnTop();
  });
  // Modo compacto: encolhe pra faixa larga/baixa, always-on-top e arrastável.
  // Guarda os bounds/estado anteriores pra restaurar ao voltar.
  ipcMain.handle("win:setCompact", (_e, on, width) => {
    const w = mainW(); if (!w) return { ok: false };
    if (on) {
      const area = screen.getPrimaryDisplay().workArea;
      // Largura: usa a medida do conteúdo (CompactBar) se veio, senão um
      // padrão. Ajustar a largura sem ativar de novo (mesmo compacto) evita
      // piscar — só re-seta bounds.
      // width vem em CSS px do renderer; converte pra DIP com o zoom real da
      // janela (main window usa zoomFactor 0.96) — sem isso sobra ~4% de
      // espaço preto porque CSS px > DIP.
      let zoom = 1; try { zoom = w.webContents.getZoomFactor() || 1; } catch {}
      const cssW = Number(width) || 900;
      const cw = Math.max(320, Math.min(Math.round(cssW * zoom) + 2, area.width - 40));
      const ch = 172;
      if (!state.__compact) {
        // Primeira entrada no compacto: centraliza no topo.
        if (w.isMaximized()) w.unmaximize();
        state.__prevBounds = w.getBounds();
        state.__prevAoT = w.isAlwaysOnTop();
        state.__compact = true;
        w.setMinimumSize(320, 120);
        w.setAlwaysOnTop(true, "floating");
        w.setBounds({ x: area.x + Math.max(0, Math.floor((area.width - cw) / 2)), y: area.y + 16, width: cw, height: ch });
      } else {
        // Só ajuste de largura (ex.: rótulo mudou ao clicar Espelho/Dados) —
        // MANTÉM a posição atual pra janela não "pular" pro topo. Bug real
        // 2026-08-22: re-centralizar aqui fazia o bot subir a cada clique.
        const b = w.getBounds();
        w.setBounds({ x: b.x, y: b.y, width: cw, height: ch });
      }
    } else {
      state.__compact = false;
      w.setAlwaysOnTop(!!state.__prevAoT, "floating");
      const fm = state.__fullMinSize || { width: 1000, height: 700 };
      if (state.__prevBounds) w.setBounds(state.__prevBounds);
      w.setMinimumSize(fm.width, fm.height);
    }
    return { ok: true, compact: !!on };
  });
}

module.exports = { registerAppHandlers };
