// ============================================================================
// IPC: app:* — monitores, link externo, reload da UI, checagem/instalação de
// atualização, info do app e foco da janela principal.
// ============================================================================
const { app, screen, shell, dialog } = require("electron");
const state = require("../state.cjs");
const { getSettingSync } = require("../settings/settingsStore.cjs");
const { loadMain } = require("../window/windowManager.cjs");
const {
  requestJson, getManifestUrl, getUpdateId, compareBaseVersion, installLatestUpdate,
} = require("../updater/updater.cjs");

function registerAppHandlers(ipcMain) {
  ipcMain.handle("app:listMonitors", () => {
    const primary = screen.getPrimaryDisplay();
    return screen.getAllDisplays().map((d, i) => ({
      index: i,
      id: d.id,
      label: `Monitor ${i + 1}${d.id === primary.id ? " (Principal)" : ""}: ${d.size.width}x${d.size.height}`,
      width: d.size.width,
      height: d.size.height,
      scaleFactor: d.scaleFactor,
      primary: d.id === primary.id,
    }));
  });
  ipcMain.handle("app:openExternal", (_e, url) => { shell.openExternal(url); return true; });
  ipcMain.handle("app:reload", () => {
    if (state.mainWin) { loadMain(state.mainWin); }
    return true;
  });
  ipcMain.handle("app:checkUpdate", async () => {
    try {
      const manifest = await requestJson(getManifestUrl());
      const updateId = getUpdateId(manifest);
      const currentId = getSettingSync("renderer_update_id", app.getVersion());
      const manifestBase = String(manifest.version || "").split("+")[0];
      const currentBase = String(app.getVersion() || "").split("+")[0];
      const baseIsNewer = manifestBase && compareBaseVersion(manifestBase, currentBase) > 0;
      const hasUpdate = baseIsNewer || Boolean(updateId && updateId !== currentId);
      return { ok: true, hasUpdate, version: manifest.version, url: manifest.url || manifest.packageUrl || manifest.rendererUrl };
    } catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
  ipcMain.handle("app:installUpdate", async () => {
    const openChrome = state.chromeWins.filter((w) => w && !w.isDestroyed()).length;
    const openWorkers = state.workerWins.filter((w) => w && !w.isDestroyed()).length;
    const openCount = openChrome + openWorkers;
    if (openCount > 0) {
      const msg = `Existem ${openCount} janela(s) abertas em execução.\n\nFeche todas as janelas antes de aplicar a atualização.\n\nApós o fechamento das janelas, tente novamente.`;
      try { console.log(`[pandora] [update] bloqueado — ${openChrome} Chromium + ${openWorkers} worker(s) abertas`); } catch {}
      try {
        if (state.mainWin && !state.mainWin.isDestroyed()) {
          dialog.showMessageBox(state.mainWin, { type: "warning", title: "Atualização bloqueada", message: "Feche as janelas antes de atualizar", detail: msg, buttons: ["OK"] });
        }
      } catch {}
      return { ok: false, error: msg, blocked: true, openWindows: openCount };
    }
    return installLatestUpdate();
  });
  ipcMain.handle("app:info", () => ({
    version: app.getVersion(), platform: process.platform, userData: app.getPath("userData"), dbPath: state.dbPath,
  }));
  ipcMain.handle("app:focusMain", () => {
    try {
      if (state.mainWin && !state.mainWin.isDestroyed()) {
        if (state.mainWin.isMinimized()) state.mainWin.restore();
        state.mainWin.show();
        state.mainWin.focus();
        try { state.mainWin.webContents.focus(); } catch {}
      }
    } catch {}
    return true;
  });
}

module.exports = { registerAppHandlers };
