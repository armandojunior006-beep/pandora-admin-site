// ============================================================================
// IPC: contas:* — CRUD de contas salvas (contasStore.cjs) + abrir selecionadas.
// ============================================================================
const { shell } = require("electron");
const { ROOT_DIR } = require("../paths.cjs");
const { openChromiumForContas } = require("../window/chromiumWindows.cjs");
const { logSystem } = require("../settings/settingsStore.cjs");

function registerContasHandlers(ipcMain) {
  try {
    const cs = require(require('path').join(ROOT_DIR, 'contasStore.cjs'));
    ipcMain.handle('contas:listar', () => cs.listarContas());
    ipcMain.handle('contas:remover', (_e, id) => cs.removerConta(id));
    ipcMain.handle('contas:removerVarios', (_e, ids) => cs.removerVarios(ids));
    ipcMain.handle('contas:removerTodos', () => cs.removerTodos());
    ipcMain.handle('contas:abrirBackup', async () => {
      try {
        const filePath = cs.regenerarBackupTxt();
        const err = await shell.openPath(filePath);
        if (err) { try { shell.showItemInFolder(filePath); } catch {} return { ok: false, error: err, path: filePath }; }
        return { ok: true, path: filePath };
      } catch (e) { return { ok: false, error: e?.message || String(e) }; }
    });
    ipcMain.handle('contas:abrirSelecionadas', async (_e, contas, delaySec) => {
      try {
        const arr = Array.isArray(contas) ? contas.filter((c) => c && c.url) : [];
        if (!arr.length) return { ok: false, error: 'Nenhuma conta selecionada' };
        // Pedido do usuário 2026-08-10: mostrar "Abrindo contas" no Log de
        // Operações assim que a ação começa — antes só aparecia o log de
        // "Login concluído" por tela mais tarde (via attachContaAutoLogin em
        // autoLogin.cjs), sem nenhum aviso de que a ação sequer tinha
        // iniciado.
        try { logSystem(`Abrindo contas — ${arr.length} tela(s)`, { kind: "abrir-contas", total: arr.length }, "info", "operacao-login"); } catch {}
        const n = await openChromiumForContas(arr, Number(delaySec) || 0);
        return { ok: true, opened: n };
      } catch (e) { return { ok: false, error: e?.message || String(e) }; }
    });
  } catch (e) { console.warn('[contasStore] falhou:', e?.message); }
}

module.exports = { registerContasHandlers };
