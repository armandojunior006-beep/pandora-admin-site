// Auto-cadastro: detecta modal de registro no site alvo e preenche
// 4 campos (conta, senha, confirmar senha, celular) clicando em "Registro".
// Em caso de "usuário em uso" tenta outros logins alternativos.

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
let _diagFilePath = null;
// Rotação automática — o arquivo de diagnóstico é escrito de MUITOS lugares
// diferentes (auto-register.cjs, securityPin.cjs, autoCaptura.cjs,
// browserInjections.cjs, chromiumWindows.cjs, realChromeManager.cjs,
// saquesHandler.cjs...), sempre via fs.appendFileSync(getDiagFilePath(), ...)
// — sem limite nenhum, crescia pra sempre (chegou a passar de 14 milhões de
// caracteres no uso real). Centralizado AQUI (todo mundo chama
// getDiagFilePath() antes de escrever) em vez de mexer em cada ponto de
// escrita: quando passa do teto, mantém só o pedaço mais recente (o que
// importa pra debugar) e descarta o resto. Checagem throttled (no máx. a
// cada 10s) pra não fazer um stat() do arquivo em toda escrita, que são
// frequentes.
const DIAG_MAX_BYTES = 3 * 1024 * 1024; // 3MB — bem acima do normal, só entra em ação se algo realmente disparar logs sem parar
const DIAG_KEEP_BYTES = 1 * 1024 * 1024; // mantém o último ~1MB ao rotacionar
const DIAG_CHECK_INTERVAL_MS = 10000;
let _lastDiagSizeCheck = 0;
function maybeRotateDiagFile() {
  const now = Date.now();
  if (now - _lastDiagSizeCheck < DIAG_CHECK_INTERVAL_MS) return;
  _lastDiagSizeCheck = now;
  try {
    const st = fs.statSync(_diagFilePath);
    if (st.size <= DIAG_MAX_BYTES) return;
    const fd = fs.openSync(_diagFilePath, "r");
    const buf = Buffer.alloc(DIAG_KEEP_BYTES);
    fs.readSync(fd, buf, 0, DIAG_KEEP_BYTES, st.size - DIAG_KEEP_BYTES);
    fs.closeSync(fd);
    const header = `[${new Date().toISOString()}] [DIAG] log rotacionado automaticamente (estava em ${(st.size / 1024 / 1024).toFixed(1)}MB) — mantido só o trecho mais recente abaixo\r\n`;
    fs.writeFileSync(_diagFilePath, header + buf.toString("utf8"), "utf8");
  } catch {}
}
function getDiagFilePath() {
  if (_diagFilePath) { maybeRotateDiagFile(); return _diagFilePath; }
  // CONSOLIDAÇÃO (2026-08-27): no modo MultiBot, main.cjs faz app.setPath
  // ("userData", profileDir) — cada perfil/launcher passava a ter o SEU
  // diag-auto-register.txt. Resultado: o cliente criava a conta num perfil mas
  // o botão de log abria o de outro, então o log chegava só com os eventos de
  // FECHAMENTO (sem BOOT/conta-criada/re-login/qr). global.__pandoraBaseUserData
  // é a userData ANTES do override (main.cjs:68) e é IGUAL em todos os
  // processos/perfis (Electron default %APPDATA%\<app>) — escrevendo lá, TODO o
  // diag de todos os perfis cai num único arquivo. Só cacheia quando a base já
  // está firme (senão o BOOT bem cedo cacharia o path do perfil).
  let resolved = "";
  let stable = false;
  try {
    let dir = (typeof global !== "undefined" && global.__pandoraBaseUserData) || "";
    if (dir) { stable = true; }
    else { const { app } = require("electron"); dir = app.getPath("userData"); }
    try { fs.mkdirSync(dir, { recursive: true }); } catch {}
    resolved = path.join(dir, "diag-auto-register.txt");
  } catch { resolved = path.join(process.cwd(), "diag-auto-register.txt"); stable = true; }
  if (stable) _diagFilePath = resolved;
  return resolved;
}
// Fila assíncrona pro arquivo de diagnóstico — antes CADA log (BOOT do
// cadastro, watchdog, PIX, senha de saque, etc.) fazia um fs.appendFileSync
// SÍNCRONO, travando a thread principal por um instante; com várias
// janelas logando ativamente ao mesmo tempo (abrindo ou cadastrando), essas
// travadinhas se somavam e deixavam o app INTEIRO (incluindo a janela
// principal/UI) pesado pra clicar em qualquer botão. Agora as linhas entram
// numa fila em memória e são gravadas de UMA VEZ, de forma assíncrona
// (fs.appendFile, não bloqueia), a cada DIAG_FLUSH_MS — sem perder nenhuma
// linha, só atrasa a gravação em disco por uma fração de segundo (o que não
// importa pra um arquivo de log).
const DIAG_FLUSH_MS = 400;
let _diagQueue = [];
let _diagFlushTimer = null;
let _diagWriting = false;
function queueDiagLine(line) {
  _diagQueue.push(line);
  if (!_diagFlushTimer) _diagFlushTimer = setTimeout(flushDiagQueue, DIAG_FLUSH_MS);
}
function flushDiagQueue() {
  _diagFlushTimer = null;
  if (!_diagQueue.length) return;
  // Se um appendFile anterior ainda está em curso, NÃO descarta: reagenda.
  // Antes, com _diagWriting=true o timer já tinha sido zerado e a função saía
  // sem remarcar — as linhas enfileiradas só saíam se viesse OUTRA linha depois
  // (senão ficavam presas até o flush síncrono do quit). Reagendar garante que
  // toda linha vá pro disco mesmo sob escrita concorrente.
  if (_diagWriting) { if (!_diagFlushTimer) _diagFlushTimer = setTimeout(flushDiagQueue, DIAG_FLUSH_MS); return; }
  const chunk = _diagQueue.join("");
  _diagQueue = [];
  _diagWriting = true;
  fs.appendFile(getDiagFilePath(), chunk, "utf8", () => {
    _diagWriting = false;
    // Se chegou linha nova enquanto escrevia, garante o próximo flush.
    if (_diagQueue.length && !_diagFlushTimer) _diagFlushTimer = setTimeout(flushDiagQueue, DIAG_FLUSH_MS);
  });
}
// Só usado no fechamento do app (before-quit) — grava de forma síncrona o
// que ainda estiver pendente na fila, pra não perder as últimas linhas.
function flushDiagQueueSync() {
  if (_diagFlushTimer) { clearTimeout(_diagFlushTimer); _diagFlushTimer = null; }
  if (!_diagQueue.length) return;
  const chunk = _diagQueue.join("");
  _diagQueue = [];
  try { fs.appendFileSync(getDiagFilePath(), chunk, "utf8"); } catch {}
}
function appendDiagFile(message, context) {
  try {
    const ts = new Date().toISOString();
    const ctx = context && Object.keys(context).length ? " " + JSON.stringify(context) : "";
    queueDiagLine(`[${ts}] ${message}${ctx}\r\n`);
  } catch {}
}
appendDiagFile("BOOT 1 - arquivo carregado", { pid: process.pid, cwd: process.cwd() });


// Pools enormes para máxima variedade (BR + internacionais + sobrenomes).
const NAMES_FIRST = [
  "lucas","maria","joao","ana","pedro","julia","rafael","beatriz","gustavo","camila",
  "bruno","larissa","felipe","amanda","rodrigo","natalia","thiago","carla","diego","patricia",
  "marcelo","renata","andre","fernanda","vinicius","jessica","leonardo","mariana","rafaela","gabriel",
  "sophia","daniel","isabela","matheus","laura","henrique","leticia","caio","vitoria","eduardo",
  "yasmin","samuel","tatiana","joaquim","carolina","miguel","alice","arthur","helena","davi",
  "manuela","bernardo","valentina","heitor","cecilia","theo","luiza","enzo","clara","murilo",
  "agatha","nicolas","melissa","lorenzo","alana","ravi","ayla","kauan","elis","benjamin",
  "ines","tomas","emanuel","raissa","otavio","sara","ian","liz","aaron","mila",
  "noah","ella","liam","mia","oliver","ava","ethan","emma","mason","amelia",
  "logan","scarlett","jack","grace","leo","chloe","ryan","zoe","aria","luna",
  "kai","nova","axel","sage","reid","wren","quinn","june","ezra","iris",
];
const NAMES_LAST = [
  "silva","souza","santos","oliveira","pereira","lima","ribeiro","carvalho","alves","costa",
  "ferreira","rodrigues","gomes","martins","araujo","melo","barbosa","rocha","cardoso","teixeira",
  "correia","cunha","castro","dias","monteiro","moreira","ramos","sousa","freitas","azevedo",
  "moura","viana","duarte","reis","nunes","mendes","cavalcanti","peixoto","pinheiro","sampaio",
  "moraes","brandao","fonseca","caldeira","vargas","prado","tavares","queiroz","barros","macedo",
];
const ADJ = [
  "fast","cool","wild","blue","gold","royal","epic","nova","prime","mega",
  "alpha","omega","lucky","brave","silent","cyber","neo","ultra","sigma","delta",
  "phantom","stellar","lunar","solar","crimson","mystic","arctic","turbo","vivid","sharp",
];
const NOUNS = [
  "tiger","wolf","eagle","lion","shark","fox","cobra","hawk","raven","bear",
  "dragon","ninja","ghost","viper","ranger","rocket","comet","pixel","matrix","rider",
  "knight","samurai","phoenix","jaguar","panda","falcon","puma","orca","kraken","saber",
];

const DDDs = [11,12,13,14,15,16,17,18,19,21,22,24,27,28,31,32,33,34,35,37,38,41,42,43,44,45,46,47,48,49,51,53,54,55,61,62,63,64,65,66,67,68,69,71,73,74,75,77,79,81,82,83,84,85,86,87,88,89,91,92,93,94,95,96,97,98,99];

// Helpers de entropia (CSPRNG) — substitui Math.random() em todos os geradores.
function rndInt(maxExclusive) {
  if (maxExclusive <= 1) return 0;
  // rejeição para evitar viés
  const limit = Math.floor(0xffffffff / maxExclusive) * maxExclusive;
  while (true) {
    const x = crypto.randomBytes(4).readUInt32BE(0);
    if (x < limit) return x % maxExclusive;
  }
}
function pick(arr) { return arr[rndInt(arr.length)]; }
function maybe(p) { return rndInt(10000) / 10000 < p; }
function rndDigits(n) {
  let s = ""; for (let i = 0; i < n; i++) s += rndInt(10); return s;
}

// Logins humanos, mas com altíssima variedade. Combina nome + complementos.
// Exemplos: "lucas.silva92", "phoenix_42aa", "MariaP_7831", "kauan-tiger91", "fastWolf2025"
function genLogin() {
  const style = rndInt(8);
  // Sem separador ("." "_" "-"): sites de cadastro em geral só aceitam
  // usuário alfanumérico — esses símbolos eram digitados no campo mas o
  // site os rejeitava/filtrava em silêncio, então o login REAL criado no
  // site (ex.: "raissacor") ficava diferente do que o app mostrava/salvava
  // (ex.: "raissa-cor"), já que nada relia o valor de volta do campo depois
  // de digitar. Gerar só alfanumérico evita o descompasso de vez.
  const sep = "";
  const cap = (s) => maybe(0.35) ? s.charAt(0).toUpperCase() + s.slice(1) : s;
  const first = cap(pick(NAMES_FIRST));
  const last  = cap(pick(NAMES_LAST));
  const adj   = cap(pick(ADJ));
  const noun  = cap(pick(NOUNS));
  const yr    = String(1980 + rndInt(46)); // 1980-2025
  const tail  = rndDigits(2 + rndInt(4));  // 2-5 dígitos
  let base;
  switch (style) {
    case 0: base = `${first}${sep}${last}${tail}`; break;
    case 1: base = `${adj}${sep}${noun}${tail}`; break;
    case 2: base = `${first}${tail}`; break;
    case 3: base = `${noun}${sep}${first}${tail}`; break;
    case 4: base = `${first}${sep}${noun}${yr.slice(-2)}`; break;
    case 5: base = `${first.charAt(0)}${sep}${last}${tail}`; break;
    case 6: base = `${adj}${first}${tail}`; break;
    default: base = `${first}${last}${rndDigits(3)}`;
  }
  // sufixo aleatório curto para reduzir colisões (apenas em alguns)
  if (maybe(0.5)) base += String.fromCharCode(97 + rndInt(26)); // letra extra
  // remove caracteres acentuados/inválidos e limita a 10 (site suporta 16, mas mantemos 10)
  let out = base.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase()
                .replace(/[^a-z0-9]/g, "");
  if (out.length > 10) out = out.slice(0, 10);
  // garante mínimo de 5 chars preenchendo com dígitos aleatórios
  while (out.length < 5) out += rndInt(10);
  return out;
}

// Senha 8-10 chars (site limita a 10) com 4 categorias garantidas.
function genPassword() {
  const lo = "abcdefghijkmnopqrstuvwxyz";
  const up = "ABCDEFGHJKLMNPQRSTUVWXYZ";
  const dg = "23456789";
  const sy = "!@#$%&*?";
  let chars = [pick(lo.split("")), pick(up.split("")), pick(dg.split("")), pick(sy.split(""))];
  const all = (lo + up + dg + sy).split("");
  const len = 8 + rndInt(3); // 8-10 (máximo 10 conforme regra do site)
  while (chars.length < len) chars.push(pick(all));
  // embaralhamento Fisher–Yates com CSPRNG
  for (let i = chars.length - 1; i > 0; i--) {
    const j = rndInt(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("").slice(0, 10);
}

// Pedido do usuário 2026-08-19 (versopg.vip): esse site não tem campo de
// celular no cadastro — tem "realName" ("Introduza o seu nome real") no
// lugar. Nome completo plausível reaproveitando os mesmos pools de
// NAMES_FIRST/NAMES_LAST do genLogin(), mas capitalizado normal (sem o
// embaralhamento de caixa que o login usa).
function genRealName() {
  const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
  return `${cap(pick(NAMES_FIRST))} ${cap(pick(NAMES_LAST))}`;
}

function genPhone() {
  const ddd = pick(DDDs);
  // celular brasileiro: 9 + 8 dígitos (segundo dígito 6-9 é mais realista)
  const second = String(6 + rndInt(4));
  return `${ddd}9${second}${rndDigits(7)}`;
}

// Verifica se o login já existe em accounts ou generated_credentials.
function loginExists(db, login) {
  if (!db) return false;
  try {
    const q = (sql) => {
      try {
        const r = db.exec(sql);
        return !!(r && r[0] && r[0].values && r[0].values.length);
      } catch { return false; }
    };
    const safe = String(login).replace(/'/g, "''");
    if (q(`SELECT 1 FROM accounts WHERE username='${safe}' LIMIT 1`)) return true;
    if (q(`SELECT 1 FROM generated_credentials WHERE login='${safe}' LIMIT 1`)) return true;
  } catch {}
  return false;
}

// Registra um login para impedir reuso futuro (mesmo se cadastro falhar no site).
function reserveLogin(db, login) {
  if (!db) return;
  try {
    const stmt = db.prepare("INSERT OR IGNORE INTO generated_credentials (login) VALUES (?)");
    stmt.run([login]);
    stmt.free();
  } catch {}
}

// Gera um login inédito (até 200 tentativas; se ainda colidir, anexa entropia bruta).
function genUniqueLogin(db) {
  for (let i = 0; i < 200; i++) {
    const l = genLogin();
    if (!loginExists(db, l)) { reserveLogin(db, l); return l; }
  }
  // fallback infalível: prefixo curto + entropia hex, total <= 10
  for (let i = 0; i < 50; i++) {
    const l = (genLogin().slice(0, 4) + crypto.randomBytes(3).toString("hex")).slice(0, 10);
    if (!loginExists(db, l)) { reserveLogin(db, l); return l; }
  }
  // último recurso (praticamente impossível chegar aqui) — 10 chars
  const l = ("u" + crypto.randomBytes(5).toString("hex")).slice(0, 10);
  reserveLogin(db, l); return l;
}

function genCredentials(db = null) {
  return {
    login: genUniqueLogin(db),
    senha: genPassword(),
    celular: genPhone(),
    nomeReal: genRealName(),
    alternativos: Array.from({ length: 8 }, () => genUniqueLogin(db)),
  };
}

function hostFromUrl(url) {
  try { return new URL(url || "").host; } catch { return ""; }
}

function saveAutoAccount(db, saveDB, dbPath, payload, sourceUrl) {
  const t0 = Date.now();
  const tag = "[contas-db]";
  if (!db) { console.warn(`${tag} ABORT: db indisponível`); return false; }
  if (!payload || !payload.login || !payload.senha) {
    console.warn(`${tag} ABORT: payload inválido login=${payload && payload.login} senha=${payload && payload.senha ? "***" : "(vazia)"}`);
    return false;
  }
  const url = sourceUrl || payload.site || "";
  const host = hostFromUrl(url) || "auto-cadastro";
  const notes = JSON.stringify({
    celular: payload.celular || null,
    site: url,
    criado_em: payload.criadoEm || new Date().toISOString(),
    saque: payload.saque || null,
    saque_pin: payload.saquePin || payload.pin || null,
    dep_status: payload.depStatus || null,
    cadastro_status: payload.status || payload.cadastroStatus || null,
  });
  console.log(`${tag} TENTATIVA INSERT host=${host} login=${payload.login} senha=${String(payload.senha).replace(/./g, "•")} url=${url}`);
  try {
    const chk = db.prepare("SELECT id FROM accounts WHERE label=? AND username=? LIMIT 1");
    chk.bind([host, String(payload.login)]);
    const exists = chk.step();
    const existingId = exists ? chk.getAsObject().id : null;
    chk.free();
    if (exists) {
      const up = db.prepare("UPDATE accounts SET password=?, notes=?, status='active', updated_at=datetime('now') WHERE id=?");
      up.run([String(payload.senha), notes, existingId]);
      up.free();
      saveDB && saveDB(db, dbPath).catch((e) => console.warn(`${tag} saveDB(update) falhou:`, e?.message || e));
      console.log(`${tag} UPDATE OK id=${existingId} host=${host} login=${payload.login} (${Date.now() - t0}ms)`);
      try { notifyAccountsChanged({ action: "update", id: existingId, host, login: payload.login }); } catch {}
      return true;
    }

    const stmt = db.prepare("INSERT INTO accounts (label, username, password, notes, status) VALUES (?,?,?,?,?)");
    stmt.run([
      host,
      String(payload.login),
      String(payload.senha),
      notes,
      "active",
    ]);
    stmt.free();
    let newId = null;
    try {
      const r = db.exec("SELECT last_insert_rowid()");
      newId = r[0]?.values?.[0]?.[0] ?? null;
    } catch {}

    try {
      const lg = db.prepare("INSERT INTO logs (level, source, message, context_json) VALUES (?,?,?,?)");
      lg.run([
        "info",
        "auto-register",
        `Conta salva em Contas | ${host} | login=${payload.login} senha=${payload.senha}`,
        JSON.stringify({ host, login: payload.login, status: payload.status || payload.cadastroStatus || null, depStatus: payload.depStatus || null }),
      ]);
      lg.free();
    } catch {}

    saveDB && saveDB(db, dbPath).catch((e) => console.warn(`${tag} saveDB(insert) falhou:`, e?.message || e));
    console.log(`${tag} INSERT OK id=${newId} host=${host} login=${payload.login} (${Date.now() - t0}ms)`);
    try { notifyAccountsChanged({ action: "insert", id: newId, host, login: payload.login }); } catch {}
    return true;
  } catch (e) {
    console.error(`${tag} INSERT FALHOU host=${host} login=${payload.login} erro=${e?.message || e}`);
    if (e && e.stack) console.error(`${tag} stack: ${e.stack}`);
    return false;
  }
}

// Broadcaster — preenchido pelo main.cjs via setAccountsChangeNotifier.
// Permite que a aba Contas atualize a lista imediatamente após cada insert/update.
let __accountsChangeNotifier = null;
function setAccountsChangeNotifier(fn) { __accountsChangeNotifier = typeof fn === "function" ? fn : null; }
function notifyAccountsChanged(info) {
  if (__accountsChangeNotifier) {
    try { __accountsChangeNotifier(info); } catch (e) { console.warn("[contas-db] notifier falhou:", e?.message || e); }
  }
}

function deleteAutoAccount(db, saveDB, dbPath, payload, sourceUrl) {
  if (!db || !payload || !payload.login) return;
  const host = hostFromUrl(sourceUrl || payload.site || "") || "auto-cadastro";
  try {
    const stmt = db.prepare("DELETE FROM accounts WHERE label=? AND username=? AND notes LIKE '%submitted%' ");
    stmt.run([host, String(payload.login)]);
    stmt.free();
    saveDB && saveDB(db, dbPath).catch(() => {});
  } catch {}
}

function persistAutoRegisterLog(db, saveDB, dbPath, message, context = {}) {
  appendDiagFile(message, context);
  try {
    if (!db) return;
    const stmt = db.prepare("INSERT INTO logs (level, source, message, context_json) VALUES (?,?,?,?)");
    stmt.run(["info", "auto-register", String(message || ""), JSON.stringify(context || {})]);
    stmt.free();
    saveDB && saveDB(db, dbPath).catch(() => {});
  } catch {}
}

// Log visível no painel "Log de Operações" (aba Início) — pedido do usuário
// 2026-08-09: "quando a conta estiver sendo criada após abrir o site, envie
// pro log também: criando conta", igual já existe pra Saque/PIX/Login.
// source com prefixo "operacao" pra bater no filtro (source LIKE 'operacao%')
// que Inicio.tsx usa; persistAutoRegisterLog sozinho usa source="auto-register",
// que NÃO aparece nesse painel (só no diag). Notifica state.mainWin (a janela
// da UI do app, não a `win` do Chrome sendo automatizado) igual logSystem
// (settingsStore.cjs) faz, pra atualizar o painel na hora sem precisar F5.
function logOperacaoPanel(db, saveDB, dbPath, message, context = {}) {
  try {
    if (!db) return;
    const stmt = db.prepare("INSERT INTO logs (level, source, message, context_json) VALUES (?,?,?,?)");
    stmt.run(["info", "operacao-registro", String(message || ""), JSON.stringify(context || {})]);
    stmt.free();
    saveDB && saveDB(db, dbPath).catch(() => {});
    try {
      const state = require("./src/state.cjs");
      if (state.mainWin && !state.mainWin.isDestroyed()) state.mainWin.webContents.send("logs:updated");
    } catch {}
  } catch {}
}

function buildSafeInjectionWrapper(injectedScript) {
  // Logs RAW via console.log direto, sem helpers, para evitar que falhas
  // no próprio helper escondam a causa real.
  // IMPORTANTE: muitos cassinos (PG SOFT/Saas Lobby/dz-tabloidpg) sobrescrevem
  // console.log no boot, fazendo nossos markers desaparecerem. Roubamos um
  // console.log "limpo" de um iframe sandbox same-origin antes de tudo.
  return `(() => {
    try {
      if (typeof window.__pandoraRawLog !== 'function') {
        try {
          var __ifr = document.createElement('iframe');
          __ifr.style.cssText = 'display:none!important;width:0;height:0;border:0;position:absolute;left:-9999px;top:-9999px';
          (document.documentElement || document.body).appendChild(__ifr);
          var __cw = __ifr.contentWindow;
          if (__cw && __cw.console && typeof __cw.console.log === 'function') {
            window.__pandoraRawLog = __cw.console.log.bind(__cw.console);
          }
        } catch (e) {}
        if (typeof window.__pandoraRawLog !== 'function') {
          try {
            var __proto = Object.getPrototypeOf(console);
            var __desc = __proto && Object.getOwnPropertyDescriptor(__proto, 'log');
            if (__desc && typeof __desc.value === 'function') window.__pandoraRawLog = __desc.value.bind(console);
          } catch (e) {}
        }
        if (typeof window.__pandoraRawLog !== 'function') window.__pandoraRawLog = console.log.bind(console);
      }
    } catch (e) { try { window.__pandoraRawLog = console.log.bind(console); } catch (_) {} }
    // __plog manda por DOIS canais: o console.log "roubado" (pode falhar em
    // sites que bloqueiam de outra forma) E window.__pandoraRegSignal, um
    // canal via CDP (Runtime.addBinding) que não passa pelo console da
    // página de jeito nenhum — só existe no Chrome real (ver
    // exposeFunction("__pandoraRegSignal") em auto-register.cjs).
    var __plogRaw = window.__pandoraRawLog || function(){};
    var __plog = function(msg) {
      try { __plogRaw(msg); } catch (e) {}
      try { if (typeof window.__pandoraRegSignal === 'function') window.__pandoraRegSignal(msg); } catch (e) {}
    };
    try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.1 - wrapper executando (rawLog ativo)'})); } catch(e){}
    const __pandoraReport = (label, error, extra) => {
      try {
        const err = error || {};
        const msg = [
          String(label || 'BOOT erro'),
          'name=' + String(err.name || (extra && extra.name) || ''),
          'message=' + String(err.message || (extra && extra.message) || err || ''),
          'stack=' + String(err.stack || (extra && extra.stack) || ''),
        ].join(' | ');
        __plog('__PANDORA_REG__' + JSON.stringify({ kind: 'log', msg }));
      } catch (e) {
        try { __plog('PANDORA_FATAL:report-helper-failed:' + String(e && e.message)); } catch(_){}
      }
    };
    try {
      window.addEventListener('error', (event) => {
        try { __plog('PANDORA_FATAL:window.onerror:' + JSON.stringify({name: event && event.error && event.error.name, message: event && (event.message || (event.error && event.error.message)), stack: event && event.error && event.error.stack})); } catch(_){}
      }, true);
      window.addEventListener('unhandledrejection', (event) => {
        const reason = event && event.reason;
        try { __plog('PANDORA_FATAL:unhandledrejection:' + JSON.stringify({name: reason && reason.name, message: reason && (reason.message || String(reason)), stack: reason && reason.stack})); } catch(_){}
      });
      try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.2 - handlers registrados'})); } catch(e){}
    } catch (error) {
      try { __plog('PANDORA_FATAL:handlers:' + JSON.stringify({name: error && error.name, message: error && error.message, stack: error && error.stack})); } catch(_){}
    }
    try {
      const __pandoraSource = ${JSON.stringify(injectedScript)};
      try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.3 - fonte len=' + __pandoraSource.length + ' hasBOOT5=' + (__pandoraSource.indexOf('BOOT 5 - IIFE iniciado') !== -1)})); } catch(e){}
      try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.4 - fonte head=' + __pandoraSource.slice(0, 200)})); } catch(e){}
      try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.5 - fonte tail=' + __pandoraSource.slice(-200)})); } catch(e){}
      try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.55 - antes do new Function'})); } catch(e){}
      let __pandoraFn;
      try {
        __pandoraFn = new Function(__pandoraSource);
        try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.56 - depois do new Function typeof=' + (typeof __pandoraFn)})); } catch(e){}
      } catch (parseErr) {
        try { __plog('PANDORA_FATAL:new-Function-parse:' + JSON.stringify({name: parseErr && parseErr.name, message: parseErr && parseErr.message, stack: parseErr && parseErr.stack})); } catch(_){}
        // Diag 2026-08-09: pega a linha EXATA do erro (via parseErr.stack,
        // formato "at <anonymous>:LINHA:COLUNA") e loga ela + as vizinhas —
        // sem isso só sabíamos "deu erro de sintaxe em algum lugar dos
        // 62KB do script", impossível de saber onde sem adivinhar.
        try {
          const m = String(parseErr && parseErr.stack || '').match(/<anonymous>:(\\d+):(\\d+)/);
          if (m) {
            const linhaAlvo = parseInt(m[1], 10);
            const linhas = __pandoraSource.split('\\n');
            const ini = Math.max(0, linhaAlvo - 3);
            const fim = Math.min(linhas.length, linhaAlvo + 2);
            const trecho = linhas.slice(ini, fim).map((l, i) => (ini + i + 1) + (ini + i + 1 === linhaAlvo ? ' >>> ' : ': ') + l).join(' | ');
            __plog('PANDORA_FATAL:parse-context:' + JSON.stringify({ linha: linhaAlvo, coluna: m[2], trecho: trecho.slice(0, 1500) }));
          }
        } catch(_){}
        return 'pandora-wrapper-parse-err';
      }
      try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.57 - antes da chamada da função'})); } catch(e){}
      let __pandoraResult;
      try {
        __pandoraResult = __pandoraFn();
        try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.58 - depois da chamada typeof=' + (typeof __pandoraResult)})); } catch(e){}
      } catch (invokeErr) {
        try { __plog('PANDORA_FATAL:invoke-iife:' + JSON.stringify({name: invokeErr && invokeErr.name, message: invokeErr && invokeErr.message, stack: invokeErr && invokeErr.stack})); } catch(_){}
        return 'pandora-wrapper-invoke-err';
      }
      try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.7 - IIFE invocada typeof=' + (typeof __pandoraResult)})); } catch(e){}
      if (__pandoraResult && typeof __pandoraResult.then === 'function') {
        __pandoraResult.then(
          (v) => { try { __plog('__PANDORA_REG__' + JSON.stringify({kind:'log',msg:'BOOT 4.8 - IIFE resolved typeof=' + (typeof v)})); } catch(e){} },
          (err) => {
            try { __plog('PANDORA_FATAL:iife-rejected:' + JSON.stringify({name: err && err.name, message: err && err.message, stack: err && err.stack})); } catch(_){}
            __pandoraReport('BOOT 4.8 - IIFE rejected', err);
          }
        );
      }
      return 'pandora-wrapper-ok';
    } catch (error) {
      try { __plog('PANDORA_FATAL:outer-catch:' + JSON.stringify({name: error && error.name, message: error && error.message, stack: error && error.stack})); } catch(_){}
      __pandoraReport('BOOT exceção sync/parse no código injetado', error);
      return 'pandora-wrapper-err';
    }
  })();`;
}



function buildInjectionScript(cred, opts = {}) {
  const payload = JSON.stringify(cred);
  const optsPayload = JSON.stringify({
    depMin: Number(opts.depMin) || 0,
    depMax: Number(opts.depMax) || 0,
    depositValue: Number(opts.depositValue) || 0,
    closeAds: !!opts.closeAds,
    senhaSaque: String(opts.senhaSaque || "").replace(/\D/g, "").slice(0, 6),
    phonePixKey: String(opts.phonePixKey || "").trim(),
  });
  const injectedScript = `/* BOOT 4.9 - antes da IIFE */
/* Bloqueio de fullscreen (PG Soft / slots) — precisa rodar ANTES da IIFE */
(() => {
  try {
    if (window.__pandoraNoFullscreen) return; window.__pandoraNoFullscreen = true;
    const desativarFullscreen = () => {
      const ignorar = () => Promise.resolve();
      if (typeof Element !== 'undefined') {
        try { Element.prototype.requestFullscreen = ignorar; } catch(e){}
        try { Element.prototype.webkitRequestFullscreen = ignorar; } catch(e){}
        try { Element.prototype.mozRequestFullScreen = ignorar; } catch(e){}
        try { Element.prototype.msRequestFullscreen = ignorar; } catch(e){}
      }
      if (typeof document !== 'undefined' && document.documentElement) {
        try { document.documentElement.requestFullscreen = ignorar; } catch(e){}
        try { document.documentElement.webkitRequestFullscreen = ignorar; } catch(e){}
        try { document.documentElement.mozRequestFullScreen = ignorar; } catch(e){}
        try { document.documentElement.msRequestFullscreen = ignorar; } catch(e){}
      }
    };
    desativarFullscreen();
    window.addEventListener('DOMContentLoaded', desativarFullscreen);
    window.addEventListener('load', desativarFullscreen);
  } catch(e){}
})();
(async () => {
  /* BOOT 4.95 - primeira linha da IIFE */
  /* Canal de log à prova de hijack: muitos cassinos (PG SOFT/Saas Lobby)
     sobrescrevem console.log no boot do app, fazendo nossos markers
     __PANDORA_REG__ desaparecerem. Abrimos um iframe sandbox same-origin
     e roubamos o console.log dele, que o site da página de fora não tocou. */
  if (!window.__pandoraRawLog) {
    try {
      const ifr = document.createElement('iframe');
      ifr.style.cssText = 'display:none!important;width:0;height:0;border:0;position:absolute;left:-9999px;top:-9999px';
      (document.documentElement || document.body).appendChild(ifr);
      const cw = ifr.contentWindow;
      if (cw && cw.console && typeof cw.console.log === 'function') {
        window.__pandoraRawLog = cw.console.log.bind(cw.console);
      }
    } catch (e) {}
    if (typeof window.__pandoraRawLog !== 'function') {
      // Fallback: tenta restaurar via Object.getOwnPropertyDescriptor do prototype.
      try {
        const proto = Object.getPrototypeOf(console);
        const desc = proto && Object.getOwnPropertyDescriptor(proto, 'log');
        if (desc && typeof desc.value === 'function') window.__pandoraRawLog = desc.value.bind(console);
      } catch (e) {}
    }
    if (typeof window.__pandoraRawLog !== 'function') {
      window.__pandoraRawLog = console.log.bind(console);
    }
  }
  // Mesmo canal duplo do __plog acima (buildSafeInjectionWrapper) — ver
  // comentário lá. window.__pandoraRegSignal só existe no Chrome real.
  const __rawLogRaw = window.__pandoraRawLog;
  const __rawLog = function(msg) {
    try { __rawLogRaw(msg); } catch (e) {}
    try { if (typeof window.__pandoraRegSignal === 'function') window.__pandoraRegSignal(msg); } catch (e) {}
  };
  try { __rawLog('__PANDORA_REG__' + JSON.stringify({ kind:'log', msg:'BOOT 4.96 - IIFE entrou no corpo (rawLog ativo)' })); } catch (e) {}
  const bootLog = (msg, extra) => { try { __rawLog('__PANDORA_REG__' + JSON.stringify(Object.assign({ kind:'log', msg }, extra || {}))); } catch (e) {} };
  bootLog('BOOT 5 - IIFE iniciado');
  bootLog('BOOT 6 - URL atual ' + location.href);
  bootLog('BOOT 7 - readyState atual ' + document.readyState);
  if (window.__pandoraReg) { bootLog('BOOT 5.1 - IIFE ignorado por guard window.__pandoraReg'); return; }

  window.__pandoraReg = true;
  if (!window.__pandoraWindowId) {
    try { window.__pandoraWindowId = 'WIN-' + Math.floor(Math.random() * 9000 + 1000); } catch { window.__pandoraWindowId = 'WIN-0000'; }
  }
  const WIN = window.__pandoraWindowId;
  const cred = ${payload};
  const opts = ${optsPayload};
  const log = (...a) => { try { __rawLog('__PANDORA_REG__' + JSON.stringify({ kind:'log', msg: '[' + WIN + '] ' + a.join(' ') })); } catch (e) {} };
  const done = (status, extra) => { try { __rawLog('__PANDORA_REG__' + JSON.stringify(Object.assign({ kind:'done', status, login: cred.login, senha: cred.senha, celular: cred.celular, win: WIN }, extra||{}))); } catch (e) {} };
  const created = (extra) => { try { __rawLog('__PANDORA_REG__' + JSON.stringify(Object.assign({ kind:'created', status:'created', login: cred.login, senha: cred.senha, celular: cred.celular, win: WIN }, extra||{}))); } catch (e) {} };
  const submitted = (extra) => { try { __rawLog('__PANDORA_REG__' + JSON.stringify(Object.assign({ kind:'submitted', status:'submitted', login: cred.login, senha: cred.senha, celular: cred.celular, win: WIN }, extra||{}))); } catch (e) {} };
  const rejected = (extra) => { try { __rawLog('__PANDORA_REG__' + JSON.stringify(Object.assign({ kind:'rejected', login: cred.login, senha: cred.senha, celular: cred.celular, win: WIN }, extra||{}))); } catch (e) {} };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));

  // ---------- waitForReady removido: runRegister inicia imediatamente ----------
  // (em 1.1.31 ele estava bloqueando o fluxo da tela inicial em algumas janelas)


  // ---------- waitForElement: polling robusto ----------
  const waitForElement = async (selectorOrFn, timeoutMs = 30000, label = '') => {
    const desc = typeof selectorOrFn === 'string' ? selectorOrFn : (label || 'fn');
    log('DIAG WAIT selector=' + desc);
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
      let el = null;
      try {
        el = typeof selectorOrFn === 'string'
          ? document.querySelector(selectorOrFn)
          : selectorOrFn();
      } catch {}
      if (el) { log('DIAG WAIT encontrado ' + desc); return el; }
      await sleep(250);
    }
    log('DIAG WAIT timeout ' + desc);
    return null;
  };

  log('DIAG 1/13: Script injetado com sucesso');
  log('DIAG 2/13: URL atual detectada=' + location.href + ' readyState=' + document.readyState);

  const visible = el => {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 3 || r.height < 3) return false;
    const s = getComputedStyle(el);
    return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity) > 0.05;
  };
  const keepHomeWhenDepositEmpty = (reason = '') => {
    const hasDepositConfigured = () => (Number(opts && opts.depMin) || 0) > 0 || (Number(opts && opts.depMax) || 0) > 0 || (Number(opts && opts.depositValue) || 0) > 0;
    if (hasDepositConfigured()) return;
    const clickSafe = (el) => { try { el.scrollIntoView({ block:'center' }); } catch {} try { el.click(); } catch {} };
    const findByText = (regex) => Array.from(document.querySelectorAll('a, button, [role=button], li, div, span'))
      .filter(visible).find(el => regex.test((el.textContent || '').trim()));
    const findHomeTarget = () => {
      const el = findByText(/^(in[íi]cio|home)$/i);
      return el && ((typeof el.closest === 'function' && el.closest('a, button, [role=button], li')) || el);
    };
    const depositOpen = () => {
      if (document.querySelector('#depositSubmitClick')) return true;
      const input = Array.from(document.querySelectorAll('input')).filter(visible).find(i => /m[íi]nimo|minimo|m[áa]ximo|maximo|valor|amount|recarga|recharge/i.test((i.placeholder || '') + ' ' + (i.name || '') + ' ' + (i.id || '')));
      if (input) return true;
      const txt = (document.body.innerText || '').toLowerCase();
      if (!/(dep[óo]sito|depositar|recarregar|recarga)/i.test(txt)) return false;
      const amounts = Array.from(document.querySelectorAll('button, [role=button], li, div, span, a')).filter(visible).filter(el => /^\s*(r\$\s*)?\d+([,.]\d{1,2})?\s*$/.test((el.textContent || '').trim()));
      return amounts.length >= 2;
    };
    let tries = 0;
    const tick = () => {
      tries++;
      try {
        if (depositOpen()) {
          const close = Array.from(document.querySelectorAll('.ui-dialog__close, .el-dialog__close, .close, [class*="close"], [aria-label*="lose" i], [aria-label*="echar" i]')).filter(visible)[0];
          if (close) clickSafe(close);
          const home = findHomeTarget();
          if (home) clickSafe(home); else try { history.back(); } catch {}
          log('DIAG DEPOSITO SKIP - tela de depósito detectada e Home restaurada ' + reason);
        }
      } catch {}
      if (tries < 40) setTimeout(tick, 250);
    };
    tick();
  };
  const describeEl = (el) => {
    if (!el) return 'null';
    try {
      const bits = [
        el.tagName && el.tagName.toLowerCase(),
        el.id ? '#' + el.id : '',
        el.getAttribute && el.getAttribute('data-input-name') ? '[data-input-name=' + el.getAttribute('data-input-name') + ']' : '',
        el.name ? '[name=' + el.name + ']' : '',
        el.type ? '[type=' + el.type + ']' : '',
        el.placeholder ? '[ph=' + el.placeholder + ']' : '',
      ].filter(Boolean);
      return bits.join('');
    } catch { return 'element'; }
  };
  const dispatchValueEvents = (el, label, inputType = 'insertReplacementText', data = null) => {
    const events = [];
    try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles: true, cancelable: true, composed: true, inputType, data })); events.push('beforeinput'); } catch {}
    try { el.dispatchEvent(new InputEvent('input', { bubbles: true, composed: true, inputType, data })); events.push('input'); } catch {
      try { el.dispatchEvent(new Event('input', { bubbles: true, composed: true })); events.push('input'); } catch {}
    }
    try { el.dispatchEvent(new Event('change', { bubbles: true, composed: true })); events.push('change'); } catch {}
    try { el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true })); events.push('keyup'); } catch {}
    if (label) log('runRegister: evento disparado ' + label + ' -> ' + events.join(','));
  };
  const setVal = (el, v, { clearFirst = true, doBlur = true, label = '' } = {}) => {
    const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    try { el.focus(); } catch {}
    if (clearFirst) {
      setter.call(el, '');
      dispatchValueEvents(el, label ? label + ' limpar' : '', 'deleteContentBackward', null);
    }
    setter.call(el, v);
    dispatchValueEvents(el, label, 'insertReplacementText', String(v));
    if (label) log('runRegister: valor inserido ' + label + ' len=' + String(v || '').length + ' atualLen=' + String(el.value || '').length);
    if (doBlur) { try { el.blur(); } catch {} }
  };
  const ctxOf = (i) => {
    const parts = [
      i.name, i.id, i.placeholder, i.type,
      i.getAttribute('aria-label'),
      i.getAttribute('autocomplete'),
      i.closest('label')?.innerText,
      i.previousElementSibling?.innerText,
      i.parentElement?.innerText?.slice(0, 80),
      i.parentElement?.parentElement?.querySelector('label, span, div')?.innerText?.slice(0, 80),
    ];
    return parts.filter(Boolean).join(' | ').toLowerCase();
  };
  const allTextInputs = () => $$('input, textarea').filter(i => {
    const t = (i.type || '').toLowerCase();
    return !['hidden','submit','button','checkbox','radio','file','image','reset'].includes(t);
  });
  const inputSummary = (i, idx) => {
    try {
      return '#' + idx
        + ' visible=' + visible(i)
        + ' type=' + (i.type || '')
        + ' name=' + (i.name || '')
        + ' id=' + (i.id || '')
        + ' placeholder=' + (i.placeholder || '')
        + ' class=' + (typeof i.className === 'string' ? i.className : '')
        + ' data-input-name=' + (i.getAttribute('data-input-name') || '')
        + ' valueLen=' + String(i.value || '').length;
    } catch (e) { return '#' + idx + ' summary-error=' + (e && e.message); }
  };
  const logInputInventory = (prefix = 'DIAG') => {
    const inputs = allTextInputs();
    log(prefix + ' 4/13: Quantidade de inputs encontrados=' + inputs.length + ' visiveis=' + inputs.filter(visible).length);
    log(prefix + ' 5/13: Lista completa dos inputs encontrados:');
    inputs.forEach((i, idx) => log(prefix + ' input ' + inputSummary(i, idx)));
    return inputs;
  };
  let findFieldsLogLast = 0;
  const shouldLogFieldScan = () => {
    const now = Date.now();
    if (now - findFieldsLogLast < 2500) return false;
    findFieldsLogLast = now;
    return true;
  };
  const findFields = () => {
    // 1) Caminho rápido: seletores exatos do site alvo (data-input-name)
    const byName = (n) => $$('input[data-input-name="' + n + '"], textarea[data-input-name="' + n + '"]').filter(visible)[0];
    const byLoose = (rx) => $$('input, textarea').filter(visible).find(i => rx.test(((i.getAttribute('data-input-name') || '') + ' ' + (i.name || '') + ' ' + (i.id || '') + ' ' + (i.autocomplete || '') + ' ' + (i.placeholder || '')).toLowerCase()));
    const acctEx = byName('account') || byLoose(/\\b(account|username|user|login)\\b/);
    const p1Ex   = byName('userpass') || byLoose(/\\buserpass\\b/) || $$('input, textarea').filter(visible).find(i => /pass|senha|password/i.test(ctxOf(i)) && !/confirm|repet|novamente|de novo/.test(ctxOf(i)));
    const p2Ex   = byName('confirmPassword') || byLoose(/confirm.*(pass|senha)|repet.*senha|novamente/);
    const phEx   = byName('phone') || byLoose(/\\b(phone|mobile|tel|celular|telefone|whatsapp)\\b/);
    // Pedido do usuário 2026-08-19 (versopg.vip): esse site não pede
    // telefone no cadastro, pede "realName" ("Introduza o seu nome real")
    // no lugar. phone e realName são ALTERNATIVOS (cada site pede um ou
    // outro, nunca os dois) — daí extraSlot em vez de exigir os dois juntos.
    const realEx = byName('realName') || byLoose(/real ?name|nome real|nome completo|full ?name/);
    const extraEx = phEx || realEx;
    if (acctEx && p1Ex && p2Ex && extraEx) {
      if (shouldLogFieldScan()) log('runRegister: seletores diretos encontrados account=' + describeEl(acctEx) + ' pass1=' + describeEl(p1Ex) + ' pass2=' + describeEl(p2Ex) + ' phone=' + describeEl(phEx) + ' realName=' + describeEl(realEx));
      return { acct: acctEx, pass1: p1Ex, pass2: p2Ex, phone: phEx, real: realEx };
    }
    // 2) Fallback heurístico genérico
    const inputs = $$('input, textarea').filter(visible).filter(i => {
      const t = (i.type || '').toLowerCase();
      return !['hidden','submit','button','checkbox','radio','file','image','reset'].includes(t);
    });
    const tagged = inputs.map(i => ({ i, c: ctxOf(i), t: (i.type||'').toLowerCase() }));
    const acct = tagged.find(x => /conta|usu[aá]rio|user(?!agent)|login|account|nome de usu/.test(x.c)
                                && !/email|e-?mail/.test(x.c)
                                && !/celular|telefone|phone|whatsapp/.test(x.c)
                                && !/senha|password/.test(x.c))
               // Campo combinado "Celular/E-mail/Conta" (5gbet.com, 2026-08-22):
               // menciona os três juntos num input só — as exclusões acima
               // derrubavam ele e o cadastro nunca achava o campo de conta.
               // Vale como conta (o guard phone!==acct impede sobrescrever).
               || tagged.find(x => /conta|account/.test(x.c)
                                 && /e-?mail|email/.test(x.c)
                                 && /celular|telefone|phone|mobile/.test(x.c)
                                 && !/senha|password/.test(x.c));
    const passes = tagged.filter(x => x.t === 'password' || /senha|password|userpass|confirmpassword/.test(x.c));
    let pass1 = passes.find(x => !/confirm|repet|novamente|de novo/.test(x.c)) || passes[0];
    let pass2 = passes.find(x => /confirm|repet|novamente|de novo/.test(x.c))
             || passes.find(x => x !== pass1);
    const phone = tagged.find(x => /celular|telefone|phone|whatsapp|mobile|cel\\b/.test(x.c));
    const real = tagged.find(x => /real ?name|nome real|nome completo|full ?name/.test(x.c) && x !== acct);
    if (shouldLogFieldScan()) log('runRegister: fallback campos total=' + inputs.length + ' account=' + describeEl(acct?.i) + ' pass1=' + describeEl(pass1?.i) + ' pass2=' + describeEl(pass2?.i) + ' phone=' + describeEl(phone?.i) + ' realName=' + describeEl(real?.i));
    return { acct: acct?.i, pass1: pass1?.i, pass2: pass2?.i, phone: phone?.i, real: real?.i };
  };
  const findRegisterButton = () => {
    // 1) Seletor exato do site alvo
    const exact = document.querySelector('#insideRegisterSubmitClick');
    if (exact && visible(exact)) return exact;
    // 2) Fallback heurístico
    const btns = $$('button, [role=button], input[type=submit], a').filter(visible);
    return btns.find(b => {
      const t = ((b.innerText || b.value || b.getAttribute('aria-label') || '') + '').toLowerCase().trim();
      if (!t || t.length > 40) return false;
      return /^(registr|cadastr|criar conta|sign\\s*up|inscrever|registar)/.test(t)
          || /(registr|cadastr|criar conta|sign\\s*up)/.test(t) && !/login|entrar|esqueci/.test(t);
    });
  };
  const fieldState = (el) => {
    try { return 'valueLen=' + String(el.value || '').length + ' disabled=' + !!el.disabled + ' readonly=' + !!el.readOnly + ' active=' + (document.activeElement === el); }
    catch { return 'state-unavailable'; }
  };
  const fillRegisterField = async (label, el, value) => {
    if (!el) { log('runRegister: campo NÃO encontrado ' + label); return false; }
    log('runRegister: campo encontrado ' + label + ' -> ' + describeEl(el) + ' ' + fieldState(el));
    try { el.scrollIntoView({ block: 'center' }); } catch {}
    try { el.click(); } catch {}
    setVal(el, value, { label });
    await sleep(10);
    if (String(el.value || '') === String(value)) return true;
    log('runRegister: valor não fixou em ' + label + ' após setter; retry digitado atualLen=' + String(el.value || '').length);
    try { el.focus(); } catch {}
    try {
      const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      setter.call(el, '');
      dispatchValueEvents(el, label + ' limpar-retry', 'deleteContentBackward', null);
      for (const ch of String(value).split('')) {
        const code = /\d/.test(ch) ? ('Digit' + ch) : ('Key' + ch.toUpperCase());
        const kc = /\d/.test(ch) ? (48 + Number(ch)) : ch.toUpperCase().charCodeAt(0);
        try { el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, key: ch, code, keyCode: kc, which: kc })); } catch {}
        try { el.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, cancelable: true, key: ch, code, keyCode: kc, which: kc, charCode: kc })); } catch {}
        setter.call(el, String(el.value || '') + ch);
        dispatchValueEvents(el, label + ' char', 'insertText', ch);
      }
      try { el.dispatchEvent(new Event('change', { bubbles: true, composed: true })); } catch {}
      log('runRegister: retry concluído ' + label + ' atualLen=' + String(el.value || '').length);
    } catch (e) { log('runRegister: erro preenchendo ' + label + ' -> ' + (e && e.message)); }
    return String(el.value || '').length > 0;
  };
  const waitForRegisterFieldsByMutation = async (timeoutMs = 90000) => {
    log('DIAG observer: aguardando campos visíveis via MutationObserver; readyState=' + document.readyState);
    let lastLog = 0;
    return await new Promise((resolve) => {
      let doneWait = false;
      let observer = null;
      const finish = (fields, reason) => {
        if (doneWait) return;
        doneWait = true;
        try { observer && observer.disconnect(); } catch {}
        log('DIAG observer: finalizado reason=' + reason);
        resolve(fields || findFields());
      };
      const scan = (reason) => {
        if (isNetworkErrorText(pageText())) {
          log('DIAG observer: erro de rede/proxy detectado; abortando cadastro');
          finish({ networkError: true }, reason + '-network-error');
          return;
        }
        const fields = findFields();
        const ready = !!(fields.acct && fields.pass1 && fields.pass2 && (fields.phone || fields.real));
        const now = Date.now();
        if (ready || now - lastLog > 5000) {
          lastLog = now;
          log('DIAG observer scan reason=' + reason + ' ready=' + ready + ' login=' + !!fields.acct + ' senha=' + !!fields.pass1 + ' confirmacao=' + !!fields.pass2 + ' telefone=' + !!fields.phone + ' nomeReal=' + !!fields.real);
          logInputInventory('DIAG observer');
        }
        if (ready) finish(fields, reason);
      };
      try {
        observer = new MutationObserver(() => scan('mutation'));
        observer.observe(document.documentElement || document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class','style','type','placeholder','name','id','data-input-name'] });
      } catch (e) { log('DIAG observer: erro ao iniciar=' + (e && e.message)); }
      scan('initial');
      const tick = setInterval(() => {
        if (doneWait) { clearInterval(tick); return; }
        scan('interval');
      }, 1000);
      setTimeout(() => {
        clearInterval(tick);
        finish(findFields(), 'timeout');
      }, timeoutMs);
    });
  };
  const pageText = () => (((document.body && document.body.innerText) || '') + ' ' + (document.title || '') + ' ' + location.href).toLowerCase();
  const isNetworkErrorText = txt => /upstream\s+error|err_tunnel_connection_failed|err_proxy_connection_failed|err_connection_(closed|reset|refused|timed_out)|bad\s+gateway|502\s+bad\s+gateway|proxy\s+error|t[uú]nel|tunnel|n[aã]o [ée] poss[ií]vel acessar|site can.?t be reached|this site can.?t be reached|connection timed out/.test(String(txt || '').toLowerCase());
  const isTaken = txt => /(usu[aá]rio|conta|login|nome|account).{0,30}(j[aá] (existe|cadastrad|em uso|usado)|existente|indispon[ií]vel|n[aã]o dispon[ií]vel|taken|in use|already|exists)/.test(txt)
                      || /(conta|account)\s+(j[aá]\s+)?(existe|exists|existente)/.test(txt)
                      || /escolha outro (nome|usu[aá]rio|login)/.test(txt);
  const isSuccess = txt => /(cadastrad[oa] com sucesso|registr(o|ad[oa]) (conclu|com sucesso)|bem.?vind[oa]|welcome|conta criada)/.test(txt);

  // ---------- MODO REGISTRO-ONLY (v1.1.24) ----------
  // Fluxos pós-cadastro (deposito/saque/addAccount/sessionStorage stage)
  // foram REMOVIDOS temporariamente para restaurar o preenchimento básico
  // da tela inicial. O parse-check do INNER falhava com SyntaxError neste
  // bloco; manter apenas runRegister garante INNER válido.

  log('DIAG 3/13: runRegister chamado url=' + (location.pathname + location.search) + ' readyState=' + document.readyState);
  logInputInventory('DIAG inicial');
  if (isNetworkErrorText(pageText())) {
    log('DIAG REGISTER abortado: Upstream/proxy error detectado antes do preenchimento');
    done('network-error', { cadastroStatus: 'network-error', site: location.href });
    return;
  }
  // BUG real 2026-08-09 (reportado pelo usuário: clicar em "Página Inicial"
  // numa conta JÁ registrada — mas que ainda não passou pelo PIX, então
  // win.__pandoraRegistrationFinished ainda não tinha sido ligada — fazia a
  // tela "atualizar um monte de vezes sozinha") — a lógica de recarregar se
  // os campos de cadastro não aparecem em 3s (abaixo) não sabia distinguir
  // "campos ainda não renderizaram" de "não tem campo nenhum porque já
  // estou logado". Pedido explícito do usuário: NUNCA recarregar fora da
  // criação da conta. Checa sinais de página já logada (barra inferior
  // Começar/Perfil/Depósito + nenhum campo de conta) e pula o cadastro
  // inteiro, sem nenhum reload, se já estiver logado.
  const jaLogado = () => {
    try {
      const t = ((document.body && document.body.innerText) || '').toLowerCase();
      const temBarraLogada = /come[çc]ar/.test(t) && /perfil/.test(t) && /dep[óo]sito/.test(t);
      const semCampoDeConta = !document.querySelector('input[data-input-name="account"], textarea[data-input-name="account"]');
      return temBarraLogada && semCampoDeConta;
    } catch (e) { return false; }
  };
  // Pedido do usuário 2026-08-19 (versopg.vip): jaLogado() checava só UMA
  // VEZ, instantaneamente, no exato momento em que o script começa — nesse
  // site o modal de cadastro (confirmado com print real do usuário: Conta/
  // Senha/Confirmar senha/Nome real) leva uma fração de segundo pra
  // renderizar, e a barra "Começar/Perfil/Depósito" já existe no layout por
  // baixo dele — dava falso positivo de "já logado" antes do modal abrir,
  // abortando o cadastro de um jeito que "nada acontece" pro usuário. Espera
  // até 2s, checando a cada 300ms — só considera logado se continuar sem
  // campo de conta no fim da espera (dá tempo do modal renderizar).
  // Pedido do usuário 2026-08-19 (2ª rodada, versopg.vip): mesmo com a
  // espera de 2s acima, o modal continuava sem abrir sozinho nesse site —
  // diferente de outros domínios da mesma plataforma, aqui o cadastro exige
  // clicar num botão de abertura (ex.: "Cadastro"/"Registro") antes do
  // modal aparecer. Clica UMA VEZ nesse botão (se existir e visível) antes
  // de concluir "já logado" — se realmente estiver logado, esse botão nem
  // existe na tela (é substituído por saldo/perfil), então o clique é
  // seguro (não acha nada, não faz nada).
  const clicarAbrirCadastro = () => {
    try {
      const nodes = Array.from(document.querySelectorAll('button, a, div, span'));
      // "começar"/"entrar" adicionados 2026-08-19 (2ª tentativa, versopg.vip)
      // — a 1ª tentativa (só cadastr/registr/criar conta) não achou nada;
      // "começar" é a mesma palavra usada como sinal (impreciso) de já
      // logado, forte candidato a ser o próprio botão que abre o modal.
      const alvo = nodes.find((el) => {
        if (!visible(el)) return false;
        const t = ((el.textContent || '') + '').trim().toLowerCase();
        return /^(cadastr[oa]?|registr[oa]?|criar conta|sign\s*up|come[çc]ar|entrar)$/i.test(t);
      });
      log('runRegister: clicarAbrirCadastro alvo=' + (alvo ? describeEl(alvo) : 'NENHUM'));
      if (alvo) { alvo.click(); return true; }
    } catch (e) {}
    return false;
  };
  let jaLogadoConfirmado = jaLogado();
  if (jaLogadoConfirmado) {
    const dlLogado = Date.now() + 2000;
    while (Date.now() < dlLogado && jaLogadoConfirmado) {
      await sleep(300);
      jaLogadoConfirmado = jaLogado();
    }
  }
  // Pedido do usuário 2026-08-19 (3ª rodada, versopg.vip): o clique em
  // clicarAbrirCadastro() dividia o MESMO orçamento de 2s da espera acima —
  // quando o clique só acontecia perto do fim (log confirmado: alvo=div
  // achado e clicado, mas só sobravam ~400ms pro modal renderizar depois),
  // nunca dava tempo. Agora, se ainda parecer "já logado" depois dos 2s
  // normais, tenta clicar e dá um orçamento PRÓPRIO de até 2s só pro modal
  // aparecer depois do clique — antes de desistir de vez.
  if (jaLogadoConfirmado) {
    const cliquei = clicarAbrirCadastro();
    if (cliquei) {
      const dlPosClique = Date.now() + 2000;
      while (Date.now() < dlPosClique && jaLogadoConfirmado) {
        await sleep(300);
        jaLogadoConfirmado = jaLogado();
      }
    }
  }
  if (jaLogadoConfirmado) {
    log('DIAG REGISTER pulado: página já logada (barra Começar/Perfil/Depósito presente, sem campo de conta, confirmado após 2s + tentativa de abrir cadastro) — nunca recarrega aqui.');
    done('already-logged-in', { cadastroStatus: 'already-logged-in', site: location.href });
    return;
  }
  // Pedido do usuário 2026-08-09: "de 10 telas, 2 não apareceu a tela de
  // preencher os dados... faça com que se não aparecer em até 3 segundos a
  // página atualiza pra aparecer" — antes esperava até 90s DIRETO pelos
  // campos, sem nunca recarregar; se o formulário simplesmente não
  // renderizasse nessa janela específica (falha de render pontual do site,
  // já vista acontecer em algumas janelas de um lote), ficava só esperando
  // os 90s inteiros, quase sempre sem sucesso. Agora tenta rápido (3s) —
  // se não achar, recarrega a página: o Node reinjeta esse script inteiro
  // sozinho assim que o "did-finish-load" do reload disparar (ver
  // attachAutoRegister mais abaixo, já funciona pra QUALQUER navegação).
  // Limite de 3 recarregamentos por essa razão específica — evita loop
  // infinito se o site estiver genuinamente fora do ar; depois disso volta
  // a esperar os 90s normais como antes (ainda tenta, só não recarrega mais).
  // sessionStorage (não window.*) porque location.reload() apaga TODO o
  // estado da página — um contador em window sempre voltaria a 0 depois de
  // recarregar, nunca respeitando o limite de tentativas. sessionStorage
  // sobrevive a reload (mesma aba/origem), exatamente o que precisa aqui.
  const MAX_RELOAD_ATTEMPTS = 3;
  let reloadAttempts = 0;
  try { reloadAttempts = parseInt(sessionStorage.getItem('__pandoraRegReloadAttempts') || '0', 10) || 0; } catch (e) {}
  let fields;
  if (reloadAttempts < MAX_RELOAD_ATTEMPTS) {
    fields = await waitForRegisterFieldsByMutation(3000);
    const gotAll = fields && fields.acct && fields.pass1 && fields.pass2 && (fields.phone || fields.real);
    if (!gotAll && !(fields && fields.networkError)) {
      reloadAttempts++;
      try { sessionStorage.setItem('__pandoraRegReloadAttempts', String(reloadAttempts)); } catch (e) {}
      log('runRegister: campos não apareceram em 3s (tentativa ' + reloadAttempts + '/' + MAX_RELOAD_ATTEMPTS + ') — recarregando página');
      try { bootLog('BOOT 3.9 - recarregando por falta de campos em 3s', { tentativa: reloadAttempts }); } catch (e) {}
      try { location.reload(); } catch (e) {}
      return;
    }
  } else {
    fields = await waitForRegisterFieldsByMutation(90000);
  }
  if (fields && fields.networkError) {
    done('network-error', { cadastroStatus: 'network-error', site: location.href });
    return;
  }
  log('DIAG 6/13: Campo de login localizado=' + (!!(fields && fields.acct)) + ' ' + describeEl(fields && fields.acct));
  log('DIAG 7/13: Campo de senha localizado=' + (!!(fields && fields.pass1)) + ' ' + describeEl(fields && fields.pass1));
  log('DIAG 8/13: Campo de confirmação localizado=' + (!!(fields && fields.pass2)) + ' ' + describeEl(fields && fields.pass2));
  log('DIAG 9/13: Campo de telefone localizado=' + (!!(fields && fields.phone)) + ' ' + describeEl(fields && fields.phone));
  log('DIAG 9b/13: Campo de nome real localizado=' + (!!(fields && fields.real)) + ' ' + describeEl(fields && fields.real));
  if (!fields || !fields.acct || !fields.pass1 || !fields.pass2 || !(fields.phone || fields.real)) {
    log('runRegister: campos incompletos após timeout account=' + !!(fields && fields.acct) + ' pass1=' + !!(fields && fields.pass1) + ' pass2=' + !!(fields && fields.pass2) + ' phone=' + !!(fields && fields.phone) + ' real=' + !!(fields && fields.real));
    done('no-modal'); return;
  }
  log('DIAG REGISTER 1 - campos localizados');

  const login = cred.login;
  fields = findFields();
  if (!fields.acct) { done('lost-modal'); return; }

  await fillRegisterField('login', fields.acct, login);
  log('DIAG REGISTER 2 - login preenchido valor="' + String(fields.acct.value || '') + '"');

  await fillRegisterField('senha', fields.pass1, cred.senha);
  log('DIAG REGISTER 3 - senha preenchida len=' + String(fields.pass1.value || '').length);

  await fillRegisterField('confirmarSenha', fields.pass2, cred.senha);
  log('DIAG REGISTER 4 - confirmação preenchida len=' + String(fields.pass2.value || '').length);

  // Pedido do usuário 2026-08-19 (versopg.vip): site sem campo de telefone,
  // com "realName" no lugar — preenche o que existir (nunca os dois).
  // Pedido do usuário 2026-08-20 (821win.win): site tem UM campo só pra
  // "Número do Celular/Conta" (data-input-name="account") — o heurístico
  // de telefone (procura "celular"/"telefone" no placeholder) reconhece
  // esse MESMO campo como fields.phone também (fields.phone === fields.acct).
  // Sem essa checagem, preenchia login normal e depois SOBRESCREVIA com o
  // celular no mesmo campo. Só preenche telefone se for um campo diferente.
  if (fields.phone && fields.phone !== fields.acct) {
    await fillRegisterField('telefone', fields.phone, cred.celular);
    log('DIAG REGISTER 5 - telefone preenchido valor="' + String(fields.phone.value || '') + '"');
  } else if (fields.real) {
    await fillRegisterField('nomeReal', fields.real, cred.nomeReal);
    log('DIAG REGISTER 5 - nome real preenchido valor="' + String(fields.real.value || '') + '"');
    // Pedido do usuário 2026-08-19: "cadastrar chaves PIX dá erro 'o nome
    // real do membro não corresponde'" — causa raiz real: pixFlowV2.cjs já
    // lia __pandoraRegisteredRealName do localStorage pra usar o MESMO nome
    // do cadastro, mas esse valor NUNCA era gravado aqui (só o lado de
    // leitura existia) — sempre caía no fallback de nome aleatório, que não
    // bate com o nome real usado no cadastro. Grava agora.
    try { localStorage.setItem('__pandoraRegisteredRealName', String(cred.nomeReal || '')); } catch {}
  }
  // Dispara input/change/blur em todos os campos para habilitar validadores (Vue/Vuetify)
  try {
    for (const f of [fields.acct, fields.pass1, fields.pass2, fields.phone, fields.real]) {
      try { f.dispatchEvent(new Event('input', { bubbles:true })); } catch {}
      try { f.dispatchEvent(new Event('change', { bubbles:true })); } catch {}
      try { f.dispatchEvent(new Event('blur', { bubbles:true })); } catch {}
    }
  } catch {}
  await sleep(250);

  const isBtnDisabled = (b) => {
    if (!b) return true;
    if (b.disabled) return true;
    const ad = (b.getAttribute('aria-disabled') || '').toLowerCase();
    if (ad === 'true') return true;
    const cls = ((b.className || '') + '');
    if (/(^|\s)(is-disabled|ui-button--disabled|disabled)(\s|$)/.test(cls)) return true;
    return false;
  };
  const clickBtn = async (b) => {
    // Estratégia humanizada: usa sendInputEvent (mouse físico do Chromium) via IPC.
    // Vantagens: preserva event.target/closest nativos, dispara handlers de framework
    // (Vue/Geetest) corretamente e não é detectado como "clique sintético".
    let el = null;
    try {
      el = document.querySelector('button[type="submit"]');
    } catch {}
    if (!el) {
      try {
        el = Array.from(document.querySelectorAll('button')).find((x) => {
          const t = (x.textContent || '').trim();
          return /cadastrar|registrar|register|sign\s*up/i.test(t);
        }) || null;
      } catch {}
    }
    if (!el) el = b;
    try {
      while (el && !(el instanceof HTMLElement) && el.parentNode) el = el.parentNode;
    } catch {}
    if (!el || !(el instanceof HTMLElement)) return;
    try { el.scrollIntoView({ block: 'center', behavior: 'instant' }); } catch { try { el.scrollIntoView({ block: 'center' }); } catch {} }
    // Aguarda o scroll/animação assentar (rect estável)
    await new Promise((r) => setTimeout(r, 80));

    // Calcula centro do botão + jitter humano (não clica sempre no pixel exato)
    let cx = 0, cy = 0;
    try {
      const r = el.getBoundingClientRect();
      if (r && r.width > 0 && r.height > 0) {
        const jitterX = (Math.random() - 0.5) * Math.min(r.width * 0.4, 14);
        const jitterY = (Math.random() - 0.5) * Math.min(r.height * 0.4, 10);
        cx = r.left + r.width / 2 + jitterX;
        cy = r.top + r.height / 2 + jitterY;
      }
    } catch {}

    try { el.focus(); } catch {}

    // Caminho preferido: clique humanizado nativo via main process (IPC)
    if (cx > 0 && cy > 0 && typeof window.__pandoraHumanClick === 'function') {
      try {
        const res = await window.__pandoraHumanClick(cx, cy);
        if (res && res.ok) return;
      } catch {}
    }
    // Fallback: click nativo do HTMLElement (preserva closest/target)
    try { HTMLElement.prototype.click.call(el); } catch {}
  };
  const isRegisterSubmitting = (b) => {
    if (!b) return false;
    try {
      if (b.disabled) return true;
      const cls = String(b.className || '');
      if (/is-loading|loading|is-disabled|disabled|spinner|ui-button--loading|van-button--loading/i.test(cls)) return true;
      const aria = b.getAttribute && ((b.getAttribute('aria-busy') || '') + ' ' + (b.getAttribute('aria-disabled') || ''));
      if (aria && /true|1/i.test(aria)) return true;
      if (b.querySelector && b.querySelector('.ui-loading, .is-loading, .spinner, [class*="loading"], [class*="spinner"], svg.animate-spin')) return true;
      const txt = (b.textContent || '').trim().toLowerCase();
      if (/^(carregando|loading|enviando|aguarde|processando|cadastrando|registrando)\.{0,3}$/.test(txt)) return true;
    } catch {}
    return false;
  };
  const hasCaptchaChallenge = () => {
    try {
      if (document.getElementById('__pandora_captcha_solving_overlay__')) return true;
      if (window.__pandoraGeetest && window.__pandoraGeetest.ready) return true;
      if (window.__pandoraGeetestSolvedAt && Date.now() - window.__pandoraGeetestSolvedAt < 8000) return true;
      const sels = '#__pandora_captcha_solving_overlay__, .geetest_panel, .geetest_panel_box, .geetest_box, .geetest_holder, .geetest_box_wrap, .geetest_panelshowclick, .geetest_widget, iframe[src*="geetest"], iframe[src*="gcaptcha"], iframe[src*="gsensebot"], iframe[src*="geevisit"]';
      return !!Array.from(document.querySelectorAll(sels)).find(visible);
    } catch { return false; }
  };

  // Aguarda botão habilitar (até 8s)
  let btn = null;
  const tBtn0 = Date.now();
  while (Date.now() - tBtn0 < 8000) {
    btn = findRegisterButton();
    if (btn && !isBtnDisabled(btn)) break;
    await sleep(150);
  }
  if (!btn) btn = findRegisterButton();
  if (!btn) { log('DIAG REGISTER 6 - botão NÃO localizado'); done('no-button'); return; }
  log('DIAG REGISTER 6 - botão localizado -> ' + describeEl(btn) + ' disabled=' + isBtnDisabled(btn));

  // Ouve o evento pandora-geetest-solved e re-clica o botão Cadastrar
  // imediatamente após o captcha passar. Muitos sites travam o botão em
  // "Cadastrando..." porque exigem um NOVO clique após o widget retornar.
  // Sem esse re-clique, o auto-register só destrava após 5s+ de detecção
  // de stuck. Throttle de 800ms para não disparar várias vezes seguidas.
  try {
    if (!window.__pandoraReclickOnCaptcha) {
      window.__pandoraReclickOnCaptcha = true;
      let lastReclick = 0;
      const onSolved = () => {
        const now = Date.now();
        if (now - lastReclick < 800) return;
        lastReclick = now;
        log('DIAG REGISTER captcha resolvido -> re-clicando Cadastrar');
        setTimeout(async () => {
          try {
            const nb = findRegisterButton();
            if (!nb) return;
            // Destrava se o site marcou loading/disabled
            try { nb.disabled = false; } catch {}
            try { nb.removeAttribute('disabled'); } catch {}
            try { nb.removeAttribute('aria-disabled'); } catch {}
            try { nb.removeAttribute('aria-busy'); } catch {}
            await clickBtn(nb);
          } catch {}
        }, 250);
      };
      try { window.addEventListener('pandora-geetest-solved', onSolved, true); } catch {}
    }
  } catch {}

  // Até 3 tentativas de clique, dando tempo para o site se recuperar após o Captcha/Geetest
  let clicked = false;
  for (let i = 0; i < 3; i++) {
    await clickBtn(btn);
    log('DIAG REGISTER 7 - clique tentativa ' + (i + 1));
    await sleep(500);
    const afterClickBtn = findRegisterButton() || btn;
    if (isRegisterSubmitting(afterClickBtn) || hasCaptchaChallenge()) { clicked = true; break; }
    const f2 = findFields();
    if (!f2.acct || !f2.pass1) { clicked = true; break; }
    const txt2 = pageText();
    if (isTaken(txt2) || isSuccess(txt2)) { clicked = true; break; }
    const nb = findRegisterButton();
    if (nb) btn = nb;
  }
  if (!clicked) {
    log('DIAG REGISTER 7b - fallback: Enter no último campo');
    try {
      const ultimoCampo = fields.phone || fields.real;
      ultimoCampo.focus();
      ultimoCampo.dispatchEvent(new KeyboardEvent('keydown', { bubbles:true, cancelable:true, key:'Enter', code:'Enter', keyCode:13, which:13 }));
      ultimoCampo.dispatchEvent(new KeyboardEvent('keyup', { bubbles:true, cancelable:true, key:'Enter', code:'Enter', keyCode:13, which:13 }));
    } catch {}
  }

  submitted({ cadastroStatus: 'submitted', site: location.href, criadoEm: new Date().toISOString() });

  // ---------- Aguarda confirmação do cadastro (sem PIN/saque) ----------
  const isBtnLoading = isRegisterSubmitting;
  const forceUnstickAndReclick = (b) => {
    if (!b) return false;
    try {
      // Remove estados de "loading/disabled" que prendem o botão sem ter enviado a requisição.
      try { b.disabled = false; } catch {}
      try { b.removeAttribute('disabled'); } catch {}
      try { b.removeAttribute('aria-disabled'); } catch {}
      try { b.removeAttribute('aria-busy'); } catch {}
      try {
        const cls = String(b.className || '');
        const cleaned = cls.split(/\s+/).filter(c => !/loading|spinner|disabled|busy/i.test(c)).join(' ');
        if (cleaned !== cls) b.className = cleaned;
      } catch {}
      // Remove spinners internos que bloqueiam o clique
      try {
        b.querySelectorAll('.ui-loading, .is-loading, .spinner, [class*="loading"], [class*="spinner"], svg.animate-spin')
          .forEach(n => { try { n.remove(); } catch {} });
      } catch {}
    } catch {}
    try { Promise.resolve(clickBtn(b)).catch(()=>{}); return true; } catch { return false; }
  };
  const stuckReload = () => {
    let retry = 0;
    try { retry = parseInt(sessionStorage.getItem('pandoraStuckRetry') || '0', 10) || 0; } catch {}
    if (retry >= 6) { log('DIAG REGISTER stuck -> limite de reload atingido'); return false; }
    try { sessionStorage.setItem('pandoraStuckRetry', String(retry + 1)); } catch {}
    try { sessionStorage.setItem('pandoraForceNewCredentials', String(Date.now())); } catch {}
    try { done('stuck-reload', { cadastroStatus: 'stuck-reload', site: location.href, retry: retry + 1 }); } catch {}
    log('DIAG REGISTER stuck (botão cadastrar travado) -> reload n=' + (retry + 1));
    try { setTimeout(() => { try { location.reload(); } catch {} }, 300); } catch {}
    return true;
  };
  const captchaActive = hasCaptchaChallenge;
  const waitCadastroOk = async () => {
    const t0 = Date.now();
    let formGoneStreak = 0;
    let stuckStreak = 0;
    let lastCaptchaWaitLog = 0;
    // Pedido do usuário 2026-08-22: se a tela ficar presa no captcha (sem
    // resolver) por muito tempo, recarrega e preenche tudo de novo em vez de
    // esperar o timeout total de 150s. Marca quando o captcha ficou ativo de
    // forma contínua; zera quando o captcha some/resolve. Um captcha que resolve
    // antes do limite não é afetado (não recarrega no meio do solve).
    let captchaActiveSince = 0;
    const CAPTCHA_STUCK_MS = 45000;
    let lastSnapshot = 0;
    log('DBG waitCadastroOk: INICIO url=' + location.href);
    const snapshot = (reason) => {
      try {
        const nb = findRegisterButton();
        const f = findFields();
        const txt = pageText();
        const popups = Array.from(document.querySelectorAll('.ui-dialog, .el-dialog, .modal, [role="dialog"], [role="alertdialog"], [class*="dialog"], [class*="modal"], [class*="popup"]'))
          .filter(visible)
          .map(p => ((p.innerText || '').trim().slice(0, 80))).filter(Boolean);
        const state = {
          reason,
          elapsedMs: Date.now() - t0,
          url: location.href,
          readyState: document.readyState,
          btn: nb ? {
            desc: describeEl(nb),
            disabled: isBtnDisabled(nb),
            loading: isRegisterSubmitting(nb),
            text: (nb.textContent || '').trim().slice(0, 40),
          } : null,
          fields: { acct: !!f.acct, pass1: !!f.pass1, pass2: !!f.pass2, phone: !!f.phone },
          captchaActive: captchaActive(),
          geetestReady: !!(window.__pandoraGeetest && window.__pandoraGeetest.ready),
          geetestSolvedMsAgo: window.__pandoraGeetestSolvedAt ? (Date.now() - window.__pandoraGeetestSolvedAt) : null,
          networkErr: isNetworkErrorText(txt),
          taken: isTaken(txt),
          success: isSuccess(txt),
          popups,
          stuckStreak,
          formGoneStreak,
          pageHead: txt.slice(0, 160),
        };
        log('DBG waitCadastroOk SNAPSHOT ' + JSON.stringify(state));
      } catch (e) { try { log('DBG waitCadastroOk SNAPSHOT erro ' + (e && e.message)); } catch {} }
    };
    snapshot('start');
    while (Date.now() - t0 < 150000) {
      const nowSnap = Date.now();
      if (nowSnap - lastSnapshot > 3000) { lastSnapshot = nowSnap; snapshot('tick'); }
      const txt = pageText();
      if (isNetworkErrorText(txt)) {
        log('DIAG REGISTER erro de rede/proxy detectado após envio; parando sem salvar como cadastro válido');
        return 'network-error';
      }
      if (isTaken(txt)) {
        let retry = 0;
        try { retry = parseInt(sessionStorage.getItem('pandoraTakenRetry') || '0', 10) || 0; } catch {}
        log('DIAG REGISTER taken detectado retry=' + retry);
        try { sessionStorage.setItem('pandoraForceNewCredentials', String(Date.now())); } catch {}
        rejected({ cadastroStatus: 'taken', site: location.href, retry });
        if (retry < 8) {
          try { sessionStorage.setItem('pandoraTakenRetry', String(retry + 1)); } catch {}
          log('DIAG REGISTER taken -> reload para tentar novos dados (n=' + (retry + 1) + ')');
          try { setTimeout(() => { try { location.reload(); } catch {} }, 300); } catch {}
          return 'reloading';
        }
        log('DIAG REGISTER taken -> limite de retries atingido, desistindo');
        return 'taken';
      }
      // Detector genérico de popup/modal de erro/aviso (rede, servidor, falha, tente novamente, etc.)
      // NUNCA em /home/mine — é onde o modal do QR de depósito PIX fica (pedido
      // do usuário 2026-08-08): fechar qualquer coisa ali por engano fecha o
      // próprio QR/confirmação de pagamento que o bot precisa capturar.
      try {
        if (/\\/home\\/mine(\\/|\\?|#|$)/i.test(location.pathname + location.search)) throw 0;
        const popupSel = '.ui-dialog, .el-dialog, .v-dialog, .modal, .ui-message-box, .ui-message, .ui-toast, [role="dialog"], [role="alertdialog"], [class*="dialog"], [class*="modal"], [class*="popup"]';
        const popups = Array.from(document.querySelectorAll(popupSel)).filter(visible);
        for (const pop of popups) {
          const ptxt = (pop.innerText || '').toLowerCase();
          if (!ptxt || ptxt.length < 3) continue;
          const isErr = /(erro|error|falha|fail|n[aã]o foi poss[ií]vel|tente novamente|try again|servidor|server|conex[aã]o|connection|timeout|tempo esgotado|inv[aá]lid|invalid|sistema|busy|ocupad|tente mais tarde|excedid|limit)/.test(ptxt);
          if (!isErr) continue;
          let popRetry = 0;
          try { popRetry = parseInt(sessionStorage.getItem('pandoraPopupRetry') || '0', 10) || 0; } catch {}
          log('DIAG REGISTER popup de erro detectado retry=' + popRetry + ' txt="' + ptxt.slice(0,120) + '"');
          if (popRetry >= 6) { log('DIAG REGISTER popup -> limite atingido, desistindo'); return 'timeout'; }
          try { sessionStorage.setItem('pandoraPopupRetry', String(popRetry + 1)); } catch {}
          // Tenta fechar o popup (botão "X", "Fechar", "OK", "Confirmar")
          try {
            const closeSel = pop.querySelector('.ui-dialog__close, .el-dialog__close, .close, [class*="close"], [aria-label*="lose" i], [aria-label*="echar" i]');
            if (closeSel) { try { closeSel.click(); } catch {} }
            const btns = Array.from(pop.querySelectorAll('button, [role="button"], .ui-button, .el-button'));
            const okBtn = btns.find(b => /^(ok|fechar|close|confirmar|entendi|cancelar|cancel)$/i.test((b.textContent || '').trim()));
            if (okBtn) { try { okBtn.click(); } catch {} }
          } catch {}
          try { setTimeout(() => { try { location.reload(); } catch {} }, 400); } catch {}
          return 'reloading';
        }
      } catch {}
      if (isSuccess(txt)) return 'ok';

      try {
        if (document.querySelector('button.registerRechargeBtn, .registerRechargeBtn')) return 'ok';
        const navDep = Array.from(document.querySelectorAll('span[class*="_text_"]'))
          .filter(visible).find(el => /^dep[óo]sito$/i.test((el.textContent || '').trim()));
        if (navDep) return 'ok';
      } catch {}
      const f = findFields();
      if (!f.acct || !f.pass1) { formGoneStreak++; if (formGoneStreak >= 3) return 'ok'; }
      else formGoneStreak = 0;

      // Enquanto o GeeTest/captcha estiver aberto ou recém-resolvido, NÃO mexe
      // no botão "Cadastrando...". O solver pode levar dezenas de segundos,
      // principalmente com várias janelas; reclicar/recarregar nesse período
      // invalida o challenge e prende todas as telas em loop.
      if (captchaActive()) {
        stuckStreak = 0;
        const now = Date.now();
        if (!captchaActiveSince) captchaActiveSince = now;
        // Preso no captcha tempo demais (sem resolver) → recarrega + novas
        // credenciais (refill acontece sozinho no reload). Reusa o limite de
        // reloads do stuckReload (máx 6) pra não entrar em loop infinito.
        if (now - captchaActiveSince >= CAPTCHA_STUCK_MS) {
          log('DIAG REGISTER captcha preso ' + Math.round((now - captchaActiveSince) / 1000) + 's -> reload com novas credenciais');
          if (stuckReload()) return 'reloading';
          captchaActiveSince = now; // stuckReload no limite: não fica remartelando
        }
        if (now - lastCaptchaWaitLog > 5000) {
          lastCaptchaWaitLog = now;
          log('DIAG REGISTER aguardando captcha resolver; sem reclick/reload');
        }
        await sleep(250);
        continue;
      }
      // Captcha não está mais ativo → zera o cronômetro de "preso no captcha".
      captchaActiveSince = 0;

      // Detecta botão "Cadastrar" preso em loading somente quando NÃO há captcha.
      // Antes de recarregar, tenta destravar e re-clicar algumas vezes.
      if (Date.now() - t0 > 2000) {
        try {
          const nb = findRegisterButton();
          if (nb && isBtnLoading(nb)) {
            stuckStreak++;
            // Não fica martelando o botão em "Cadastrando...": isso duplica envio
            // quando o gargalo é proxy/upstream. Só aguarda e recarrega bem depois.
            if (stuckStreak % 150 === 0) {
              log('DIAG REGISTER stuck -> aguardando resposta do servidor, sem reclick');
            }
            // Só recarrega depois de ~45s travado sem captcha e sem avanço.
            if (stuckStreak >= 150) {
              log('DIAG REGISTER stuck persistente -> reload com novas credenciais');
              if (stuckReload()) return 'reloading';
              stuckStreak = 0;
            }
          } else {
            stuckStreak = 0;
          }
        } catch {}
      }

      await sleep(100);
    }
    // Timeout total: tenta reload uma vez antes de desistir.
    log('DBG waitCadastroOk: TIMEOUT 150s atingido, snapshot final:');
    snapshot('timeout-final');
    if (stuckReload()) return 'reloading';
    return 'timeout';
  };


  const cadastroOutcome = await waitCadastroOk();
  log('DBG waitCadastroOk: FIM outcome=' + cadastroOutcome);
  if (cadastroOutcome === 'reloading') { log('DIAG REGISTER aguardando reload da página...'); return; }
  if (cadastroOutcome === 'network-error') { done('network-error', { cadastroStatus: 'network-error', site: location.href }); return; }
  if (cadastroOutcome !== 'ok') { done(cadastroOutcome === 'taken' ? 'taken' : 'timeout'); return; }
  try { sessionStorage.removeItem('pandoraTakenRetry'); } catch {}
  try { sessionStorage.removeItem('pandoraStuckRetry'); } catch {}
  try { sessionStorage.removeItem('pandoraPopupRetry'); } catch {}

  created({ cadastroStatus: 'ok', site: location.href });

  // TRATAMENTO DE MÚLTIPLOS POP-UPS PÓS-REGISTRO
  // Após o cadastro ser concluído, o site costuma disparar popups em cadeia
  // (boas-vindas, promoção, pesquisa, termos, app, etc.). Fecha tudo que
  // encontrar em algumas tentativas antes de seguir pro fluxo de depósito,
  // evitando que um popup residual atrapalhe os próximos passos.
  const closePostRegisterPopups = async () => {
    // Pedido do usuário 2026-08-20: "só vai fechar popup se a caixinha Sem
    // anúncios estiver marcada" — antes esse fechador (diferente do
    // attachPopupCloser em autoLogin.cjs, que já respeitava a opção) rodava
    // SEMPRE, incondicional, depois de qualquer cadastro. opts.closeAds já
    // existe e reflete func_sem_envelopes (ver buildInjectionScript acima).
    if (!opts.closeAds) return;
    // NUNCA em /home/mine — modal do QR de depósito PIX fica lá (pedido do
    // usuário 2026-08-08), não pode ser fechado por engano.
    if (/\\/home\\/mine(\\/|\\?|#|$)/i.test(location.pathname + location.search)) return;
    // Pedido do usuário 2026-08-19: o popup "Cadastro Concluído" continuava
    // detectado em TODAS as 22 tentativas (log real: nunca ficava "quieto")
    // mesmo com closedAny=true — .click() puro não disparava o handler real
    // do site (React escuta pointerdown/mousedown/pointerup/mouseup, não só
    // "click"). Mesmo padrão do realClick já usado mais abaixo, neste mesmo
    // arquivo, pro clique de depósito.
    const realClickPopup = (el) => {
      try { el.scrollIntoView({ block: 'center' }); } catch {}
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      const mk = (type) => new MouseEvent(type, { bubbles: true, cancelable: true, view: window, button: 0, clientX: cx, clientY: cy });
      try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerType: 'mouse' })); } catch {}
      el.dispatchEvent(mk('mousedown'));
      try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, clientX: cx, clientY: cy, pointerType: 'mouse' })); } catch {}
      el.dispatchEvent(mk('mouseup'));
      el.dispatchEvent(mk('click'));
      try { el.click(); } catch {}
    };
    const closeSel = [
      '.ui-dialog__close', '.el-dialog__close', '.v-dialog__close',
      'button[class*="close" i]', '[class*="close-box"]', '[class*="close-btn"]',
      '.modal-close', '.dialog-close', '[aria-label*="lose" i]', '[aria-label*="echar" i]',
    ].join(', ');
    const popupSel = '.ui-dialog, .el-dialog, .v-dialog, .modal, .ui-message-box, [role="dialog"], [role="alertdialog"], [class*="dialog"], [class*="modal"], [class*="popup"]';
    const okTextRe = /^(ok|fechar|close|entendi|confirmar|cancelar|cancel|n[ãa]o,?\s*obrigad[oa]|agora n[ãa]o|depois|pular|skip|×|✕|x)$/i;
    let closedAny = false;
    let attempt = 0;
    let emptyStreak = 0;
    const t0 = Date.now();
    const MAX_MS = 15000; // popups podem chegar em cadeia, com atraso entre um e outro
    const MIN_MS = 4000;  // não desiste antes disso mesmo sem ver popup, dá tempo do 1º chegar
    // Enquanto houver popup visível, ou ainda não passou o tempo mínimo, ou ainda
    // não ficou "quieto" (sem popup novo) por streak suficiente, continua checando.
    while (Date.now() - t0 < MAX_MS) {
      attempt++;
      const popups = Array.from(document.querySelectorAll(popupSel)).filter(visible);
      if (popups.length) {
        emptyStreak = 0;
        log('DIAG POST-REGISTER popup(s) detectado(s) tentativa=' + attempt + ' total=' + popups.length);
        for (const pop of popups) {
          try {
            // Pedido do usuário 2026-08-19 (versopg.vip e voy-exhaustpg.com,
            // popup "Parabéns, Cadastro Concluído!"): o X é um <svg><path>
            // puro, sem classe/aria-label nenhuma — não bate com closeSel
            // acima. Casa pelo início do "d" do path (HTML real confirmado
            // pelo usuário) e clica no <svg> pai.
            const closeIconPath = pop.querySelector('path[d^="M2.729 45.278a2.304 2.304 0 0 1-.666-1.11"]');
            const closeBtn = pop.querySelector(closeSel) || (closeIconPath && (closeIconPath.closest('svg') || closeIconPath.parentElement));
            if (closeBtn) { try { realClickPopup(closeBtn); closedAny = true; } catch {} continue; }
            const btns = Array.from(pop.querySelectorAll('button, [role="button"], .ui-button, .el-button, a'));
            const okBtn = btns.find(b => okTextRe.test((b.textContent || '').trim()));
            if (okBtn) { try { realClickPopup(okBtn); closedAny = true; } catch {} continue; }
            // Sem botão de fechar identificável: tenta clicar fora do modal (overlay).
            const overlay = document.querySelector('.ui-dialog__overlay, .el-dialog__wrapper, .v-overlay, [class*="overlay" i], [class*="mask" i]');
            if (overlay && overlay !== pop && visible(overlay)) { try { realClickPopup(overlay); closedAny = true; } catch {} }
          } catch {}
        }
      } else {
        emptyStreak++;
      }
      // Só encerra cedo se: já passou o tempo mínimo E ficou "quieto" (sem popup)
      // por 3 checagens seguidas (~2.1s sem nada aparecer).
      if (Date.now() - t0 >= MIN_MS && emptyStreak >= 3) break;
      await sleep(700);
    }
    if (closedAny) log('DIAG POST-REGISTER popups fechados com sucesso (tentativas=' + attempt + ')');
    else log('DIAG POST-REGISTER nenhum popup pendente (ou não foi possível fechar)');
  };
  try { await closePostRegisterPopups(); } catch (e) { try { log('DIAG POST-REGISTER erro ' + (e && e.message)); } catch {} }

  // Se não houver valores de depósito configurados (mínimo e máximo vazios/zero),
  // pula o fluxo de depósito e permanece na Home.
  {
    const _dMin = Number(opts && opts.depMin) || 0;
    const _dMax = Number(opts && opts.depMax) || 0;
    const _dVal = Number(opts && opts.depositValue) || 0;
    if (_dMin <= 0 && _dMax <= 0 && _dVal <= 0) {
      log('DIAG DEPOSITO SKIP - sem valores configurados (min/max vazios), permanecendo na Home');
      keepHomeWhenDepositEmpty('após cadastro');
      done('ok-no-deposit', { depStatus: 'skipped' });
      return;
    }
  }

  // ---------- DEPÓSITO (somente seleção de valor + clique) ----------
  const realClick = (el) => {
    try { el.scrollIntoView({ block: 'center' }); } catch {}
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const mk = (type) => new MouseEvent(type, { bubbles:true, cancelable:true, view:window, button:0, clientX:cx, clientY:cy });
    try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles:true, cancelable:true, clientX:cx, clientY:cy, pointerType:'mouse' })); } catch {}
    el.dispatchEvent(mk('mousedown'));
    try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles:true, cancelable:true, clientX:cx, clientY:cy, pointerType:'mouse' })); } catch {}
    el.dispatchEvent(mk('mouseup'));
    el.dispatchEvent(mk('click'));
    try { el.click(); } catch {}
  };

  const pickDepositTarget = (el) => {
    if (!el) return null;
    const direct = document.querySelector('#depositClick');
    if (direct && visible(direct)) return direct;
    if (el && typeof el.click === 'function') return el;
    const parent = el && el.parentElement;
    if (parent && typeof parent.click === 'function') return parent;
    return null;
  };

  const findDepositEntry = () => {
    // 0) HTML informado pelo usuário: <div role="tab" id="depositClick">...Depósito...</div>
    const depositClick = document.querySelector('#depositClick');
    if (depositClick && visible(depositClick)) return { el: depositClick, sel: '#depositClick' };
    // 1) Botão "Recarregar" pós-cadastro
    const rch = document.querySelector('button.registerRechargeBtn, .registerRechargeBtn');
    if (rch && visible(rch)) return { el: rch, sel: '.registerRechargeBtn' };
    // 2) Span específico do bottom-nav: <span class="_text_xm25p_221">Depósito</span>
    const exactSpans = Array.from(document.querySelectorAll('span[class*="_text_"]'))
      .filter(visible).filter(el => /^dep[óo]sito$/i.test((el.textContent || '').trim()));
    for (const s of exactSpans) {
      const target = pickDepositTarget(s) || s;
      if (visible(target)) return { el: target, sel: 'nav:span._text_*:Depósito (' + describeEl(target) + ')' };
    }
    // 3) Fallback genérico: qualquer elemento clicável cujo texto seja "Depósito"
    const spans = Array.from(document.querySelectorAll('span, a, button, div'))
      .filter(visible).filter(el => /^dep[óo]sito$/i.test((el.textContent || '').trim()));
    for (const s of spans) {
      const target = pickDepositTarget(s) || s;
      if (visible(target)) return { el: target, sel: 'nav:Depósito (' + describeEl(target) + ')' };
    }
    return null;
  };

  const waitDepositScreen = async (maxMs) => {
    const t0 = Date.now();
    while (Date.now() - t0 < maxMs) {
      // Tela tem várias opções de valor (R$10, R$50, etc) ou input de valor
      const opts = collectAmountOptions();
      if (opts.length >= 1) return opts;
      // detecta cabeçalho/texto "Depósito"/"Recarregar"
      await sleep(120);
    }
    return collectAmountOptions();
  };

  const parseAmount = (txt) => {
    if (!txt) return null;
    const m = String(txt).match(/([0-9]+(?:[.,][0-9]{1,2})?)/);
    if (!m) return null;
    const n = Number(m[1].replace(',', '.'));
    return Number.isFinite(n) ? n : null;
  };


  const collectAmountOptions = () => {
    const cand = Array.from(document.querySelectorAll('button, [role=button], li, div, span, a'))
      .filter(visible)
      .map(el => {
        const t = (el.innerText || el.textContent || '').trim();
        if (!t || t.length > 30) return null;
        const v = parseAmount(t);
        if (v == null || v < 1 || v > 100000) return null;
        // precisa ser clicável (não wrapper gigante)
        const r = el.getBoundingClientRect();
        if (r.width < 30 || r.height < 20 || r.width > 600) return null;
        return { el, value: v, text: t, sel: describeEl(el) };
      })
      .filter(Boolean);
    // dedup por elemento mais interno
    const out = [];
    for (const c of cand) {
      if (!cand.some(o => o !== c && c.el.contains(o.el))) out.push(c);
    }
    return out;
  };

  const findDepositConfirmBtn = () => {
    // 1) Seletor exato fornecido pelo site
    const exact = document.querySelector('#depositSubmitClick');
    if (exact && visible(exact)) return exact;
    // 2) Fallback por texto
    const btns = Array.from(document.querySelectorAll('button, [role=button], input[type=submit], a')).filter(visible);
    return btns.find(b => {
      const t = ((b.innerText || b.value || '') + '').toLowerCase().trim();
      if (!t || t.length > 40) return false;
      return /(deposite agora|depositar|recarregar|confirmar|pagar|gerar)/.test(t);
    });
  };

  const findAmountInput = () => {
    // 1) Seletor exato do site
    const exact = document.querySelector('input.ui-input__input[type=number], input.ui-input__input');
    if (exact && visible(exact) && !exact.disabled && !exact.readOnly) return exact;
    // 2) Input cujo placeholder contém "Mínimo" / "Máximo"
    const byPh = Array.from(document.querySelectorAll('input')).filter(visible)
      .find(i => /m[íi]nimo|m[áa]ximo/i.test(i.placeholder || ''));
    if (byPh) return byPh;
    // 3) Heurística genérica
    const inputs = Array.from(document.querySelectorAll('input')).filter(visible).filter(i => {
      const t = (i.type || 'text').toLowerCase();
      if (['hidden','checkbox','radio','submit','button','file'].includes(t)) return false;
      if (i.disabled || i.readOnly) return false;
      return true;
    });
    const hint = (i) => (((i.placeholder || '') + ' ' + (i.name || '') + ' ' + (i.id || '') + ' ' + (i.getAttribute('aria-label') || ''))).toLowerCase();
    const scored = inputs.map(i => {
      const h = hint(i);
      let s = 0;
      if (/(valor|quantia|montante|amount|valor.*dep|recarga|recharge)/.test(h)) s += 10;
      if ((i.type || '').toLowerCase() === 'number') s += 5;
      if (/[0-9]/.test(i.placeholder || '')) s += 2;
      return { el: i, s };
    }).sort((a,b) => b.s - a.s);
    return scored[0] && scored[0].s > 0 ? scored[0].el : null;
  };

  const setReactInputValue = (el, value) => {
    try { el.focus(); } catch {}
    try {
      const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      setter.call(el, '');
      el.dispatchEvent(new Event('input', { bubbles: true }));
      setter.call(el, String(value));
    } catch { try { el.value = String(value); } catch {} }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    try { el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' })); } catch {}
  };

  // ============= DEPÓSITO (retry global + MutationObserver) =============
  const desired = Number(opts && opts.depositValue) || Number(opts && opts.depMin) || Number(opts && opts.depMax) || 0;
  if (!(desired > 0)) { log('DIAG DEPOSITO 0 - pulado: valor não configurado'); return; }
  log('DIAG DEPOSITO 1 - iniciando fluxo valor=R$' + desired);
  const startUrl = location.href;
  const amountInputSelector = 'input.ui-input__input[type="number"], input.ui-input__input, input[placeholder*="Mínimo"], input[placeholder*="Minimo"]';

  const isBtnEnabled = (b) => b && !b.disabled
    && !b.classList.contains('ui-button--disabled')
    && !b.classList.contains('is-disabled')
    && b.getAttribute('aria-disabled') !== 'true';

  const detectSuccess = () => {
    try {
      // 1) QR code
      if (document.querySelector('canvas, img[src*="qr" i], img[alt*="qr" i], [class*="qrcode" i], [class*="qr-code" i]')) return 'qr';
      // 2) Texto PIX/copia-cola
      const t = (document.body.innerText || '').toLowerCase();
      if (/copia e cola|copiar c[oó]digo|pix copia|qr code|escaneie/.test(t)) return 'qr-text';
      // 3) Mudança de rota
      if (location.href !== startUrl && /pay|pagamento|checkout|order|pedido|qrcode/i.test(location.href)) return 'route';
      // 4) Modal de pagamento
      if (document.querySelector('[class*="payment" i], [class*="pagamento" i], [class*="checkout" i]')) return 'modal';
    } catch {}
    return null;
  };

  const findAmountInputNow = () => {
    const input = document.querySelector(amountInputSelector) || findAmountInput();
    return input && visible(input) && !input.disabled && !input.readOnly ? input : null;
  };

  let fastAmountInput = null;
  let fastAmountFilled = false;
  let depositClickDone = false;
  const primeFillAmount = (el, reason) => {
    if (!el || !visible(el) || el.disabled || el.readOnly) return false;
    fastAmountInput = el;
    try { el.focus(); } catch {}
    try { el.select && el.select(); } catch {}
    setReactInputValue(el, desired);
    try { el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true })); } catch {}
    const ok = Number(String(el.value || '').replace(',', '.')) === Number(desired);
    if (ok && !fastAmountFilled) log('INPUT preenchido imediato valor=' + desired + ' reason=' + reason);
    fastAmountFilled = fastAmountFilled || ok;
    return ok;
  };
  const primeAmountObserver = () => {
    try {
      const scan = (reason, obs) => {
        const el = findAmountInputNow();
        if (el && primeFillAmount(el, reason)) { try { obs && obs.disconnect(); } catch {} }
      };
      const obs = new MutationObserver(() => {
        scan('observer', obs);
      });
      obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class','style','type','placeholder','disabled','readonly'] });
      scan('prime', obs);
      return obs;
    } catch { return null; }
  };
  const waitAmountInputFast = async (maxMs = 8000) => {
    if (fastAmountInput && fastAmountInput.isConnected && visible(fastAmountInput) && !fastAmountInput.disabled && !fastAmountInput.readOnly) return fastAmountInput;
    const immediate = findAmountInputNow();
    if (immediate) { primeFillAmount(immediate, 'wait-immediate'); return immediate; }
    return await new Promise((resolve) => {
      let doneWait = false;
      let obs = null;
      const finish = (el, reason) => {
        if (doneWait) return;
        doneWait = true;
        try { obs && obs.disconnect(); } catch {}
        if (el) log('OBSERVER elemento detectado=' + describeEl(el) + ' reason=' + reason);
        resolve(el || null);
      };
      const scan = (reason) => {
        const el = findAmountInputNow();
        if (el) finish(el, reason);
      };
      try {
        obs = new MutationObserver(() => scan('mutation'));
        obs.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class','style','type','placeholder','disabled','readonly'] });
      } catch {}
      const tick = setInterval(() => {
        if (doneWait) { clearInterval(tick); return; }
        scan('interval');
      }, 10);
      setTimeout(() => { clearInterval(tick); finish(findAmountInputNow(), 'timeout'); }, maxMs);
    });
  };

  const earlyAmountObs = primeAmountObserver();

  // Tenta navegar para a tela de depósito com o observer já armado
  // BUG real 2026-08-09 (reportado pelo usuário: "às vezes, raramente
  // alguma tela não vai para o depósito após criar") — antes essa checagem
  // rodava UMA ÚNICA VEZ logo depois do cadastro: se o botão de entrada
  // (ex.: .registerRechargeBtn) ainda não tinha renderizado NESSE instante
  // exato (corrida normal entre o cadastro terminar e a UI de pós-cadastro
  // montar), o código desistia e só ASSUMIA que a tela de depósito já
  // estava aberta — quando na verdade não estava, e o resto do fluxo
  // (procurar input de valor) ficava procurando na tela errada até estourar
  // timeout. Agora tenta por até 4s (a cada 150ms) antes de desistir de
  // verdade — cobre a folga normal de renderização sem trocar o
  // comportamento (se realmente não existir entrada nenhuma — ex.: já caiu
  // direto na tela de depósito —, segue exatamente como antes).
  // 2026-08-10: avisa o pixModalEnhancer.cjs que um depósito de VERDADE está
  // começando agora nesta janela também — antes só depositHandler.cjs (botão
  // manual "Depositar" da aba Operação) setava essa flag; o fluxo de
  // depósito automático pós-cadastro (aba Início) nunca setava, então o QR
  // que abre aqui nunca era aumentado pelo enhancer (ficava do tamanho
  // natural do site). Mesmo sinal, mesmo mecanismo já usado lá.
  try { window.__pandoraDepositoAtivoEm = Date.now(); } catch {}
  try {
    let entry = null;
    const tEntry = Date.now();
    while (Date.now() - tEntry < 4000) {
      entry = findDepositEntry();
      if (entry) break;
      await sleep(150);
    }
    if (entry) { log('DEPOSITO nav: entrada localizada -> ' + entry.sel); realClick(entry.el); }
    else log('DEPOSITO nav: sem entrada visível após 4s de espera; assumindo tela já aberta');
  } catch (e) {
    // Diag 2026-08-09: esse catch ficava mudo — nenhuma das duas linhas
    // acima aparecia no log quando uma exceção estourava aqui dentro (ex.:
    // findDepositEntry() ou realClick() lançando por algum motivo), então
    // não dava pra saber que essa era exatamente a janela que "não foi pro
    // depósito" reportada pelo usuário. Loga a mensagem/stack agora.
    try { log('DEPOSITO nav: EXCEÇÃO ao localizar/clicar entrada -> ' + (e && e.message) + (e && e.stack ? ('\\n' + e.stack) : '')); } catch (e2) {}
  }

  const tryOnce = async (n) => {
    log('DEPOSITO tentativa=' + n);
    // renova o "depósito ativo agora" a cada tentativa — cobre casos em que
    // o fluxo leva mais que os 60s de validade da flag (várias tentativas/
    // reloads) antes do QR realmente aparecer.
    try { window.__pandoraDepositoAtivoEm = Date.now(); } catch {}
    if (depositClickDone) {
      log('DEPOSITO tentativa=' + n + ' ignorada: depósito já foi gerado, aguardando confirmação');
      const tWait = Date.now();
      while (Date.now() - tWait < 8000) {
        const kind = detectSuccess();
        if (kind) { log('QR detectado tipo=' + kind); return true; }
        await sleep(120);
      }
      return false;
    }
    // 1) Localiza input FRESCO (nunca reutiliza)
    let input = await waitAmountInputFast(8000);
    if (!input) { log('tentativa falhou motivo=input-nao-encontrado'); return false; }
    log('INPUT encontrado ' + describeEl(input));

    // 2) Confirma valor; se o observer já preencheu, segue direto
    let ok = Number(String(input.value || '').replace(',', '.')) === Number(desired);
    for (let i = 1; i <= 2 && !ok; i++) {
      ok = primeFillAmount(input, 'try-' + i);
      if (!ok) await sleep(5);
    }
    if (!ok) { log('tentativa falhou motivo=input-valor-nao-confirmado atual="' + (input.value || '') + '"'); return false; }
    log('INPUT preenchido valor=' + desired);

    // 3) Localiza botão FRESCO
    const tBt = Date.now();
    let btn = null;
    while (Date.now() - tBt < 5000) {
      btn = document.querySelector('#depositSubmitClick') || findDepositConfirmBtn();
      if (btn && visible(btn)) break;
      btn = null;
      await sleep(5);
    }
    if (!btn) { log('tentativa falhou motivo=botao-nao-encontrado'); return false; }
    log('BOTAO encontrado ' + describeEl(btn));

    // 4) Aguarda habilitação (até 5s)
    const tEn = Date.now();
    while (Date.now() - tEn < 5000) {
      const fresh = document.querySelector('#depositSubmitClick');
      if (fresh) btn = fresh;
      if (isBtnEnabled(btn) && String(input.value || '').trim()) break;
      await sleep(5);
    }
    if (!isBtnEnabled(btn)) { log('tentativa falhou motivo=botao-desabilitado'); return false; }
    log('BOTAO habilitado');

    // 5) Click
    depositClickDone = true;
    realClick(btn);
    log('CLICK executado');

    // 6) Aguarda confirmação de sucesso (QR/modal/rota)
    const tSuc = Date.now();
    while (Date.now() - tSuc < 8000) {
      const kind = detectSuccess();
      if (kind) { log('QR detectado tipo=' + kind); return true; }
      await sleep(120);
    }
    log('tentativa falhou motivo=sem-confirmacao-qr');
    return false;
  };

  // MutationObserver: dispara reexecução assim que o input surgir
  let observerSignaled = false;
  const obs = new MutationObserver(() => {
    if (observerSignaled) return;
    const el = document.querySelector('input.ui-input__input[type="number"]');
    if (el) { observerSignaled = true; log('OBSERVER elemento detectado=input.ui-input__input'); }
  });
  try { obs.observe(document.body, { childList: true, subtree: true }); } catch {}

  // Retry global: tentativa 1 imediata, depois acelerada
  const delays = [0, 800, 2000, 5000, 10000];
  let success = false;
  let finalValue = desired;
  for (let i = 0; i < delays.length; i++) {
    if (delays[i] > 0) await sleep(delays[i]);
    try {
      success = await tryOnce(i + 1);
      if (success) break;
    } catch (e) {
      log('DEPOSITO tentativa=' + (i + 1) + ' exception=' + (e && e.message));
    }
  }
  try { obs.disconnect(); } catch {}
  try { earlyAmountObs && earlyAmountObs.disconnect(); } catch {}

  if (success) {
    log('DIAG DEPOSITO 7 - resultado=sucesso valor=R$' + finalValue);
    done('ok', { saque: finalValue, depStatus: 'ok' });
  } else {
    // Pedido do usuário 2026-08-09: "se não for para a tela de depósito,
    // atualize a página e faça ir" — mesmo padrão já aplicado pros campos
    // de cadastro (recarrega se não achar em pouco tempo). Aqui só faz
    // sentido recarregar se o INPUT de valor nunca apareceu em NENHUMA das
    // 5 tentativas (sinal forte de que a navegação pro depósito falhou de
    // verdade, não só um clique isolado que não confirmou) — usa
    // sessionStorage (sobrevive a reload) com limite de tentativas, mesmo
    // mecanismo/mesma razão de ser do fix de campos de cadastro.
    const inputNuncaApareceu = !document.querySelector('input.ui-input__input[type="number"]') && !observerSignaled;
    const MAX_DEP_RELOAD = 3;
    let depReloadAttempts = 0;
    try { depReloadAttempts = parseInt(sessionStorage.getItem('__pandoraDepReloadAttempts') || '0', 10) || 0; } catch (e) {}
    if (inputNuncaApareceu && depReloadAttempts < MAX_DEP_RELOAD) {
      depReloadAttempts++;
      try { sessionStorage.setItem('__pandoraDepReloadAttempts', String(depReloadAttempts)); } catch (e) {}
      log('DIAG DEPOSITO 7 - tela de depósito nunca apareceu (tentativa ' + depReloadAttempts + '/' + MAX_DEP_RELOAD + ') — recarregando página');
      try { bootLog('BOOT 3.95 - recarregando por falta da tela de depósito', { tentativa: depReloadAttempts }); } catch (e) {}
      try { location.reload(); } catch (e) {}
      return;
    }
    log('DIAG DEPOSITO 7 - resultado=falha após 5 tentativas' + (inputNuncaApareceu ? ' (e já esgotou os reloads)' : ''));
    done('deposito-falhou', { saque: finalValue, depStatus: 'fail' });
  }

  return;
})();`;
  const wrapper = buildSafeInjectionWrapper(injectedScript);
  buildInjectionScript._lastInner = injectedScript;
  buildInjectionScript._lastWrapper = wrapper;
  return wrapper;
}



// BUG real 2026-08-10 (reportado pelo usuário, depois do fix de duplicação):
// com N telas rodando cadastro em paralelo, cada uma termina de verdade num
// instante diferente (rede/captcha/proxy variam por janela) — então
// "Tela 2 — Conta criada" podia aparecer antes de "Tela 1", mesmo os dois
// tendo começado juntos. Pedido do usuário: aparecer em ordem de tela.
//
// 1ª tentativa (debounce de 3s de silêncio) melhorou bastante mas ainda
// falhava quando UMA tela demorava mais que as outras: as 4 rápidas
// flushavam juntas depois de 3s quietas, e a 5ª (mais lenta) chegava DEPOIS
// desse flush — saindo sozinha, no fim, fora de ordem. Fix real: a chamada
// que abre o lote agora avisa quantas telas vão registrar
// (setContaCriadaBatchTotal), e o buffer só flusha quando TODAS as
// esperadas já chegaram (ordenadas por tela nesse momento) — nunca mais
// solta um grupo incompleto. Trava de segurança (90s) evita esperar pra
// sempre se uma tela travar/falhar e nunca chegar a "criada" de verdade.
// BUG real 2026-08-10 (2ª rodada — reportado de novo mesmo depois do fix de
// batch total): investigando o diag, a tela que faltou (login "kai84s")
// tinha travado de verdade no formulário de cadastro do site (não respondia
// mais) — o watchdog tentou recarregar com credenciais novas 2x e ainda
// estava tentando quando o resto do lote já tinha acabado. Ou seja, aquela
// tela genuinamente não tinha terminado ainda quando o log foi checado
// (não sobra pra sempre — se o watchdog desistir depois de 8 tentativas,
// ver liberarContaCriadaBatchSlot abaixo, chamado perto de "WATCHDOG
// cadastro limite atingido"). Deixado um diag permanente e leve (1 linha
// por chegada/flush, não por item) pra nunca mais precisar adivinhar isso.
let __contaCriadaBuffer = [];
let __contaCriadaTimer = null;
let __contaCriadaHardTimer = null;
let __contaCriadaExpectedTotal = 0;
function flushContaCriadaBuffer() {
  if (__contaCriadaTimer) { clearTimeout(__contaCriadaTimer); __contaCriadaTimer = null; }
  if (__contaCriadaHardTimer) { clearTimeout(__contaCriadaHardTimer); __contaCriadaHardTimer = null; }
  const items = __contaCriadaBuffer;
  __contaCriadaBuffer = [];
  __contaCriadaExpectedTotal = 0;
  items.sort((a, b) => (Number(a.tela) || 0) - (Number(b.tela) || 0));
  try { queueDiagLine(`[${new Date().toISOString()}] [conta-criada] flush de ${items.length} tela(s): [${items.map((it) => it.tela).join(",")}]\r\n`); } catch {}
  for (const it of items) {
    try { logOperacaoPanel(it.db, it.saveDB, it.dbPath, it.message, it.context); } catch {}
  }
}
// Chamado pelas rotinas que abrem um lote novo de janelas de cadastro
// (openRealChromiumWindows/openRealChromiumMulti), já sabendo quantas contas
// novas vão ser criadas nesse lote. Descarta qualquer lote anterior
// incompleto (alguma tela que travou e nunca chegou) em vez de misturar com
// o novo lote.
function setContaCriadaBatchTotal(n) {
  if (__contaCriadaBuffer.length) flushContaCriadaBuffer();
  __contaCriadaExpectedTotal = Math.max(0, Number(n) || 0);
  try { queueDiagLine(`[${new Date().toISOString()}] [conta-criada] novo lote — esperando ${__contaCriadaExpectedTotal} tela(s)\r\n`); } catch {}
  if (__contaCriadaHardTimer) { clearTimeout(__contaCriadaHardTimer); __contaCriadaHardTimer = null; }
  if (__contaCriadaExpectedTotal > 0) {
    __contaCriadaHardTimer = setTimeout(flushContaCriadaBuffer, 90000);
  }
}
// Chamado quando uma tela DESISTE de vez (watchdog bateu o limite de
// tentativas, ver "WATCHDOG cadastro limite atingido") — sem isso o buffer
// ficaria esperando os 90s inteiros por uma tela que nunca vai completar,
// atrasando sem necessidade o log das que já terminaram certinho.
function liberarContaCriadaBatchSlot() {
  if (__contaCriadaExpectedTotal > 0) __contaCriadaExpectedTotal--;
  if (__contaCriadaExpectedTotal > 0 && __contaCriadaBuffer.length >= __contaCriadaExpectedTotal) {
    flushContaCriadaBuffer();
  }
}
function queueContaCriadaLog(db, saveDB, dbPath, message, context, tela) {
  __contaCriadaBuffer.push({ db, saveDB, dbPath, message, context, tela });
  try { queueDiagLine(`[${new Date().toISOString()}] [conta-criada] chegou tela=${tela} (${__contaCriadaBuffer.length}/${__contaCriadaExpectedTotal || "?"})\r\n`); } catch {}
  if (__contaCriadaExpectedTotal > 0 && __contaCriadaBuffer.length >= __contaCriadaExpectedTotal) {
    flushContaCriadaBuffer();
    return;
  }
  // Total do lote desconhecido (chamador antigo/fallback) — usa o debounce
  // de silêncio de 3s como antes, melhor do que nada.
  if (__contaCriadaExpectedTotal === 0) {
    if (__contaCriadaTimer) clearTimeout(__contaCriadaTimer);
    __contaCriadaTimer = setTimeout(flushContaCriadaBuffer, 3000);
  }
}

function attachAutoRegister(win, db, saveDB, dbPath) {
  if (!win || win.isDestroyed()) return;
  persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 1.5 - attachAutoRegister chamado", { destroyed: false });
  // Pedido do usuário 2026-08-09: mostrar "Criando conta" no Log de Operações
  // assim que o site abre e o auto-cadastro é ligado nessa janela — mesmo
  // padrão de antes/depois já usado em Saque/PIX/Login (Operacao.tsx,
  // ChavesPix.tsx, autoLogin.cjs).
  try {
    const tela = win._pandoraOrder || "?";
    logOperacaoPanel(db, saveDB, dbPath, `Tela ${tela} — Criando conta...`, { tela });
  } catch {}
  let cred = genCredentials(db);
  let registrationWatchdogTimer = null;
  let registrationWatchdogStartedAt = 0;
  let registrationWatchdogStuckSince = 0;
  let registrationWatchdogReloads = 0;
  if (saveDB && dbPath) { try { saveDB(db, dbPath).catch(() => {}); } catch {} }
  win._regCred = cred;
  const rotateCredentials = (reason) => {
    try {
      const oldLogin = cred && cred.login;
      const newCred = genCredentials(db);
      cred = newCred;
      win._regCred = cred;
      win._regCredTaken = false;
      win._regCredUsed = false;
      win._depositValue = 0;
      if (saveDB && dbPath) { try { saveDB(db, dbPath).catch(() => {}); } catch {} }
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 1.7 - novas credenciais geradas", { reason, oldLogin, newLogin: cred.login });
      return true;
    } catch (e) {
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 1.7 - falha ao regenerar credenciais", { reason, error: e?.message || String(e) });
      return false;
    }
  };
  const stopRegistrationWatchdog = (reason) => {
    if (registrationWatchdogTimer) {
      clearInterval(registrationWatchdogTimer);
      registrationWatchdogTimer = null;
      persistAutoRegisterLog(db, saveDB, dbPath, "WATCHDOG cadastro parado", { reason: reason || "" });
    }
    registrationWatchdogStartedAt = 0;
    registrationWatchdogStuckSince = 0;
  };
  const startRegistrationWatchdog = (payload) => {
    stopRegistrationWatchdog("restart");
    registrationWatchdogReloads = 0;
    registrationWatchdogStartedAt = Date.now();
    registrationWatchdogStuckSince = 0;
    const login = payload && payload.login ? String(payload.login) : (cred && cred.login) || "";
    persistAutoRegisterLog(db, saveDB, dbPath, "WATCHDOG cadastro iniciado", { login });
    registrationWatchdogTimer = setInterval(async () => {
      if (!win || win.isDestroyed()) { stopRegistrationWatchdog("window-destroyed"); return; }
      try {
        const state = await win.webContents.executeJavaScript(`(() => {
          try {
            const visible = (el) => {
              if (!el || !el.isConnected) return false;
              const r = el.getBoundingClientRect();
              if (!r || r.width < 3 || r.height < 3) return false;
              const s = getComputedStyle(el);
              return s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.05;
            };
            const norm = (s) => String(s || '').toLowerCase();
            const bodyText = norm(document.body && document.body.innerText);
            const networkError = /upstream\s+error|err_tunnel_connection_failed|err_proxy_connection_failed|err_connection_(closed|reset|refused|timed_out)|bad\s+gateway|502\s+bad\s+gateway|proxy\s+error|t[uú]nel|tunnel|site can.?t be reached|this site can.?t be reached|connection timed out/.test(bodyText + ' ' + norm(document.title) + ' ' + norm(location.href));
            const success = /(cadastrad[oa] com sucesso|registr(o|ad[oa]) (conclu|com sucesso)|bem.?vind[oa]|welcome|conta criada|dep[óo]sito|depositar|recarregar)/.test(bodyText)
              || !!document.querySelector('button.registerRechargeBtn, .registerRechargeBtn');
            const taken = /(usu[aá]rio|conta|login|nome|account).{0,40}(j[aá] (existe|cadastrad|em uso|usado)|existente|indispon[ií]vel|n[aã]o dispon[ií]vel|taken|in use|already|exists)/.test(bodyText);
            const hasRegisterFields = !!(document.querySelector('input[data-input-name="account"], textarea[data-input-name="account"]')
              && document.querySelector('input[data-input-name="userpass"], textarea[data-input-name="userpass"]'));
            const captchaActive = !!Array.from(document.querySelectorAll('#__pandora_captcha_solving_overlay__, .geetest_panel, .geetest_panel_box, .geetest_box, .geetest_holder, .geetest_box_wrap, .geetest_panelshowclick, .geetest_widget, iframe[src*="geetest"], iframe[src*="gcaptcha"], iframe[src*="gsensebot"], iframe[src*="geevisit"]')).find(visible)
              || !!(window.__pandoraGeetest && window.__pandoraGeetest.ready)
              || !!(window.__pandoraGeetestSolvedAt && Date.now() - window.__pandoraGeetestSolvedAt < 8000);
            const nodes = Array.from(document.querySelectorAll('button, [role="button"], input[type="submit"], .ui-button, .van-button, a, div, span')).filter(visible);
            let stuckText = '';
            let stuck = false;
            for (const el of nodes) {
              const txt = norm((el.innerText || el.textContent || el.value || '').trim());
              const cls = norm(el.className || '');
              const aria = norm((el.getAttribute && ((el.getAttribute('aria-busy') || '') + ' ' + (el.getAttribute('aria-disabled') || ''))) || '');
              const loadingLike = /(cadastrando|registrando|processando|enviando|aguarde|loading|spinner|is-loading|ui-button--loading|van-button--loading)/.test(txt + ' ' + cls + ' ' + aria)
                || !!(el.querySelector && el.querySelector('.ui-loading, .is-loading, .spinner, [class*="loading"], [class*="spinner"], svg.animate-spin'));
              const registerLike = /(cadastr|registr|sign\s*up|criar conta|submit|insideRegisterSubmitClick)/.test(txt + ' ' + cls + ' ' + (el.id || ''));
              if (loadingLike && (registerLike || hasRegisterFields)) { stuck = true; stuckText = txt.slice(0, 80) || cls.slice(0, 80); break; }
            }
            return { ok: true, href: location.href, readyState: document.readyState, networkError, success, taken, hasRegisterFields, captchaActive, stuck, stuckText };
          } catch (e) { return { ok: false, error: e && e.message ? e.message : String(e) }; }
        })();`, true);
        if (!state || state.ok === false) return;
        if (state.networkError) {
          persistAutoRegisterLog(db, saveDB, dbPath, "WATCHDOG cadastro parou por erro upstream/proxy", { login, href: state.href });
          stopRegistrationWatchdog("network-error");
          return;
        }
        if (state.success) { stopRegistrationWatchdog("success"); return; }
        if (state.taken) {
          persistAutoRegisterLog(db, saveDB, dbPath, "WATCHDOG cadastro detectou login rejeitado", { login, href: state.href });
          stopRegistrationWatchdog("taken");
          rotateCredentials("watchdog-taken");
          setTimeout(() => { try { if (win && !win.isDestroyed()) win.webContents.reloadIgnoringCache(); } catch {} }, 500);
          return;
        }
        const now = Date.now();
        const totalFor = now - registrationWatchdogStartedAt;
        if (state.captchaActive) {
          registrationWatchdogStuckSince = 0;
          if (totalFor >= 150000 && state.hasRegisterFields) {
            persistAutoRegisterLog(db, saveDB, dbPath, "WATCHDOG cadastro aguardando captcha", { login, totalFor, state });
          }
          return;
        }
        if (state.stuck) {
          if (!registrationWatchdogStuckSince) registrationWatchdogStuckSince = now;
        } else {
          registrationWatchdogStuckSince = 0;
        }
        const stuckFor = registrationWatchdogStuckSince ? now - registrationWatchdogStuckSince : 0;
        const shouldReload = (stuckFor >= 5000) || (totalFor >= 30000 && state.hasRegisterFields);
        if (!shouldReload) return;
        if (registrationWatchdogReloads >= 8) {
          persistAutoRegisterLog(db, saveDB, dbPath, "WATCHDOG cadastro limite atingido", { login, stuckFor, totalFor, state });
          // BUG real 2026-08-10 (reportado pelo usuário: "uma [tela] não
          // criou" — nenhum aviso apareceu, só sumiu): até aqui, esse
          // "desisti depois de 8 tentativas" só ia pro diag invisível
          // (persistAutoRegisterLog). Do ponto de vista do usuário a tela
          // simplesmente nunca aparecia no Log de Operações, sem explicação.
          // Agora avisa no painel visível também — e "libera" essa tela do
          // total esperado pelo buffer de ordenação (ver
          // liberarContaCriadaBatchSlot em queueContaCriadaLog), senão o
          // buffer ficaria esperando pra sempre uma tela que nunca vai
          // completar.
          try {
            const tela = win._pandoraOrder || "?";
            logOperacaoPanel(db, saveDB, dbPath, `Tela ${tela} — Cadastro travado, desisti após 8 tentativas (login=${login})`, { tela, login });
            liberarContaCriadaBatchSlot();
          } catch {}
          stopRegistrationWatchdog("limit");
          return;
        }
        registrationWatchdogReloads++;
        persistAutoRegisterLog(db, saveDB, dbPath, "WATCHDOG cadastro travado — recarregando com novas credenciais", { login, reload: registrationWatchdogReloads, stuckFor, totalFor, state });
        try { win._regCredUsed = true; } catch {}
        rotateCredentials(stuckFor >= 5000 ? "watchdog-cadastrando" : "watchdog-timeout");
        stopRegistrationWatchdog("reload");
        try {
          await win.webContents.executeJavaScript(`(() => { try { sessionStorage.setItem('pandoraForceNewCredentials', String(Date.now())); } catch {} return true; })();`, true).catch(() => null);
        } catch {}
        try { win.webContents.reloadIgnoringCache(); } catch {}
      } catch (_) {}
    }, 2500);
    try { registrationWatchdogTimer.unref && registrationWatchdogTimer.unref(); } catch {}
  };
  try { win.once("closed", () => stopRegistrationWatchdog("closed")); } catch {}
  persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 1.6 - listener did-finish-load registrado", { hasWebContents: !!win.webContents });

  win.webContents.on("did-finish-load", () => {
    // Re-injetar em CADA navegação (para retomar o fluxo após o reload pós-PIN).
    // O guard window.__pandoraReg dentro do IIFE evita execução duplicada na
    // mesma página; a navegação cria um novo document, então o guard é resetado.
    const url = (() => { try { return win.webContents.getURL(); } catch (e) { return ""; } })();
    persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 2 - did-finish-load recebido", { url });
    if (!url || url.startsWith("file:") || url.startsWith("data:") || url.startsWith("about:")) {
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 2.1 - did-finish-load ignorado por URL interna", { url });
      return;
    }
    // Interruptor geral: depois que a chave PIX já foi confirmada (clique
    // real disparado em pixHandler.cjs), o cadastro dessa janela terminou —
    // não reinjeta mais nada nela nunca mais, nenhuma navegação futura.
    if (win.__pandoraRegistrationFinished) {
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 2.0 - did-finish-load ignorado (cadastro já finalizado nessa janela)", { url });
      return;
    }
    // Páginas pós-cadastro (definir senha de saque / cadastrar chave PIX) já
    // têm seus próprios fluxos dedicados e bem travados (securityPin.cjs,
    // pixHandler.cjs). O script de CADASTRO DE CONTA não tem nada a fazer
    // ali — mas como ele se reinjeta em toda navegação da janela (comentário
    // acima), sem esse filtro ele confundia o campo "adicionar conta de
    // saque"/chave PIX com o campo de login do cadastro (runRegister:
    // fallback campos account=...Adicione uma conta de saque...) e tentava
    // clicar em Confirmar sozinho, por cima do clique já controlado do PIX —
    // essa era a causa real do "fica clicando Confirmar várias vezes".
    // BUG GRAVE real 2026-08-09 (reportado pelo usuário: navegar pra
    // "Relatório de Apostas" — /home/report — fazia a tela "ficar bugando
    // querendo mudar e recarregando sozinha" em várias das 5 janelas
    // abertas) — causa raiz: esse filtro só excluía /home/withdraw e
    // /home/security; QUALQUER outra rota (report, event/baús, etc.)
    // reinjetava o script de CADASTRO inteiro de novo a cada navegação —
    // incluindo o fix de hoje que recarrega a página se não achar os
    // campos de cadastro em 3s. Na tela de Relatório NUNCA existem esses
    // campos (é só consulta), então cada reload disparava outro reload,
    // em loop, até o limite de 3 tentativas — e cada vez que o usuário
    // clicava em "Relatório de Apostas" de novo (win.loadURL de novo) o
    // ciclo inteiro recomeçava. Ampliado pra excluir qualquer rota que não
    // seja a própria tela de cadastro (report, event/baús — nenhuma delas
    // tem campo de cadastro, o script de registro não tem nada a fazer em
    // NENHUMA das duas).
    // BUG real 2026-08-10 (reportado pelo usuário: clicou em "IR" no Lucky
    // Dog, entrou no slot e voltou pra Home sozinho) — esse filtro não
    // incluía /home/subgame nem /home/embedded (as rotas reais de entrar
    // num slot — mesmo padrão já usado em __isSlotUrl em
    // browserInjections.cjs). Sem isso, o script de CADASTRO inteiro
    // reinjetava de novo na tela do jogo; se o depósito não estivesse
    // configurado (aba Início), keepHomeWhenDepositEmpty (mais abaixo)
    // confundia os botões de valor de aposta do jogo com uma tela de
    // depósito e clicava em "Início" sozinho.
    if (/\/home\/(withdraw|security|report|event|subgame|embedded)\b/i.test(url)) {
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 2.2 - did-finish-load ignorado (página pós-cadastro: saque/senha/pix/relatório/baús/slot)", { url });
      return;
    }
    setTimeout(async () => {
      if (win.isDestroyed()) return;
      try {
        let forceNewFromPage = false;
        try {
          const marker = await win.webContents.executeJavaScript(`(() => { try { const v = sessionStorage.getItem('pandoraForceNewCredentials') || ''; if (v) sessionStorage.removeItem('pandoraForceNewCredentials'); return v; } catch { return ''; } })();`, true);
          forceNewFromPage = !!marker;
        } catch {}
        // Regenera credenciais se:
        //  - a página marcou no sessionStorage que recusou o login atual, OU
        //  - popup "conta já existente" foi detectado (_regCredTaken), OU
        //  - as credenciais atuais já foram submetidas ao site (_regCredUsed),
        //    cobrindo reload manual (toolbar) ou popups não-casados pela regex.
        // Safety-net: se o login atual já consta em accounts (foi cadastrado
        // em algum momento), força regeneração — evita repetir login após
        // popup "já existe" quando o marker ou flags não pegaram.
        let loginAlreadyInDb = false;
        try {
          if (db && cred && cred.login) {
            const safe = String(cred.login).replace(/'/g, "''");
            const r = db.exec(`SELECT 1 FROM accounts WHERE username='${safe}' LIMIT 1`);
            loginAlreadyInDb = !!(r && r[0] && r[0].values && r[0].values.length);
          }
        } catch {}
        if (forceNewFromPage || win._regCredTaken || win._regCredUsed || loginAlreadyInDb) {
          const reason = forceNewFromPage ? "taken-marker" : (win._regCredTaken ? "taken" : (loginAlreadyInDb ? "login-in-db" : "reload-after-submit"));
          rotateCredentials(reason);
        }

        const get = global.__pandoraGetSetting || (() => "");
        const parseDepositSetting = (value) => parseFloat(String(value || "0").replace(",", ".")) || 0;
        // Pedido do usuário 2026-08-09: os valores de depósito configurados
        // na aba Operação (op_dep_1/2) NUNCA devem interferir na criação de
        // conta (aba Início) — antes, se exec_dep_1/2 estivesse vazio, caía
        // no fallback pra op_dep_1/2, misturando as duas abas.
        // BUG real 2026-08-10 (reportado pelo usuário: "está indo pra
        // depósito com os valores configurados da aba Operação") — o
        // fallback "|| 10"/"|| 30" que eu tinha posto aqui ontem, pra quando
        // exec_dep_1/2 estivesse vazio, coincidiu por acaso com os valores
        // configurados em Operação (10/30 também), dando a impressão de que
        // ainda estava lendo de lá. Na verdade exec_dep_1/2 estavam vazios
        // de verdade (o usuário nunca configurou a aba Início) — e o código
        // logo abaixo (linha ~1406, "SKIP - sem valores configurados") já
        // existe justamente pra pular o depósito inteiro nesse caso. Sem
        // exec_dep_1/2 configurado, tem que cair em 0/0 (skip), nunca em um
        // valor fixo qualquer.
        let depMin = parseDepositSetting(get("exec_dep_1", "")) || 0;
        const depMax = parseDepositSetting(get("exec_dep_2", "")) || 0;
        // CAUSA-RAIZ QR okok (2026-08-27, confirmada por log: exec_dep_1=0
        // exec_dep_2=20 apesar de o cliente configurar 10-20). A UI da aba Início
        // mostra o default "10" no mínimo mas só PERSISTE no blur — se o campo
        // não foi editado, get("exec_dep_1") vinha "" => 0, e min=0 caía em
        // "valores inválidos", PULANDO o depósito inteiro => watchForDepositQr
        // nunca chamado => QR nunca aparecia. Fix: se o MÁXIMO está configurado
        // mas o mínimo não (0/vazio), usa o default 10 da UI (limitado ao máximo)
        // — dá o range 10..max que o usuário vê na tela. Se NENHUM está
        // configurado (0/0), continua pulando (não deposita à toa).
        if (depMax > 0 && !(depMin > 0)) depMin = Math.min(10, depMax);
        const closeAds = String(get("func_sem_envelopes", "0")) === "1";
        const senhaSaque = String(get("senha_saque", "")).replace(/\D/g, "").slice(0, 6);

        // ===== Valor de depósito: sorteado uma única vez por conta/janela =====
        if (!win._winTag) win._winTag = "WIN-" + String(Math.floor(1000 + Math.random() * 9000));
        const winTag = win._winTag;
        let depositValue = 0;
        if (win._depositValue && Number(win._depositValue) > 0) {
          depositValue = Number(win._depositValue);
        } else {
          const minOk = Number.isFinite(depMin) && depMin > 0;
          const maxOk = Number.isFinite(depMax) && depMax > 0;
          if (!minOk || !maxOk) {
            persistAutoRegisterLog(db, saveDB, dbPath, `[${winTag}] DEPOSITO ERRO valores inválidos`, { depMin, depMax });
          } else if (depMin > depMax) {
            persistAutoRegisterLog(db, saveDB, dbPath, `[${winTag}] DEPOSITO ERRO min>max`, { depMin, depMax });
          } else if (depMin === depMax) {
            depositValue = depMin;
            persistAutoRegisterLog(db, saveDB, dbPath, `[${winTag}] DEPOSITO intervalo min=${depMin} max=${depMax}`, {});
            persistAutoRegisterLog(db, saveDB, dbPath, `[${winTag}] DEPOSITO valor-sorteado=${depositValue}`, {});
          } else {
            const lo = Math.min(depMin, depMax);
            const hi = Math.max(depMin, depMax);
            const isInt = Number.isInteger(depMin) && Number.isInteger(depMax);
            if (isInt) {
              depositValue = Math.floor(Math.random() * (hi - lo + 1)) + lo;
            } else {
              depositValue = Math.round((Math.random() * (hi - lo) + lo) * 100) / 100;
            }
            persistAutoRegisterLog(db, saveDB, dbPath, `[${winTag}] DEPOSITO intervalo min=${lo} max=${hi}`, {});
            persistAutoRegisterLog(db, saveDB, dbPath, `[${winTag}] DEPOSITO valor-sorteado=${depositValue}`, {});
          }
          if (depositValue > 0) win._depositValue = depositValue;
        }

        // BUG real 2026-08-10 (reportado pelo usuário: QR ainda não abriu
        // grande mesmo já setando window.__pandoraDepositoAtivoEm dentro do
        // script de cadastro) — aquele set só alcança o FRAME PRINCIPAL da
        // página (é onde o script inteiro roda); qrCapture.cjs já
        // documentava que "o formulário de depósito às vezes roda dentro de
        // um iframe de pagamento de terceiros" — cada frame tem seu próprio
        // objeto `window`, então a flag setada no principal nunca aparece
        // pro iframe do QR. Aqui do lado Node (tem acesso a TODOS os frames
        // via win.webContents.mainFrame.framesInSubtree) espalha a mesma
        // flag pra cada frame, repetindo por ~90s (tempo de sobra pro
        // depósito ser processado e o QR aparecer, mesmo com retry/reload).
        if (depositValue > 0 && !win._pandoraDepFlagBroadcastStarted) {
          win._pandoraDepFlagBroadcastStarted = true;
          let __depFlagTicks = 0;
          const __depFlagBroadcast = () => {
            __depFlagTicks++;
            try {
              if (!win || win.isDestroyed()) { clearInterval(__depFlagTimer); return; }
              const setFlag = "try{window.__pandoraDepositoAtivoEm=Date.now();}catch(e){}";
              win.webContents.executeJavaScript(setFlag, true).catch(() => {});
              const frames = (win.webContents.mainFrame && win.webContents.mainFrame.framesInSubtree) || [];
              for (const f of frames) {
                if (!f || f === win.webContents.mainFrame) continue;
                try { f.executeJavaScript(setFlag, true).catch(() => {}); } catch {}
              }
            } catch {}
            if (__depFlagTicks >= 45) clearInterval(__depFlagTimer);
          };
          const __depFlagTimer = setInterval(__depFlagBroadcast, 2000);
          __depFlagBroadcast();
        }

        // Captura o QR Code do depósito e manda pra UI do app (painel em
        // Início → Funcionalidades) — pensado pro modo "Operação Oculta"
        // (headless, sem janela visível pra escanear na tela), mas funciona
        // igual com janela visível também. Só uma vez por janela (evita
        // reagendar de novo a cada re-injeção do script de cadastro).
        // DIAG incondicional (2026-08-27): o QR só é buscado se depositValue>0.
        // Esse valor vem de exec_dep_1/2 (aba Início) — se o usuário configurou
        // depósito só na aba Operação, aqui fica 0 e o QR nunca é buscado (some
        // no Início, sem nenhuma linha [qr-capture] no log). Esta linha diz
        // DEFINITIVAMENTE se o watch foi iniciado e por quê.
        if (!win._qrWatchDiagDone) {
          win._qrWatchDiagDone = true;
          try { queueDiagLine(`[${new Date().toISOString()}] [qr-decisao] winTag=${win._winTag} headless=${!!win._headless} depositValue=${depositValue} (exec_dep_1=${depMin} exec_dep_2=${depMax}) vaiBuscarQR=${depositValue > 0}\r\n`); } catch {}
        }
        if (depositValue > 0 && !win._qrWatchStarted) {
          win._qrWatchStarted = true;
          try {
            const { watchForDepositQr } = require("./src/window/qrCapture.cjs");
            // "tela" precisa ser o número real da janela (1, 2, 3...), igual
            // usado em todo o resto do app (Auto Slot, etc.) — win._winTag é
            // só um identificador interno aleatório (ex.: "WIN-9757"), não o
            // número da tela que o usuário vê.
            watchForDepositQr(win, { valor: depositValue, tela: win._pandoraOrder || win._winTag, login: cred?.login || "" });
          } catch (e) { console.warn("[qr-capture] falha ao iniciar watch:", e?.message); }
        }

        let phonePixKey = "";
        try {
          if (db) {
            const stmt = db.prepare("SELECT key_value FROM pix_keys WHERE key_type='phone' AND status='active' ORDER BY RANDOM() LIMIT 1");
            if (stmt.step()) { const row = stmt.getAsObject(); phonePixKey = String(row.key_value || ""); }
            stmt.free();
          }
        } catch (e) { console.warn("[auto-register] phonePixKey query falhou:", e?.message || e); }
        persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 3 - início da injeção", { url: (() => { try { return win.webContents.getURL(); } catch { return url; } })() });
        const finalScript = buildInjectionScript(cred, { depMin, depMax, depositValue, closeAds, senhaSaque, phonePixKey });
        // Diagnóstico temporário (bug urgente 2026-08-09): mede o tamanho do
        // script AQUI, do lado do Node, ANTES de mandar pro navegador — pra
        // saber se o corte reportado no BOOT 4.3 ("fonte len=") já vem
        // truncado da geração ou acontece depois, no transporte CDP.
        persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 3.5 - finalScript gerado (lado Node)", { len: finalScript.length, tail200: finalScript.slice(-200) });
        // BUG GRAVE real 2026-08-09 (reportado pelo usuário: "não está
        // preenchendo os dados quando abre o site") — confirmado com prova
        // dos dois lados: o Node gera o script com ~71 mil caracteres (log
        // "BOOT 3.5" acima), mas o navegador recebe só ~62 mil ("BOOT 4.3
        // fonte len") — quase 9 mil caracteres somem no meio do caminho, em
        // TODAS as tentativas, sempre cortando perto do mesmo tamanho
        // (~62.446-62.447 em testes diferentes, com scripts de tamanhos
        // finais diferentes) — sinal forte de um limite de tamanho fixo em
        // algum ponto do transporte CDP (executeJavaScript/Runtime.evaluate
        // manda o script INTEIRO numa mensagem só). O retry antigo (reenviar
        // o MESMO script inteiro de novo, até 3x) não resolve mais — se o
        // limite for realmente de TAMANHO, reenviar o mesmo tamanho falha
        // do mesmo jeito toda vez (e foi exatamente o que aconteceu: 3/3
        // tentativas falharam pro usuário).
        //
        // Correção: manda o script em PEDAÇOS pequenos (bem abaixo de
        // qualquer limite que esteja cortando ~62KB), cada um numa chamada
        // separada de executeJavaScript que só ACUMULA texto numa variável
        // global da página (window.__pandoraChunks) — nunca tenta rodar
        // nada até o último pedaço chegar. Só depois de mandar TODOS os
        // pedaços e CONFERIR que o tamanho total bate com o que foi gerado
        // é que roda de verdade (new Function). Cada pedaço isolado é
        // pequeno o bastante pra nunca esbarrar no limite que cortava o
        // envio de uma vez só.
        const CHUNK_SIZE = 12000;
        const injectChunked = async (attempt) => {
          try {
            await win.webContents.executeJavaScript("window.__pandoraChunks = [];", true);
            let idx = 0;
            for (let off = 0; off < finalScript.length; off += CHUNK_SIZE) {
              const chunk = finalScript.slice(off, off + CHUNK_SIZE);
              // BUG real 2026-08-09 (achado NESTE diagnóstico): o tamanho
              // total batia certinho (71195=71195) mesmo assim o parse
              // continuava falhando — suspeita forte de reordenação dos
              // pedaços (mesmo com await sequencial no lado Node, alguma
              // instabilidade do transporte CDP já vista o resto dessa
              // investigação pode entregar fora de ordem). Escreve por
              // ÍNDICE FIXO (array), não por concatenação (+=) — mesmo que
              // as chamadas cheguem fora de ordem, a posição de cada pedaço
              // no resultado final nunca muda.
              // eslint-disable-next-line no-await-in-loop
              await win.webContents.executeJavaScript(`window.__pandoraChunks[${idx}] = ${JSON.stringify(chunk)};`, true);
              idx++;
            }
            const receivedLen = await win.webContents.executeJavaScript("window.__pandoraChunks.join('').length", true);
            persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 3.6 - upload em pedaços concluído", { attempt, enviado: finalScript.length, recebido: receivedLen, totalPedacos: idx });
            if (receivedLen !== finalScript.length) {
              persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 3.7 - tamanho não bateu mesmo em pedaços — tentando de novo", { attempt, enviado: finalScript.length, recebido: receivedLen });
              if (attempt < 3 && !win.isDestroyed()) { setTimeout(() => injectChunked(attempt + 1), 400); return; }
            }
            const v = await win.webContents.executeJavaScript("(new Function(window.__pandoraChunks.join('')))();", true);
            persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 4.0b - wrapper retornou", { attempt, type: typeof v, value: (() => { try { return JSON.stringify(v); } catch { return String(v); } })() });
            if (v === "pandora-wrapper-parse-err" && attempt < 3 && !win.isDestroyed()) {
              persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 4.0c - reinjetando após parse-err", { attempt: attempt + 1 });
              setTimeout(() => injectChunked(attempt + 1), 400);
            }
          } catch (e) {
            persistAutoRegisterLog(db, saveDB, dbPath, "BOOT auto-register executeJavaScript erro", { attempt, name: e?.name || "", message: e?.message || String(e), stack: e?.stack || "" });
            if (attempt < 3 && !win.isDestroyed()) setTimeout(() => injectChunked(attempt + 1), 400);
          }
        };
        injectChunked(1);


      } catch (e) {
        persistAutoRegisterLog(db, saveDB, dbPath, "BOOT exceção antes/durante injeção", { name: e?.name || "", message: e?.message || String(e), stack: e?.stack || "" });
      }
    }, 1500);
  });

  // Listeners diagnósticos: detectam crash do renderer, preload errors e travamentos
  try {
    win.webContents.on("render-process-gone", (_e, details) => {
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT EVT render-process-gone", details || {});
    });
    win.webContents.on("unresponsive", () => {
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT EVT unresponsive", {});
    });
    win.webContents.on("preload-error", (_e, preloadPath, error) => {
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT EVT preload-error", { preloadPath, error: error?.message || String(error) });
    });
    // "did-frame-finish-load" foi removido daqui (2026-08-06) — disparava
    // pra CADA frame/iframe que carregava (incluindo ads/trackers de
    // terceiros embutidos no site alvo), gravando em disco toda vez, pelo
    // tempo de vida INTEIRO da janela (não só durante o cadastro) — uma
    // fonte contínua e sem limite de I/O síncrono, multiplicada por quantas
    // janelas estivessem abertas. Puro ruído de debug que nunca foi
    // removido; render-process-gone/unresponsive/preload-error (eventos
    // raros) continuam logados normalmente.
    persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 1.7 - listeners diagnósticos registrados", {});
  } catch (e) {
    persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 1.7 - falha registrando listeners diagnósticos", { error: e?.message || String(e) });
  }

  // Lógica de fato de processar um marcador __PANDORA_REG__ já extraído —
  // separada do listener de console-message pra poder ser chamada TAMBÉM
  // por um canal direto (page.exposeFunction, ver mais abaixo) que não
  // depende de console.log da página. Muitos sites de produção sobrescrevem
  // console.log no boot (o comentário de buildSafeInjectionWrapper já
  // documentava isso) — o "roubo" de um console.log limpo via iframe ajuda
  // em alguns casos, mas não é garantido contra toda técnica; o canal via
  // exposeFunction (Runtime.addBinding via CDP) é imune a qualquer
  // sobrescrita de console.log da página, igual já resolvemos pro
  // __pandoraNavSignal da toolbar.
  // BUG real 2026-08-10 (reportado pelo usuário: criou 5 contas, log de
  // "Conta criada" saiu tudo duplicado — cada linha duas vezes): o script
  // injetado (buildSafeInjectionWrapper) chama window.__pandoraRawLog, que
  // dispara o MESMO marcador __PANDORA_REG__ em paralelo por dois canais —
  // console.log (capturado pelo listener "console-message" abaixo) E
  // window.__pandoraRegSignal (o exposeFunction mais abaixo) — de propósito,
  // pra funcionar mesmo se um dos dois canais falhar num site específico.
  // Quando os DOIS funcionam (caso normal), handleRegMarker roda 2x pro
  // mesmo evento. Dedup por conteúdo exato do marcador, expirando depois de
  // alguns segundos (msgs iguais legítimas — pouco provável mas possível —
  // não ficam bloqueadas pra sempre).
  const __regMarkerSeen = new Map();
  const handleRegMarker = (message) => {
    if (!message || message.indexOf("__PANDORA_REG__") === -1) return;
    const idx = message.indexOf("__PANDORA_REG__");
    const payload = message.slice(idx + "__PANDORA_REG__".length);

    const now = Date.now();
    for (const [k, t] of __regMarkerSeen) { if (now - t > 5000) __regMarkerSeen.delete(k); }
    if (__regMarkerSeen.has(payload)) return;
    __regMarkerSeen.set(payload, now);

    let data;
    try { data = JSON.parse(payload); } catch { return; }
    if (data.kind === "log") {
      console.log(`[auto-register] ${data.msg}`);
      persistAutoRegisterLog(db, saveDB, dbPath, data.msg, { url: (() => { try { return win.webContents.getURL(); } catch { return ""; } })() });
      return;
    }
    if (data.kind === "submitted") {
      const url = (() => { try { return win.webContents.getURL(); } catch { return ""; } })();
      const saved = saveAutoAccount(db, saveDB, dbPath, data, url);
      if (saved) console.log(`[auto-register] conta enviada salva provisoriamente: ${data.login}`);
      // Marca credenciais como já usadas — qualquer reload subsequente
      // (manual via toolbar, popup não-detectado, etc.) gera novas credenciais.
      try { win._regCredUsed = true; } catch {}
      startRegistrationWatchdog(data);
      return;
    }
    if (data.kind === "created") {
      stopRegistrationWatchdog("created");
      const url = (() => { try { return win.webContents.getURL(); } catch { return ""; } })();
      const saved = saveAutoAccount(db, saveDB, dbPath, data, url);
      if (saved) console.log(`[auto-register] conta salva imediatamente: ${data.login}`);
      // "Depois" do par Criando conta.../Conta criada (mesmo padrão de
      // Saque/PIX/Login) — só quando salvou de fato, evita log de sucesso
      // falso se o insert no banco falhar por algum motivo.
      if (saved) {
        const tela = win._pandoraOrder || "?";
        queueContaCriadaLog(db, saveDB, dbPath, `Tela ${tela} — Conta criada — login=${data.login}`, { tela, login: data.login }, tela);
      }
      // Pedido do usuário 2026-08-09 (reformulado — não é sobre proteger
      // ESSE ou AQUELE popup específico): "após criar a conta e fechar os
      // popups que abrem, deve desativar o script de fechar popup e ir
      // para depósito." Ou seja: o fechador de anúncios (attachPopupCloser)
      // só existe pra limpar a Home logo depois do cadastro — a partir do
      // momento que a conta foi criada, a navegação pro depósito começa
      // (ver "DEPOSITO nav" mais abaixo no script injetado), e NENHUM
      // popup depois disso pode ser mexido (nem no depósito, nem no QR,
      // nem ao clicar em voltar) — desliga aqui, ANTES de qualquer coisa
      // do fluxo de depósito começar, com uma flag permanente na janela
      // (win._pandoraPopupCloserOff, mesma que autoLogin.cjs já respeita —
      // reaproveitada aqui pra não duplicar a lógica de "nunca mais
      // reativar", ver comentário grande em autoLogin.cjs).
      try {
        win._pandoraPopupCloserOff = true;
        win.webContents.executeJavaScript(
          "try{window.__pandoraPopupCloserEnabled=false;window.__pandoraPopupCloserOn=false;document.getElementById('trava-antifecho-lembrete')?.remove();}catch(e){}",
          true
        ).catch(() => {});
      } catch {}
      return;
    }
    if (data.kind === "rejected") {
      stopRegistrationWatchdog("rejected");
      const url = (() => { try { return win.webContents.getURL(); } catch { return ""; } })();
      deleteAutoAccount(db, saveDB, dbPath, data, url);
      // Gera outro login imediatamente: mesmo se o reload atrasar ou não acontecer,
      // a próxima injeção já usa dados novos e nunca repete a conta existente.
      rotateCredentials("taken-immediate");
      try {
        if (win && !win.isDestroyed()) {
          setTimeout(() => {
            try {
              if (!win.isDestroyed()) win.webContents.reloadIgnoringCache();
            } catch {}
          }, 150);
        }
      } catch {}
      return;
    }
    if (data.kind === "done") {
      stopRegistrationWatchdog("done-" + (data.status || ""));
      console.log(`[auto-register] resultado: ${data.status} login=${data.login} dep=${data.depStatus}`);
      if (data.status === "network-error") {
        const url = (() => { try { return win.webContents.getURL(); } catch { return ""; } })();
        deleteAutoAccount(db, saveDB, dbPath, data, url);
        return;
      }
      // Salva a conta sempre que o cadastro tiver sido efetivamente enviado ao site.
      // Antes só salvávamos com status === 'ok' (QR de depósito atingido); agora também
      // salvamos quando 'timeout' (form sumiu / proxy lenta) — o cadastro foi concluído
      // no servidor mesmo sem alcançar o QR de depósito. Assim nenhuma conta criada
      // se perde em Contas.
      const SAVE_STATUS = new Set(["ok", "timeout"]);
      const registered = data && SAVE_STATUS.has(data.status);
      const hasCreds = data && data.login && data.senha;
      if (registered && hasCreds && db) {
        const url = (() => { try { return win.webContents.getURL(); } catch { return ""; } })();
        saveAutoAccount(db, saveDB, dbPath, data, url);
      }
    }
  };

  let __consoleMsgCount = 0;
  win.webContents.on("console-message", (...args) => {
    __consoleMsgCount++;
    // Electron 33 antigo: (event, level, message, line, sourceId)
    // Electron novo (object form): (event) onde event.message contém o texto
    let message = "";
    let level = "";
    if (args.length >= 3 && typeof args[2] === "string") {
      message = args[2];
      level = String(args[1] || "");
    } else if (args[0] && typeof args[0] === "object" && typeof args[0].message === "string") {
      message = args[0].message;
      level = String(args[0].level || "");
    }
    // Loga TODA mensagem capturada (truncada) para confirmar que console-message está ativo
    if (__consoleMsgCount <= 50) {
      persistAutoRegisterLog(db, saveDB, dbPath, "BOOT EVT console-message raw", {
        n: __consoleMsgCount,
        level,
        len: message.length,
        hasMarker: message.indexOf("__PANDORA_REG__") !== -1,
        sample: message.slice(0, 200),
      });
    }
    // Captura PANDORA_FATAL independentemente do prefixo __PANDORA_REG__
    if (message && message.indexOf("PANDORA_FATAL:") !== -1) {
      const fIdx = message.indexOf("PANDORA_FATAL:");
      persistAutoRegisterLog(db, saveDB, dbPath, "PANDORA_FATAL capturado", { raw: message.slice(fIdx, fIdx + 2000) });
    }
    handleRegMarker(message);
  });

  // Canal direto (Chrome real — ver realChromeManager.cjs/webContentsShim.cjs):
  // page.exposeFunction usa Runtime.addBinding via CDP, que não passa pelo
  // console da página de jeito nenhum — imune a qualquer técnica de
  // sobrescrever/desativar console.log que o site use. window.__pandoraRawLog
  // (buildSafeInjectionWrapper, acima) chama isso em paralelo ao console.log
  // "roubado" sempre que existir, então esse canal funciona mesmo quando o
  // outro falhar.
  if (win._realChrome && win._page && typeof win._page.exposeFunction === "function") {
    win._page.exposeFunction("__pandoraRegSignal", (raw) => {
      try { handleRegMarker(String(raw || "")); } catch (e) {}
    }).catch((e) => {
      try { persistAutoRegisterLog(db, saveDB, dbPath, "BOOT 1.7 - exposeFunction __pandoraRegSignal falhou", { error: e?.message || String(e) }); } catch {}
    });
  }
}

// ============================================================
// Captcha solver: APENAS CapSolver (Geetest) via geetest-attach.cjs
// IA da Lovable foi removida por decisão do usuário — não reintroduzir.
// ============================================================

function attachCaptchaSolver(_win) {
  // no-op: resolução do captcha é feita exclusivamente pelo CapSolver
  // dentro de geetest-attach.cjs / captcha-solver.cjs.
  return;
}

module.exports = { attachAutoRegister, attachCaptchaSolver, genCredentials, getDiagFilePath, saveAutoAccount, persistAutoRegisterLog, setAccountsChangeNotifier, queueDiagLine, flushDiagQueueSync, setContaCriadaBatchTotal };

