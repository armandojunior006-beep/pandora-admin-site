// Pandora popup killer — adaptado das extensões Cash_Hunters (mobile + desktop).
// Executado em TODO frame via chromium-preload.cjs (nodeIntegrationInSubFrames).
// NÃO clica em "Registro" — quem cuida do fluxo de cadastro é o auto-register.
// Mantém apenas a remoção de popups/overlays/banners que cobrem o submit.
(function () {
  if (window.__pandoraPopupKillerInstalled) return;
  window.__pandoraPopupKillerInstalled = true;

  var CONFIG = { OBSERVER_THROTTLE: 10, INTERVAL_CHECK: 1500, LOGGING: false };
  var log = function (m) { if (CONFIG.LOGGING) try { console.log('[pandora-popup]', m); } catch (_) {} };
  var processed = new WeakSet();

  function safeRemove(el) {
    try {
      if (el && el.parentNode && !processed.has(el)) {
        // Não remove o overlay do nosso próprio solver
        if (el.id === '__pandora_captcha_solving_overlay__') return false;
        if (el.querySelector && el.querySelector('#__pandora_captcha_solving_overlay__')) return false;
        // Não remove cadastro/captcha/sucesso de registro: isso deixava telas presas em "Cadastrando...".
        if (isProtectedRegistrationNode(el)) return false;
        el.remove();
        processed.add(el);
        return true;
      }
    } catch (_) {}
    return false;
  }

  function isProtectedRegistrationNode(el) {
    try {
      if (!el || !el.querySelector) return false;
      if (el.matches && el.matches('#insideRegisterSubmitClick,[data-type="MangoMobileRegisterSuccessDialog"],.geetest_panel,.geetest_panel_box,.geetest_box,.geetest_holder,.geetest_widget')) return true;
      if (el.querySelector('#insideRegisterSubmitClick,input[data-input-name="account"],input[data-input-name="userpass"],input[data-input-name="confirmPassword"],input[data-input-name="phone"],textarea[data-input-name="account"],[data-type="MangoMobileRegisterSuccessDialog"],.geetest_panel,.geetest_panel_box,.geetest_box,.geetest_holder,.geetest_widget,iframe[src*="geetest"],iframe[src*="gcaptcha"],iframe[src*="gsensebot"],iframe[src*="geevisit"]')) return true;
      var text = String(el.textContent || '').toLowerCase();
      if (/cadastrando|cadastro|registro|registrado com sucesso|cadastrado com sucesso|nome de usu[aá]rio existente/.test(text)) return true;
    } catch (_) {}
    return false;
  }

  var ALWAYS_REMOVE_SELECTORS = [
    '[class^="_Style02_"]','[class^="_carouselBox_"]','#downloadDom','[class*="_pot_container_"]',
    'div[data-v][class*="menu-button-left"][class*="menu-button"]','.top-noty-bar-frame',
    '[class*="grid-container item"]','[class*="tournamentBg"]','#credential_picker_iframe',
    '[class*="cursor-pointer fixed absolute-bottom"]','[class*="appDownload "]',
    'img[src*="website/wheel_show"]','#draggableArea',
    '#js_banner','.app-download','[class^="_voiceIconBox_"]','[class^="global-live"]','[class*="_live-stream-drag"]',
    '#js_notice','.menu-float-frame','#credentials-picker-container','[style*="/static/img/jackpot/"]',
    '[class^="_floatInHome_"]','[class*="_jackpot_"]','[class^="_marquee_"]',
    '[class^="swiperWarp-"]','.top-libanner-frame','[class^="_banner-container"]',
    '[class^="_top-download"]','[class^="_footerBox_"]','[class^="warpaa-"]','#jackportNoticeTop',
    '.vague_mask_dialog','.bottom-btn-box','.jackpot-box',
    '#MobileTopDownloadDom','.bg.top-banner-frame','.van-swipe.swipe-box','.filter.maskColor1','.pwaDownload',
    '.mangoPopup-shadow-jcq6v','.jackpot-H6o_i','[data-type="MobileBackHomePopup"]',
    '.anno-dialog','.pop-red-envelopes','.banner-qFrt8','.jackpot-LCRJl',
    '.notice-HNE7Y','[class^="_fastList_"]','.marquee','.footer-iSAvP','[data-type="MobileBottomDownloadPopupStyle"]',
    '.nav-top-down-apk','.password-save-dialog','[data-type="NotiftPopup"]','#orientationMask',
    '[class^="drag-wNihq"]','uni-view.notice','uni-view.jackpot','[data-type^="MobileCenterDownload"]',
    'uni-view.copyright','uni-view.advertising','uni-view.swiper','.swiper_box',
    '.top-fixed-box','[class^="_broadcast_"]','[class^="_hk-activities"]','#rotateTip',
    '.marryImg','.swiper-container.my-swipe.swiper-container-initialized.swiper-container-horizontal','.jackpot','.notice.flex',
    '.xiazaippp','.indextongzhu','.headerDownloadBox',
    '#jackportBannerTop','#rewardRecord_bannerTop','#forumBoard_bannerTop','#forumTopic_bannerTop','.banner-M0p_H',
    '#rewardRecord_bannerBottom','#forumBoard_bannerBottom','#forumTopic_bannerBottom','#jackportBannerBottom','#jackportNoticeBottom',
    '#floatBannerBottom','[class^="fp-"]','[class^="ts-content-"]',
    '[class^="_download-i"]','[class^="_live-player-"]',
    // Botão flutuante "voltar ao topo" (ícone de foguete): fica clicável mesmo
    // sem texto/filhos visíveis no HTML e faz a página subir sozinha quando
    // acionado — remove pra não ter como isso acontecer, de propósito ou não.
    '[class^="_floatBox_"]'
  ];

  function bulkRemove(sels) {
    for (var i = 0; i < sels.length; i++) {
      try {
        var nodes = document.querySelectorAll(sels[i]);
        for (var j = 0; j < nodes.length; j++) safeRemove(nodes[j]);
      } catch (_) {}
    }
  }

  function removeUnwantedModals() {
    var modals = document.querySelectorAll('.ui-overlay.wg-fixed-no-desktop');
    for (var i = 0; i < modals.length; i++) {
      var modal = modals[i];
      var popup = modal.querySelector('.ui-popup') || modal;
      var classList = Array.from(popup.classList || []);
      var text = popup.textContent || '';
      var bad = (
        classList.some(function (c) { return c.indexOf('_modal_') >= 0 && c.indexOf('_main-recharge_') < 0; }) ||
        classList.some(function (c) { return c.indexOf('_hasBtn_') >= 0; }) ||
        classList.some(function (c) { return c.indexOf('_find-us_') >= 0; }) ||
        classList.some(function (c) { return c.indexOf('_download_') >= 0; }) ||
        classList.some(function (c) { return c.indexOf('red-pocket') >= 0; }) ||
        classList.some(function (c) { return c.indexOf('_bottom_') >= 0; }) ||
        classList.some(function (c) { return c.indexOf('_distributed') >= 0; }) ||
        classList.some(function (c) { return c.indexOf('_surprise-reward_') >= 0; }) ||
        (popup.getAttribute && popup.getAttribute('data-dialog-name') === 'surpriseReward') ||
        modal.querySelector('[data-dialog-name="surpriseReward"]') ||
        popup.querySelector('[class^="_btns_"]')
      );
      if (bad) safeRemove(modal);
    }
  }

  function removeMaskColor2() {
    var modals = document.querySelectorAll('.filter.maskColor2');
    for (var i = 0; i < modals.length; i++) {
      var modal = modals[i];
      if (!modal.firstElementChild) continue;
      var popup = modal.querySelector('[data-component]') || modal.firstElementChild;
      var classList = Array.from(popup.classList || []);
      var protectedEl = (
        classList.some(function (c) { return c.indexOf('depositBonusPopup') >= 0; }) ||
        classList.some(function (c) { return c.indexOf('claimReward') >= 0; }) ||
        modal.querySelector('.giftbox') ||
        modal.querySelector('.depositBonusPopup') ||
        modal.querySelector('.claimReward') ||
        isProtectedRegistrationNode(modal)
      );
      if (!protectedEl) safeRemove(modal);
    }
  }

  function removeUniBottom() {
    var modals = document.querySelectorAll('.uni-popup.bottom');
    for (var i = 0; i < modals.length; i++) {
      var m = modals[i];
      if (m.querySelector('.gold-element') || m.querySelector('.red-pack-award-dialog-layout') || m.querySelector('.pending-giftbox')) {
        safeRemove(m);
      }
    }
  }

  function closeAgeBoxAndAlerts() {
    // Web-push tip (ex.: 5gbet "torne-se agente"): overlay com backdrop que
    // intercepta cliques — trava a entrada no slot mesmo achando o card.
    // Fecha clicando no próprio "cancel".
    try {
      var wp = document.querySelector('.web-push-tip-cancel');
      if (wp) wp.click();
    } catch (_) {}
    // Age box: clica "Sim"
    try {
      var age = document.querySelector('div[class^="_age_box_"]');
      if (age) {
        var yes = Array.from(age.querySelectorAll('div, button')).find(function (b) { return (b.textContent || '').trim() === 'Sim'; });
        if (yes) yes.click();
      }
    } catch (_) {}
    // Language/currency popup: clica no X
    try {
      var lang = document.querySelector('[class*="_switchCurrencyLangContainer_"]');
      if (lang) {
        var overlay = lang.closest('.ui-overlay') || lang.closest('.ui-popup');
        if (overlay) {
          var ic = overlay.querySelector('.ui-dialog-close-box__icon');
          if (ic) ic.click();
        }
      }
    } catch (_) {}
    // PWA compulsory
    try {
      var pwa = document.querySelector('#pwa-compulsory-modal.show-modal');
      if (pwa && !pwa._pwaClosing) {
        pwa._pwaClosing = true;
        var ic = pwa.querySelector('ion-icon[slot="icon-only"]');
        if (ic) ic.click();
        else { try { pwa.dismiss && pwa.dismiss().catch(function(){}); } catch (_) {} }
      }
    } catch (_) {}
    // Tela cheia dialog → Cancelar
    try {
      var dialogs = document.querySelectorAll('.ui-dialog__main');
      for (var i = 0; i < dialogs.length; i++) {
        var d = dialogs[i];
        var t = (d.textContent || '').toLowerCase();
        if (t.indexOf('tela cheia') < 0 && t.indexOf('tela inteira') < 0 && t.indexOf('experiência de jogo') < 0) continue;
        var cancel = Array.from(d.querySelectorAll('button')).find(function (b) {
          return Array.from(b.classList).some(function (c) { return c.indexOf('ui-button') >= 0; }) &&
                 (b.textContent || '').trim().toLowerCase().indexOf('cancelar') >= 0;
        });
        if (cancel) { cancel.click(); break; }
      }
    } catch (_) {}
  }

  function injectCss() {
    try {
      var s = document.createElement('style');
      s.textContent =
        '.filter.maskColor2:has(.depositBonusPopup),.filter.maskColor2:has(.giftbox),.filter.maskColor2:has(.claimReward){display:block !important;}';
      (document.head || document.documentElement).appendChild(s);
    } catch (_) {}
  }

  // Abre o modal de "Registro" automaticamente ao detectar a home/landing,
  // adaptado do Cash_Script (extensão Cash_Hunters). Só clica UMA vez por
  // navegação e nunca se o modal de cadastro já está aberto.
  function openRegistroIfNeeded() {
    try {
      if (window.__pandoraRegistroOpened) return;
      // Modal já aberto? Não clica.
      if (document.querySelector(
        '#insideRegisterSubmitClick,'
        + 'input[data-input-name="account"],textarea[data-input-name="account"],'
        + 'input[data-input-name="userpass"],textarea[data-input-name="userpass"]'
      )) { window.__pandoraRegistroOpened = true; return; }
      // 1) id exato do template do site alvo
      var btn = document.getElementById('registerClickModal');
      // 2) fallback: qualquer elemento clicável com classe iniciando em _btn_
      //    cujo texto seja exatamente "registro" / "cadastro" / "cadastrar"
      if (!btn) {
        var candidates = document.querySelectorAll('a,button,div,span,li,[role="button"]');
        for (var i = 0; i < candidates.length; i++) {
          var el = candidates[i];
          if (!el || !el.classList) continue;
          var hasBtnClass = false;
          for (var k = 0; k < el.classList.length; k++) {
            if (el.classList[k].indexOf('_btn_') === 0) { hasBtnClass = true; break; }
          }
          if (!hasBtnClass) continue;
          var txt = (el.textContent || '').trim().toLowerCase();
          if (txt.length === 0 || txt.length > 24) continue;
          if (/^(registro|registrar|cadastro|cadastrar|sign\s*up)$/.test(txt)) { btn = el; break; }
        }
      }
      if (!btn) return;
      try {
        var r = btn.getBoundingClientRect();
        if (!r || r.width < 1 || r.height < 1) return;
      } catch (_) {}
      window.__pandoraRegistroOpened = true;
      try { btn.click(); } catch (_) {}
    } catch (_) {}
  }

  function tick() {
    try {
      closeAgeBoxAndAlerts();
      removeUnwantedModals();
      removeMaskColor2();
      removeUniBottom();
      bulkRemove(ALWAYS_REMOVE_SELECTORS);
      openRegistroIfNeeded();
    } catch (_) {}
  }

  function init() {
    injectCss();
    tick();
    var last = 0;
    try {
      var obs = new MutationObserver(function (muts) {
        var now = performance.now();
        if (now - last < CONFIG.OBSERVER_THROTTLE) return;
        last = now;
        var hasAdded = false;
        for (var i = 0; i < muts.length; i++) { if (muts[i].addedNodes && muts[i].addedNodes.length) { hasAdded = true; break; } }
        if (!hasAdded) return;
        tick();
      });
      obs.observe(document.body || document.documentElement, { childList: true, subtree: true });
    } catch (_) {}
    try { setInterval(tick, CONFIG.INTERVAL_CHECK); } catch (_) {}
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    setTimeout(init, 0);
  } else {
    window.addEventListener('DOMContentLoaded', init);
  }
})();
