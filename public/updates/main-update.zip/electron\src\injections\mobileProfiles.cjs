// ============================================================================
// CHROME INDETECTÁVEL — Rotação de User-Agent MOBILE por janela
// ----------------------------------------------------------------------------
// Quando a opção "Chrome Indetectável" estiver ativa (nav_chrome_indetectavel=1),
// cada nova janela/aba Chromium recebe um perfil de dispositivo móvel diferente
// (iOS Safari e Android Chrome alternados aleatoriamente). Isso engloba:
//   - User-Agent na sessão e no webContents
//   - navigator.platform, maxTouchPoints, vendor coerentes
//   - dica visual: o site renderiza como mobile (a janela continua desktop)
// ============================================================================
const { getSettingSync } = require("../settings/settingsStore.cjs");

const STEALTH_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

const MOBILE_DEVICE_PROFILES = [
  // ---------- iOS ----------
  { os: "ios", name: "iPhone 15 Pro Max",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 15 Pro",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 15",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 14 Pro Max",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 16_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 14 Pro",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 14",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 13 Pro Max",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 16_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.3 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 13",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 15_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 12 Pro",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 15_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.4 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 12",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 15_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.2 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 11 Pro",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone 11",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 14_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone XR",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 13_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  { os: "ios", name: "iPhone SE",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 16_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1",
    platform: "iPhone", vendor: "Apple Computer, Inc.", touch: 5 },
  // ---------- Android ----------
  { os: "android", name: "Samsung Galaxy S24 Ultra",
    ua: "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Samsung Galaxy S24",
    ua: "Mozilla/5.0 (Linux; Android 14; SM-S921B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Samsung Galaxy S23 Ultra",
    ua: "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Samsung Galaxy S23",
    ua: "Mozilla/5.0 (Linux; Android 13; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Samsung Galaxy A54",
    ua: "Mozilla/5.0 (Linux; Android 13; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Samsung Galaxy A34",
    ua: "Mozilla/5.0 (Linux; Android 13; SM-A346B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Samsung Galaxy Note 20",
    ua: "Mozilla/5.0 (Linux; Android 12; SM-N981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Google Pixel 8 Pro",
    ua: "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Google Pixel 8",
    ua: "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Google Pixel 7 Pro",
    ua: "Mozilla/5.0 (Linux; Android 13; Pixel 7 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Google Pixel 7",
    ua: "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Google Pixel 6a",
    ua: "Mozilla/5.0 (Linux; Android 13; Pixel 6a) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Xiaomi 13 Pro",
    ua: "Mozilla/5.0 (Linux; Android 13; 2210132G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Xiaomi Redmi Note 12",
    ua: "Mozilla/5.0 (Linux; Android 13; 23021RAAEG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Xiaomi Poco X5 Pro",
    ua: "Mozilla/5.0 (Linux; Android 13; 22101320G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Motorola Edge 40",
    ua: "Mozilla/5.0 (Linux; Android 13; motorola edge 40) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Motorola Moto G84",
    ua: "Mozilla/5.0 (Linux; Android 13; moto g84 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "OnePlus 11",
    ua: "Mozilla/5.0 (Linux; Android 13; CPH2449) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "OnePlus Nord 3",
    ua: "Mozilla/5.0 (Linux; Android 13; CPH2491) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Realme GT Neo 5",
    ua: "Mozilla/5.0 (Linux; Android 13; RMX3708) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
  { os: "android", name: "Asus ROG Phone 7",
    ua: "Mozilla/5.0 (Linux; Android 13; ASUS_AI2205) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv8l", vendor: "Google Inc.", touch: 5 },
];

let __mobileProfileCursor = Math.floor(Math.random() * MOBILE_DEVICE_PROFILES.length);
function pickMobileProfile() {
  // Alterna garantindo intercalar iOS/Android quando possível (não 2 iguais seguidos).
  const last = global.__pandoraLastMobileProfile || null;
  for (let tries = 0; tries < 8; tries++) {
    __mobileProfileCursor = (__mobileProfileCursor + 1 + Math.floor(Math.random() * 3)) % MOBILE_DEVICE_PROFILES.length;
    const p = MOBILE_DEVICE_PROFILES[__mobileProfileCursor];
    if (!last || p.os !== last.os || Math.random() < 0.35) {
      global.__pandoraLastMobileProfile = p;
      return p;
    }
  }
  const p = MOBILE_DEVICE_PROFILES[__mobileProfileCursor];
  global.__pandoraLastMobileProfile = p;
  return p;
}

function isChromeIndetectavelOn() {
  try { return getSettingSync("nav_chrome_indetectavel", "0") === "1"; } catch { return false; }
}

// Retorna { ua, profile|null }. profile != null somente quando indetectável está ON.
function nextSessionUA() {
  if (!isChromeIndetectavelOn()) return { ua: STEALTH_UA, profile: null };
  const p = pickMobileProfile();
  return { ua: p.ua, profile: p };
}

// Ajusta cabeçalhos HTTP para combinar com o perfil mobile escolhido
// (Accept-Language natural pt-BR e Sec-CH-UA-* coerentes com SO).
// IMPORTANTE: NÃO mexe em viewport, touch, ou qualquer comportamento.
function applyMobileHeaders(ses, profile) {
  if (!ses || !profile) return;
  try {
    ses.webRequest.onBeforeSendHeaders((details, cb) => {
      const h = details.requestHeaders || {};
      h["Accept-Language"] = "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7";
      // Safari iOS não envia Sec-CH-UA; Chrome Android sim.
      if (profile.os === "ios") {
        delete h["sec-ch-ua"]; delete h["Sec-CH-UA"];
        delete h["sec-ch-ua-mobile"]; delete h["Sec-CH-UA-Mobile"];
        delete h["sec-ch-ua-platform"]; delete h["Sec-CH-UA-Platform"];
      } else {
        // Android Chrome
        const chromeVer = (profile.ua.match(/Chrome\/(\d+)/) || [, "126"])[1];
        h["sec-ch-ua"] = `"Chromium";v="${chromeVer}", "Not.A/Brand";v="24", "Google Chrome";v="${chromeVer}"`;
        h["sec-ch-ua-mobile"] = "?1";
        h["sec-ch-ua-platform"] = '"Android"';
      }
      cb({ requestHeaders: h });
    });
  } catch {}
}

module.exports = {
  STEALTH_UA,
  MOBILE_DEVICE_PROFILES,
  pickMobileProfile,
  isChromeIndetectavelOn,
  nextSessionUA,
  applyMobileHeaders,
};
