import { useEffect, useState } from "react";
import { Plus, Play, Pencil, Trash2, ShieldCheck, Loader2, LogOut, Box } from "lucide-react";
import pandoraLogo from "@/assets/logo.png";
import { useAuth } from "@/stores/auth";
import { useCloudSession } from "@/stores/cloud-session";

type Profile = {
  id: string;
  name: string;
  createdAt: string;
  lastOpenedAt: string | null;
  isPrincipal: boolean;
};

declare global {
  interface Window {
    multibotAPI?: {
      mode: () => Promise<{ isLauncher: boolean; profileId: string | null }>;
      list: () => Promise<{ ok: boolean; profiles?: Profile[]; error?: string }>;
      create: (name: string, importSettings?: boolean) => Promise<{ ok: boolean; profile?: Profile; error?: string }>;
      rename: (id: string, name: string) => Promise<{ ok: boolean; error?: string }>;
      remove: (id: string) => Promise<{ ok: boolean; error?: string }>;
      open: (id: string, session?: unknown) => Promise<{ ok: boolean; pid?: number; error?: string }>;
    };
  }
}

function formatDate(iso: string | null): string {
  if (!iso) return "Nunca aberto";
  try {
    return new Date(iso).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
  } catch { return "—"; }
}

export function MultiBot() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState("");
  const [importSettings, setImportSettings] = useState(true);
  const [renameTarget, setRenameTarget] = useState<Profile | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const logoutAuth = useAuth((s) => s.logout);
  const clearCloud = useCloudSession((s) => s.clear);
  const session = useCloudSession((s) => s.session);

  async function reload() {
    if (!window.multibotAPI) {
      setError("Multi Bot indisponível: reinstale o app atualizado.");
      setLoading(false);
      return;
    }
    setLoading(true);
    const r = await window.multibotAPI.list();
    if (r.ok) { setProfiles(r.profiles || []); setError(null); }
    else setError(r.error || "Falha ao carregar perfis");
    setLoading(false);
  }

  useEffect(() => { reload(); }, []);

  async function handleOpen(p: Profile) {
    if (!window.multibotAPI) return;
    setBusyId(p.id);
    // Repassa a sessão de nuvem já validada aqui no launcher — o perfil que
    // abre não deve pedir login de novo (pedido do usuário 2026-08-09).
    const r = await window.multibotAPI.open(p.id, session || undefined);
    setBusyId(null);
    if (!r.ok) setError(r.error || "Falha ao abrir perfil");
    else setTimeout(reload, 500);
  }

  async function handleCreate() {
    if (!window.multibotAPI) return;
    const name = newName.trim();
    if (!name) return;
    const r = await window.multibotAPI.create(name, importSettings);
    if (!r.ok) { setError(r.error || "Falha ao criar"); return; }
    setShowNew(false); setNewName(""); setImportSettings(true);
    await reload();
    if (r.profile) await handleOpen({ ...r.profile, isPrincipal: false } as Profile);
  }

  async function handleRename() {
    if (!window.multibotAPI || !renameTarget) return;
    const name = renameValue.trim();
    if (!name) return;
    const r = await window.multibotAPI.rename(renameTarget.id, name);
    if (!r.ok) { setError(r.error || "Falha ao renomear"); return; }
    setRenameTarget(null); setRenameValue("");
    reload();
  }

  async function handleDelete(p: Profile) {
    if (!window.multibotAPI) return;
    if (!confirm(`Excluir perfil "${p.name}"? Todos os dados (contas, sessões, proxies, chaves) serão perdidos.`)) return;
    const r = await window.multibotAPI.remove(p.id);
    if (!r.ok) { setError(r.error || "Falha ao excluir"); return; }
    reload();
  }

  function handleLogout() {
    try { clearCloud(); } catch {}
    try { logoutAuth(); } catch {}
  }

  return (
    <div className="min-h-screen app-bg text-neutral-100">
      <header className="flex items-center justify-between px-6 py-4 border-b border-white/10">
        <div className="flex items-center gap-3">
          <img src={pandoraLogo} alt="Spider Bot" className="h-9 w-9 rounded" />
          <div>
            <div className="text-lg font-semibold tracking-wide">Spider Multi Bot</div>
            <div className="text-xs text-neutral-400 flex items-center gap-1">
              <ShieldCheck className="h-3 w-3" />
              07corp · gerenciador de perfis
            </div>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-3 py-2 rounded-md text-sm border border-white/10 hover:bg-white/5"
        >
          <LogOut className="h-4 w-4" /> Sair
        </button>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Perfis</h1>
            <p className="text-sm text-neutral-400">
              Cada perfil é uma instância 100% isolada do bot: contas, sessões, proxies e chaves separadas.
            </p>
          </div>
          <button
            onClick={() => setShowNew(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-md bg-white text-black font-semibold hover:bg-neutral-200"
          >
            <Plus className="h-5 w-5" /> Novo Perfil
          </button>
        </div>

        {error && (
          <div className="mb-4 px-4 py-3 rounded-md bg-red-950/40 border border-red-800/60 text-red-200 text-sm">
            {error}
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-20 text-neutral-400">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {profiles.map((p) => (
              <div
                key={p.id}
                className="rounded-xl border border-white/10 bg-panel2 p-5 flex flex-col gap-3 hover:border-white/20 transition"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-11 w-11 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
                      <Box className="h-5 w-5 text-neutral-300" />
                    </div>
                    <div>
                      <div className="font-semibold text-base leading-tight">{p.name}</div>
                      {p.isPrincipal && (
                        <span className="text-[10px] uppercase tracking-wider text-emerald-400 font-semibold">
                          Padrão
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-xs text-neutral-500">
                  Última abertura: {formatDate(p.lastOpenedAt)}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <button
                    onClick={() => handleOpen(p)}
                    disabled={busyId === p.id}
                    className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-md bg-white text-black font-semibold text-sm hover:bg-neutral-200 disabled:opacity-60"
                  >
                    {busyId === p.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />}
                    Abrir
                  </button>
                  {!p.isPrincipal && (
                    <>
                      <button
                        onClick={() => { setRenameTarget(p); setRenameValue(p.name); }}
                        title="Renomear"
                        className="p-2 rounded-md border border-white/10 hover:bg-white/5"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(p)}
                        title="Excluir"
                        className="p-2 rounded-md border border-white/10 hover:bg-red-950/40 hover:border-red-800/60 text-red-300"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {showNew && (
        <Modal title="Novo Perfil" onClose={() => { setShowNew(false); setNewName(""); setImportSettings(true); }}>
          <input
            autoFocus
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleCreate()}
            placeholder="Nome do perfil (ex.: Conta 2)"
            className="w-full px-3 py-2 rounded-md bg-black/40 border border-white/10 text-sm"
            maxLength={40}
          />

          <div className="mt-4">
            <div className="text-sm font-medium mb-2">Importar configurações do bot principal?</div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setImportSettings(true)}
                className={`flex-1 px-3 py-2 rounded-md border text-sm font-semibold transition ${
                  importSettings ? "bg-white text-black border-white" : "border-white/10 text-neutral-300 hover:bg-white/5"
                }`}
              >
                Sim
              </button>
              <button
                type="button"
                onClick={() => setImportSettings(false)}
                className={`flex-1 px-3 py-2 rounded-md border text-sm font-semibold transition ${
                  !importSettings ? "bg-white text-black border-white" : "border-white/10 text-neutral-300 hover:bg-white/5"
                }`}
              >
                Não
              </button>
            </div>
            <div className="text-xs text-neutral-500 mt-2">
              {importSettings
                ? "Copia contas, proxies, chaves Pix e demais configurações do perfil PRINCIPAL para este novo perfil (contas de cassino/sessões do Chromium continuam separadas — cada perfil loga as suas)."
                : "O perfil será criado vazio. Você precisará configurar contas, proxies e chaves do zero."}
            </div>
          </div>

          <div className="flex justify-end gap-2 mt-4">
            <button onClick={() => { setShowNew(false); setNewName(""); setImportSettings(true); }}
              className="px-3 py-2 rounded-md border border-white/10 text-sm">Cancelar</button>
            <button onClick={handleCreate}
              className="px-4 py-2 rounded-md bg-white text-black font-semibold text-sm">Criar e Abrir</button>
          </div>
        </Modal>
      )}

      {renameTarget && (
        <Modal title={`Renomear "${renameTarget.name}"`} onClose={() => setRenameTarget(null)}>
          <input
            autoFocus
            value={renameValue}
            onChange={(e) => setRenameValue(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleRename()}
            className="w-full px-3 py-2 rounded-md bg-black/40 border border-white/10 text-sm"
            maxLength={40}
          />
          <div className="flex justify-end gap-2 mt-4">
            <button onClick={() => setRenameTarget(null)}
              className="px-3 py-2 rounded-md border border-white/10 text-sm">Cancelar</button>
            <button onClick={handleRename}
              className="px-4 py-2 rounded-md bg-white text-black font-semibold text-sm">Salvar</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-panel2 border border-white/10 rounded-xl p-6 w-full max-w-md mx-4" onClick={(e) => e.stopPropagation()}>
        <div className="text-lg font-semibold mb-3">{title}</div>
        {children}
      </div>
    </div>
  );
}
