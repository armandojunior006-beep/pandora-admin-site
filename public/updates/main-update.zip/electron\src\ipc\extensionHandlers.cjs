// ============================================================================
// IPC: extensão customizada (Operação → Ferramentas → "Extensão"). Permite
// importar um .zip de extensão Chrome e usá-la em TODAS as janelas Chromium
// abertas (open/openMulti/openForContas) quando o toggle "Extensão" está
// ativo (setting op_extensao_ativa). Independente da extensão de captcha
// interna (loadCaptchaExtension em stealth.cjs) — as duas convivem.
// ============================================================================
const { app, dialog } = require("electron");
const fs = require("fs");
const path = require("path");
const extractZip = require("extract-zip");
const state = require("../state.cjs");
const { getSettingSync, setSettingSync } = require("../settings/settingsStore.cjs");

function getExtensionDir() {
  return path.join(app.getPath("userData"), "custom-extension");
}

// O .zip pode ter o manifest.json na raiz OU dentro de uma única pasta-wrapper
// (comum em exports do Chrome Web Store / "Download as zip" do GitHub).
// Procura até 2 níveis de profundidade e retorna a pasta que contém o manifest.
function findManifestDir(root) {
  const direct = path.join(root, "manifest.json");
  if (fs.existsSync(direct)) return root;
  let entries = [];
  try { entries = fs.readdirSync(root, { withFileTypes: true }); } catch { return null; }
  for (const e of entries) {
    if (!e.isDirectory()) continue;
    const sub = path.join(root, e.name);
    if (fs.existsSync(path.join(sub, "manifest.json"))) return sub;
  }
  return null;
}

function registerExtensionHandlers(ipcMain) {
  ipcMain.handle("ext:import", async () => {
    try {
      const r = await dialog.showOpenDialog(state.mainWin, {
        title: "Importar extensão (.zip)",
        filters: [{ name: "Extensão Chrome (zip)", extensions: ["zip"] }],
        properties: ["openFile"],
      });
      if (r.canceled || !r.filePaths.length) return { ok: false, canceled: true };
      const zipPath = r.filePaths[0];

      const destDir = getExtensionDir();
      fs.rmSync(destDir, { recursive: true, force: true });
      fs.mkdirSync(destDir, { recursive: true });
      await extractZip(zipPath, { dir: destDir });

      const manifestDir = findManifestDir(destDir);
      if (!manifestDir) {
        fs.rmSync(destDir, { recursive: true, force: true });
        return { ok: false, error: "manifest.json não encontrado no .zip — não parece ser uma extensão Chrome válida." };
      }
      let name = path.basename(zipPath, ".zip");
      try {
        const manifest = JSON.parse(fs.readFileSync(path.join(manifestDir, "manifest.json"), "utf8"));
        if (manifest.name) name = String(manifest.name);
      } catch {}

      setSettingSync("op_custom_extension_path", manifestDir);
      setSettingSync("op_custom_extension_name", name);
      return { ok: true, name, path: manifestDir };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  ipcMain.handle("ext:getInfo", async () => {
    const extPath = getSettingSync("op_custom_extension_path", "");
    const name = getSettingSync("op_custom_extension_name", "");
    const active = getSettingSync("op_extensao_ativa", "0") === "1";
    const exists = !!(extPath && fs.existsSync(path.join(extPath, "manifest.json")));
    return { ok: true, name: exists ? name : "", path: exists ? extPath : "", active };
  });

  ipcMain.handle("ext:remove", async () => {
    try {
      fs.rmSync(getExtensionDir(), { recursive: true, force: true });
      setSettingSync("op_custom_extension_path", "");
      setSettingSync("op_custom_extension_name", "");
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });
}

// Usado por chromiumWindows.cjs ao preparar cada sessão — carrega a extensão
// customizada importada, se estiver ativa e válida.
async function loadCustomExtensionIfActive(ses) {
  try {
    if (getSettingSync("op_extensao_ativa", "0") !== "1") return;
    const extPath = getSettingSync("op_custom_extension_path", "");
    if (!extPath || !fs.existsSync(path.join(extPath, "manifest.json"))) return;
    await ses.loadExtension(extPath, { allowFileAccess: true });
  } catch (e) {
    console.warn("[ext] falha ao carregar extensão customizada:", e?.message || e);
  }
}

module.exports = { registerExtensionHandlers, loadCustomExtensionIfActive };
