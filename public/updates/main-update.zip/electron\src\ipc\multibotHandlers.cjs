// ============================================================================
// IPC: multibot:* — modo multi-perfil (cada perfil roda com seu próprio
// userData, permitindo várias instâncias independentes do bot).
// ============================================================================
const { app } = require("electron");
const multibot = require("../../multibot.cjs");

function registerMultibotHandlers(ipcMain) {
  ipcMain.handle("multibot:mode", () => ({
    isLauncher: !!global.__pandoraIsMultiBotLauncher,
    profileId: global.__pandoraProfileId || null,
  }));
  ipcMain.handle("multibot:list", () => {
    try { return { ok: true, profiles: multibot.listProfiles(global.__pandoraBaseUserData) }; }
    catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
  ipcMain.handle("multibot:create", (_e, name, importSettings) => {
    try { return { ok: true, profile: multibot.createProfile(global.__pandoraBaseUserData, name, !!importSettings) }; }
    catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
  ipcMain.handle("multibot:rename", (_e, id, name) => {
    try { return { ok: true, profile: multibot.renameProfile(global.__pandoraBaseUserData, id, name) }; }
    catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
  ipcMain.handle("multibot:delete", (_e, id) => {
    try { return { ok: multibot.deleteProfile(global.__pandoraBaseUserData, id) }; }
    catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
  ipcMain.handle("multibot:open", (_e, id, session) => {
    try { return multibot.openProfile(global.__pandoraBaseUserData, id, app, session); }
    catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
  // Chamado pelo processo FILHO (perfil já aberto) na subida da UI — repassa
  // a sessão de nuvem que o launcher já tinha validado, pra não pedir login
  // de novo em todo perfil aberto (pedido do usuário 2026-08-09).
  ipcMain.handle("multibot:consume-session", () => {
    try { return { ok: true, session: multibot.consumePendingSession(app.getPath("userData")) }; }
    catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });
}

module.exports = { registerMultibotHandlers };
