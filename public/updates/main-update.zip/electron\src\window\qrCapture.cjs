// ============================================================================
// Captura de QR Code de depósito (PIX) — 2026-08-08, pedido do usuário pra
// funcionar com "Operação Oculta" (headless): sem janela visível, não dá pra
// escanear o QR na tela, então o bot precisa achar a imagem sozinho na
// página e mandar pra própria UI do app mostrar.
//
// Heurística genérica (não depende de seletor específico do site — funciona
// mesmo se o layout mudar): procura um <img> com src em data:image (jeito
// mais comum de gerar QR no cliente) ou um <canvas> quase quadrado (outra
// forma comum de renderizar QR), em TODOS os frames da janela. Poll curto
// depois de um depósito ser disparado (dá tempo do site processar e mostrar
// a tela de pagamento).
// ============================================================================
const { BrowserWindow } = require("electron");
const state = require("../state.cjs");
const { queueDiagLine } = require("../../auto-register.cjs");

// Retorna diagnóstico completo (não só o achado) — sem isso, uma falha em
// achar o QR é muda: não dá pra saber se a heurística errou o alvo, se a
// tela de pagamento nem carregou, ou se o script nem rodou.
const QR_FIND_SCRIPT = `(() => {
  try {
    // BUG real 2026-08-09 (reportado pelo usuário: "o QR fica pequeno,
    // padrão" às vezes) — antes pegava o PRIMEIRO elemento quadrado-ish
    // achado (>80px), sem comparar com os outros candidatos da página. Se
    // ANTES do QR de verdade (geralmente grande, pra dar pra escanear) algum
    // ícone/logo/avatar pequeno mas também quadrado-ish já tivesse
    // renderizado, esse era capturado errado — pequeno, "padrão", sem
    // nenhum jeito de perceber o erro (a busca já parava ali, satisfeita).
    // Agora junta TODOS os candidatos (img + canvas) e pega o MAIOR — o QR
    // de pagamento é sempre o elemento quadrado mais proeminente da tela de
    // depósito, nunca o menor. Limiar mínimo subiu de 80 pra 120px também
    // (ícones comuns de UI raramente passam disso; QR de verdade quase
    // sempre passa).
    const isSquareish = (r) => r.width > 120 && r.height > 120 && Math.abs(r.width - r.height) < r.width * 0.35;
    const area = (r) => r.width * r.height;
    const imgs = Array.from(document.querySelectorAll('img'));
    const dataImgs = imgs.filter((img) => img.src && img.src.startsWith('data:image'));
    const qrImgCandidates = dataImgs
      .map((img) => { try { return { img, r: img.getBoundingClientRect() }; } catch (e) { return null; } })
      .filter((c) => c && isSquareish(c.r))
      .sort((a, b) => area(b.r) - area(a.r));
    const canvases = Array.from(document.querySelectorAll('canvas'));
    const squareCanvases = canvases
      .map((c) => { try { return { c, r: c.getBoundingClientRect() }; } catch (e) { return null; } })
      .filter((x) => x && isSquareish(x.r))
      .sort((a, b) => area(b.r) - area(a.r));
    let found = null;
    // Compara o MAIOR candidato de cada tipo entre si (não assume que <img>
    // sempre vale mais que <canvas> — pega o que for fisicamente maior).
    const bestImg = qrImgCandidates[0];
    const bestCanvas = squareCanvases[0];
    if (bestImg && (!bestCanvas || area(bestImg.r) >= area(bestCanvas.r))) found = bestImg.img.src;
    else if (bestCanvas) { try { found = bestCanvas.c.toDataURL('image/png'); } catch (e) {} }
    return JSON.stringify({
      found,
      url: location.href,
      imgCount: imgs.length,
      dataImgCount: dataImgs.length,
      dataImgSizes: dataImgs.slice(0, 8).map((img) => { try { const r = img.getBoundingClientRect(); return Math.round(r.width) + 'x' + Math.round(r.height); } catch (e) { return '?'; } }),
      canvasCount: canvases.length,
      squareCanvasCount: squareCanvases.length,
    });
  } catch (e) { return JSON.stringify({ error: e && e.message }); }
})();`;

// Fila em memória (perdida ao fechar o app — não precisa persistir em
// disco, é só pra UI conseguir "recarregar" ao trocar de aba/reabrir sem
// perder o que já foi capturado nesta sessão). Limitada pra não crescer
// pra sempre em rodadas longas.
const MAX_QUEUE = 40;
const queue = [];

function broadcastToApp(channel, payload) {
  try {
    const wins = BrowserWindow.getAllWindows() || [];
    for (const w of wins) {
      try {
        if (!w || w.isDestroyed()) continue;
        if (state.chromeWins && state.chromeWins.includes && state.chromeWins.includes(w)) continue;
        w.webContents.send(channel, payload);
      } catch {}
    }
  } catch {}
}

// Confirmação de pagamento — evidência real (2026-08-08, print enviado pelo
// usuário): assim que paga, a MESMA tela do QR muda sozinha — aparece um
// selo verde de check por cima do QR, um banner verde "Depósito Bem-
// sucedido!" no topo, e o texto "Recebido com sucesso" embaixo. Esse texto
// exato é o sinal principal agora (bem mais confiável que adivinhar saldo).
// Mantém a comparação de saldo como sinal SECUNDÁRIO (fallback pra outras
// plataformas que não usem esse texto exato).
const PAID_SCRIPT = `(() => {
  try {
    const txt = ((document.body && document.body.innerText) || '');
    const low = txt.toLowerCase();
    const textMatch = /recebido com sucesso|dep[óo]sito bem-?sucedido/i.test(low);
    const snippet = txt.replace(/\\s+/g, ' ').trim().slice(0, 300);
    let m = txt.match(/saldo[^\\d]{0,6}(\\d{1,3}(?:\\.\\d{3})*,\\d{2})/i);
    if (!m) m = txt.match(/(\\d{1,3}(?:\\.\\d{3})*,\\d{2})/);
    const balance = m ? parseFloat(m[1].replace(/\\./g, '').replace(',', '.')) : null;
    return JSON.stringify({ textMatch, balance: isFinite(balance) ? balance : null, url: location.href, snippet });
  } catch (e) { return JSON.stringify({ error: e && e.message }); }
})();`;

async function readPaidState(win) {
  try {
    const wc = win.webContents;
    if (!wc) return null;
    const raw = await wc.executeJavaScript(PAID_SCRIPT, true).catch(() => null);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function watchForPaymentConfirmation(win, entryId, tag, qrDataUrl, valorEsperado) {
  let tries = 0;
  const maxTries = 200; // ~200 * 2s ≈ 6,5min — PIX pode demorar pra cair
  let baseBalance = null;
  const check = async () => {
    tries++;
    try {
      if (!win || (typeof win.isDestroyed === "function" && win.isDestroyed())) return;
      const wc = win.webContents;
      if (!wc) return;
      const diag = await readPaidState(win);
      if (diag?.balance != null && baseBalance === null) {
        // Primeira leitura de saldo depois de começar a esperar — vira a
        // linha de base pra comparar contra o depósito (fallback).
        baseBalance = diag.balance;
      }
      const alvo = valorEsperado != null ? (baseBalance ?? 0) + Number(valorEsperado) * 0.98 : null;
      const balancePaid = alvo != null && diag?.balance != null && diag.balance >= alvo;
      const paid = !!diag?.textMatch || balancePaid;
      if (tries === 1 || tries % 10 === 0) {
        log(`tag=${tag} confirmação tentativa=${tries} textoSucesso=${diag?.textMatch} saldoBase=${baseBalance} saldoAtual=${diag?.balance} trecho="${diag?.snippet || ""}"`);
      }
      if (paid) {
        log(`tag=${tag} PAGAMENTO CONFIRMADO (tentativa=${tries}) — via ${diag?.textMatch ? "texto" : "saldo"} (base ${baseBalance} -> ${diag?.balance}, depósito R$${valorEsperado})`);
        const entry = queue.find((q) => q.id === entryId);
        if (entry) entry.paid = true;
        broadcastToApp("deposit:qrPaid", { id: entryId });
        return;
      }
    } catch {}
    if (tries < maxTries) setTimeout(check, 2000);
    else log(`tag=${tag} desistiu de esperar confirmação de pagamento após ${tries} tentativas`);
  };
  setTimeout(check, 2000);
}

function getQrQueue() {
  return queue.slice(-MAX_QUEUE);
}

// Chamado no STOP (Início) — os QR capturados são das contas que acabaram
// de ser encerradas, não fazem mais sentido ficar na tela.
function clearQrQueue() {
  queue.length = 0;
}

function log(msg) {
  try { queueDiagLine(`[${new Date().toISOString()}] [qr-capture] ${msg}\r\n`); } catch {}
}

// win: BrowserWindow/webContentsShim (Electron legado OU Chrome real —
// ambos expõem .webContents com executeJavaScript, então funciona igual).
// meta: { valor, tela, login } — só pra identificar a captura na UI.
function watchForDepositQr(win, meta = {}) {
  if (!win) return;
  // Pedido do usuário 2026-08-09: "o QR code quando as telas abrem está
  // aparecendo no bot, deve aparecer somente se estiver em operação
  // oculta" — o painel de QR na aba Início existe pra suprir a falta de
  // tela visível (Operação Oculta = sem janela nenhuma na tela, sem isso o
  // usuário não teria NENHUM jeito de ver o QR pra pagar). Com janela
  // visível, o usuário já vê o QR direto no próprio site — capturar e
  // mostrar de novo no painel era redundante e não foi pedido.
  if (!win._headless) { log(`tag=${meta.tela || meta.login || "?"} pulado — janela não está em Operação Oculta`); return; }
  const tag = meta.tela || meta.login || "?";
  log(`iniciando busca tag=${tag} valor=${meta.valor}`);
  let tries = 0;
  const maxTries = 34; // ~34 * 900ms ≈ 30s de espera
  const check = async () => {
    tries++;
    try {
      // BUG (2026-08-08): a checagem anterior tinha "win.isDestroyed ||" sem
      // chamar a função — win.isDestroyed é uma referência de função, que é
      // sempre truthy, então isso abortava a busca IMEDIATAMENTE na
      // primeira tentativa, sempre, mesmo com a janela bem viva. Era por
      // isso que nunca achava QR nenhum.
      if (!win || (typeof win.isDestroyed === "function" && win.isDestroyed())) { log(`tag=${tag} janela fechada, abortando`); return; }
      const wc = win.webContents;
      if (!wc) return;
      // Procura no frame principal primeiro, depois em todo subframe (o
      // formulário de depósito às vezes roda dentro de um iframe de
      // pagamento de terceiros).
      const scan = async (executor, label) => {
        try {
          const raw = await executor(QR_FIND_SCRIPT, true);
          const parsed = raw ? JSON.parse(raw) : null;
          if (parsed && (tries === 1 || tries % 5 === 0)) {
            log(`tag=${tag} tentativa=${tries} frame=${label} url=${parsed.url} imgs=${parsed.imgCount} dataImgs=${parsed.dataImgCount} tamanhos=${JSON.stringify(parsed.dataImgSizes)} canvases=${parsed.canvasCount} canvasQuadrado=${parsed.squareCanvasCount}`);
          }
          return parsed?.found || null;
        } catch (e) {
          if (tries === 1 || tries % 5 === 0) log(`tag=${tag} tentativa=${tries} frame=${label} falhou: ${e?.message}`);
          return null;
        }
      };
      let dataUrl = await scan((s, w2) => wc.executeJavaScript(s, w2), "main");
      if (!dataUrl) {
        try {
          const frames = (wc.mainFrame && wc.mainFrame.framesInSubtree) || [];
          let idx = 0;
          for (const f of frames) {
            if (!f || f === wc.mainFrame) continue;
            idx++;
            const r = await scan((s, w2) => f.executeJavaScript(s, w2), `sub${idx}`);
            if (r) { dataUrl = r; break; }
          }
        } catch {}
      }
      if (dataUrl) {
        log(`tag=${tag} ACHOU QR na tentativa=${tries}`);
        // Pedido do usuário 2026-08-09: "após abrir o QR code não pode
        // fechar popup algum" — o fechador de anúncios (attachPopupCloser,
        // autoLogin.cjs) normalmente já se desliga sozinho ao sair da Home
        // via detecção de rota (isHome pela URL), mas o QR de pagamento
        // costuma aparecer num MODAL por cima da MESMA página (SPA, sem
        // troca de rota de verdade) — nesse caso a detecção por URL nunca
        // dispara, e o fechador continua rodando "por trás" achando que
        // ainda está na Home, podendo fechar o próprio modal do QR ou
        // qualquer popup de confirmação que apareça em cima dele (voltar,
        // cancelar, etc.). Desliga explicitamente pra ESSA janela assim que
        // o QR é encontrado — sem depender de rota nenhuma.
        try {
          // Flag PERMANENTE na janela (não só na página) — sem isso,
          // qualquer navegação/transição de SPA depois (ex.: clicar na
          // seta de voltar do QR) fazia attachPopupCloser's apply()
          // REATIVAR o fechador de novo achando que "voltou pra Home"
          // (ver comentário grande em autoLogin.cjs). Setado no objeto
          // win em si — sobrevive a qualquer navegação/reload da página.
          try { win._pandoraPopupCloserOff = true; } catch {}
          wc.executeJavaScript(
            "try{window.__pandoraPopupCloserEnabled=false;window.__pandoraPopupCloserOn=false;document.getElementById('trava-antifecho-lembrete')?.remove();}catch(e){}",
            true
          ).catch(() => {});
          log(`tag=${tag} fechador de popup desligado (QR capturado)`);
        } catch {}
        const entry = {
          id: `qr-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          dataUrl,
          valor: meta.valor ?? null,
          tela: meta.tela ?? null,
          login: meta.login ?? "",
          at: Date.now(),
        };
        queue.push(entry);
        if (queue.length > MAX_QUEUE) queue.splice(0, queue.length - MAX_QUEUE);
        broadcastToApp("deposit:qrCaptured", entry);
        watchForPaymentConfirmation(win, entry.id, tag, dataUrl, meta.valor);
        return; // achou — para de tentar
      }
    } catch (e) {
      log(`tag=${tag} erro na tentativa=${tries}: ${e?.message}`);
    }
    if (tries < maxTries) setTimeout(check, 900);
    else log(`tag=${tag} desistiu após ${tries} tentativas — QR nunca apareceu na heurística`);
  };
  // Dá um tempo inicial pro clique/submit do depósito ser processado antes
  // de começar a procurar (evita achar um QR "velho" de uma tela anterior).
  setTimeout(check, 1800);
}

module.exports = { watchForDepositQr, getQrQueue, clearQrQueue };
