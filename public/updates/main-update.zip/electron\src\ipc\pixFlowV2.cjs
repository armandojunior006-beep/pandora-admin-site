// ============================================================================
// PIX Flow V2 — reescrita do zero, 100% baseada em detecção de elementos DOM
// (querySelector + .click()/dispatchEvent no próprio elemento), SEM nenhum
// clique por coordenada de tela (sendInputEvent/nativeClick). Como agora
// rodamos em Chrome real via CDP, clicar direto no elemento certo é mais
// confiável do que calcular x/y (que quebra se algo mudar de posição, tiver
// scroll diferente, ou for coberto por um toast).
//
// Construído incrementalmente passo a passo — cada função aqui é testada
// isoladamente antes de virar o fluxo principal. Se algo não funcionar, o
// fluxo antigo (pixHandler.cjs) continua intacto como fallback.
// ============================================================================
const { appendSecDiag } = require("../security/securityPin.cjs");
const { getWithdrawPin } = require("../security/securityPin.cjs");
const state = require("../state.cjs");
const { getSettingSync } = require("../settings/settingsStore.cjs");

// BUG GRAVE real 2026-08-09 (reportado pelo usuário: "eu estava usando
// we-canteenpg.com, cliquei em Cadastrar Chave Pix e ele foi pro
// voy-hallwaypg.com" — site TOTALMENTE diferente do que a janela estava
// operando) — essas URLs eram uma string FIXA com o domínio
// "voy-hallwaypg.com" (site usado só nos testes durante o desenvolvimento
// desse fluxo), então TODA janela, não importa em qual site de verdade
// estivesse rodando, era arrancada pro domínio de teste no meio da
// operação. Esses sites (voy-hallwaypg.com, we-canteenpg.com, etc.) são
// todos o MESMO template WG com o MESMO caminho/query — só o domínio muda
// — então a correção certa é manter só o CAMINHO fixo e montar a URL
// completa em cima do domínio de verdade da janela (wc.getURL()), nunca
// mais um domínio cravado. Nunca mais pode acontecer de uma janela pular
// pra outro site sozinha.
const STEP1_PATH = "/home/security?active=5&redirect=%257B%2522name%2522%253A%2522withdraw%2522%252C%2522query%2522%253A%257B%2522active%2522%253A20%257D%257D";
const STEP2_PATH = "/home/withdraw?active=10";

// Monta a URL do passo usando o domínio ATUAL da janela (nunca um domínio
// fixo) — só cai no fallback de voy-hallwaypg.com se wc.getURL() falhar de
// vez (não deveria acontecer nunca, mas evita um crash duro no lugar de um
// site errado, que era o bug original).
function urlOnCurrentSite(wc, path) {
  try {
    const cur = new URL(wc.getURL());
    return cur.origin + path;
  } catch (e) {
    log("AVISO: não consegui ler o domínio atual da janela (" + (e && e.message) + ") — usando fallback de teste");
    return "https://voy-hallwaypg.com" + path;
  }
}

const NOMES = ['Lucas','Mariana','Bruno','Camila','Pedro','Ana','Rafael','Juliana','Felipe','Larissa','Gustavo','Beatriz','Thiago','Carolina','Diego','Patricia'];
const SOBRENOMES = ['Silva','Souza','Oliveira','Santos','Pereira','Lima','Costa','Almeida','Rodrigues','Ferreira','Gomes','Martins','Araujo','Ribeiro'];
const randNome = () => NOMES[Math.floor(Math.random() * NOMES.length)] + ' ' + SOBRENOMES[Math.floor(Math.random() * SOBRENOMES.length)];
const randCpf = () => { let s = ''; for (let i = 0; i < 11; i++) s += Math.floor(Math.random() * 10); return s; };

function log(msg) {
  try { appendSecDiag("[PIX-V2] " + msg); } catch {}
}

// Script injetado: preenche a senha de 12 dígitos (2 grupos de 6) e clica em
// Confirmar — tudo via elemento encontrado no DOM, nenhuma coordenada.
function buildStep1Script(pin6) {
  return `(async () => {
    if (window.__pandoraPixV2Step1Busy) return { ok: false, reason: 'já rodando' };
    window.__pandoraPixV2Step1Busy = true;
    const PIN = ${JSON.stringify(String(pin6 || "").replace(/\D/g, "").slice(0, 6))};
    // Guarda os logs numa variável global em vez de depender de console-message
    // ser repassado (no Chrome real via CDP isso nem sempre chega ao lado
    // Node) — o Node lê window.__pandoraPixV2Log direto por polling.
    if (!Array.isArray(window.__pandoraPixV2Log)) window.__pandoraPixV2Log = [];
    const log = (m) => { try { window.__pandoraPixV2Log.push(String(m)); } catch {} };
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const visible = (el) => {
      if (!el || !el.isConnected) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
    };
    const domClick = (el) => {
      if (!el) return false;
      try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      // Teclado virtual mobile costuma escutar touch, não só mouse — sem
      // isso o clique "acontecia" no código mas não registrava no site
      // (mesma classe de bug já vista antes nessa sessão com CDP/touch).
      try {
        const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
        el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
      } catch {}
      try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 1, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try {
        const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
        el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch {}
      try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.click(); } catch {}
      return true;
    };
    const findKeyboardKey = (ch) => {
      const sel = '.ui-number-keyboard__key, .van-number-keyboard .van-key, .van-key, [class*="number-keyboard"] [class*="key"], [class*="keyboard"] button, [data-key]';
      return Array.from(document.querySelectorAll(sel)).filter(visible).find(k => {
        const t = String((k.innerText || k.textContent || k.getAttribute('data-key') || k.getAttribute('aria-label') || '')).trim();
        return t === String(ch);
      });
    };
    const findPasswordGroups = () => {
      const lis = Array.from(document.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).filter(visible);
      const parents = [];
      for (const li of lis) {
        const p = li.parentElement;
        if (p && !parents.includes(p) && Array.from(p.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).length >= 6) parents.push(p);
      }
      if (parents.length >= 2) return parents.slice(0, 2);
      return [];
    };
    const findConfirmBtn = () => {
      const btns = Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible);
      return btns.find(b => /^\\s*confirmar\\s*$/i.test((b.innerText || b.textContent || '').trim()) && !b.disabled);
    };
    try {
        log('BOOT: aguardando os 2 grupos de senha aparecerem');
        const dl = Date.now() + 30000;
        let groups = [];
        while (Date.now() < dl) {
          groups = findPasswordGroups();
          if (groups.length >= 2) break;
          await sleep(300);
        }
        if (groups.length < 2) { log('FALHA: grupos de senha não apareceram em 30s'); return { ok: false }; }
        log('grupos encontrados, preenchendo 6+6');
        let grpIdx = 0;
        for (const grp of groups) {
          grpIdx++;
          try { grp.click(); } catch {}
          await sleep(150);
          // Espera o teclado virtual aparecer de verdade antes de tentar clicar nele.
          const kbDeadline = Date.now() + 3000;
          let kbReady = false;
          while (Date.now() < kbDeadline) {
            if (findKeyboardKey('0') || findKeyboardKey('1')) { kbReady = true; break; }
            await sleep(100);
          }
          if (!kbReady) {
            const allBtns = Array.from(document.querySelectorAll('button, [role="button"], [class*="key" i]')).filter(visible)
              .map(b => (b.className || '') + '/' + (b.innerText || b.textContent || '').trim().slice(0, 10)).slice(0, 20);
            log('grupo ' + grpIdx + ': teclado NÃO apareceu em 3s. Elementos visíveis candidatos: ' + JSON.stringify(allBtns));
          } else {
            log('grupo ' + grpIdx + ': teclado apareceu, digitando');
          }
          for (const ch of PIN) {
            const k = findKeyboardKey(ch);
            if (k) { domClick(k); log('grupo ' + grpIdx + ': dígito ' + ch + ' clicado'); }
            else { log('grupo ' + grpIdx + ': dígito ' + ch + ' — tecla NÃO encontrada'); }
            await sleep(120);
          }
          await sleep(300);
        }
        log('preenchimento concluído, procurando botão Confirmar');
        const dl2 = Date.now() + 8000;
        let btn = null;
        while (Date.now() < dl2) {
          btn = findConfirmBtn();
          if (btn) break;
          await sleep(300);
        }
        if (!btn) { log('FALHA: botão Confirmar não encontrado/habilitado em 8s'); return { ok: false }; }
        log('clicando Confirmar (via elemento DOM, sem coordenada)');
        domClick(btn);
        window.__pandoraPixV2Step1Clicked = true;
        // Dá tempo do site processar/enviar a confirmação de verdade antes
        // da gente navegar pra outra URL — sem isso a navegação forçada do
        // Passo 2 podia interromper o envio no meio.
        log('aguardando o site processar a confirmação antes de prosseguir');
        await sleep(2500);
        return { ok: true };
      } catch (e) {
        log('ERRO: ' + (e && e.message ? e.message : String(e)));
        return { ok: false, error: String(e && e.message ? e.message : e) };
      } finally {
        window.__pandoraPixV2Step1Busy = false;
      }
  })();`;
}

// Script injetado no PASSO 2: acha e clica "Adicionar Conta para Saque" e,
// em seguida, um botão/link separado chamado "Adicionar" (se existir) —
// tudo por texto/DOM, sem coordenada.
const STEP2_SCRIPT = `(async () => {
  if (window.__pandoraPixV2Step2Busy) return { ok: false, reason: 'já rodando' };
  window.__pandoraPixV2Step2Busy = true;
  if (!Array.isArray(window.__pandoraPixV2Log)) window.__pandoraPixV2Log = [];
  const log = (m) => { try { window.__pandoraPixV2Log.push(String(m)); } catch {} };
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const visible = (el) => {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
  };
  const domClick = (el) => {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    try {
      const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
      el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
    } catch {}
    try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 1, clientX: cx, clientY: cy })); } catch {}
    try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
    try {
      const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
      el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, touches: [], targetTouches: [], changedTouches: [touch] }));
    } catch {}
    try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 0, clientX: cx, clientY: cy })); } catch {}
    try { el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
    try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
    try { el.click(); } catch {}
    return true;
  };
  const describeEl = (el) => el ? (el.tagName + (el.id ? '#' + el.id : '') + (el.className ? '.' + String(el.className).replace(/\\s+/g, '.').slice(0, 60) : '') + ' texto="' + (el.innerText || el.textContent || '').trim().slice(0, 40) + '"') : 'null';
  try {
    log('PASSO 2: procurando botão "Adicionar" (já na URL certa: /home/withdraw?active=10)');
    const dl2 = Date.now() + 15000;
    let addBtn = null;
    let candidatesLogged = false;
    while (Date.now() < dl2) {
      const all = Array.from(document.querySelectorAll('button, [role="button"], a, li, div, span')).filter(visible)
        .filter(el => /^\\s*adicionar\\s*$/i.test((el.innerText || el.textContent || '').trim()));
      if (all.length && !candidatesLogged) {
        candidatesLogged = true;
        log('PASSO 2: candidatos "Adicionar" encontrados (' + all.length + '): ' + all.slice(0, 6).map(describeEl).join(' | '));
      }
      addBtn = all[0] || null;
      if (addBtn) break;
      await sleep(300);
    }
    if (addBtn) {
      // O texto "Adicionar" pode estar num <span>/<div> puramente visual —
      // o handler de clique de verdade geralmente é da LINHA inteira (li/a/
      // role=button mais acima), não do texto em si. Sobe até achar isso,
      // ou no máximo 4 níveis, e clica no container mais externo razoável.
      let target = addBtn.closest('li, a, button, [role="button"], [class*="item" i], [class*="row" i]');
      if (!target) {
        target = addBtn;
        for (let i = 0; i < 3 && target.parentElement; i++) target = target.parentElement;
      }
      // Critério de parada real: o prompt de senha (6 dígitos) apareceu?
      // Não basta o texto "Adicionar" sumir/mudar — isso não garante que o
      // modal abriu, e continuar clicando ancestrais DEPOIS que já abriu
      // corria o risco de clicar de novo num toggle e fechar o modal
      // (era exatamente esse o bug: "abre e fecha na hora").
      const hasPasswordPrompt = () => Array.from(document.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).filter(visible).length >= 6;
      log('PASSO 2b: clicando "Adicionar" -> alvo real: ' + describeEl(target) + ' (texto original: ' + describeEl(addBtn) + ')');
      domClick(target);
      await sleep(800);
      let opened = hasPasswordPrompt();
      log('PASSO 2b: após clique no alvo real, prompt de senha apareceu? ' + opened);
      if (!opened) {
        // Reforço: tenta clicar em cada nível de ancestral (1 a 5), parando
        // IMEDIATAMENTE assim que o prompt de senha aparecer — nunca clica
        // de novo depois disso.
        let anc = addBtn;
        for (let i = 1; i <= 5 && anc.parentElement && !opened; i++) {
          anc = anc.parentElement;
          domClick(anc);
          await sleep(500);
          opened = hasPasswordPrompt();
          if (opened) log('PASSO 2b: reforço funcionou no nível ' + i + ' (' + describeEl(anc) + ')');
        }
      }
      if (!opened) log('PASSO 2b: prompt de senha ainda não apareceu após todas as tentativas — Passo 3 vai continuar tentando por conta própria');
    } else {
      log('PASSO 2 FALHA: botão "Adicionar" não encontrado em 15s');
      return { ok: false };
    }
    return { ok: true };
  } catch (e) {
    log('PASSO 2 ERRO: ' + (e && e.message ? e.message : String(e)));
    return { ok: false, error: String(e && e.message ? e.message : e) };
  } finally {
    window.__pandoraPixV2Step2Busy = false;
  }
})();`;

// Script injetado no PASSO 3: depois de "Adicionar", aparece um prompt de
// senha de saque de 6 dígitos (só 1 grupo, não 6+6) — preenche e clica
// Confirmar. Mesma lógica de teclado do passo 1, mas 1 grupo só.
function buildStep3Script(pin6) {
  return `(async () => {
    if (window.__pandoraPixV2Step3Busy) return { ok: false, reason: 'já rodando' };
    window.__pandoraPixV2Step3Busy = true;
    const PIN = ${JSON.stringify(String(pin6 || "").replace(/\D/g, "").slice(0, 6))};
    if (!Array.isArray(window.__pandoraPixV2Log)) window.__pandoraPixV2Log = [];
    const log = (m) => { try { window.__pandoraPixV2Log.push(String(m)); } catch {} };
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const visible = (el) => {
      if (!el || !el.isConnected) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
    };
    const domClick = (el) => {
      if (!el) return false;
      try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      try {
        const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
        el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
      } catch {}
      try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 1, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try {
        const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
        el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch {}
      try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.click(); } catch {}
      return true;
    };
    const findKeyboardKey = (ch) => {
      const sel = '.ui-number-keyboard__key, .van-number-keyboard .van-key, .van-key, [class*="number-keyboard"] [class*="key"], [class*="keyboard"] button, [data-key]';
      return Array.from(document.querySelectorAll(sel)).filter(visible).find(k => {
        const t = String((k.innerText || k.textContent || k.getAttribute('data-key') || k.getAttribute('aria-label') || '')).trim();
        return t === String(ch);
      });
    };
    const findPasswordGroup = () => {
      const lis = Array.from(document.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).filter(visible);
      if (lis.length >= 6) {
        const p = lis[0].parentElement;
        return p || lis[0];
      }
      return null;
    };
    // Aqui o botão pode se chamar "Próximo" em vez de "Confirmar" (varia
    // conforme a etapa do site).
    const findConfirmBtn = () => {
      const btns = Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible);
      return btns.find(b => /^\\s*(confirmar|pr[óo]ximo)\\s*$/i.test((b.innerText || b.textContent || '').trim()) && !b.disabled);
    };
    try {
        log('PASSO 3: aguardando prompt de senha (6 dígitos)');
        const dl = Date.now() + 15000;
        let grp = null;
        while (Date.now() < dl) {
          grp = findPasswordGroup();
          if (grp) break;
          await sleep(300);
        }
        if (!grp) {
          const pageText = (document.body.innerText || '').slice(0, 300).replace(/\\n+/g, ' | ');
          log('PASSO 3 FALHA: prompt de senha não apareceu em 15s. URL=' + location.href + ' texto da tela: ' + pageText);
          return { ok: false };
        }
        log('PASSO 3: prompt encontrado, abrindo teclado');
        try { grp.click(); } catch {}
        await sleep(150);
        const kbDeadline = Date.now() + 3000;
        let kbReady = false;
        while (Date.now() < kbDeadline) {
          if (findKeyboardKey('0') || findKeyboardKey('1')) { kbReady = true; break; }
          await sleep(100);
        }
        if (!kbReady) log('PASSO 3: teclado não apareceu em 3s, tentando digitar mesmo assim');
        for (const ch of PIN) {
          const k = findKeyboardKey(ch);
          if (k) { domClick(k); log('PASSO 3: dígito ' + ch + ' clicado'); }
          else { log('PASSO 3: dígito ' + ch + ' — tecla NÃO encontrada'); }
          await sleep(120);
        }
        await sleep(300);
        log('PASSO 3: procurando botão Confirmar');
        const dl2 = Date.now() + 8000;
        let btn = null;
        while (Date.now() < dl2) {
          btn = findConfirmBtn();
          if (btn) break;
          await sleep(300);
        }
        if (!btn) { log('PASSO 3 FALHA: botão Confirmar não encontrado/habilitado em 8s'); return { ok: false }; }
        log('PASSO 3: clicando Confirmar');
        domClick(btn);
        return { ok: true };
      } catch (e) {
        log('PASSO 3 ERRO: ' + (e && e.message ? e.message : String(e)));
        return { ok: false, error: String(e && e.message ? e.message : e) };
      } finally {
        window.__pandoraPixV2Step3Busy = false;
      }
  })();`;
}

// Script injetado no PASSO 4: no modal "Adicionar PIX" que abre depois do
// Passo 3, seleciona PHONE (em vez de CPF, que é o padrão), preenche nome
// aleatório, a chave PIX (telefone) e um CPF aleatório. NÃO clica em
// Confirmar — isso fica pra configurar depois.
function buildStep4Script(chave, nomeReal, cpfReal) {
  return `(async () => {
    if (window.__pandoraPixV2Step4Busy) return { ok: false, reason: 'já rodando' };
    window.__pandoraPixV2Step4Busy = true;
    if (!Array.isArray(window.__pandoraPixV2Log)) window.__pandoraPixV2Log = [];
    const log = (m) => { try { window.__pandoraPixV2Log.push(String(m)); } catch {} };
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const CHAVE = ${JSON.stringify(String(chave || "").replace(/\D/g, "").slice(0, 11))};
    const NOME = ${JSON.stringify(String(nomeReal || ""))};
    const CPF = ${JSON.stringify(String(cpfReal || ""))};
    try {
      log('PASSO 4: aguardando modal "Adicionar PIX" (campo nome aparecer)');
      const dl = Date.now() + 30000;
      let modalReady = false;
      while (Date.now() < dl) {
        modalReady = !!document.querySelector('input[data-input-name="name"]');
        if (modalReady) break;
        await sleep(200);
      }
      if (!modalReady) { log('PASSO 4 FALHA: modal não apareceu em 30s'); return { ok: false }; }
      log('PASSO 4: modal detectado, aguardando render completo');
      await sleep(900);

      // Seleciona PHONE — mesma lógica "spider" já comprovada no fluxo antigo:
      // dispatch de eventos no trigger, espera, acha a opção PHONE por texto
      // (ou por índice como fallback), clica nela.
      const selectPhone = async () => {
        const trigger = document.querySelector('.ui-select-single__content') || document.querySelector('.ui-select-single');
        if (!trigger) {
          // Diagnóstico 2026-08-09: sem isso, uma falha aqui só dizia "não
          // encontrado" — sem pista de POR QUÊ (site diferente? classe
          // mudou? modal nem abriu?). Loga o que existe de fato na tela.
          const candidatosSelect = Array.from(document.querySelectorAll('[class*="select"]')).slice(0, 10)
            .map(el => el.className).join(' | ');
          log('PASSO 4: trigger do tipo de chave não encontrado. Elementos com "select" na classe: ' + (candidatosSelect || '(nenhum)'));
          return false;
        }
        ['mousedown', 'click', 'mouseup'].forEach(evt => { try { trigger.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true })); } catch {} });
        try { trigger.dispatchEvent(new TouchEvent('touchstart', { bubbles: true })); } catch {}
        try { trigger.dispatchEvent(new TouchEvent('touchend', { bubbles: true })); } catch {}
        await sleep(300);
        let opcoes = Array.from(document.querySelectorAll('.ui-select-single__option, .v-dropdown__item, li, span, div'))
          .filter(el => { const t = (el.textContent || '').trim().toUpperCase(); return t === 'PHONE' || t === 'CELULAR' || t === 'TELEFONE'; });
        let alvo = opcoes[0];
        if (!alvo) {
          const todas = Array.from(document.querySelectorAll('.ui-select-single__option, [class*="option"], [class*="item"]'));
          alvo = todas.length > 1 ? todas[1] : todas[0];
          // Diagnóstico: lista os textos de TODOS os candidatos achados (não
          // só "não achou"), pra ver o que o dropdown desse site realmente
          // oferece e ajustar a lista de sinônimos/seletor se precisar.
          const textos = todas.slice(0, 15).map(el => JSON.stringify((el.textContent || '').trim().slice(0, 30))).join(', ');
          log('PASSO 4: nenhuma opção bateu PHONE/CELULAR/TELEFONE por texto exato. Candidatos genéricos (' + todas.length + '): ' + (textos || '(nenhum)'));
        }
        if (!alvo) { log('PASSO 4: opção PHONE não encontrada no dropdown'); return false; }
        try { alvo.scrollIntoView({ block: 'center' }); } catch {}
        try { alvo.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); } catch {}
        try { alvo.click(); } catch {}
        try { alvo.dispatchEvent(new MouseEvent('mouseup', { bubbles: true })); } catch {}
        try { alvo.dispatchEvent(new TouchEvent('touchstart', { bubbles: true })); } catch {}
        try { alvo.dispatchEvent(new TouchEvent('touchend', { bubbles: true })); } catch {}
        await sleep(300);
        return true;
      };
      // BUG real 2026-08-10 (reportado pelo usuário: "antes estava
      // funcionando perfeitamente" — na verdade preenchia sempre, mesmo sem
      // confirmar PHONE, e cadastrava com o tipo errado CPF; a trava nova
      // corrigiu isso mas passou a abortar até quando a seleção funcionava
      // de verdade) — document.querySelector pega só o PRIMEIRO elemento
      // ".ui-select-single" da página; se existir mais de um seletor desse
      // tipo no formulário (ex.: banco/tipo de conta em outro campo), a
      // checagem podia estar sempre olhando o elemento ERRADO, nunca o que
      // de fato mostra "PHONE" depois da seleção. Agora checa TODOS os
      // elementos que baterem no seletor, não só o primeiro.
      // BUG CRÍTICO real 2026-08-10 (reportado pelo usuário: em Operação
      // Oculta, o código achava que PHONE tinha sido selecionado — chegou
      // a confirmar e excluir a chave de "Chaves PIX" como usada — mas o
      // site continuava de verdade com CPF, não Telefone) — o regex
      // anterior usava \\b...\\b (bate a palavra em QUALQUER lugar dentro
      // do texto do elemento), e "Mobile" é uma palavra comum demais (ex.:
      // um banner "Baixe o App Mobile" ou texto similar, mais provável de
      // estar presente/visível em Operação Oculta por alguma diferença de
      // viewport/timing) — batia em outro elemento qualquer da tela, nunca
      // no seletor de tipo de chave de verdade. Agora exige que o texto do
      // elemento seja EXATAMENTE um desses valores (só espaço em volta,
      // nada mais) — um .ui-select-single__content mostrando o valor
      // selecionado de verdade só tem esse valor sozinho, não uma frase.
      const isPhoneSelected = () => {
        const list = document.querySelectorAll('.ui-select-single__content, .ui-select-single');
        for (const t of list) {
          if (/^\\s*(PHONE|Phone|Telefone|Celular|Mobile)\\s*$/i.test((t.innerText || t.textContent || ''))) return true;
        }
        return false;
      };
      if (isPhoneSelected()) {
        log('PASSO 4: PHONE já estava selecionado');
      } else {
        log('PASSO 4: selecionando PHONE');
        await selectPhone();
        // BUG real 2026-08-10 (log confirmou: o clique na opção certa
        // acontece — nenhum diagnóstico de "opção não encontrada" disparou
        // — mas isPhoneSelected() logo depois ainda voltava falso) — antes
        // checava UMA vez só, ~300ms depois do clique; não dava tempo do
        // site re-renderizar o texto do dropdown selecionado. Poll de até
        // 1.5s antes de desistir de verdade.
        let phoneOk = isPhoneSelected();
        if (!phoneOk) {
          const dlPhone = Date.now() + 1500;
          while (Date.now() < dlPhone) {
            await sleep(150);
            if (isPhoneSelected()) { phoneOk = true; break; }
          }
        }
        if (phoneOk) {
          log('PASSO 4: PHONE selecionado com sucesso');
        } else {
          // BUG CRÍTICO real 2026-08-10 (reportado pelo usuário: cadastrou a
          // chave como CPF em vez de PHONE, com o número de telefone dentro
          // do campo errado) — antes, quando a seleção de PHONE falhava,
          // isso só era LOGADO como aviso e o código seguia preenchendo os
          // campos e devolvendo { ok: true } do mesmo jeito — o PASSO 5
          // clicava em "Confirmar" mesmo assim, cadastrando uma chave PIX
          // com o TIPO padrão do site (CPF) mas com um número de telefone
          // dentro, corrompendo o cadastro de verdade na plataforma. Agora
          // aborta aqui: não preenche nada, não confirma nada, retorna
          // ok:false — runFullFlow já para no primeiro passo que falhar
          // (nunca chega no PASSO 5) e a chave também não é excluída de
          // Chaves PIX (só é excluída quando o PASSO 5 confirma de verdade).
          const candidatosDbg = Array.from(document.querySelectorAll('.ui-select-single__content, .ui-select-single'))
            .map((el) => JSON.stringify((el.innerText || el.textContent || '').trim().slice(0, 40))).join(', ');
          log('PASSO 4 FALHA: não confirmou seleção de PHONE — candidatos encontrados (' + candidatosDbg.split(',').length + '): ' + (candidatosDbg || '(nenhum)') + ' — abortando (não preenche/confirma com tipo errado)');
          return { ok: false, reason: 'não conseguiu selecionar PHONE — cadastro abortado pra não gravar como CPF por engano' };
        }
      }
      // BUG real 2026-08-10 (reportado pelo usuário: PHONE agora é
      // selecionado com sucesso, mas nome/chave/CPF pararam de ser
      // preenchidos) — o formulário provavelmente RE-RENDERIZA os campos
      // quando o tipo muda de CPF (padrão) pra PHONE (inputs diferentes,
      // maxlength/placeholder diferentes) — antes disso nunca era testado
      // de verdade porque a seleção de PHONE quase nunca confirmava e o
      // código só continuava com o formulário ainda no layout de CPF (por
      // coincidência batendo nos seletores antigos). 300ms fixo não dava
      // tempo do re-render acontecer, e os seletores (maxlength 11/14,
      // placeholder "chave do PIX"/"CPF") podem não bater mais no layout de
      // PHONE. Poll de até 5s pra cada campo (dá tempo do re-render) + loga
      // TODOS os inputs visíveis quando não acha, pra dar visibilidade real
      // do layout de PHONE se ainda falhar de novo.
      await sleep(600);
      const setNative = (el, val) => {
        if (!el) return false;
        const proto = HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
        try { el.focus(); } catch {}
        setter.call(el, val);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        try { el.blur(); } catch {}
        return true;
      };
      const visible = (el) => !!(el && el.offsetParent !== null);
      const describeInputs = () => Array.from(document.querySelectorAll('input')).filter(visible)
        .map(i => JSON.stringify({ name: i.getAttribute('data-input-name') || '', placeholder: i.placeholder || '', maxlength: i.getAttribute('maxlength') || '', type: i.type || '' }))
        .join(' | ');
      const pollFor = async (find, label) => {
        const dl = Date.now() + 5000;
        let el = null;
        while (Date.now() < dl) {
          el = find();
          if (el && visible(el)) return el;
          await sleep(200);
        }
        log('PASSO 4: campo "' + label + '" não encontrado após poll de 5s. Inputs visíveis na tela: ' + (describeInputs() || '(nenhum)'));
        return null;
      };

      // Preenche nome / chave PIX / CPF
      const nomeInp = await pollFor(() => document.querySelector('input[data-input-name="name"]'), 'nome');
      if (nomeInp) { setNative(nomeInp, NOME); log('PASSO 4: nome preenchido'); }
      const chaveInp = await pollFor(() => {
        let el = document.querySelector('input[data-input-name="account"], input[data-input-name="key"], input[data-input-name="pixKey"], input[maxlength="11"]');
        if (el && visible(el)) return el;
        return Array.from(document.querySelectorAll('input')).filter(visible)
          .find(i => /chave do pix|n[úu]mero de celular|n[úu]mero de telefone|celular|telefone/i.test(i.placeholder || ''));
      }, 'chave PIX');
      if (chaveInp) { setNative(chaveInp, CHAVE); log('PASSO 4: chave PIX preenchida'); }
      const cpfInp = await pollFor(() => {
        let el = document.querySelector('input[data-input-name="cpf"], input[data-input-name="idNumber"], input[maxlength="14"]');
        if (el && visible(el) && el !== chaveInp) return el;
        return Array.from(document.querySelectorAll('input')).filter(visible)
          .find(i => i !== chaveInp && /cpf/i.test(i.placeholder || ''));
      }, 'CPF');
      if (cpfInp) { setNative(cpfInp, CPF); log('PASSO 4: CPF preenchido'); }

      // Sem a chave PIX preenchida, o PASSO 5 confirmaria um formulário
      // incompleto/errado — mais grave que simplesmente não preencher nome/
      // CPF (esses têm menos impacto se ficarem vazios/errados). Aborta se
      // o campo da chave não foi achado, mesmo com PHONE selecionado certo.
      if (!chaveInp) {
        log('PASSO 4 FALHA: campo da chave PIX não encontrado — abortando sem confirmar');
        return { ok: false, reason: 'campo da chave PIX não encontrado' };
      }
      log('PASSO 4: campos preenchidos');
      return { ok: true };
    } catch (e) {
      log('PASSO 4 ERRO: ' + (e && e.message ? e.message : String(e)));
      return { ok: false, error: String(e && e.message ? e.message : e) };
    } finally {
      window.__pandoraPixV2Step4Busy = false;
    }
  })();`;
}

// Script injetado no PASSO 5: clica no botão "Confirmar" do modal "Adicionar
// PIX" — UMA ÚNICA VEZ (trava por window.__pandoraPixV2Step5Clicked).
const STEP5_SCRIPT = `(async () => {
  if (window.__pandoraPixV2Step5Busy) return { ok: false, reason: 'já rodando' };
  if (window.__pandoraPixV2Step5Clicked) return { ok: false, reason: 'já clicou antes' };
  window.__pandoraPixV2Step5Busy = true;
  if (!Array.isArray(window.__pandoraPixV2Log)) window.__pandoraPixV2Log = [];
  const log = (m) => { try { window.__pandoraPixV2Log.push(String(m)); } catch {} };
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const visible = (el) => {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const s = getComputedStyle(el);
    return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
  };
  const domClick = (el) => {
    if (!el) return false;
    try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    try {
      const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
      el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
    } catch {}
    try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 1, clientX: cx, clientY: cy })); } catch {}
    try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
    try {
      const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
      el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, touches: [], targetTouches: [], changedTouches: [touch] }));
    } catch {}
    try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 0, clientX: cx, clientY: cy })); } catch {}
    try { el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
    try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
    try { el.click(); } catch {}
    return true;
  };
  const findConfirmBtn = () => Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible)
    .find(b => /^\\s*confirmar\\s*$/i.test((b.innerText || b.textContent || '').trim()) && !b.disabled);
  try {
    log('PASSO 5: procurando botão Confirmar do modal Adicionar PIX');
    const dl = Date.now() + 8000;
    let btn = null;
    while (Date.now() < dl) {
      btn = findConfirmBtn();
      if (btn) break;
      await sleep(300);
    }
    if (!btn) { log('PASSO 5 FALHA: botão Confirmar não encontrado/habilitado em 8s'); return { ok: false }; }
    log('PASSO 5: clicando Confirmar (única vez)');
    window.__pandoraPixV2Step5Clicked = true;
    domClick(btn);
    return { ok: true };
  } catch (e) {
    log('PASSO 5 ERRO: ' + (e && e.message ? e.message : String(e)));
    return { ok: false, error: String(e && e.message ? e.message : e) };
  } finally {
    window.__pandoraPixV2Step5Busy = false;
  }
})();`;

// Drena window.__pandoraPixV2Log por polling (mais confiável que
// console-message no Chrome real via CDP) e joga cada linha nova pro nosso
// log assim que aparece. Retorna uma função pra parar o polling.
function startLogDrain(win, wc) {
  let drainedCount = 0;
  const timer = setInterval(async () => {
    if (win.isDestroyed()) { clearInterval(timer); return; }
    try {
      const lines = await wc.executeJavaScript("(window.__pandoraPixV2Log || [])", true);
      if (Array.isArray(lines)) {
        // BUG real 2026-08-10 (achado investigando por que os diagnósticos
        // dos PASSOS 3/4/5 nunca apareciam no arquivo de log) — o PASSO 2 e
        // o PASSO 3 navegam pra outra URL (wc.loadURL); isso reseta
        // window.__pandoraPixV2Log pra um array NOVO e VAZIO na página
        // seguinte (é um objeto window diferente). drainedCount, porém, só
        // crescia — nunca voltava a zero. Depois da 1ª navegação,
        // lines.length (da página nova) ficava sempre MENOR que
        // drainedCount (herdado da página anterior), então o for
        // "i = drainedCount; i < lines.length" nunca executava de novo —
        // TODO log dos passos depois da 1ª navegação (3, 4, 5) ficava mudo
        // pra sempre, mesmo com log() sendo chamado normalmente lá dentro.
        // Detecta o reset (array encolheu) e volta a drenar do zero.
        if (lines.length < drainedCount) drainedCount = 0;
        for (let i = drainedCount; i < lines.length; i++) log(lines[i]);
        drainedCount = lines.length;
      }
    } catch {}
  }, 400);
  return () => clearInterval(timer);
}

// PASSO 1: navega pra URL da senha de saque, preenche 6+6, clica Confirmar.
async function runStep1(win) {
  if (!win || win.isDestroyed()) return { ok: false, error: "janela inválida" };
  const wc = win.webContents;
  const pin = String(getWithdrawPin(win) || "").replace(/\D/g, "").slice(0, 6);
  if (!/^\d{6}$/.test(pin)) {
    log("PASSO 1 abortado: senha de saque não configurada/inválida");
    return { ok: false, error: "senha de saque (6 dígitos) não configurada em Início" };
  }
  const step1Url = urlOnCurrentSite(wc, STEP1_PATH);
  log("PASSO 1: navegando para " + step1Url);
  try { await wc.loadURL(step1Url); } catch (e) {
    log("PASSO 1: falha ao navegar — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao navegar" };
  }
  await new Promise((r) => setTimeout(r, 1200));
  log("PASSO 1: injetando script de preenchimento (senha 6+6) + Confirmar");
  const stopDrain = startLogDrain(win, wc);
  try {
    // BUG CRÍTICO real 2026-08-10 (reportado pelo usuário: preencheu os 12
    // dígitos, mas não confirmou — e o fluxo seguiu adiante do mesmo jeito,
    // acabando por cadastrar a chave PIX errada em background sem avisar
    // nada) — igual ao PASSO 4, este código ignorava o que o script
    // injetado retornava (mesmo ele já podendo devolver { ok: false } se o
    // botão Confirmar não fosse achado/clicado) e sempre respondia
    // { ok: true } aqui. Agora repassa o resultado de verdade.
    const res = await wc.executeJavaScript(buildStep1Script(pin), true);
    if (!res || !res.ok) {
      stopDrain();
      log("PASSO 1: script retornou falha — " + (res && res.reason ? res.reason : "sem detalhe"));
      return { ok: false, error: (res && res.reason) || "passo 1 falhou (senha não confirmada)" };
    }
    return { ok: true, stopDrain };
  } catch (e) {
    stopDrain();
    log("PASSO 1: falha ao injetar script — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao injetar script" };
  }
}

// PASSO 2: espera navegar pra tela de saque, clica "Adicionar Conta para
// Saque" e, se aparecer, um botão "Adicionar" separado.
async function runStep2(win) {
  if (!win || win.isDestroyed()) return { ok: false, error: "janela inválida" };
  const wc = win.webContents;
  const step2Url = urlOnCurrentSite(wc, STEP2_PATH);
  log("PASSO 2: navegando direto para " + step2Url);
  try { await wc.loadURL(step2Url); } catch (e) {
    log("PASSO 2: falha ao navegar — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao navegar" };
  }
  await new Promise((r) => setTimeout(r, 1200));
  log("PASSO 2: injetando script (procurar/clicar Adicionar)");
  try {
    // Mesmo bug do PASSO 1/4 corrigido 2026-08-10 — repassa o resultado de
    // verdade do script em vez de assumir { ok: true } sempre.
    const res = await wc.executeJavaScript(STEP2_SCRIPT, true);
    if (!res || !res.ok) {
      log("PASSO 2: script retornou falha — " + (res && res.reason ? res.reason : "sem detalhe"));
      return { ok: false, error: (res && res.reason) || "passo 2 falhou" };
    }
    return { ok: true };
  } catch (e) {
    log("PASSO 2: falha ao injetar script — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao injetar script" };
  }
}

// PASSO 3: preenche a senha de 6 dígitos (1 grupo) que aparece depois de
// "Adicionar" e clica Confirmar.
async function runStep3(win) {
  if (!win || win.isDestroyed()) return { ok: false, error: "janela inválida" };
  const wc = win.webContents;
  const pin = String(getWithdrawPin(win) || "").replace(/\D/g, "").slice(0, 6);
  await new Promise((r) => setTimeout(r, 800));
  log("PASSO 3: injetando script (senha 6 dígitos + Confirmar)");
  try {
    // Mesmo bug do PASSO 1/2/4 corrigido 2026-08-10 — repassa o resultado de
    // verdade do script em vez de assumir { ok: true } sempre.
    const res = await wc.executeJavaScript(buildStep3Script(pin), true);
    if (!res || !res.ok) {
      log("PASSO 3: script retornou falha — " + (res && res.reason ? res.reason : "sem detalhe"));
      return { ok: false, error: (res && res.reason) || "passo 3 falhou (senha não confirmada)" };
    }
    return { ok: true };
  } catch (e) {
    log("PASSO 3: falha ao injetar script — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao injetar script" };
  }
}

// PASSO 4: no modal "Adicionar PIX", seleciona PHONE, preenche nome/chave/CPF.
// NÃO clica em Confirmar (fica pra configurar depois).
// Pedido do usuário 2026-08-11: "se a opção mesmas chaves para links
// diferentes estiver ativa, irá usar a mesma chave em todas as telas" — o
// botão "Cadastrar Chaves PIX" da aba Operação chama esse fluxo (V2), mas
// essa opção só estava implementada no fluxo ANTIGO (pixHandler.cjs), que
// não é mais usado pela UI — nesse fluxo (o de verdade), cada janela sempre
// sorteava uma chave DIFERENTE do banco, ignorando a opção por completo.
// Agora aceita uma chave FIXA opcional (decidida uma única vez, fora do
// loop de janelas, quando a opção está ativa) — se vier preenchida, usa ela
// direto sem sortear outra do banco.
async function runStep4(win, chaveFixa) {
  if (!win || win.isDestroyed()) return { ok: false, error: "janela inválida" };
  const wc = win.webContents;
  let chave = chaveFixa || "";
  if (!chave) {
    try {
      const stmt = state.db.prepare("SELECT key_value FROM pix_keys WHERE key_type='phone' AND status='active' ORDER BY RANDOM() LIMIT 1");
      if (stmt.step()) chave = String(stmt.getAsObject().key_value || "");
      stmt.free();
    } catch (e) {
      log("PASSO 4: falha ao ler chave PIX do banco — " + (e && e.message ? e.message : String(e)));
    }
  }
  if (!chave) {
    log("PASSO 4 abortado: nenhuma chave PIX (tipo phone, ativa) cadastrada em Chaves PIX");
    return { ok: false, error: "nenhuma chave PIX cadastrada" };
  }
  // Site novo 2026-08-18 (versopg.vip, reportado pelo usuário: erro "nome
  // real do membro não corresponde" ao cadastrar chave PIX) — esse site
  // exige o MESMO nome usado no registro (ver auto-register.cjs, que
  // guarda no localStorage quando o cadastro pede "nome real"). Lê daqui
  // primeiro; sorteia um nome novo só se não achar (sites sem esse
  // requisito, como antes).
  let nomeReal = null;
  try { nomeReal = await wc.executeJavaScript("try{localStorage.getItem('__pandoraRegisteredRealName')}catch(e){null}", true); } catch {}
  if (!nomeReal) nomeReal = randNome();
  const cpfReal = randCpf();
  await new Promise((r) => setTimeout(r, 800));
  log("PASSO 4: injetando script (selecionar PHONE + preencher nome/chave/CPF)");
  try {
    // BUG CRÍTICO real 2026-08-10 (reportado pelo usuário: chave cadastrada
    // como CPF em vez de PHONE) — este código ignorava por completo o que o
    // script injetado retornava (mesmo já ele podendo devolver { ok: false }
    // quando não confirma PHONE), sempre respondendo { ok: true } aqui. Sem
    // isso, o fix dentro do script (abortar quando PHONE não é confirmado)
    // não tinha efeito nenhum no fluxo — runFullFlow via r4.ok sempre true e
    // seguia pro PASSO 5 (Confirmar) do mesmo jeito. Agora repassa o
    // resultado de verdade do script.
    const res = await wc.executeJavaScript(buildStep4Script(chave, nomeReal, cpfReal), true);
    if (!res || !res.ok) {
      log("PASSO 4: script retornou falha — " + (res && res.reason ? res.reason : "sem detalhe"));
      return { ok: false, error: (res && res.reason) || "passo 4 falhou" };
    }
    return { ok: true, chave };
  } catch (e) {
    log("PASSO 4: falha ao injetar script — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao injetar script" };
  }
}

// Exclui a chave de Chaves PIX depois de usada — igual o fluxo antigo fazia,
// sem esperar confirmação do site (a chave já foi enviada pro formulário).
function excluirChaveUsada(chave) {
  if (!chave) return;
  try {
    const stmt = state.db.prepare("DELETE FROM pix_keys WHERE key_value=?");
    stmt.run([chave]);
    stmt.free();
    log("chave " + chave + " excluída de Chaves PIX (já foi usada)");
  } catch (e) {
    log("falha ao excluir chave usada — " + (e && e.message ? e.message : String(e)));
  }
}

// PASSO 5: clica em Confirmar (única vez) no modal "Adicionar PIX".
async function runStep5(win) {
  if (!win || win.isDestroyed()) return { ok: false, error: "janela inválida" };
  const wc = win.webContents;
  await new Promise((r) => setTimeout(r, 500));
  log("PASSO 5: injetando script (clicar Confirmar, única vez)");
  try {
    // Mesmo bug do PASSO 1/2/3/4 corrigido 2026-08-10 — este era o mais
    // grave dos cinco: r5.ok decide se a chave é excluída de "Chaves PIX"
    // (ver runFullFlow, "if (r5.ok && r4.chave) excluirChaveUsada"). Sempre
    // devolver ok:true aqui mesmo quando o botão Confirmar não era achado/
    // clicado significava apagar a chave da lista como se tivesse sido
    // usada de verdade, mesmo quando NADA foi confirmado no site.
    const res = await wc.executeJavaScript(STEP5_SCRIPT, true);
    if (!res || !res.ok) {
      log("PASSO 5: script retornou falha — " + (res && res.reason ? res.reason : "sem detalhe"));
      return { ok: false, error: (res && res.reason) || "passo 5 falhou (não confirmou)" };
    }
    return { ok: true };
  } catch (e) {
    log("PASSO 5: falha ao injetar script — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao injetar script" };
  }
}

// Corre os passos em sequência numa janela. chaveFixa (opcional) — ver
// comentário em runStep4: quando "Mesmas chaves para links diferentes"
// está ativa, todas as janelas recebem a MESMA chave em vez de sortear uma
// diferente cada uma.
async function runFullFlow(win, chaveFixa) {
  const r1 = await runStep1(win);
  if (!r1.ok) return r1;
  const r2 = await runStep2(win);
  if (!r2.ok) { if (r1.stopDrain) r1.stopDrain(); return r2; }
  const r3 = await runStep3(win);
  if (!r3.ok) { if (r1.stopDrain) r1.stopDrain(); return r3; }
  const r4 = await runStep4(win, chaveFixa);
  if (!r4.ok) { if (r1.stopDrain) r1.stopDrain(); return r4; }
  const r5 = await runStep5(win);
  // BUG real 2026-08-09 (reportado pelo usuário: chave apagada de Chaves PIX
  // mesmo o cadastro tendo falhado — nem PHONE foi selecionado certo) —
  // excluía a chave só por r4.chave existir, sem checar se o PASSO 5
  // (clique em "Confirmar") de fato aconteceu. Se o botão não foi achado/
  // clicado, a chave nunca foi usada de verdade e não devia ser apagada.
  if (r5.ok && r4.chave) excluirChaveUsada(r4.chave);
  // dá tempo do polling pegar as últimas linhas antes de parar
  setTimeout(() => { if (r1.stopDrain) r1.stopDrain(); }, 9000);
  return r5;
}

function registerPixFlowV2Handler(ipcMain) {
  const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");
  ipcMain.handle("chrome:cadastrarPixV2", async () => {
    const wins = getSelectedChromeWins();
    if (!wins.length) return { ok: false, error: "Nenhuma tela selecionada/aberta" };
    // Pedido do usuário 2026-08-11: "mesmas chaves para links diferentes" —
    // decide a chave UMA vez aqui fora (antes de disparar as janelas em
    // paralelo) quando a opção está ativa, em vez de deixar cada
    // runStep4/janela sortear a sua própria chave do banco.
    const mesmasChaves = String(getSettingSync("op_mesmas_chaves", "0")) === "1";
    let chaveFixa = "";
    if (mesmasChaves) {
      try {
        const stmt = state.db.prepare("SELECT key_value FROM pix_keys WHERE key_type='phone' AND status='active' ORDER BY RANDOM() LIMIT 1");
        if (stmt.step()) chaveFixa = String(stmt.getAsObject().key_value || "");
        stmt.free();
      } catch (e) {
        log("cadastrarPixV2: falha ao sortear chave fixa pra 'mesmas chaves' — " + (e && e.message ? e.message : String(e)));
      }
      log(`cadastrarPixV2: "Mesmas chaves para links diferentes" ativa — usando a mesma chave (${chaveFixa || "NENHUMA — nenhuma chave ativa encontrada"}) em todas as ${wins.length} tela(s)`);
    }
    const results = await Promise.all(wins.map((w) => runFullFlow(w, mesmasChaves ? chaveFixa : undefined)));
    const ok = results.filter((r) => r.ok).length;
    return { ok: true, windows: wins.length, sucesso: ok };
  });
}

module.exports = { runStep1, runStep2, runStep3, runStep4, runStep5, runFullFlow, registerPixFlowV2Handler };
