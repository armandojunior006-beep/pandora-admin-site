// ============================================================================
// Chrome real via CDP (protocolo do DevTools, mesma base do Puppeteer) no
// lugar da janela Electron custom. Reaproveita 1:1 o que já existia — só
// troca COMO é aplicado:
//   - proxy: ses.setProxy() (Electron)          → --proxy-server (flag de launch)
//   - stealth/popup-killer: executeJavaScript()  → page.evaluateOnNewDocument()
//   - posição/tamanho: BrowserWindow({x,y,w,h})  → CDP Browser.setWindowBounds
//   - clique humanizado: preload + IPC            → page.exposeFunction + CDP Input
//   - auto-cadastro/GeeTest/popup-closer/PIX: mesmíssimo código (auto-register.cjs,
//     geetest-attach.cjs, autoLogin.cjs, pixModalEnhancer.cjs), rodando por
//     cima de um shim que faz a Page do Puppeteer parecer um webContents
//     (webContentsShim.cjs) — ver esse arquivo pra entender a cobertura.
//
// FASE 3: as janelas abertas aqui entram no MESMO state.chromeWins que as
// janelas Electron (via registerChromeWin) — chrome:navigate, chrome:depositar,
// chrome:cadastrarPix, chrome:searchSlot etc. continuam funcionando sem
// nenhuma mudança nesses arquivos, porque o shim implementa a mesma interface.
// ============================================================================
const fs = require("fs");
const path = require("path");
const { ROOT_DIR } = require("../../paths.cjs");
const state = require("../../state.cjs");
const { getSettingSync, logSystem, logSystemProgress, clearProgressLog } = require("../../settings/settingsStore.cjs");
const { getTargetDisplay, gridWindowBounds, getCustomWindowBounds, registerChromeWin } = require("../windowManager.cjs");
const { getActiveProxiesSync } = require("../../proxy/proxyManager.cjs");
const { createToggleableProxyBridge } = require("../../proxy/toggleableBridge.cjs");
const { nextSessionUA } = require("../../injections/mobileProfiles.cjs");
const { buildStealthScript } = require("../../injections/stealth.cjs");
const { ensureChromeBinary } = require("./chromeBinary.cjs");
const { applyNativeIdentity } = require("./nativeIcon.cjs");
const { createWindowShim } = require("./webContentsShim.cjs");
const { attachBrowserToolbar, runToolbarNavCommand, __SPEEDHACK_SCRIPT, __CANVAS_CLICK_SCRIPT, __API_INSPECT_SCRIPT, __WORKER_INSPECT_SCRIPT, __WG_SCENE_BET_FINDER_SCRIPT } = require("../../injections/browserInjections.cjs");
const { attachPopupCloser, attachContaAutoLogin } = require("../autoLogin.cjs");
const { attachPixModalEnhancer } = require("../../injections/pixModalEnhancer.cjs");
const { attachAutoRegister, getDiagFilePath, queueDiagLine, setContaCriadaBatchTotal } = require("../../../auto-register.cjs");
const { iniciarAutoCaptura } = require("../../../autoCaptura.cjs");
const { listarContas } = require("../../../contasStore.cjs");
const { attachGeetestSolver } = require("../../../geetest-attach.cjs");
const { saveDB } = require("../../../db.cjs");
const { humanClickSequence } = require("../../lib/humanClick.cjs");

let _popupKillerJs = "";
function getPopupKillerJs() {
  if (_popupKillerJs) return _popupKillerJs;
  try { _popupKillerJs = fs.readFileSync(path.join(ROOT_DIR, "popup-killer-injected.js"), "utf8"); } catch { _popupKillerJs = ""; }
  return _popupKillerJs;
}

// Toda janela abre em Chrome PADRÃO (abas, voltar/avançar/atualizar nativos
// — sem barra customizada nossa por cima), respeitando EXATAMENTE o tamanho/
// posição configurado em TELAS, não importa quão pequeno.
//
// O Chrome trava o CONTEÚDO em ~500px de largura quando a UI de abas/barra
// de endereço está visível — é uma constante fixa no C++ da toolbar (não uma
// negociação de mensagem do Windows: testado exaustivamente, inclusive
// injetando uma DLL de verdade dentro do processo do Chrome pra tentar
// contornar via WM_GETMINMAXINFO/WM_WINDOWPOSCHANGING, sem sucesso).
//
// A saída real (achada analisando __posicao_telas.json de outro bot que
// consegue isso): --force-device-scale-factor. Esse flag SÓ afeta a conta
// que o Chrome faz pra converter pixels físicos da janela em pixels
// "lógicos" (DIP) — é EM CIMA do valor em DIP que a checagem de largura
// mínima da toolbar roda. --window-size continua sendo pixels FÍSICOS (o
// tamanho que realmente aparece na tela não muda nada); só a config de DSF
// muda quanto o Chrome ACHA que tem de espaço em DIP pra desenhar a UI.
// Testado e confirmado via GetWindowRect (Win32, tamanho físico real na
// tela): pedindo --window-size=529,696 --force-device-scale-factor=0.65,
// a janela ocupa fisicamente 344×453px na tela (529×0.65≈344), mas o Chrome
// "acha" que tem 529 DIP de largura — acima do mínimo — e desenha a
// toolbar/abas normalmente, sem cortar nada. É exatamente essa a conta que
// bate com os valores do arquivo de config do outro bot (w:344, scale_factor
// 0.65 → 344/0.65≈529).
const MIN_NATIVE_CHROME_WIDTH = 520;

// Cria um profile temporário (--user-data-dir) por janela — equivalente ao
// session.fromPartition() de cada BrowserWindow hoje: isolamento total de
// cookies/storage entre janelas.
function makeUserDataDir(index) {
  const os = require("os");
  const dir = path.join(os.tmpdir(), "pandora-realchrome", `profile-${index}-${Date.now()}`);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

// Bridge TOGGLEÁVEL (liga/desliga proxy em tempo real, sem relançar o
// Chrome — ver toggleableBridge.cjs) em vez do bridge fixo do proxy-chain.
// O Chrome sempre aponta pra esse endereço local; o F8 só vira uma flag em
// memória (proxyToggle.setEnabled).
async function resolveProxyBridge(proxy) {
  if (!proxy || !proxy.host || !proxy.port) return null;
  try {
    const toggle = await createToggleableProxyBridge(proxy);
    return { localUrl: toggle.localUrl, toggle };
  } catch (e) {
    console.warn(`[realchrome] falha ao criar bridge toggleável pra ${proxy.host}:${proxy.port}: ${e?.message || e}`);
    return null;
  }
}

// Badge de IP no canto (mesmo visual do caminho Electron — proxyManager.cjs
// showProxyIpOnWindow), adaptado pro Chrome real: lá o IP é buscado via
// net.request(session) do Electron (não existe em Chrome real); aqui pede
// pra própria PÁGINA buscar (fetch dentro do page.evaluate) — como o proxy
// é aplicado no processo inteiro do Chrome via --proxy-server, qualquer
// requisição feita PELA página já sai pelo mesmo proxy da janela, então o
// IP retornado é exatamente o IP de saída de verdade daquela janela.
async function fetchProxyIpReal(page) {
  try {
    const ip = await page.evaluate(async () => {
      try {
        const res = await fetch("https://api.ipify.org?format=json", { cache: "no-store" });
        const j = await res.json();
        return (j && j.ip) || "";
      } catch { return ""; }
    });
    return String(ip || "").trim();
  } catch { return ""; }
}

async function showProxyIpOnRealChromeWindow(winShim, opts = {}) {
  if (!winShim || winShim.isDestroyed()) return;
  if (opts.force) winShim._proxyIp = "";
  let ip = winShim._proxyIp || await fetchProxyIpReal(winShim._page);
  if (!ip || winShim.isDestroyed()) return;
  winShim._proxyIp = ip;
  // Fundo continua sempre cinza — só o TEXTO (número do IP) fica vermelho
  // quando a proxy está desativada, a pedido do usuário (antes o badge
  // inteiro ficava vermelho, o que chamava atenção demais/parecia erro).
  const disabled = !!(winShim._proxyToggle && winShim._proxyToggle.isEnabled && !winShim._proxyToggle.isEnabled());
  const textColor = disabled ? "#ff5555" : "#ffffff";
  const label = disabled ? `⚠ ${ip}` : ip;
  const safeLabel = String(label).replace(/[\\'"<>]/g, "");
  try {
    await winShim.webContents.executeJavaScript(`(() => {
      try {
        const id = '__pandora_ip_badge__';
        document.getElementById(id)?.remove();
        const el = document.createElement('div');
        el.id = id;
        el.textContent = '${safeLabel}';
        Object.assign(el.style, {
          position: 'fixed', bottom: '8px', left: '8px', zIndex: 2147483647,
          background: 'rgba(0,0,0,0.55)', color: '${textColor}',
          font: '700 11px system-ui,sans-serif', padding: '4px 8px',
          borderRadius: '6px', border: '1px solid rgba(255,255,255,0.15)',
          pointerEvents: 'none', letterSpacing: '0.3px',
          backdropFilter: 'blur(4px)',
        });
        (document.body || document.documentElement).appendChild(el);
      } catch(e){}
    })();`);
  } catch {}
}

// Prepara um Page recém-criado (janela inicial OU aba nova — mesma coisa do
// ponto de vista do que precisa ser injetado/exposto) pra funcionar com todo
// o resto do app: stealth, popup-killer, clique humanizado, shim de
// webContents, registro em state.chromeWins, e as automações (popup-closer,
// PIX, GeeTest, auto-cadastro/login). `nativeChrome` decide se a barra
// customizada é injetada (só faz sentido no modo --app, sem UI própria).
// Helper genérico pra qualquer comando CDP que possa travar sem nunca
// resolver nem rejeitar (o mesmo sintoma intermitente já visto em
// Runtime.evaluate/api-inspect/exposeFunction — CAUSA RAIZ real 2026-08-09
// do "carregando infinito" + "Stop não fecha": Browser.getWindowForTarget/
// setWindowBounds, chamados ANTES de wireNewPage sequer começar, travavam
// SEM guarda nenhuma — o await ficava pendurado pra sempre, então
// wireNewPage/registerChromeWin NUNCA rodavam, a janela nunca entrava em
// state.chromeWins (Stop não achava nada pra fechar) e a navegação real
// nunca era agendada (splash pra sempre). timeoutMs generoso (8s, igual o
// resto do arquivo) — esses comandos normalmente levam <200ms.
function cdpSendGuarded(cdp, method, params, timeoutMs = 8000) {
  return Promise.race([
    cdp.send(method, params),
    new Promise((_, reject) => setTimeout(() => reject(new Error(`${method} travou (sem resposta em ${timeoutMs}ms)`)), timeoutMs)),
  ]);
}

// Reforça o tamanho/posição CONFIGURADOS (grid de Telas) numa janela já
// aberta, sob demanda — pedido do usuário 2026-08-09 (foto real: o QR de
// uma janela saiu visivelmente menor que o de outra, mesma grade
// configurada). Usado por qrCapture.cjs bem antes do depósito carregar,
// como reforço adicional aos dois pontos que já existiam (na abertura e
// logo após a navegação real) — cobre o caso de a janela "desassentar" de
// novo mais tarde, no meio da sessão (troca de tela/SPA dentro do site),
// que os dois pontos anteriores não alcançam por já terem rodado há tempo.
async function reapplyWindowBounds(win, tag = "") {
  try {
    if (!win || win.isDestroyed() || !win._cdp || !win._configuredBounds) return false;
    const { pos, size } = win._configuredBounds;
    const cdp = win._cdp;
    const { windowId, bounds: curBounds } = await cdpSendGuarded(cdp, "Browser.getWindowForTarget");
    if (curBounds.width === size.w && curBounds.height === size.h) return true; // já está certo
    queueDiagLine(`[${new Date().toISOString()}] [cdp-bounds] ${tag} reforçando tamanho fora do esperado (${JSON.stringify(curBounds)}) -> ${JSON.stringify(size)}\r\n`);
    await cdpSendGuarded(cdp, "Browser.setWindowBounds", { windowId, bounds: { windowState: "normal" } });
    await cdpSendGuarded(cdp, "Browser.setWindowBounds", { windowId, bounds: { left: pos.x, top: pos.y, width: size.w, height: size.h, windowState: "normal" } });
    return true;
  } catch (e) {
    try { queueDiagLine(`[${new Date().toISOString()}] [cdp-bounds] ${tag} reapplyWindowBounds falhou: ${e?.message}\r\n`); } catch {}
    return false;
  }
}

async function wireNewPage({ browser, page, cdp, targetUrl, mobileProfile, nativeChrome, conta, acc = null, chromePid = null }) {
  // Teste A/B 2026-08-09 (stealth desligado) não resolveu o bug do
  // "Relatório de Apostas" — reativado.
  const { js: stealthJs } = buildStealthScript(mobileProfile, null);
  try { await page.evaluateOnNewDocument(stealthJs); } catch {}
  const popupKillerJs = getPopupKillerJs();
  if (popupKillerJs) { try { await page.evaluateOnNewDocument(popupKillerJs); } catch {} }
  // Speedhack + clique de canvas + ponte mouse→touch, registrados via
  // evaluateOnNewDocument (Page.addScriptToEvaluateOnNewDocument) em vez de
  // só reativo (attachBrowserToolbar's executeInAllFrames/frame-created).
  // Isso é uma garantia do PRÓPRIO Chrome: o script roda em TODA página e
  // TODO iframe (incluindo os cross-origin/OOPIF dos motores de slot),
  // antes de qualquer JS do jogo — sem depender da nossa árvore de frames
  // simulada (webContentsShim.cjs não implementa framesInSubtree/.send()/
  // .once() como o Electron de verdade tem, então o caminho reativo sozinho
  // podia não alcançar o iframe do jogo a tempo, ou nunca). O caminho
  // reativo continua rodando também (necessário pra ATUALIZAR o multiplicador
  // de velocidade em tempo real numa página já carregada), isso aqui só
  // garante que o hook em si sempre existe desde o primeiro instante.
  try { await page.evaluateOnNewDocument(__SPEEDHACK_SCRIPT); } catch {}
  try { await page.evaluateOnNewDocument(__CANVAS_CLICK_SCRIPT); } catch {}
  // TEMPORÁRIO — investigação de API de aposta (2026-08-07). Remover depois.
  if (mobileProfile) { try { await page.evaluateOnNewDocument(__API_INSPECT_SCRIPT); } catch {} }
  try {
    await page.exposeFunction("__pandoraHumanClick", async (x, y) => {
      // Janelas com toque emulado (mobileProfile/Modo Mobile) usam TOQUE de
      // verdade (Input.dispatchTouchEvent), não mouse. Descoberto em
      // 2026-08-07 (investigação Pragmatic/WG + bug do botão Cadastrar):
      // Input.dispatchMouseEvent tipo mousePressed/mouseReleased NUNCA
      // resolve nessas janelas (nem erro, nem sucesso) — só travar o await
      // pra sempre (trava o fluxo inteiro que chamou o clique, ex.:
      // clickBtn do cadastro) OU abandonar via timeout (mandava mouseUp
      // antes do mouseDown ser confirmado — bagunçava a tradução mouse→
      // toque do Chrome e gerava cliques fantasmas, incl. um de botão
      // direito visto em teste real). Toque direto não tem esse problema
      // (testado e confirmado antes). Sem "mouseMove"/hover — toque de
      // verdade não paira antes de tocar, então esses passos da trajetória
      // humanizada só são pulados aqui (sem custo, é só visual/timing).
      if (mobileProfile) {
        const dispatch = async (type, mx, my) => {
          if (type === "mouseMove") return; // toque não paira — pula os passos de hover
          const touchType = type === "mouseDown" ? "touchStart" : "touchEnd";
          const touchPoints = type === "mouseDown" ? [{ x: mx, y: my, radiusX: 5, radiusY: 5, force: 1 }] : [];
          await cdp.send("Input.dispatchTouchEvent", { type: touchType, touchPoints });
        };
        return humanClickSequence(dispatch, x, y);
      }
      const dispatch = async (type, mx, my) => {
        const map = { mouseMove: "mouseMoved", mouseDown: "mousePressed", mouseUp: "mouseReleased" };
        await cdp.send("Input.dispatchMouseEvent", {
          type: map[type], x: mx, y: my,
          button: type === "mouseMove" ? "none" : "left",
          clickCount: type === "mouseMove" ? 0 : 1,
        });
      };
      return humanClickSequence(dispatch, x, y);
    });
  } catch {}

  // TEMPORÁRIO — investigação de API de aposta (2026-08-07). O motor de
  // giros via API (__pandoraApiSpinRun em browserInjections.cjs) chama isso
  // depois de CADA giro — joga direto pro Log de Operações (mesma tabela
  // "logs" que a aba usa) em vez de só ficar no arquivo de diagnóstico, pra
  // dar acompanhamento em tempo real (rodadas restantes, saldo, ganho).
  try {
    await page.exposeFunction("__pandoraApiSpinProgress", (info) => {
      try {
        const tela = winShim?._pandoraOrder || "?";
        // Atualiza a MESMA linha a cada giro (uma por tela+slot) em vez de
        // criar uma nova — "giro 65/500" virando 500 linhas inundava o Log
        // de Operações, ficava inviável de acompanhar com várias telas.
        const key = `auto-slot-${tela}-${info?.slot || "slot"}`;
        const msg = `Tela ${tela} — ${info?.slot || "Slot"}: giro ${info?.i}/${info?.count} — saldo R$${Number(info?.bl ?? 0).toFixed(2)}`;
        logSystemProgress(key, msg, { kind: "auto-slot-api", tela, ...info }, info?.err ? "warning" : "info", "operacao-auto-slot");
        // Saldo zerado — para o giro, pedido do usuário 2026-08-08: precisa
        // aparecer bem claro no Log de Operações (não só sumir no meio de
        // "giro X/Y" com saldo 0.00), como uma linha PRÓPRIA no histórico.
        if (info?.zerado) {
          clearProgressLog(key);
          logSystem(`Tela ${tela} — ${info?.slot || "Slot"}: SALDO ZERADO`, { kind: "auto-slot-api-zerado", tela, ...info }, "warning", "operacao-auto-slot");
        }
        if (info?.i != null && info?.count != null && info.i >= info.count && !info.err && !info.zerado) {
          clearProgressLog(key);
          logSystem(`Tela ${tela} — ${info?.slot || "Slot"}: GIROS COMPLETOS`, { kind: "auto-slot-api-completo", tela, ...info }, "success", "operacao-auto-slot");
        }
      } catch {}
    });
  } catch {}

  // Toque NATIVO de verdade — histórico do que já foi tentado (mantido pra
  // não repetir os mesmos becos-sem-saída no futuro):
  //   1) TouchEvent via dispatchEvent em JS (ponte em JS puro): SEMPRE
  //      isTrusted:false — o Cocos do PG SOFT filtra input não confiável no
  //      InputManager e descarta. REMOVIDA (ver browserInjections.cjs).
  //   2) Input.dispatchTouchEvent com coordenadas calculadas por NÓS a
  //      partir de e.clientX/clientY capturados DENTRO do frame do jogo:
  //      isTrusted:true mas erra o alvo (coordenada é relativa só ao iframe
  //      aninhado, não à janela).
  //   3) elementHandle.tap()/clickablePoint() do Puppeteer + touchmove:
  //      toque certo, no lugar certo, isTrusted:true — mesmo assim não
  //      bastou sozinho.
  // SOLUÇÃO: Emulation.setEmitTouchEventsForMouse, aplicado em CADA TARGET
  // (a página principal E cada iframe OOPIF do jogo — são processos
  // separados, um comando na sessão da página principal não alcança o
  // iframe cross-origin sozinho). Liga a tradução mouse→touch DENTRO do
  // próprio Blink — todo clique de mouse de verdade (físico ou nosso
  // sendInputEvent) já sai como touch isTrusted:true, com a mesma robustez
  // de coordenada/frame que o navegador usa pra qualquer evento real. É
  // DIFERENTE de Emulation.setTouchEmulationEnabled (+setDeviceMetricsOverride),
  // que é o que quebra layout/viewport — esse aqui sozinho não mexe em
  // viewport, só na tradução do tipo de evento.
  if (mobileProfile) {
    const applyTouchEmulationToTarget = async (target) => {
      try {
        if (!["page", "iframe"].includes(target.type())) return;
        const session = await target.createCDPSession();
        await session.send("Emulation.setEmitTouchEventsForMouse", { enabled: true, configuration: "mobile" });
      } catch (e) {
        console.warn("[realchrome] setEmitTouchEventsForMouse (target) falhou:", e?.message);
      }
    };
    browser.on("targetcreated", applyTouchEmulationToTarget);
    // Mesmo timeout duro do api-inspect logo abaixo (ver comentário grande
    // lá) — qualquer await direto de comando CDP aqui dentro de wireNewPage
    // pode travar a criação da janela inteira se travar sem nunca resolver.
    await Promise.race([applyTouchEmulationToTarget(page.target()), new Promise((r) => setTimeout(r, 8000))]);
  }

  // Speedhack: mesmo problema/mesma solução do touch acima — um iframe
  // cross-origin (ex.: motor da WG, domínio totalmente diferente do site)
  // roda em processo/sessão CDP separada, e page.evaluateOnNewDocument()
  // no frame principal não é garantido chegar nele (evidência: o hook
  // ficava registrado mas tinha ZERO efeito nesse iframe específico,
  // enquanto funcionava normal nos iframes da PG). Registra o script
  // DIRETO na sessão CDP de CADA target (page + iframe), igual o touch.
  const applySpeedhackToTarget = async (target) => {
    try {
      if (!["page", "iframe"].includes(target.type())) return;
      const session = await target.createCDPSession();
      await session.send("Page.enable").catch(() => {});
      await session.send("Page.addScriptToEvaluateOnNewDocument", { source: __SPEEDHACK_SCRIPT });
      // Reforço: se o frame já carregou (ex.: adotamos o target depois do
      // documento pronto), injeta imediatamente também — addScriptToEvaluateOnNewDocument
      // sozinho só vale pra PRÓXIMA navegação daquele frame.
      await session.send("Runtime.evaluate", { expression: __SPEEDHACK_SCRIPT, awaitPromise: false }).catch(() => {});
      // Reforço extra (WG/Lucky Dog): a tela de loading acelera mas o motor
      // "de verdade" do jogo, que aparece um pouco depois, não — reinjeta
      // mais 12x nos primeiros ~6s pra pegar esse motor caso ele monte seus
      // próprios timers depois da nossa primeira injeção (o guard interno do
      // script evita reinstalar duas vezes se já estiver ativo, então isso
      // é seguro/sem custo extra quando desnecessário).
      let tries = 0;
      const reinforce = setInterval(() => {
        tries++;
        if (tries > 12) { clearInterval(reinforce); return; }
        session.send("Runtime.evaluate", { expression: __SPEEDHACK_SCRIPT, awaitPromise: false }).catch(() => clearInterval(reinforce));
      }, 500);
    } catch (e) {
      console.warn("[realchrome] speedhack (target) falhou:", e?.message);
    }
  };
  browser.on("targetcreated", applySpeedhackToTarget);
  // Mesmo timeout duro do api-inspect abaixo — ver comentário grande lá.
  await Promise.race([applySpeedhackToTarget(page.target()), new Promise((r) => setTimeout(r, 8000))]);

  // Inspetor de rede (WebSocket/fetch/XHR/sendBeacon) — MESMA técnica
  // por-target que corrigiu o speedhack. Investigação de API de aposta
  // (WG/Lucky Dog) rodada antes só injetava via page.evaluateOnNewDocument
  // na página principal, que não é garantido chegar no iframe cross-origin
  // do motor do jogo — ou seja, é bem possível que o tráfego de rede desse
  // iframe NUNCA tenha sido monitorado de verdade. TEMPORÁRIO — reinvestigação.
  // Referência compartilhada pro CDP session do alvo onde achamos
  // window.__pandoraWgBetCtrl (motor da WG) — winShim ainda não existe
  // nesse ponto da função (só é criado mais abaixo), então guarda num
  // objeto estável que os dois lados (o achador async e winShim, depois de
  // criado) enxergam pela mesma referência. Usado por chrome:testarApostaWG.
  const wgBetRef = { session: null, type: null, foundAt: null };
  // Mesma ideia, pra PP (Pragmatic Play) — investigação 2026-08-07: protocolo
  // HTTP puro (não WebSocket/binário como WG), então não precisa achar
  // método nenhum em árvore de cena — só rastrear o estado encadeado
  // (index/counter/mgckey) direto dos POSTs em /gs2c/ge/v3/gameService pra
  // conseguir montar a PRÓXIMA chamada. Ver runPpSpinChain mais abaixo.
  const ppSpinRef = { session: null, state: null };
  if (mobileProfile) {
    // Tipos de alvo cobertos pelo Network nativo. Antes só "page"/"iframe" —
    // por isso um Worker/Service Worker que o motor do jogo crie pra rede
    // NUNCA tinha o domínio Network ligado nele (só recebia o hook JS via
    // __WORKER_INSPECT_SCRIPT, que o próprio worker pode não usar as APIs
    // monkey-patchadas). Ampliado por sugestão do Gemini (armadilha #1:
    // Worker/Service Worker/sub-iframe dinâmico com targetId próprio).
    const NETWORK_TARGET_TYPES = ["page", "iframe", "worker", "service_worker", "shared_worker", "other"];
    const decodeWsPayload = (event) => {
      const data = event.response?.payloadData;
      if (!data) return "";
      // opcode 2 = frame binário: payloadData vem em base64 nesse caso
      // (armadilha #3 do Gemini — protocolo binário custom tipo protobuf/
      // msgpack). Decodifica pra hex + tenta como texto também.
      if (event.response?.opcode === 2) {
        try {
          const buf = Buffer.from(data, "base64");
          const asText = buf.toString("utf8").replace(/[^\x20-\x7e]/g, ".");
          return `[BIN opcode=2 len=${buf.length}] hex=${buf.toString("hex").slice(0, 300)} text~=${asText.slice(0, 300)}`;
        } catch {
          return `[BIN opcode=2, falha ao decodificar base64] raw=${String(data).slice(0, 300)}`;
        }
      }
      return String(data).slice(0, 500);
    };
    // Ponto 1 do Gemini (2026-08-07): dump em disco de .js/.wasm/.bin do
    // motor da WG, pra grepar strings (bet/spin/action/balance/chaves) no
    // código-fonte real em vez de só adivinhar pelo tráfego. Só dispara pros
    // domínios do motor (evita salvar o site inteiro) e só uma vez por URL.
    const WG_HOST_RX = /wgnetworking|wgosd|wgkonnect|fvnkonnect|140\.150\.33\.110|wggos|pwmercjm/i;
    const WG_DUMP_EXT_RX = /\.(js|mjs|wasm|bin)(\?|#|$)/i;
    const wgDumpDir = path.join(require("electron").app.getPath("userData"), "wg-dump");
    const wgDumped = new Set();
    const KEYWORD_RX = /\b(bet|spin|action|balance|wallet|saldo|aposta|girar|wager|placebet|sendaction|token|encrypt|decrypt|cipher|protobuf|msgpack)\b/gi;
    const dumpIfInteresting = async (session, requestId, rurl) => {
      try {
        if (!WG_HOST_RX.test(rurl) || !WG_DUMP_EXT_RX.test(rurl)) return;
        if (wgDumped.has(rurl)) return;
        wgDumped.add(rurl);
        const body = await session.send("Network.getResponseBody", { requestId }).catch(() => null);
        if (!body) return;
        const content = body.base64Encoded ? Buffer.from(body.body, "base64").toString("utf8") : String(body.body);
        try { fs.mkdirSync(wgDumpDir, { recursive: true }); } catch {}
        let name = "";
        try { name = new URL(rurl).pathname.split("/").filter(Boolean).join("_"); } catch { name = rurl.replace(/[^a-z0-9._-]/gi, "_"); }
        if (!name) name = `arquivo_${Date.now()}`;
        const outPath = path.join(wgDumpDir, name.slice(0, 180));
        fs.writeFileSync(outPath, content, "utf8");
        const hits = content.match(KEYWORD_RX);
        const uniqHits = hits ? [...new Set(hits.map((h) => h.toLowerCase()))] : [];
        queueDiagLine(`[${new Date().toISOString()}] [wg-dump] salvo ${outPath} (${content.length} bytes) — palavras-chave achadas: ${uniqHits.length ? uniqHits.join(", ") : "(nenhuma)"}\r\n`);
      } catch (e) {
        try { queueDiagLine(`[${new Date().toISOString()}] [wg-dump] falha ao salvar ${rurl}: ${e?.message}\r\n`); } catch {}
      }
    };
    const applyApiInspectToTarget = async (target) => {
      try {
        const type = target.type();
        if (!NETWORK_TARGET_TYPES.includes(type)) return;
        const session = await target.createCDPSession();
        let url = "?"; try { url = target.url(); } catch {}
        try { queueDiagLine(`[${new Date().toISOString()}] [cdp-network] alvo anexado type=${type} url=${url}\r\n`); } catch {}

        // "other" incluído aqui de propósito: foi exatamente esse tipo de
        // alvo (não "iframe" nem "worker" puros — o Puppeteer classifica
        // assim um contexto que o Chrome interno rotula "other") que
        // hospedava o motor de verdade da WG (2026-08-07: confirmado pelo
        // primeiro tráfego real do jogo já visto nessa investigação).
        if (type === "page" || type === "iframe" || type === "other") {
          await session.send("Page.enable").catch(() => {});
          await session.send("Page.addScriptToEvaluateOnNewDocument", { source: __API_INSPECT_SCRIPT });
          await session.send("Runtime.evaluate", { expression: __API_INSPECT_SCRIPT, awaitPromise: false }).catch(() => {});
          // Achador do controller de aposta real da WG (window.__pandoraWgBet)
          // — ver comentário grande na definição do script. Mesmos alvos do
          // inspetor de API acima (é onde window.cc/cc.director vive).
          await session.send("Page.addScriptToEvaluateOnNewDocument", { source: __WG_SCENE_BET_FINDER_SCRIPT });
          await session.send("Runtime.evaluate", { expression: __WG_SCENE_BET_FINDER_SCRIPT, awaitPromise: false }).catch(() => {});

          // Verificação direta via Node (NÃO depende do pipeline de console,
          // que se mostrou não-confiável nesse "other" específico — os logs
          // [pandora-api] paravam de aparecer pouco depois do target anexar,
          // mesmo com Runtime.enable ligado, então o achado real pode estar
          // silenciosamente pronto sem a gente conseguir VER o log). Pergunta
          // pro próprio target, via Runtime.evaluate + returnByValue, se
          // window.__pandoraWgBetCtrl já existe — funciona mesmo se
          // console.log estiver mudo por qualquer motivo.
          // Pula o heartbeat pra alvos que são só a splash local (file://,
          // logo/nome do dispositivo antes da navegação real) — o motor de
          // verdade da WG nunca vive ali, só no jogo depois de navegar (um
          // target NOVO tipo "other"/"iframe" que aciona essa função de
          // novo). Rodar aqui só gerava tráfego CDP concorrente à toa bem no
          // instante em que a navegação real (doRealNavigate) mais precisa
          // de banda livre — contribuía pra janela ficar presa na splash
          // (bug real 2026-08-09, reportado pelo usuário). O
          // addScriptToEvaluateOnNewDocument acima continua registrado
          // normalmente (vale pra navegações futuras desse MESMO target).
          const isLocalSplash = /^file:/i.test(url) || url === "about:blank";
          let wgChecks = 0;
          const wgCheckIv = isLocalSplash ? null : setInterval(async () => {
            wgChecks++;
            if (wgChecks > 30) { clearInterval(wgCheckIv); return; }
            try {
              const r = await session.send("Runtime.evaluate", {
                // found agora olha __pandoraWgFinderReady, não mais
                // __pandoraWgBetCtrl — esse só é setado DENTRO de uma
                // chamada de verdade a __pandoraWgBet (a busca virou
                // sempre-fresca por chamada, não cacheada — ver
                // __WG_SCENE_BET_FINDER_SCRIPT em browserInjections.cjs).
                expression: `(() => { try { return JSON.stringify({ hasCc: !!window.cc, hasDirector: !!(window.cc && window.cc.director), hasScene: !!(window.cc && window.cc.director && window.cc.director.getScene && window.cc.director.getScene()), found: !!window.__pandoraWgFinderReady }); } catch(e) { return JSON.stringify({ erro: e && e.message }); } })()`,
                returnByValue: true,
                awaitPromise: false,
              });
              const val = r?.result?.value;
              if (val) {
                queueDiagLine(`[${new Date().toISOString()}] [wg-check][${type}] tentativa ${wgChecks}: ${val}\r\n`);
                const parsed = JSON.parse(val);
                if (parsed.found) {
                  wgBetRef.session = session;
                  wgBetRef.type = type;
                  wgBetRef.foundAt = Date.now();
                  clearInterval(wgCheckIv);
                  // Limpa a referência quando ESSE target/sessão fecha de
                  // verdade (saiu da Home, trocou de jogo, iframe morreu) —
                  // pedido do usuário 2026-08-08: sem isso, "Session closed.
                  // Most likely the iframe has been closed" era tratado
                  // como erro definitivo (a sessão morta ficava presa pra
                  // sempre em wgBetRef, mesmo depois de entrar de novo no
                  // jogo e uma sessão NOVA já estar disponível via um novo
                  // ciclo de applyApiInspectToTarget). Limpar aqui deixa o
                  // runWgSpinChain corretamente reportar "ainda não
                  // encontrado" (retriável) em vez de reusar a sessão morta.
                  session.once("detached", () => {
                    if (wgBetRef.session === session) {
                      wgBetRef.session = null;
                      wgBetRef.type = null;
                      wgBetRef.foundAt = null;
                    }
                  });
                }
              }
            } catch (e) {
              try { queueDiagLine(`[${new Date().toISOString()}] [wg-check][${type}] falha na verificação: ${e?.message}\r\n`); } catch {}
            }
          }, 4000);

          // BUG achado (2026-08-07): console.log dentro de um alvo type="other"
          // NUNCA chegava no diag — page.on("console") do Puppeteer só recebe
          // mensagens do frame principal da Page, não de um CDP target à parte
          // que anexamos manualmente (é uma sessão totalmente separada). Os
          // logs [pandora-api]/[pandora-wg] rodavam certinho DENTRO do motor
          // da WG mas eram jogados fora silenciosamente. Captura via
          // Runtime.consoleAPICalled na PRÓPRIA sessão do target resolve —
          // mesmo princípio do Network nativo acima, sem depender do
          // pipeline de console do Puppeteer.
          await session.send("Runtime.enable").catch(() => {});
          session.on("Runtime.consoleAPICalled", (event) => {
            try {
              const parts = (event.args || []).map((a) => {
                if (a.value !== undefined) return typeof a.value === "string" ? a.value : JSON.stringify(a.value);
                if (a.description) return a.description;
                return "";
              });
              const text = parts.join(" ").trim();
              if (!text || !/\[pandora-/i.test(text)) return;
              queueDiagLine(`[${new Date().toISOString()}] [console][${type}] ${text.slice(0, 1500)}\r\n`);
            } catch {}
          });
        }

        // Sugestão do Gemini (2026-08-07): domínio Network nativo do CDP em
        // vez de só monkey-patch em JS — vê o tráfego BRUTO na camada do
        // navegador, direto na sessão do target, sem depender de nenhum
        // código rodando certo dentro da página (não tem como o jogo
        // "sobrescrever" isso, é fora do alcance do JS dele). Cobre HTTP
        // (fetch/XHR/qualquer POST) e WebSocket nativamente. Agora ligado
        // em QUALQUER tipo de alvo (page/iframe/worker/service_worker/...).
        await session.send("Network.enable").catch((e) => {
          try { queueDiagLine(`[${new Date().toISOString()}] [cdp-network] Network.enable falhou em type=${type} url=${url}: ${e?.message}\r\n`); } catch {}
        });
        // Mapa requestId -> url pra correlacionar com loadingFailed abaixo
        // (o evento de falha não traz a URL, só o requestId). Bug real
        // 2026-08-09: "só fica carregando" — precisamos ver QUAL recurso
        // trava/falha (proxy caindo, WASM bloqueado, WS recusado, etc.) em
        // vez de ficar só adivinhando. Escopo por sessão (não vaza entre
        // janelas), sem limite de limpeza — sessão morre com o target.
        const reqUrlMap = new Map();
        session.on("Network.requestWillBeSent", (event) => {
          try {
            const req = event.request;
            try { reqUrlMap.set(event.requestId, req.url); } catch {}
            if (req.method === "POST" || /bet|spin|game|api|wager/i.test(req.url)) {
              const line = `[cdp-network][${type}] ${req.method} ${req.url}` + (req.postData ? ` body=> ${String(req.postData).slice(0, 800)}` : "");
              queueDiagLine(`[${new Date().toISOString()}] ${line}\r\n`);
            }
            // PP (Pragmatic Play) — investigação 2026-08-07: protocolo HTTP
            // puro (form-urlencoded), encadeado via index/counter (+1 a cada
            // chamada, spin OU collect), autenticado por um mgckey fixo por
            // sessão. Guarda o que precisamos pra montar a PRÓXIMA chamada
            // sozinho (ver runPpSpinChain). A cada request de verdade do
            // jogo, reafirma mgckey/symbol/origin (não muda durante a sessão).
            if (/\/gs2c\/ge\/v3\/gameService(\?|$)/i.test(req.url) && req.postData) {
              const p = new URLSearchParams(req.postData);
              const mgckey = p.get("mgckey");
              const symbol = p.get("symbol");
              if (mgckey && symbol) {
                if (!ppSpinRef.state) ppSpinRef.state = {};
                ppSpinRef.state.mgckey = mgckey;
                ppSpinRef.state.symbol = symbol;
                ppSpinRef.state.url = req.url;
                if (ppSpinRef.session !== session) {
                  ppSpinRef.session = session;
                  // Mesma limpeza de referência morta que o wgBetRef —
                  // pedido do usuário 2026-08-08. Guarda contra registrar
                  // esse listener de novo a cada request (só na 1ª vez que
                  // essa sessão vira a "atual").
                  session.once("detached", () => {
                    if (ppSpinRef.session === session) {
                      ppSpinRef.session = null;
                      ppSpinRef.state = null;
                    }
                  });
                }
              }
            }
          } catch {}
        });
        session.on("Network.responseReceived", async (event) => {
          try {
            const rurl = event.response.url;
            // Resposta HTTP "bem-sucedida" na camada de transporte mas com
            // status de erro (403/404/5xx) num recurso pesado do jogo (js/
            // wasm/media) explica um "carregando infinito" que loadingFailed
            // nunca pegaria (não é falha de rede, é o servidor recusando
            // servir o recurso — bloqueio por IP/proxy, geo, anti-bot etc.).
            const st = event.response.status;
            if (st >= 400 && /\.(js|mjs|wasm|json|png|jpg|webp|mp3|ogg|bin)(\?|#|$)/i.test(rurl)) {
              queueDiagLine(`[${new Date().toISOString()}] [cdp-network][${type}] HTTP ${st} url=${rurl}\r\n`);
            }
            dumpIfInteresting(session, event.requestId, rurl).catch(() => {});
            const isPpGameService = /\/gs2c\/ge\/v3\/gameService(\?|$)/i.test(rurl);
            if (!/bet|spin|game|api|wager/i.test(rurl) && !isPpGameService) return;
            const body = await session.send("Network.getResponseBody", { requestId: event.requestId }).catch(() => null);
            if (!body) return;
            if (!isPpGameService) {
              queueDiagLine(`[${new Date().toISOString()}] [cdp-network][${type}] <= ${rurl} :: ${String(body.body).slice(0, 1200)}\r\n`);
              return;
            }
            // Resposta do gameService — sempre atualiza index/counter/balance/
            // na ("next action": 's'=spin liberado, 'c'=precisa doCollect
            // antes do próximo spin, achado observando um giro premiado de
            // verdade). sc/defc só vêm na resposta do doInit (lista de
            // apostas válidas) — mantém se já capturado antes.
            try {
              const rp = new URLSearchParams(String(body.body));
              if (!ppSpinRef.state) ppSpinRef.state = {};
              const st = ppSpinRef.state;
              if (rp.has("index")) st.index = parseInt(rp.get("index"), 10);
              if (rp.has("counter")) st.counter = parseInt(rp.get("counter"), 10);
              if (rp.has("balance")) st.balance = parseFloat(rp.get("balance"));
              if (rp.has("na")) st.na = rp.get("na");
              if (rp.has("l")) st.l = rp.get("l");
              if (rp.has("sc")) st.sc = rp.get("sc").split(",").map((v) => parseFloat(v)).filter((v) => !isNaN(v));
              if (rp.has("defc")) st.defc = parseFloat(rp.get("defc"));
              st.updatedAt = Date.now();
            } catch (e) {
              try { queueDiagLine(`[${new Date().toISOString()}] [pp-spin] falha ao ler resposta do gameService: ${e?.message}\r\n`); } catch {}
            }
          } catch {}
        });
        // Diagnóstico direto de recursos que travam/falham de verdade —
        // net::ERR_* explica coisas que o app nunca conseguiria ver via JS
        // da página (proxy caindo no meio, WASM/JS bloqueado por CSP ou
        // extensão, WS recusado pelo servidor, DNS falhando etc.). Cada
        // "carregando infinito" tem uma causa concreta aqui.
        session.on("Network.loadingFailed", (event) => {
          try {
            if (event.canceled) return;
            const rurl = reqUrlMap.get(event.requestId) || "?";
            queueDiagLine(`[${new Date().toISOString()}] [cdp-network][${type}] FALHA ${event.type} errorText=${event.errorText} url=${rurl}\r\n`);
          } catch {}
        });
        session.on("Network.webSocketCreated", (event) => {
          try { queueDiagLine(`[${new Date().toISOString()}] [cdp-network][${type}] WS CRIADO -> ${event.url}\r\n`); } catch {}
        });
        session.on("Network.webSocketFrameSent", (event) => {
          try { queueDiagLine(`[${new Date().toISOString()}] [cdp-network][${type}] WS => ${decodeWsPayload(event)}\r\n`); } catch {}
        });
        session.on("Network.webSocketFrameReceived", (event) => {
          try { queueDiagLine(`[${new Date().toISOString()}] [cdp-network][${type}] WS <= ${decodeWsPayload(event)}\r\n`); } catch {}
        });
      } catch (e) {
        console.warn("[realchrome] api-inspect (target) falhou:", e?.message);
        try { queueDiagLine(`[${new Date().toISOString()}] [cdp-network] api-inspect falhou em type=${target?.type?.()}: ${e?.message}\r\n`); } catch {}
      }
    };
    browser.on("targetcreated", applyApiInspectToTarget);
    // Timeout duro (bug real 2026-08-09, reportado pelo usuário: "dei play e
    // continua só carregando", "Stop não fecha" — só voltou a normal
    // fechando o app inteiro). Causa: applyApiInspectToTarget manda vários
    // comandos CDP em sequência (Page.enable, addScriptToEvaluateOnNewDocument,
    // Runtime.evaluate) e essa chamada é AWAITADA aqui dentro de wireNewPage,
    // ANTES de wireNewPage devolver o winShim — se QUALQUER desses comandos
    // travar sem nunca resolver nem rejeitar (CDP request perdido/sessão
    // instável logo na criação do target), wireNewPage nunca retorna, então
    // winShim nunca é criado, registerChromeWin nunca roda, a janela nunca
    // entra em state.chromeWins — e por isso nem a navegação real
    // (doRealNavigate, que só é agendada DEPOIS que openOneRealChromeWindow
    // recebe o winShim) nem o "Stop" (que só fecha janelas que estão em
    // state.chromeWins) conseguem alcançar essa janela. 8s é generoso pra
    // esses comandos (normalmente levam <200ms) sem deixar a criação da
    // janela inteira refém de um travamento pontual do CDP.
    await Promise.race([
      applyApiInspectToTarget(page.target()),
      new Promise((resolve) => setTimeout(() => {
        try { queueDiagLine(`[${new Date().toISOString()}] [cdp-network] api-inspect inicial não respondeu em 8s — seguindo sem travar a janela\r\n`); } catch {}
        resolve();
      }, 8000)),
    ]);

    // Worker: browser.on("targetcreated") já recebe target.type()==="worker"
    // (dedicated worker) — o problema original era só a API de alto nível
    // do Puppeteer (target.worker()) não funcionar pra esse tipo (só
    // service_worker/shared_worker). Injeta DIRETO na sessão CDP do worker,
    // contornando isso. Mantido como hook JS complementar ao Network nativo
    // acima (agora também ligado no worker).
    const applyWorkerInspect = async (target) => {
      try {
        if (target.type() !== "worker") return;
        let url = "?"; try { url = target.url(); } catch {}
        try { queueDiagLine(`[${new Date().toISOString()}] [worker-debug] worker target detectado: ${url}\r\n`); } catch {}
        const session = await target.createCDPSession();
        await session.send("Runtime.evaluate", { expression: __WORKER_INSPECT_SCRIPT, awaitPromise: false }).catch((e) => {
          try { queueDiagLine(`[${new Date().toISOString()}] [worker-debug] falha ao injetar no worker: ${e?.message}\r\n`); } catch {}
        });
      } catch (e) {
        console.warn("[realchrome] worker-inspect (target) falhou:", e?.message);
      }
    };
    browser.on("targetcreated", applyWorkerInspect);

    // Armadilha #1 do Gemini, parte 2: Target.setDiscoverTargets GLOBAL no
    // nível do browser. O "targetcreated" do Puppeteer só reflete os alvos
    // que a própria lib decide auto-attachar (nem sempre 100% de service
    // workers / sub-iframes criados dinamicamente depois do load). Abrindo
    // uma sessão CDP direto no alvo "browser" e escutando Target.targetCreated
    // cru, pegamos QUALQUER coisa que nascer, mesmo que o Puppeteer não a
    // exponha via sua própria API de alto nível.
    (async () => {
      try {
        const browserTarget = browser.target();
        const globalSession = await browserTarget.createCDPSession();
        await globalSession.send("Target.setDiscoverTargets", { discover: true });
        const seen = new Set();
        globalSession.on("Target.targetCreated", async ({ targetInfo }) => {
          try {
            if (seen.has(targetInfo.targetId)) return;
            seen.add(targetInfo.targetId);
            queueDiagLine(`[${new Date().toISOString()}] [cdp-network][global] alvo bruto criado type=${targetInfo.type} url=${targetInfo.url}\r\n`);
          } catch {}
        });
      } catch (e) {
        try { queueDiagLine(`[${new Date().toISOString()}] [cdp-network] Target.setDiscoverTargets global falhou: ${e?.message}\r\n`); } catch {}
        console.warn("[realchrome] target discovery global falhou:", e?.message);
      }
    })();
  }

  const winShim = createWindowShim({ browser, page, cdp, chromePid });
  winShim._targetUrl = targetUrl;
  winShim._realChrome = true;
  winShim._nativeChrome = !!nativeChrome;
  winShim._browser = browser;
  winShim._page = page;
  winShim._cdp = cdp;
  winShim._pandoraMobileProfile = mobileProfile;
  winShim._wgBetRef = wgBetRef;
  winShim._ppSpinRef = ppSpinRef;
  // "acc" também pode trazer uma conta de verdade (usado por
  // openRealChromiumMulti pra reabrir contas já existentes fora da aba
  // Contas) — antes só "conta" era gravado aqui, então essas janelas nunca
  // tinham login associado e accountBalance.cjs (aba Contas → coluna Saldo)
  // nunca conseguia rastrear o saldo delas (pedido do usuário 2026-08-09).
  const contaParaLogin = conta || (acc && acc.login ? acc : null);
  if (contaParaLogin) winShim._contaAutoLogin = { login: contaParaLogin.login || "", senha: contaParaLogin.senha || "" };
  registerChromeWin(winShim);

  // Mesmo timeout duro dos comandos CDP acima (ver comentário grande no
  // api-inspect) — exposeFunction também é um comando CDP (Runtime.addBinding)
  // por baixo, mesmo risco de travar pra sempre sem nunca resolver/rejeitar.
  // Como esse await vem DEPOIS de registerChromeWin, a janela já aparecia em
  // state.chromeWins mesmo travada aqui — mas tudo que openOneRealChromeWindow
  // faz DEPOIS de wireNewPage retornar (agendar a navegação real via
  // doRealNavigate, setar _pandoraOrder etc.) nunca rodava, porque wireNewPage
  // em si nunca retornava. Bug real 2026-08-09.
  await Promise.race([exposeNavSignal(page, winShim), new Promise((r) => setTimeout(r, 8000))]);
  // Captura no arquivo de diagnóstico qualquer log com a tag [pandora] vindo
  // de scripts injetados (evita depender do usuário abrir o DevTools
  // manualmente). page.on("console") do Puppeteer já captura mensagens de
  // QUALQUER frame da página, incluindo iframes cross-origin/OOPIF.
  winShim.webContents.on("console-message", (_e, _level, message) => {
    if (typeof message === "string" && message.includes("[pandora")) {
      try {
        getDiagFilePath();
        queueDiagLine(`[${new Date().toISOString()}] ${message}\r\n`);
      } catch {}
    }
  });
  // Badge de IP: busca uma vez (cacheado em winShim._proxyIp) e reaplica no
  // DOM a cada navegação (a página troca, o badge antigo some junto).
  winShim.webContents.on("did-finish-load", () => { showProxyIpOnRealChromeWindow(winShim).catch(() => {}); });
  showProxyIpOnRealChromeWindow(winShim).catch(() => {});
  try { attachBrowserToolbar(winShim); } catch (e) { console.warn("[realchrome] toolbar-injections falhou:", e?.message); }
  // Reativado 2026-08-19 (pedido do usuário: "kd o popup killer" — popup
  // novo em voy-exhaustpg.com não fechava porque isso aqui estava desligado
  // desde o teste A/B de 2026-08-09). O root cause daquele teste (fechador
  // genérico apagando a tela de Conta/Relatório/Saldo) já foi corrigido na
  // raiz em isSafeModal (autoLogin.cjs) há dias — nunca foi reativado depois.
  try { attachPopupCloser(winShim); } catch (e) { console.warn("[realchrome] popup-closer falhou:", e?.message); }
  try { attachPixModalEnhancer(winShim); } catch (e) { console.warn("[realchrome] pix-enhancer falhou:", e?.message); }
  try { attachGeetestSolver(winShim); } catch (e) { console.warn("[realchrome] geetest falhou:", e?.message); }
  if (conta) {
    try { attachContaAutoLogin(winShim); } catch (e) { console.warn("[realchrome] conta-auto-login falhou:", e?.message); }
  } else {
    try {
      attachAutoRegister(winShim, state.db, saveDB, state.dbPath);
      getDiagFilePath();
      queueDiagLine(`[${new Date().toISOString()}] [AUTO] attach OK (realchrome) url=${targetUrl}\r\n`);
    } catch (e) {
      console.warn("[realchrome] auto-register falhou:", e?.message);
      try { queueDiagLine(`[${new Date().toISOString()}] [AUTO] attach FALHOU (realchrome): ${e?.message}\r\n`); } catch {}
    }
  }
  // "Vigia de contas" (autoCaptura.cjs) — watcher PARALELO ao attachAutoRegister
  // acima, que lê o DOM/localStorage a cada ~1.5s (executeJavaScript puro, não
  // depende de console.log) e salva em contasStore.cjs (userData/contas.json)
  // — é ESSE arquivo que a aba Contas realmente lê (contas:listar), não a
  // tabela SQLite que attachAutoRegister grava. Existia só no caminho Electron
  // antigo (chromiumWindows.cjs); nunca tinha sido ligado no Chrome real, por
  // isso a aba Contas ficava sem receber as contas criadas mesmo com o
  // cadastro em si funcionando 100%. webContents do shim já implementa tudo
  // que esse módulo usa (executeJavaScript, did-finish-load, did-navigate-in-page),
  // então funciona sem nenhuma mudança em autoCaptura.cjs.
  try {
    const parar = iniciarAutoCaptura(winShim.webContents, targetUrl, state.mainWin, { chromeWin: winShim });
    winShim.on("closed", () => { try { parar && parar(); } catch {} });
  } catch (e) {
    console.warn("[realchrome] autoCaptura falhou:", e?.message);
  }
  return winShim;
}

// Só injeta/automatiza em páginas http(s) de verdade. Clicar no "+" abre a
// Nova Guia do Chrome primeiro (chrome://newtab/, uma página INTERNA) —
// comandos CDP tipo Page.addScriptToEvaluateOnNewDocument/Runtime.addBinding
// nela podem ser recusados pelo Chrome (páginas internas são privilegiadas/
// protegidas) e isso já foi visto derrubando a sessão CDP inteira, fechando
// a janela toda em vez de só a aba. Nunca vale a pena automatizar uma
// chrome://, about:, devtools:// etc. de qualquer forma.
function isAutomatableUrl(url) {
  return /^https?:\/\//i.test(url || "");
}

// No modo nativo (UI de verdade do Chrome), o usuário pode abrir uma aba
// nova clicando no "+" DE VERDADE do Chrome (ou Ctrl+T) sem passar por
// nenhum código nosso — o Chrome cria o target sozinho. Escuta
// "targetcreated" no browser pra "adotar" essas abas automaticamente:
// injeta stealth/popup-killer/humanClick nelas e registra em
// state.chromeWins, senão o resto do app (depósito, cadastro, etc.) nunca
// saberia que essa aba existe. Se a aba nascer numa página interna (Nova
// Guia), espera ela navegar pra algo http(s) antes de tocar nela.
function watchNativeTabs(browser, { mobileProfile, blankNewTabViaCdp }) {
  browser.on("targetcreated", async (target) => {
    try {
      if (target.type() !== "page") return;
      try { queueDiagLine(`[${new Date().toISOString()}] [tabs-debug] novo target tipo=page detectado, url inicial=${(() => { try { return target.url(); } catch { return "?"; } })()}\r\n`); } catch {}
      // "Bloquear 2ª guia" (func_bloquear_2guia, aba Início): alguns slots
      // abrem uma segunda guia (window.open/target=_blank) por cima do jogo
      // — normalmente propaganda ou um link externo. Se a opção estiver
      // marcada, fecha essa guia nova assim que ela aparece, antes até de
      // adotar/injetar qualquer coisa nela. Não mexe na guia original.
      if (getSettingSync("func_bloquear_2guia", "0") === "1") {
        try {
          const page = await target.page();
          if (page && !page.isClosed()) {
            await page.close().catch(() => {});
            console.log("[realchrome] 2ª guia bloqueada (func_bloquear_2guia ativo)");
          }
        } catch {}
        return;
      }
      const page = await target.page();
      if (!page || page.__pandoraWired) return;

      // Pedido do usuário 2026-08-10: sem a extensão de Nova Guia em branco
      // (só usada quando o zoom é forçado — ver comentário grande em
      // openOneRealChromeWindow), a Nova Guia nativa do "+"/Ctrl+T chegaria
      // com o conteúdo de verdade do Google (chrome://newtab/) — redireciona
      // pra about:blank via CDP direto, antes de qualquer coisa carregar.
      // Testado só sem zoom forçado (blankNewTabViaCdp só é true nesse caso)
      // — COM zoom forçado isso derruba o processo inteiro do Chrome (ver
      // comentário grande acima, por isso a extensão continua sendo usada
      // nesse caso, nunca isso aqui).
      if (blankNewTabViaCdp) {
        (async () => {
          // Checagem imediata (url ainda vazia na maioria das vezes) não
          // basta — a aba só passa a mostrar "chrome://newtab/" um instante
          // depois de criada. Poll curto (até 2s) só pra essa URL exata
          // (nunca "" nem "about:blank" — evita interferir com a aba
          // principal do boot, que usa esse mesmo evento no fallback raro
          // de browser.newPage()).
          for (let i = 0; i < 20; i++) {
            if (page.isClosed()) return;
            let u = "";
            try { u = page.url(); } catch {}
            if (u === "chrome://newtab/") {
              page.goto("about:blank").catch(() => {});
              return;
            }
            if (u && u !== "chrome://newtab/") return; // já navegou pra outra coisa, não é o caso
            await new Promise((r) => setTimeout(r, 100));
          }
        })();
      }

      const tryWire = async () => {
        if (page.__pandoraWired || page.isClosed()) return;
        const url = page.url();
        if (!isAutomatableUrl(url)) return; // ainda é chrome://newtab ou similar — espera navegar
        page.__pandoraWired = true;
        try {
          const cdp = await page.target().createCDPSession();
          await wireNewPage({ browser, page, cdp, targetUrl: url, mobileProfile, nativeChrome: true });
          console.log("[realchrome] aba nativa nova adotada:", url);
          try { queueDiagLine(`[${new Date().toISOString()}] [tabs-debug] ABA NATIVA NOVA ADOTADA como janela separada: ${url}\r\n`); } catch {}
        } catch (e) {
          page.__pandoraWired = false;
          console.warn("[realchrome] falha ao adotar aba nativa:", e?.message);
          try { queueDiagLine(`[${new Date().toISOString()}] [tabs-debug] falha ao adotar aba nativa: ${e?.message}\r\n`); } catch {}
        }
      };

      await tryWire();
      if (!page.__pandoraWired) {
        page.on("framenavigated", (frame) => {
          if (frame === page.mainFrame()) tryWire().catch(() => {});
        });
      }
    } catch (e) {
      console.warn("[realchrome] falha ao adotar aba nativa:", e?.message);
    }
  });
}

// Abre UMA janela de Chrome real: sessão isolada, proxy (se houver), stealth
// + popup-killer injetados, posicionada no grid, navegada pra `url`.
// `acc`/`conta`: rótulo pro título e, se `conta` vier (fluxo "Contas"), liga
// attachContaAutoLogin em vez de attachAutoRegister (login numa conta já
// existente, não cadastro de conta nova).
async function openOneRealChromeWindow({ index, url, bounds, proxy, execPath, acc, conta, scaleFactor, navigateDelayMs = 0, urlPromise = null, headless = false }) {
  // puppeteer-core é ESM-only — o Node embarcado no Electron (mais antigo que
  // o Node do sistema) não suporta require(esm), precisa de import() dinâmico.
  const { default: puppeteer } = await import("puppeteer-core");
  const uaPick = nextSessionUA();
  const userDataDir = makeUserDataDir(index);

  // Quando há delay configurado (TELAS), a janela abre IMEDIATAMENTE (não
  // atrasa o lançamento do processo — isso é o que faz abrir rápido) mas
  // começa numa tela local com nossa logo + nome do dispositivo, igual
  // sempre foi no caminho antigo (assets/splash.html) — só navega pra URL
  // de verdade depois do delay. Sem isso, com delay=0 (ou várias janelas já
  // apontando direto pra URL real desde o lançamento), todas atacavam o
  // site ao mesmo tempo (JS pesado, anti-bot) e a tela de cadastro demorava
  // muito mais pra aparecer/ficar utilizável.
  // urlPromise (modo Escadinha): mesma ideia da splash acima, mas em vez de
  // esperar um tempo FIXO, espera uma Promise externa resolver com a URL de
  // verdade — usado quando a URL da janela só existe depois que a janela
  // ANTERIOR terminar de cadastrar (não dá pra saber quanto tempo isso leva
  // de antemão, então não dá pra usar navigateDelayMs aqui).
  // SEMPRE abre na splash primeiro (nunca manda a URL real direto como
  // argumento de linha de comando do Chrome) — descoberto em 2026-08-07:
  // quando não havia delay (janela única/1ª de um lote), a URL ia direto no
  // args[0] do launch, e o Chrome começava a navegar pra ela IMEDIATAMENTE
  // ao subir o processo — vencendo a corrida contra o nosso código, que só
  // consegue registrar os scripts injetados (stealth, popup-killer,
  // speedhack, canvas-click, api-inspect) via evaluateOnNewDocument DEPOIS
  // de conectar por CDP. Resultado: o primeiro carregamento saía sem
  // NENHUM desses hooks aplicados. Forçar splash sempre garante que a
  // navegação real só acontece via page.goto() no nosso código, depois que
  // wireNewPage já registrou tudo — sem raça possível.
  const splashPath = path.join(ROOT_DIR, "assets", "splash.html");
  const deviceName = (uaPick && uaPick.profile && uaPick.profile.name) || "";
  const useSplash = fs.existsSync(splashPath);
  const startUrl = useSplash
    ? "file:///" + splashPath.replace(/\\/g, "/") + (deviceName ? ("?device=" + encodeURIComponent(deviceName)) : "")
    : url;

  // Os flags de linha de comando --window-size/--window-position do Chromium
  // usam pixels FÍSICOS no Windows, enquanto o resto do app (Electron screen,
  // CDP Browser.setWindowBounds) trabalha em pixels LÓGICOS/DIP. Em monitor
  // com escala != 100% (muito comum — 125%, 150%...) isso fazia a janela
  // abrir com o tamanho errado, ignorando a grade configurada em TELAS.
  // Multiplica pelo scaleFactor só nos flags de launch; o ajuste fino depois
  // via CDP (mais abaixo) já usa os valores lógicos corretos.
  const sf = Number(scaleFactor) || 1;
  const physSize = { w: Math.round(bounds.width * sf), h: Math.round(bounds.height * sf) };
  const physPos = { x: Math.round(bounds.x * sf), y: Math.round(bounds.y * sf) };

  // Se o tamanho físico pedido for menor que o mínimo que a toolbar do
  // Chrome aceita, força um device-scale-factor MENOR que 1 — ver o
  // comentário grande em cima de MIN_NATIVE_CHROME_WIDTH pra entender a
  // conta. --window-size continua sendo o físico de sempre (o tamanho na
  // tela é exatamente o configurado em TELAS); só isso muda quanto o Chrome
  // "acha" que tem de espaço em DIP pra decidir se cabe a toolbar.
  let chromeDsf = sf;
  let forcedDsf = false;
  if (physSize.w < MIN_NATIVE_CHROME_WIDTH) {
    chromeDsf = Math.max(0.3, physSize.w / MIN_NATIVE_CHROME_WIDTH);
    forcedDsf = true;
  }
  // Bounds que o CDP (Browser.setWindowBounds/getWindowForTarget) enxerga —
  // TANTO tamanho quanto posição operam no espaço "DIP" do device-scale-
  // factor ATIVO no Chrome (testado e MEDIDO com Win32 GetWindowRect: com
  // DSF forçado, se a posição fosse passada sem dividir pelo DSF, a janela
  // abre deslocada — ex.: pedindo x=454 ela abre fisicamente em ~300 — por
  // isso left/top também precisam ser convertidos aqui, igual width/height).
  const cdpDipSize = { w: Math.round(physSize.w / chromeDsf), h: Math.round(physSize.h / chromeDsf) };
  const cdpDipPos = { x: Math.round(physPos.x / chromeDsf), y: Math.round(physPos.y / chromeDsf) };

  const args = [
    startUrl,
    `--window-size=${physSize.w},${physSize.h}`,
    `--window-position=${physPos.x},${physPos.y}`,
    ...(forcedDsf ? [`--force-device-scale-factor=${chromeDsf}`] : []),
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-blink-features=AutomationControlled",
    `--user-agent=${uaPick.ua}`,
    // Flags que só desligam coisas de background que o Chrome faz sozinho e
    // que a automação não usa (sync de conta Google, verificação de
    // atualização de componentes, telemetria, monitor de "não respondendo",
    // phishing/malware check client-side, pings de navegação, som). Nenhuma
    // muda comportamento visível da automação — só tira trabalho de fundo
    // que soma bastante CPU/rede quando várias janelas estão abertas.
    "--disable-background-networking",
    // BUG GRAVE real 2026-08-09 (semanas investigando "Relatório de
    // Apostas" sempre em branco/aba errada) — causa raiz de verdade: o
    // usuário testou com o DevTools aberto e funcionou perfeitamente todas
    // as vezes; sem DevTools, sempre bugava. DevTools aberto tira a janela
    // do modo "em segundo plano" que o Chrome aplica sozinho a abas/janelas
    // sem foco/ocultas (throttling de timers, JS mais lento, requisições
    // atrasadas) — com várias janelas do bot abertas ao mesmo tempo, só UMA
    // fica em foco por vez, então as outras rodam em segundo plano o tempo
    // todo. Se a tela do Relatório depende de uma resposta de API chegar
    // dentro de um prazo curto antes de cair num estado de "fallback"
    // (Recuperar saldo perdido / tela vazia), rodar em segundo plano
    // atrasado é o suficiente pra sempre perder esse prazo. Faltavam essas
    // 3 flags — Puppeteer não as liga por padrão:
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-renderer-backgrounding",
    "--disable-sync",
    "--disable-component-update",
    "--disable-domain-reliability",
    "--disable-hang-monitor",
    "--disable-prompt-on-repost",
    "--disable-client-side-phishing-detection",
    "--disable-default-apps",
    "--no-pings",
    "--password-store=basic",
    "--metrics-recording-only",
    "--mute-audio",
    // Faz o Blink registrar os listeners de touch desde o BOOT do documento
    // — sem isso, motores de jogo (Cocos2d/PixiJS) podem decidir por mouse
    // no init() e nunca mais considerar touch depois, mesmo que os eventos
    // (via Emulation.setEmitTouchEventsForMouse) cheguem corretos depois.
    // Só em janelas com perfil mobile — não afeta o resto.
    ...(uaPick.profile ? ["--touch-events=enabled"] : []),
  ];

  // A Nova Guia padrão do Chrome (chrome://new-tab-page/, o que abre ao
  // clicar no "+" ou Ctrl+T) DERRUBA O PROCESSO INTEIRO do Chrome quando
  // --force-device-scale-factor está ativo — testado e confirmado: crasha
  // mesmo tentando redirecionar instantaneamente via CDP (inclusive com
  // Target.setAutoAttach waitForDebuggerOnStart, o crash acontece ANTES da
  // sessão CDP conseguir atacar o novo target). Outras páginas internas
  // (chrome://settings/, chrome://version/) não têm esse problema — é
  // específico do conteúdo da NTP (provavelmente o doodle/OneGoogleBar/
  // WebGL dela) com um device-scale-factor forçado. A única forma robusta
  // de evitar é nunca deixar o Chrome navegar pra lá: uma extensão mínima
  // (chrome_url_overrides.newtab) troca a Nova Guia por uma página em
  // branco ANTES de qualquer coisa carregar — mecanismo padrão do Chrome,
  // sem CDP/timing envolvido, funciona sempre (mesmo sem DSF forçado, então
  // aplica pra toda janela, não só as pequenas).
  // Extensões carregadas no Chrome real via flag de linha de comando — não
  // existe "session.loadExtension" fora do Electron. As duas (ntp-override
  // interna + a extensão customizada importada pelo usuário em Operação →
  // Extensão) precisam ir JUNTAS na mesma flag: o Chrome só respeita a
  // ÚLTIMA ocorrência de --disable-extensions-except, então duas chamadas
  // separadas faziam a segunda desabilitar a primeira (era por isso que a
  // extensão customizada nunca carregava no fluxo de Chrome real — o código
  // antigo (ses.loadExtension) só existe no fluxo Electron, nunca chamado
  // aqui).
  // Pedido do usuário 2026-08-10: a extensão de Nova Guia em branco dispara
  // o aviso nativo do Chrome "Voltar a usar o Google?" (extensão mudou uma
  // configuração protegida) — como cada janela usa um profile novo/vazio
  // (makeUserDataDir), o Chrome nunca "lembra" que o usuário já aceitou, e o
  // aviso volta em TODO clique no "+". Tentativa de pré-preencher o
  // Preferences do profile pra fingir "já aceito" foi descartada: essas
  // configurações são protegidas por um selo anti-adulteração (MAC) que o
  // Chrome verifica — escrever isso à mão não sobrevive, o Chrome ignora.
  // Única forma sem esse aviso é NUNCA deixar uma extensão mexer nessa
  // configuração — redirecionar a Nova Guia via CDP direto (sem extensão)
  // antes dela renderizar. Só que isso é o que CRASHAVA o Chrome inteiro
  // quando o zoom é forçado (--force-device-scale-factor, ver comentário
  // grande abaixo) — por isso só faz isso quando NÃO há zoom forçado nessa
  // janela; com zoom forçado, mantém a extensão (aceita o aviso, mas nunca
  // crasha).
  const useCdpBlankNewTab = !forcedDsf;
  const extensionDirs = [];
  const ntpOverrideDir = path.join(ROOT_DIR, "assets", "ntp-override");
  if (!useCdpBlankNewTab && fs.existsSync(path.join(ntpOverrideDir, "manifest.json"))) extensionDirs.push(ntpOverrideDir);
  if (getSettingSync("op_extensao_ativa", "0") === "1") {
    const customExtDir = getSettingSync("op_custom_extension_path", "");
    if (customExtDir && fs.existsSync(path.join(customExtDir, "manifest.json"))) extensionDirs.push(customExtDir);
  }
  if (extensionDirs.length) {
    args.push(`--load-extension=${extensionDirs.join(",")}`, `--disable-extensions-except=${extensionDirs.join(",")}`);
  }

  let proxyBridge = null;
  if (proxy) {
    proxyBridge = await resolveProxyBridge(proxy);
    if (proxyBridge) args.push(`--proxy-server=${proxyBridge.localUrl}`);
  }

  // Headless de verdade (2026-08-08, pedido explícito do usuário mesmo
  // ciente do risco) — puppeteer-core v25 usa boolean puro (headless:true JÁ
  // é o "novo" headless, --headless=old nem existe mais nessa versão).
  // window-size/window-position continuam nos args por segurança (viewport
  // headless usa window-size; window-position é ignorado sem OS window, sem
  // problema). --load-extension (captcha/NTP-override) funciona no headless
  // novo — não funcionava no headless clássico antigo.
  const browser = await puppeteer.launch({
    executablePath: execPath,
    headless: !!headless,
    defaultViewport: null,
    userDataDir,
    args,
    // pipe:false (porta TCP local) — pedido do usuário 2026-08-09: vários
    // comandos CDP diferentes (Runtime.evaluate do api-inspect, exposeFunction
    // do nav-signal, ocasionalmente touch/speedhack) travavam pra sempre sem
    // nunca responder nem dar erro, mesmo em janelas completamente separadas
    // — sintoma de problema na própria conexão CDP via pipe:true, não em um
    // comando isolado. Já tem timeout de 8-35s em cada chamada individual
    // (várias, ver comentários espalhados) que evita a janela travar pra
    // sempre, mas isso só disfarça o sintoma (a navegação real nunca
    // acontecia porque o código nunca chegava lá) — TCP é o transporte CDP
    // "padrão" do Puppeteer/Chrome, mais testado. Custo: pode voltar a
    // aparecer 1x o prompt do Firewall do Windows "permitir acesso" (motivo
    // original do pipe:true), mas um app funcionando com 1 prompt é melhor
    // que travado sempre.
    pipe: false,
    // CORREÇÃO ESTRUTURAL 2026-08-09 (substitui a estratégia de "caçar
    // travamento ponto por ponto" — cada Promise.race manual cobria só UM
    // comando específico; sempre sobrava outro em algum lugar não coberto,
    // daí "carregando infinito"/"Stop não fecha" continuar acontecendo depois
    // de várias rodadas de guarda individual). protocolTimeout é NATIVO do
    // Puppeteer: aplica um timeout em TODO E QUALQUER comando CDP enviado
    // pela lib inteira (session.send de qualquer sessão, presente E futura),
    // sem precisar açoitar cada await manualmente. Se o Chrome não responder
    // em 15s pra QUALQUER comando, a promise REJEITA (em vez de ficar
    // pendurada pra sempre) — os try/catch que já existem espalhados pelo
    // código (wireNewPage, doRealNavigate, close(), etc.) já sabem lidar com
    // isso normalmente. Default do Puppeteer é 180000ms (3min) — tempo
    // demais pra um app interativo onde o usuário decide na hora se algo
    // travou.
    protocolTimeout: 15000,
  });
  // Capturado AQUI, logo após o launch (momento mais confiável) — usado só
  // como fallback de force-kill no close() (ver webContentsShim.cjs), pra
  // não depender de browser.process() ainda estar íntegro na hora de fechar
  // (bug real 2026-08-09: janela continuava na tela mesmo depois do close()
  // "ter rodado", suspeita de handle de processo ficando obsoleto com
  // pipe:true — ver comentário grande no close()).
  const chromePid = browser.process()?.pid || null;
  watchNativeTabs(browser, { mobileProfile: uaPick.profile, blankNewTabViaCdp: useCdpBlankNewTab });
  const page = (await browser.pages())[0] || (await browser.newPage());
  page.__pandoraWired = true; // essa aba já vai ser fiada abaixo — não deixa watchNativeTabs duplicar
  const cdp = await page.target().createCDPSession();

  // TESTE 2026-08-09 (pedido do usuário: "abre pequeno e depois expande pra
  // o tamanho configurado, dá pra já abrir no tamanho certo?"): minimiza a
  // janela JÁ, antes de qualquer coisa renderizar visível na tela — o loop
  // de correção de bounds abaixo termina com windowState:"normal" + os
  // bounds certos, que "des-minimiza" a janela só quando ela já está no
  // tamanho/posição configurados. Sem isso, a janela abre visível no
  // tamanho padrão do Chrome por um instante antes da correção via CDP
  // chegar — esse é o "pisca" que o usuário via.
  try {
    const { windowId: earlyWindowId } = await cdpSendGuarded(cdp, "Browser.getWindowForTarget");
    await cdpSendGuarded(cdp, "Browser.setWindowBounds", { windowId: earlyWindowId, bounds: { windowState: "minimized" } });
  } catch (e) {
    try { queueDiagLine(`[${new Date().toISOString()}] [cdp-bounds] #${index + 1} minimizar cedo falhou (segue sem isso): ${e?.message}\r\n`); } catch {}
  }

  // NÃO usar Emulation.setTouchEmulationEnabled/setEmitTouchEventsForMouse
  // aqui — testado e confirmado que quebra viewport/layout dos jogos de
  // slot (Emulation.setTouchEmulationEnabled força um modo de emulação de
  // dispositivo completo no Chrome, que mexe em como a página calcula
  // layout, não só em que tipo de evento é disparado). O touch é feito só
  // por spoof em JS (stealth.cjs) + disparo manual de touch no canvas
  // (ver __CANVAS_CLICK_SCRIPT/simularCliqueNoCanvas em browserInjections.cjs)
  // — nada em nível de CDP/Emulation.

  // BUG real 2026-08-09 (reportado pelo usuário: "abro 10 telas, 8-9 ficam
  // do tamanho configurado, 1-2 ficam pequenas/padrão") — antes, se
  // QUALQUER uma das chamadas CDP abaixo travasse (o mesmo tipo de
  // instabilidade intermitente já visto várias vezes nessa investigação —
  // mais provável com várias janelas abrindo quase juntas, cada uma
  // disputando a própria conexão CDP), o try/catch desistia na hora e a
  // janela ficava pro resto da vida no tamanho padrão do Chrome — só UMA
  // tentativa de verdade, sem nenhum retry em cima de uma FALHA (só havia
  // retry se o tamanho não batesse, não se a chamada tivesse travado).
  // Agora tenta o bloco inteiro até 3 vezes, com uma pequena pausa entre
  // tentativas — cobre tanto travamento pontual quanto tamanho não bater.
  const MAX_BOUNDS_ATTEMPTS = 3;
  for (let attempt = 1; attempt <= MAX_BOUNDS_ATTEMPTS; attempt++) {
    try {
      const { windowId, bounds: initialBounds } = await cdpSendGuarded(cdp, "Browser.getWindowForTarget");
      console.log(`[realchrome] #${index + 1} bounds ao abrir (tentativa ${attempt}):`, JSON.stringify(initialBounds), "| pedido:", JSON.stringify(bounds));
      // Pegadinha do CDP: se a janela abre maximizada/minimizada (windowState
      // != "normal"), setWindowBounds com só width/height é IGNORADO em
      // silêncio — o Chrome não redimensiona janela maximizada por width/height
      // direto. Precisa forçar "normal" numa chamada separada primeiro.
      if (initialBounds && initialBounds.windowState && initialBounds.windowState !== "normal") {
        console.warn(`[realchrome] #${index + 1} abriu com windowState="${initialBounds.windowState}" — forçando normal antes de redimensionar`);
        await cdpSendGuarded(cdp, "Browser.setWindowBounds", { windowId, bounds: { windowState: "normal" } });
      }
      await cdpSendGuarded(cdp, "Browser.setWindowBounds", { windowId, bounds: { left: cdpDipPos.x, top: cdpDipPos.y, width: cdpDipSize.w, height: cdpDipSize.h, windowState: "normal" } });
      // Confere se pegou.
      const { bounds: afterBounds } = await cdpSendGuarded(cdp, "Browser.getWindowForTarget");
      if (afterBounds.width === cdpDipSize.w && afterBounds.height === cdpDipSize.h) {
        if (attempt > 1) console.log(`[realchrome] #${index + 1} bounds OK na tentativa ${attempt}`);
        break; // sucesso — sai do loop de retry
      }
      console.warn(`[realchrome] #${index + 1} bounds não bateram na tentativa ${attempt} (${JSON.stringify(afterBounds)})`);
      if (attempt < MAX_BOUNDS_ATTEMPTS) await new Promise((r) => setTimeout(r, 250));
    } catch (e) {
      console.warn(`[realchrome] #${index + 1} setWindowBounds falhou na tentativa ${attempt}:`, e?.message);
      try { queueDiagLine(`[${new Date().toISOString()}] [cdp-bounds] #${index + 1} tentativa ${attempt} falhou/travou: ${e?.message}\r\n`); } catch {}
      if (attempt < MAX_BOUNDS_ATTEMPTS) await new Promise((r) => setTimeout(r, 250));
      else { try { queueDiagLine(`[${new Date().toISOString()}] [cdp-bounds] #${index + 1} desistiu após ${MAX_BOUNDS_ATTEMPTS} tentativas — seguindo sem travar a janela\r\n`); } catch {} }
    }
  }

  // Shim: faz essa Page parecer uma BrowserWindow/webContents do Electron pra
  // reaproveitar auto-cadastro, GeeTest solver, fechador de popup e PIX sem
  // reescrever essa lógica (ver webContentsShim.cjs, wireNewPage). Entra no
  // MESMO state.chromeWins que as janelas Electron — todo o resto do app
  // (navegação, depósito, saque, PIX, grid, mirror mode) trata igual, sem
  // saber a diferença.
  const winShim = await wireNewPage({ browser, page, cdp, targetUrl: url, mobileProfile: uaPick.profile, nativeChrome: true, conta, acc, chromePid });
  winShim._pandoraOrder = index + 1;
  // Pedido do usuário 2026-08-09 (foto real: QR de uma janela menor que o
  // de outra) — guarda o tamanho/posição CONFIGURADOS (grid de Telas) pra
  // qualquer código externo (ex.: qrCapture.cjs, bem antes do depósito
  // aparecer) poder reforçar o tamanho sob demanda via reapplyWindowBounds,
  // sem precisar recalcular nada. O tamanho renderizado do QR pelo PRÓPRIO
  // site depende do viewport no momento em que a tela de depósito carrega
  // — se a janela ainda não tiver assentado no tamanho certo bem nessa
  // hora (mesmo já corrigido antes/depois da navegação inicial), o site
  // desenha um QR menor (layout responsivo dele, fora do nosso controle
  // direto — só dá pra garantir que a JANELA esteja no tamanho certo).
  winShim._configuredBounds = { pos: cdpDipPos, size: cdpDipSize };
  // Guardado pra fluxos como o saque (saqueFlowV2.cjs) saberem se essa
  // janela roda em Operação Oculta — o clique final em "Confirmar
  // saque/Retirada" só é automático nesse modo; com janela visível o
  // usuário confirma manualmente (pedido do usuário 2026-08-08).
  winShim._headless = !!headless;
  winShim._userDataDir = userDataDir;
  winShim._proxyToggle = proxyBridge && proxyBridge.toggle ? proxyBridge.toggle : null;
  winShim.on("closed", () => {
    // Async (não rmSync) — o profile do Chrome (cache, cookies, IndexedDB)
    // pode ter milhares de arquivos pequenos; apagar de forma SÍNCRONA
    // travava a thread principal a cada janela fechada, e "Fechar todas"
    // com várias janelas de uma vez empilhava essas travadas em sequência.
    try { fs.rm(userDataDir, { recursive: true, force: true }, () => {}); } catch {}
    try { winShim._proxyToggle && winShim._proxyToggle.close(); } catch {}
  });

  // Ícone/numeração nativos (Win32) — chamadas EnumWindows/GetWindowRect são
  // SÍNCRONAS (bloqueiam a thread principal do Electron enquanto rodam, não
  // são I/O de verdade). Chamar isso ANTES do page.goto — bem na hora em que
  // várias janelas abrem em paralelo — empilhava várias varreduras de TODAS
  // as janelas do sistema exatamente durante a navegação/detecção do modal
  // de cadastro, deixando tudo lento e o modal demorando pra aparecer. Agora
  // roda só DEPOIS do goto (a página já carregando/carregada não depende
  // disso) e com um atraso escalonado por janela, pra nunca ter duas
  // varreduras concorrentes ao mesmo tempo.
  const nativeIdentityDelay = 1500 + (index % 8) * 350;
  setTimeout(() => {
    if (winShim.isDestroyed()) return;
    applyNativeIdentity(browser.process().pid, winShim._pandoraOrder || index + 1)
      .then((stop) => { winShim.on("closed", stop); })
      .catch(() => {});
  }, nativeIdentityDelay);

  if (useSplash) {
    // Já está na splash (mostrando logo + dispositivo) desde o lançamento.
    const doRealNavigate = async () => {
      let targetUrl = url;
      if (urlPromise) {
        // Escadinha: espera a URL de verdade (com "?id=" da conta anterior)
        // ser liberada — não tem como saber quanto tempo isso leva de
        // antemão, então não dá pra usar um setTimeout de duração fixa.
        try { targetUrl = await urlPromise; } catch { targetUrl = url; }
      }
      if (winShim.isDestroyed()) return;
      // Retry — com a splash sempre ligada (ver comentário em useSplash), a
      // navegação real virou uma chamada explícita nossa (page.goto) em vez
      // de ir direto no launch do Chrome; se a bridge de proxy ainda não
      // tiver assentado nesse instante (ou DNS/rede tiver um soluço), sem
      // retry a janela ficava presa na tela de erro nativa do Chrome ("não
      // é possível acessar esse site") pro resto da sessão.
      //
      // Bug real 2026-08-09 (reportado pelo usuário): com só 3 tentativas
      // rápidas (~3.6s no total) e o erro indo só pro console.warn (nunca
      // pro Log de Operações nem pro diag), uma falha de rede/proxy um
      // pouco mais teimosa deixava a janela PRESA NA SPLASH PRA SEMPRE, sem
      // nenhuma pista visível pro usuário do que aconteceu — parecia só
      // "não carrega". Agora: 10 tentativas espalhadas por até ~60s (mesma
      // janela usada pro Auto Slot carregar, ver slotHandler.cjs) e cada
      // falha (a cada 3ª tentativa, pra não floodar) e a falha final vão
      // pro Log de Operações via logSystem, visível na hora.
      const tela = winShim._pandoraOrder || index + 1;
      const MAX_ATTEMPTS = 10;
      for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
        if (winShim.isDestroyed()) return;
        try {
          // Corrida contra um timeout PRÓPRIO (35s, um pouco acima do
          // `timeout: 30000` do Puppeteer) — bug real 2026-08-09: se a
          // conexão CDP dessa página estiver realmente quebrada (não só
          // lenta), o timeout INTERNO do page.goto também depende dessa
          // mesma conexão pra funcionar direito em alguns casos, e podia
          // nunca disparar, prendendo esse await pra sempre mesmo com
          // timeout configurado. Esse timeout aqui é 100% local (setTimeout
          // puro, não depende de CDP nenhum) — sempre dispara.
          await Promise.race([
            page.goto(targetUrl, { waitUntil: "domcontentloaded", timeout: 30000 }),
            new Promise((_, rej) => setTimeout(() => rej(new Error("goto travou (timeout local 35s, sem resposta nenhuma do Chrome)")), 35000)),
          ]);
          // BUG real 2026-08-09 (reportado pelo usuário: "abro 10 telas, 1-2
          // ficam pequenas/padrão" — mesmo depois do retry na hora de abrir
          // ter reportado sucesso) — o tamanho é fixado ANTES da navegação
          // real acontecer (janela ainda na splash local). Suspeita: o site
          // de verdade, já carregado, pode disparar algum resize próprio
          // (ex.: `window.resizeTo`/mudança de layout) que desfaz o que a
          // gente setou, sem gerar nenhum erro do nosso lado — por isso o
          // retry de abertura nunca via falha. Reconfere/reaplica o tamanho
          // de novo aqui, depois que o site real já carregou (dá 1.5s pra
          // qualquer resize da PÁGINA acontecer primeiro) — best-effort, não
          // trava a navegação se isso falhar.
          setTimeout(async () => {
            try {
              if (winShim.isDestroyed()) return;
              const { windowId, bounds: curBounds } = await cdpSendGuarded(cdp, "Browser.getWindowForTarget");
              if (curBounds.width !== cdpDipSize.w || curBounds.height !== cdpDipSize.h) {
                queueDiagLine(`[${new Date().toISOString()}] [cdp-bounds] Tela ${tela} tamanho mudou sozinho após navegar (${JSON.stringify(curBounds)}) — reaplicando\r\n`);
                await cdpSendGuarded(cdp, "Browser.setWindowBounds", { windowId, bounds: { windowState: "normal" } });
                await cdpSendGuarded(cdp, "Browser.setWindowBounds", { windowId, bounds: { left: cdpDipPos.x, top: cdpDipPos.y, width: cdpDipSize.w, height: cdpDipSize.h, windowState: "normal" } });
              }
            } catch (e) {
              try { queueDiagLine(`[${new Date().toISOString()}] [cdp-bounds] Tela ${tela} reconferência pós-navegação falhou: ${e?.message}\r\n`); } catch {}
            }
          }, 1500);
          return;
        } catch (e) {
          console.warn(`[realchrome] #${index + 1} falha ao navegar pra ${targetUrl} (tentativa ${attempt}/${MAX_ATTEMPTS}):`, e?.message);
          try { queueDiagLine(`[${new Date().toISOString()}] [nav] Tela ${tela} falha ao navegar pra ${targetUrl} (tentativa ${attempt}/${MAX_ATTEMPTS}): ${e?.message}\r\n`); } catch {}
          if (attempt === 3 || attempt === 6) {
            try { logSystem(`Tela ${tela} — ainda não conseguiu carregar o site (tentativa ${attempt}/${MAX_ATTEMPTS}) — ${e?.message || "erro de rede/proxy"}`, { kind: "nav-retry", tela, attempt }, "warning", "operacao"); } catch {}
          }
          if (attempt < MAX_ATTEMPTS) await new Promise((r) => setTimeout(r, Math.min(6000, 1200 * attempt)));
        }
      }
      try { logSystem(`Tela ${tela} — não foi possível carregar o site após ${MAX_ATTEMPTS} tentativas (rede/proxy indisponível). Verifique a proxy ou tente Sacar/Play de novo.`, { kind: "nav-falhou", tela }, "error", "operacao"); } catch {}
    };
    if (urlPromise) {
      // Espera de verdade aqui — quem chamou precisa saber o instante em
      // que a navegação real começou (pra medir a criação da conta DESSA
      // janela a partir daí, não antes).
      await doRealNavigate();
    } else {
      // Delay fixo (staggering normal): não bloqueia o retorno, a janela
      // abrir/ficar pronta não espera esse tempo.
      setTimeout(doRealNavigate, navigateDelayMs);
    }
  } else {
    try {
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: 30000 });
    } catch (e) {
      console.warn(`[realchrome] #${index + 1} falha ao navegar pra ${url}:`, e?.message);
    }
  }

  return winShim;
}

// (Linhas/colunas/posições das 3 funções abaixo são SEMPRE as configuradas
// em TELAS, sem nenhum ajuste automático — a largura mínima da toolbar é
// resolvida por-janela via --force-device-scale-factor em
// openOneRealChromeWindow, não mexendo na forma da grade.)

// Expõe window.__pandoraNavSignal(cmd) na página — canal DIRETO pros botões
// da toolbar (voltar/avançar/atualizar/nova guia), sem depender de
// console.log/document.title da página. Muitos sites de produção desativam
// console.log (ou têm CSP/proxies que atrapalham), o que quebrava o único
// canal que existia antes (dispatch via console-message/page-title-updated).
// page.exposeFunction usa Runtime.addBinding via CDP — não passa pelo
// console da página, então nada nela consegue interferir.
async function exposeNavSignal(page, winShim) {
  try {
    await page.exposeFunction("__pandoraNavSignal", (cmd) => {
      try { runToolbarNavCommand(winShim, cmd); } catch (e) { console.warn("[realchrome] nav-signal falhou:", e?.message); }
    });
  } catch (e) {
    console.warn("[realchrome] exposeNavSignal falhou:", e?.message);
  }
}

function closeRealChromiumWindows() {
  for (const w of state.chromeWins) {
    if (w && w._realChrome) { try { w.close(); } catch {} }
  }
}

// ---- As 3 entradas espelhando openChromiumWindows/openChromiumMulti/openChromiumForContas ----

// Piso mínimo de escalonamento — aplicado SEMPRE, mesmo com delay=0
// configurado em TELAS. Sem isso, abrir várias janelas de uma vez fazia
// todos os processos chrome.exe nascerem exatamente no mesmo instante
// (contenção de CPU no boot de cada um) E todas navegarem pra URL real ao
// mesmo tempo (contenção no site/anti-bot), deixando a tela de cadastro
// bem mais lenta pra aparecer e responder (inclusive o clique em
// "Registro" demorando). O piso é bem menor que qualquer delay manual
// configurado — o usuário não percebe diferença perceptível no tempo total
// pra abrir tudo, mas evita esse pico de concorrência.
const MIN_LAUNCH_STAGGER_MS = 180;
const MIN_NAV_STAGGER_MS = 500;

// ID (UUID interno da linha) da conta mais recente salva em contas.json —
// usado como "marca d'água" antes de abrir uma janela em modo Escadinha.
// IMPORTANTE: existem DOIS lugares onde uma conta criada pode ser
// registrada — a tabela SQLite `accounts` (attachAutoRegister) e o arquivo
// contas.json via contasStore.cjs (autoCaptura.cjs, o "vigia de contas").
// É o contas.json que é confiável/sempre populado (é o que a aba Contas
// realmente mostra) — a tabela SQLite pode nunca receber o conta_id em
// alguns sites (o scan de fetch/XHR do __CONTA_ID_SCRIPT não pega tudo),
// e foi exatamente isso que travava a Escadinha na 2ª janela: esperava pra
// sempre um ID que nunca chegava na tabela errada.
async function getLatestContaRowId() {
  try {
    const lista = await listarContas();
    return lista[0]?.id || null;
  } catch { return null; }
}

// Espera uma conta NOVA aparecer no topo de contas.json (id de linha
// diferente do "beforeRowId") com conta_id (ID de indicação) já preenchido.
// SEM timeout/desistência — na Escadinha é terminantemente proibido a
// próxima janela cair no link original, então aqui só existem dois finais
// possíveis: capturou o ID (resolve com ele) ou a janela foi
// fechada/destruída (resolve null — só nesse caso o chamador para a
// cadeia, nunca usando o link original). Poll rápido (300ms) pra pegar o
// ID o quanto antes assim que a conta é criada.
function waitForNewContaId(beforeRowId, winShim) {
  return new Promise((resolve) => {
    let ticks = 0;
    const tick = async () => {
      if (winShim && winShim.isDestroyed()) { resolve(null); return; }
      try {
        const lista = await listarContas();
        const top = lista[0];
        if (top && top.id !== beforeRowId && top.conta_id) {
          resolve(String(top.conta_id));
          return;
        }
      } catch {}
      ticks++;
      if (ticks % 200 === 0) { // ~1 min sem resposta — só um aviso no log, continua esperando
        console.warn(`[realchrome-escadinha] ainda esperando o ID de indicação há ~${Math.round(ticks * 0.3)}s — continua tentando (proibido usar link original)`);
      }
      setTimeout(tick, 300);
    };
    tick();
  });
}

// Abre TODAS as `count` janelas imediatamente/em paralelo (processo abre
// rápido, mostrando a splash com logo + dispositivo — igual ao caminho
// normal), mas cada uma só NAVEGA pra URL de verdade depois que a ANTERIOR
// tiver cadastrado a conta e o ID de indicação dela ter sido capturado —
// a partir da 2ª, a URL usada é a mesma origem com "?id=<ID da conta
// anterior>". Cada janela recebe uma Promise (urlPromise) que só é
// resolvida quando chega sua vez; até lá, ela fica parada na splash, igual
// as outras — nunca fica uma janela "invisível" esperando pra abrir.
async function openRealChromiumWindowsEscadinha(url, count, execPath, area, scaleFactor, gridCols, gridRows, gap, customBounds, proxies) {
  let origin = "";
  try { origin = new URL(url).origin; } catch { origin = url; }

  const resolvers = [];
  const urlPromises = [];
  for (let i = 0; i < count; i++) {
    let resolve;
    urlPromises.push(new Promise((res) => { resolve = res; }));
    resolvers.push(resolve);
  }
  resolvers[0](url); // a 1ª não espera nada — navega assim que a janela abrir

  let opened = 0;
  const tasks = [];
  for (let i = 0; i < count; i++) {
    const bounds = customBounds?.[i] || gridWindowBounds(area, gridCols, gridRows, i, gap);
    const proxy = proxies.length ? proxies[i % proxies.length] : null;
    tasks.push((async () => {
      const launchDelay = i * MIN_LAUNCH_STAGGER_MS;
      if (launchDelay > 0) await new Promise((r) => setTimeout(r, launchDelay));
      const winShim = await openOneRealChromeWindow({ index: i, url, bounds, proxy, execPath, acc: null, scaleFactor, urlPromise: urlPromises[i] });
      opened++;
      console.log(`[realchrome-escadinha] janela #${i + 1}/${count} navegou de verdade`);
      if (i < count - 1) {
        // Marca d'água DEPOIS que essa janela navegou de verdade — não
        // antes (todas abrem/começam sua task quase juntas; capturar isso
        // cedo demais faria a janela #2 "roubar" o ID da conta da #1).
        const beforeRowId = await getLatestContaRowId();
        console.log(`[realchrome-escadinha] aguardando ID de indicação da janela #${i + 1} antes de liberar a #${i + 2}...`);
        // SEM timeout/fallback: é proibido a próxima janela usar o link
        // original. Só dois finais: captura o ID (por mais que demore) ou a
        // janela #${i+1} foi fechada/destruída — nesse caso a cadeia para
        // aqui (a #${i+2} fica esperando pra sempre, sem nunca "vazar" pro
        // link original).
        const contaId = await waitForNewContaId(beforeRowId, winShim);
        if (contaId) {
          const nextUrl = `${origin}/?id=${contaId}`;
          console.log(`[realchrome-escadinha] liberando janela #${i + 2} com: ${nextUrl}`);
          resolvers[i + 1](nextUrl);
        } else {
          console.error(`[realchrome-escadinha] janela #${i + 1} foi fechada antes de capturar o ID de indicação — cadeia parada (janela #${i + 2} NÃO vai navegar, pra não usar o link original)`);
        }
      }
    })().catch((e) => {
      console.error(`[realchrome-escadinha] falha na janela #${i + 1}:`, e?.message, "— cadeia parada (não usa o link original)");
    }));
  }
  await Promise.all(tasks);
  return opened;
}

async function openRealChromiumWindows(url, count = 1, accounts = [], delaySec = 0, headless = false) {
  if (!url) return 0;
  const execPath = await ensureChromeBinary();
  const target = getTargetDisplay();
  const area = target.workArea;
  const scaleFactor = target.scaleFactor || 1;
  const gridRows = Math.max(1, parseInt(getSettingSync("grid_rows", "2"), 10) || 2);
  const gridCols = Math.max(1, parseInt(getSettingSync("grid_cols", "5"), 10) || 5);
  const reduzir = getSettingSync("reduzir_janelas", "0") === "1";
  const gap = reduzir ? -7 : 5;
  const openCount = Math.min(count, gridRows * gridCols);
  const customBounds = reduzir ? null : getCustomWindowBounds(area, openCount);
  const proxies = getActiveProxiesSync();
  const delayMs = Math.max(0, Math.round(Number(delaySec) || 0) * 1000);

  // "Escadinha" (func_modo_escadinha, aba Início): cada conta nova usa o
  // link de indicação da conta ANTERIOR (origem + "?id=" + ID da conta
  // anterior) — precisa ser sequencial (não dá pra abrir tudo em paralelo
  // como o resto do app faz, já que a URL da janela N+1 só existe depois
  // que a janela N termina de cadastrar e captura seu próprio ID). Ver
  // openRealChromiumWindowsEscadinha.
  if (getSettingSync("func_modo_escadinha", "0") === "1") {
    return openRealChromiumWindowsEscadinha(url, openCount, execPath, area, scaleFactor, gridCols, gridRows, gap, customBounds, proxies);
  }

  // Abre TODOS os processos do Chrome imediatamente/em paralelo (rápido —
  // cada um é seu próprio processo independente). O delay configurado em
  // TELAS não atrasa mais o LANÇAMENTO da janela (ela já abre na hora,
  // mostrando nossa splash com logo + dispositivo, igual sempre foi) — só
  // atrasa a NAVEGAÇÃO pra URL real de cada uma (ver navigateDelayMs em
  // openOneRealChromeWindow). Isso evita que todas as janelas ataquem o
  // site de verdade (JS pesado, anti-bot, etc.) ao mesmo tempo, que é o que
  // deixava a telinha de cadastro lenta pra aparecer com várias janelas.
  // Avisa o auto-register.cjs quantas contas NOVAS (sem acc pré-definida —
  // essas fazem login em vez de cadastro, ver wireNewPage) esse lote vai
  // criar, pra ele conseguir esperar o lote inteiro e logar "Conta criada"
  // sempre em ordem de tela (ver setContaCriadaBatchTotal em auto-register.cjs).
  try {
    let novasContas = 0;
    for (let i = 0; i < openCount; i++) if (!accounts[i]) novasContas++;
    if (novasContas > 0) setContaCriadaBatchTotal(novasContas);
  } catch {}
  let opened = 0;
  const tasks = [];
  for (let i = 0; i < openCount; i++) {
    const bounds = customBounds?.[i] || gridWindowBounds(area, gridCols, gridRows, i, gap);
    const proxy = proxies.length ? proxies[i % proxies.length] : null;
    const launchDelay = i * MIN_LAUNCH_STAGGER_MS;
    const navigateDelayMs = Math.max(i * delayMs, i * MIN_NAV_STAGGER_MS);
    tasks.push((async () => {
      if (launchDelay > 0) await new Promise((r) => setTimeout(r, launchDelay));
      await openOneRealChromeWindow({ index: i, url, bounds, proxy, execPath, acc: accounts[i] || null, scaleFactor, navigateDelayMs, headless });
      opened++;
      console.log(`[realchrome] janela #${i + 1}/${openCount} aberta ok`);
    })().catch((e) => {
      console.error(`[realchrome] falha ao abrir janela #${i + 1}:`, e?.message);
      // Diag 2026-08-09: esse catch só ia pro console.error, que some (app
      // empacotado não tem console visível) — se wireNewPage/qualquer coisa
      // dentro de openOneRealChromeWindow LANÇAR (em vez de só travar), o
      // erro ficava 100% invisível: nenhum log, nenhuma pista, só "não
      // aconteceu nada". Suspeita real: pode ser exatamente isso que está
      // impedindo registerChromeWin de rodar (nem timeout guard nenhum pega
      // uma EXCEÇÃO de verdade, só travamento).
      try { queueDiagLine(`[${new Date().toISOString()}] [realchrome] FALHA ao abrir janela #${i + 1}: ${e?.message}\r\n${e?.stack || ""}\r\n`); } catch {}
    }));
  }
  await Promise.all(tasks);
  return opened;
}

async function openRealChromiumMulti(links = [], countPerLink = 1, accounts = [], delaySec = 0, headless = false) {
  const urls = (Array.isArray(links) ? links : []).map((s) => String(s || "").trim()).filter(Boolean);
  if (!urls.length) return 0;
  const execPath = await ensureChromeBinary();
  const target = getTargetDisplay();
  const area = target.workArea;
  const scaleFactor = target.scaleFactor || 1;
  const gridRows = Math.max(1, parseInt(getSettingSync("grid_rows", "2"), 10) || 2);
  const gridCols = Math.max(1, parseInt(getSettingSync("grid_cols", "5"), 10) || 5);
  const reduzir = getSettingSync("reduzir_janelas", "0") === "1";
  const gap = reduzir ? -7 : 5;
  const perLink = Math.max(1, Number(countPerLink) || 1);
  const openCount = urls.length * perLink;
  const rows = Math.max(gridRows, Math.ceil(openCount / gridCols));
  const customBounds = reduzir ? null : getCustomWindowBounds(area, openCount);
  const proxies = getActiveProxiesSync();
  const delayMs = Math.max(0, Math.round(Number(delaySec) || 0) * 1000);

  // Ver comentário equivalente em openRealChromiumWindows — mesmo lote de
  // avisos pro auto-register.cjs conseguir logar "Conta criada" em ordem.
  try {
    if (!accounts.length && openCount > 0) setContaCriadaBatchTotal(openCount);
  } catch {}

  // Paralelo no lançamento, delay só na navegação — ver comentário
  // equivalente em openRealChromiumWindows.
  let opened = 0;
  const tasks = [];
  for (let i = 0; i < openCount; i++) {
    const url = urls[Math.floor(i / perLink) % urls.length];
    const bounds = customBounds?.[i] || gridWindowBounds(area, gridCols, rows, i, gap);
    const proxy = proxies.length ? proxies[i % proxies.length] : null;
    const acc = accounts.length ? accounts[i % accounts.length] : null;
    const launchDelay = i * MIN_LAUNCH_STAGGER_MS;
    const navigateDelayMs = Math.max(i * delayMs, i * MIN_NAV_STAGGER_MS);
    tasks.push((async () => {
      if (launchDelay > 0) await new Promise((r) => setTimeout(r, launchDelay));
      await openOneRealChromeWindow({ index: i, url, bounds, proxy, execPath, acc, scaleFactor, navigateDelayMs, headless });
      opened++;
      console.log(`[realchrome-multi] janela #${i + 1}/${openCount} aberta ok`);
    })().catch((e) => console.error(`[realchrome-multi] falha ao abrir janela #${i + 1}:`, e?.message)));
  }
  await Promise.all(tasks);
  return opened;
}

// Pedido do usuário 2026-08-10: "sobre a mensagem login realizado, está
// aparecendo logo quando abre a conta, tem que aparecer se o login for
// feito realmente" — poll do lado do NODE (setTimeout aqui, não dentro do
// script injetado) checando o mesmo sinal já usado em auto-register.cjs/
// autoLogin.cjs (barra "Começar/Perfil/Depósito" visível E nenhum campo de
// conta na tela = já logado). Feito do lado de fora da página de propósito
// — sobrevive a qualquer navegação/reload que aconteça enquanto a conta
// termina de logar (o script injetado perdia todo o estado a cada reload).
function waitAndLogLoginRealizado(win, tela) {
  let tries = 0;
  const maxTries = 30; // ~30s (1s entre tentativas)
  const check = async () => {
    tries++;
    try {
      if (!win || win.isDestroyed()) return;
      const logado = await win.webContents.executeJavaScript(`(() => {
        try {
          var t = ((document.body && document.body.innerText) || '').toLowerCase();
          var temBarra = /come[çc]ar/.test(t) && /perfil/.test(t) && /dep[óo]sito/.test(t);
          var temCampoConta = !!document.querySelector('input[data-input-name="account"], textarea[data-input-name="account"]');
          return temBarra && !temCampoConta;
        } catch (e) { return false; }
      })();`, true).catch(() => false);
      if (logado) {
        logSystem(`Tela ${tela} — Login realizado`, { kind: "auto-login", tela }, "success", "operacao-login");
        return;
      }
    } catch {}
    if (tries < maxTries) setTimeout(check, 1000);
  };
  setTimeout(check, 1500);
}

async function openRealChromiumForContas(contas, delaySec = 0, headless = false) {
  const arr = (contas || []).filter((c) => c && c.url);
  if (!arr.length) return 0;
  const execPath = await ensureChromeBinary();
  const target = getTargetDisplay();
  const area = target.workArea;
  const scaleFactor = target.scaleFactor || 1;
  const gridRows = Math.max(1, parseInt(getSettingSync("grid_rows", "2"), 10) || 2);
  const gridCols = Math.max(1, parseInt(getSettingSync("grid_cols", "5"), 10) || 5);
  const reduzir = getSettingSync("reduzir_janelas", "0") === "1";
  const gap = reduzir ? -7 : 5;
  const openCount = arr.length;
  const rows = Math.max(gridRows, Math.ceil(openCount / gridCols));
  const customBounds = reduzir ? null : getCustomWindowBounds(area, openCount);
  const proxies = getActiveProxiesSync();
  const delayMs = Math.max(0, Math.round(Number(delaySec) || 0) * 1000);

  // Paralelo no lançamento, delay só na navegação — ver comentário
  // equivalente em openRealChromiumWindows.
  let opened = 0;
  const tasks = [];
  for (let i = 0; i < openCount; i++) {
    const conta = arr[i];
    const bounds = customBounds?.[i] || gridWindowBounds(area, gridCols, rows, i, gap);
    const proxy = proxies.length ? proxies[i % proxies.length] : null;
    const launchDelay = i * MIN_LAUNCH_STAGGER_MS;
    const navigateDelayMs = Math.max(i * delayMs, i * MIN_NAV_STAGGER_MS);
    tasks.push((async () => {
      if (launchDelay > 0) await new Promise((r) => setTimeout(r, launchDelay));
      const winShim = await openOneRealChromeWindow({ index: i, url: conta.url, bounds, proxy, execPath, conta, scaleFactor, navigateDelayMs, headless });
      opened++;
      console.log(`[realchrome-contas] janela #${i + 1}/${openCount} aberta ok`);
      // Pedido do usuário 2026-08-10 (2ª rodada): "está aparecendo logo
      // quando abre a conta, tem que aparecer se o login for feito
      // realmente" — o log direto na abertura era cedo demais/não confirma
      // nada de verdade. Poll do lado do NODE (não depende do estado
      // interno da página sobreviver a recarregamentos, ao contrário da
      // tentativa anterior via console.log dentro do script injetado) —
      // ver waitAndLogLoginRealizado.
      waitAndLogLoginRealizado(winShim, i + 1);
    })().catch((e) => console.error(`[realchrome-contas] falha ao abrir janela #${i + 1}:`, e?.message)));
  }
  await Promise.all(tasks);
  return opened;
}

// "Nova guia" pro botão + — modo --app não tem abas de verdade (testado e
// confirmado: browser.newPage() sempre cria uma JANELA separada do Windows,
// não uma aba dentro da mesma). Chega o mais perto possível reaproveitando o
// MESMO processo/sessão do Chrome (cookies, login e proxy continuam
// valendo — é literalmente o mesmo "browser", só mais uma página/janela),
// posicionada logo ao lado da original. Só é chamada em modo --app —
// janelas nativas (>= MIN_NATIVE_CHROME_WIDTH) nunca passam por aqui: o "+"
// que o usuário vê é o de VERDADE do Chrome, que já abre aba na mesma
// janela sozinho (watchNativeTabs adota a aba automaticamente).
async function openNewTabForWindow(sourceWin) {
  if (!sourceWin || sourceWin.isDestroyed() || !sourceWin._browser) return null;
  const browser = sourceWin._browser;
  const url = sourceWin.webContents.getURL() || sourceWin._targetUrl || "about:blank";

  const page = await browser.newPage();
  const cdp = await page.target().createCDPSession();

  // Posiciona logo ao lado/abaixo da janela de origem, mesmo tamanho dela.
  try {
    const { bounds: srcBounds } = await cdpSendGuarded(sourceWin._cdp, "Browser.getWindowForTarget");
    const { windowId } = await cdpSendGuarded(cdp, "Browser.getWindowForTarget");
    await cdpSendGuarded(cdp, "Browser.setWindowBounds", {
      windowId,
      bounds: { left: (srcBounds.left || 0) + 24, top: (srcBounds.top || 0) + 24, width: srcBounds.width, height: srcBounds.height, windowState: "normal" },
    });
  } catch (e) { console.warn("[realchrome] newtab: setWindowBounds falhou:", e?.message); }

  const winShim = await wireNewPage({ browser, page, cdp, targetUrl: url, mobileProfile: sourceWin._pandoraMobileProfile, nativeChrome: false });

  try { await page.goto(url, { waitUntil: "domcontentloaded", timeout: 30000 }); } catch (e) { console.warn("[realchrome] newtab goto falhou:", e?.message); }
  return winShim;
}

// TEMPORÁRIO — investigação de API de aposta (2026-08-07). Motor de giros
// via API pura (ver __API_INSPECT_SCRIPT em browserInjections.cjs): acha o
// frame do jogo (iframe cross-origin onde o script rodou e expôs
// window.__pandoraApiSpinRun — nunca é o frame principal, é o iframe do
// motor Cocos) e chama a função lá dentro via Puppeteer (Frame.evaluate,
// que atravessa CDP/OOPIF sozinho, sem precisar achar contextId na mão).
// Retorna { ok:false, reason } se a janela não tiver entrado em nenhum
// slot ainda (nenhum frame expõe a função) ou se o estado ainda não tiver
// sido semeado (GameInfo/Get ainda não rodou — ver __pandoraApiState).
async function runApiSpinChain(winShim, count, opts) {
  if (!winShim || winShim.isDestroyed() || !winShim._page) return { ok: false, reason: "janela inválida" };
  const page = winShim._page;
  let sawGameFrame = false;
  for (const frame of page.frames()) {
    try {
      const has = await frame.evaluate(() => !!window.__pandoraApiSpinRun);
      if (has) {
        return await frame.evaluate((c, o) => window.__pandoraApiSpinRun(c, o), count, opts || {});
      }
      // Reforço (2026-08-08, pedido do usuário — retry não pode só ficar
      // esperando passivamente): o gancho normal é instalado via
      // Page.addScriptToEvaluateOnNewDocument por-target no momento em que
      // o target É CRIADO (ver applyApiInspectToTarget acima) — se esse
      // momento passar batido por qualquer motivo (corrida, proxy lento),
      // NENHUMA quantidade de espera passiva conserta, porque o gancho
      // nunca chega a existir nesse frame. Reinjeta direto aqui, em cada
      // tentativa — idempotente (o próprio script já tem guard interno
      // contra dupla instalação), então não tem custo/risco reinjetar toda
      // vez. Não resolve giros PASSADOS perdidos, mas garante que o
      // próximo GameInfo/Get ou Spin do jogo (nesse frame) vai ser
      // capturado a partir de agora.
      if (frame !== page.mainFrame()) {
        sawGameFrame = true;
        try { await frame.evaluate(__API_INSPECT_SCRIPT); } catch {}
      }
    } catch (e) {
      // frame pode ter navegado/sido destruído no meio — ignora e tenta o próximo
    }
  }
  return { ok: false, reason: sawGameFrame ? "estado incompleto" : "frame do jogo não encontrado (ainda não entrou em nenhum slot?)" };
}

// Auto Slot via API pura pra WG (Lucky Dog) — mesmo espírito do
// runApiSpinChain da PG, mas o mecanismo é diferente: o motor da WG não
// mora numa frame da própria `page` (page.frames() não alcança), é um CDP
// target à parte ("other") que a gente já rastreia em winShim._wgBetRef
// (ver applyApiInspectToTarget + wgCheckIv acima). Chama
// window.__pandoraWgBet() ali direto via Runtime.evaluate, N vezes, com
// delay entre cada — sem clicar em nada (ver __WG_SCENE_BET_FINDER_SCRIPT
// em browserInjections.cjs pro porquê de onSpin() ser o alvo certo, não
// requestBet()). Loga cada giro no Log de Operações (logSystem), igual a
// PG, incluindo "GIROS COMPLETOS" no último.
async function runWgSpinChain(winShim, count, opts) {
  if (!winShim || winShim.isDestroyed()) return { ok: false, reason: "janela inválida" };
  const ref = winShim._wgBetRef;
  if (!ref || !ref.session) {
    return { ok: false, reason: "motor da WG ainda não encontrado nessa janela (entre no slot e espere alguns segundos antes de tentar de novo)" };
  }
  const session = ref.session;
  const n = Math.max(1, parseInt(count, 10) || 10); // 2026-08-10: limite de 1000 removido a pedido do usuário — jogos não podem ter teto de giros
  const delayMs = Math.max(300, Math.min(10000, parseInt(opts?.delayMs, 10) || 900));
  // Valor de aposta a FORÇAR em cada giro (ver window.__pandoraWgBet(valor)
  // em browserInjections.cjs) — sem isso, girava com o que já estivesse
  // selecionado na tela, o que exigia configurar manualmente antes.
  const betAmountArg = opts?.betAmount != null ? JSON.stringify(Number(opts.betAmount)) : "";
  const tela = winShim?._pandoraOrder || "?";
  let sucesso = 0;
  let sessaoMorta = false;
  for (let i = 1; i <= n; i++) {
    if (winShim.isDestroyed()) break;
    let parsed;
    // Retry curto e local (não conta como giro/erro definitivo) pro caso
    // do Map de apostas do jogo (_betInformations) ainda estar VAZIO no
    // instante exato do giro — timing, não valor errado de verdade (achado
    // 2026-08-08: "válidos: NENHUM" na primeira tentativa). bettingList()
    // normalmente já rodou muito antes disso, mas dá margem sem custo real.
    for (let mapTry = 0; mapTry < 6; mapTry++) {
      try {
        const r = await session.send("Runtime.evaluate", {
          expression: `(() => { try { if (typeof window.__pandoraWgBet !== 'function') return JSON.stringify({ ok:false, reason:'window.__pandoraWgBet sumiu (motor recarregou?)' }); return JSON.stringify(window.__pandoraWgBet(${betAmountArg})); } catch(e){ return JSON.stringify({ ok:false, error: e && e.message }); } })()`,
          returnByValue: true,
          awaitPromise: false,
        });
        const val = r?.result?.value;
        parsed = val ? JSON.parse(val) : { ok: false, reason: "sem retorno" };
      } catch (e) {
        // Sessão morta (saiu do jogo/da Home e voltou — pedido do usuário
        // 2026-08-08): normaliza pra "reason" com "ainda não encontrado"
        // (em vez de só "error") pra chrome:wgSpinRun tratar como
        // RETRIÁVEL, não erro definitivo — e limpa a referência velha aqui
        // também (extra, além do listener "detached"), garantindo que a
        // PRÓXIMA tentativa não reuse essa mesma sessão morta.
        const morreu = /session closed|target closed|no target with given id/i.test(String(e?.message || ""));
        if (morreu) {
          sessaoMorta = true;
          if (winShim._wgBetRef === ref) { ref.session = null; ref.type = null; ref.foundAt = null; }
        }
        parsed = { ok: false, reason: morreu ? "sessão anterior fechada, motor da WG ainda não encontrado (aguardando reentrar no jogo)" : undefined, error: e?.message };
        if (morreu) break; // não adianta insistir com a MESMA sessão morta
      }
      const mapaVazio = Array.isArray(parsed?.valoresValidos) && parsed.valoresValidos.length === 0;
      if (!mapaVazio) break;
      await new Promise((res) => setTimeout(res, 1000));
    }
    const progressKey = `auto-slot-${tela}-luckydog`;
    if (parsed.ok) {
      sucesso++;
      try {
        // Saldo (pedido do usuário 2026-08-09: "rodando mas não mostra o
        // saldo") — best-effort, vem de findBalance() em __pandoraWgBet
        // (browserInjections.cjs); pode não achar em todo jogo, por isso só
        // aparece na mensagem quando veio um número de verdade.
        const saldoMsg = typeof parsed.balance === "number" && isFinite(parsed.balance) ? ` — saldo R$${parsed.balance.toFixed(2)}` : "";
        logSystemProgress(progressKey, `Tela ${tela} — Lucky Dog: giro ${i}/${n} — aposta R$${Number(parsed.betAmount ?? 0).toFixed(2)}${saldoMsg}`, { kind: "auto-slot-wg", tela, i, count: n, ...parsed }, "info", "operacao-auto-slot");
        if (i >= n) { clearProgressLog(progressKey); logSystem(`Tela ${tela} — Lucky Dog: GIROS COMPLETOS`, { kind: "auto-slot-wg-completo", tela, i, count: n }, "success", "operacao-auto-slot"); }
      } catch {}
    } else {
      try {
        // Mostra as apostas válidas de VERDADE desse jogo junto do erro
        // (pedido do usuário 2026-08-08) — sem isso não dava pra saber que
        // valor configurar no lugar do que falhou.
        // Mostra SEMPRE, mesmo vazio — uma lista vazia é informação real
        // (o Map de apostas do jogo ainda não tinha carregado nada quando
        // checamos), escondendo isso a mensagem parecia "valor errado"
        // quando na verdade era "estado do jogo ainda não pronto".
        const valoresMsg = Array.isArray(parsed.valoresValidos)
          ? ` (válidos: ${parsed.valoresValidos.length ? parsed.valoresValidos.map((v) => `R$${Number(v).toFixed(2)}`).join(", ") : "NENHUM (mapa de apostas do jogo ainda vazio)"})`
          : "";
        logSystemProgress(progressKey, `Tela ${tela} — Lucky Dog: giro ${i}/${n} falhou — ${parsed.reason || parsed.error || "erro desconhecido"}${valoresMsg}`, { kind: "auto-slot-wg", tela, i, count: n, ...parsed }, "warning", "operacao-auto-slot");
      } catch {}
      break; // erro definitivo (motor sumiu/recarregou) — para o loop
    }
    if (i < n) await new Promise((res) => setTimeout(res, delayMs));
  }
  // Sessão morta precisa carregar o "reason" no retorno FINAL da função —
  // o retry (chrome:wgSpinRun em slotHandler.cjs) só olha o retorno, não o
  // log — sem isso, mesmo já logando certo, a falha aparecia como
  // definitiva na hora em vez de esperar/tentar de novo (bug real
  // 2026-08-08, reportado pelo usuário: apareceu igual mesmo depois do
  // primeiro conserto, porque só a MENSAGEM tinha o motivo, o retorno não).
  if (sessaoMorta) return { ok: false, sucesso, total: n, reason: "motor da WG ainda não encontrado nessa janela (sessão anterior fechada, aguardando reentrar no jogo)" };
  return { ok: sucesso > 0, sucesso, total: n };
}

// Auto Slot via API pura pra PP (Pragmatic Play — ex.: Plushie Wins).
// Investigação 2026-08-07: bem mais simples que WG — protocolo HTTP puro
// (form-urlencoded), sem WebSocket/binário, endpoint /gs2c/ge/v3/gameService.
// Encadeado por index/counter (cada chamada, seja doSpin ou doCollect, usa
// index/counter da ÚLTIMA RESPOSTA +1), autenticado por um mgckey fixo pra
// sessão inteira (não precisa renovar). O servidor manda no campo "na" (next
// action) o que a próxima chamada TEM que ser: 'c' = doCollect obrigatório
// antes de poder girar de novo (giro anterior teve prêmio a "recolher" —
// achado observando um giro premiado de verdade), 's' = doSpin liberado.
// Estado vem de winShim._ppSpinRef (populado nos listeners de Network em
// applyApiInspectToTarget acima, a partir do tráfego real do jogo — exige
// pelo menos 1 giro manual antes pra semear mgckey/symbol/index/counter).
async function runPpSpinChain(winShim, count, opts) {
  if (!winShim || winShim.isDestroyed()) return { ok: false, reason: "janela inválida" };
  const ref = winShim._ppSpinRef;
  const st = ref?.state;
  if (!ref?.session || !st?.mgckey || !st?.symbol || !st?.url || st.index == null || st.counter == null) {
    return { ok: false, reason: "estado da PP ainda não capturado (dê pelo menos 1 giro manual nesse jogo antes)" };
  }
  const session = ref.session;
  const n = Math.max(1, parseInt(count, 10) || 10); // 2026-08-10: limite de 1000 removido a pedido do usuário — jogos não podem ter teto de giros
  // Sem risco de corrida ao baixar isso: cada iteração já espera a resposta
  // da chamada anterior terminar (await call(...)) ANTES de começar a
  // contar esse delay — ele é só uma pausa extra depois do round-trip já
  // ter voltado, não concorrência entre chamadas. Piso baixo (era 300ms).
  const delayMs = Math.max(50, Math.min(10000, parseInt(opts?.delayMs, 10) || 150));
  const tela = winShim?._pandoraOrder || "?";
  const betAmount = opts?.betAmount != null ? Number(opts.betAmount) : (st.defc != null ? st.defc : null);
  if (st.sc && betAmount != null && !st.sc.some((v) => Math.abs(v - betAmount) < 0.001)) {
    // Loga aqui dentro (não só retorna) — a UI (Operacao.tsx) parou de
    // reportar falha de giro pra não confundir com "GIROS COMPLETOS" de
    // outra tela, então sem isso esse erro ficava mudo (pedido do usuário
    // 2026-08-08: mostrar os valores válidos de verdade desse jogo).
    const valoresMsg = st.sc.length ? ` (válidos: ${st.sc.map((v) => `R$${Number(v).toFixed(2)}`).join(", ")})` : "";
    try {
      logSystemProgress(`auto-slot-${tela}-plushiewins`, `Tela ${tela} — Plushie Wins: valor de aposta R$${betAmount.toFixed(2)} não existe nesse jogo${valoresMsg}`, { kind: "auto-slot-pp", tela }, "warning", "operacao-auto-slot");
    } catch {}
    return { ok: false, reason: `valor de aposta R$${betAmount.toFixed(2)} não existe nesse jogo`, valoresValidos: st.sc };
  }

  const call = async (action) => {
    const params = new URLSearchParams();
    if (action === "doSpin") {
      params.set("action", "doSpin");
      params.set("symbol", st.symbol);
      params.set("c", String(betAmount != null ? betAmount : st.defc || 0.1));
      params.set("l", String(st.l || "1"));
      params.set("sInfo", "n");
    } else {
      params.set("symbol", st.symbol);
      params.set("action", "doCollect");
    }
    params.set("index", String(st.index + 1));
    params.set("counter", String(st.counter + 1));
    params.set("repeat", "0");
    params.set("mgckey", st.mgckey);
    const expr = `(async () => { try { const r = await fetch(${JSON.stringify(st.url)}, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: ${JSON.stringify(params.toString())}, credentials: 'include' }); const t = await r.text(); return JSON.stringify({ ok: true, status: r.status, text: t }); } catch (e) { return JSON.stringify({ ok: false, error: e && e.message }); } })()`;
    const r = await session.send("Runtime.evaluate", { expression: expr, awaitPromise: true, returnByValue: true });
    const val = r?.result?.value;
    const parsed = val ? JSON.parse(val) : { ok: false, reason: "sem retorno" };
    if (!parsed.ok) return parsed;
    const rp = new URLSearchParams(parsed.text || "");
    // BUG real 2026-08-10 (reportado pelo usuário: log mostrou "giro 10/10 —
    // GIROS COMPLETOS", mas o Relatório de Apostas confirma que nem todos os
    // 10 giros foram realmente registrados no servidor) — antes, qualquer
    // resposta HTTP 200 que o fetch conseguisse ler (sem lançar exceção) já
    // era tratada como giro bem-sucedido (sucesso++), mesmo que o corpo NÃO
    // trouxesse index/counter de verdade (ex.: página de erro, sessão
    // expirada, resposta inesperada) — nesse caso a chamada seguinte
    // reenviava o MESMO index/counter de antes, o servidor tratava como
    // replay/duplicata e devolvia um resultado (às vezes cacheado, sem
    // aposta nova de fato), e o código contava como giro novo do mesmo jeito.
    // Agora exige index E counter presentes na resposta pra considerar um
    // giro de verdade — sem isso, é erro (não conta, não avança o estado).
    if (!rp.has("index") || !rp.has("counter")) {
      return { ok: false, reason: "resposta sem index/counter — giro pode não ter sido registrado pelo servidor", raw: (parsed.text || "").slice(0, 300) };
    }
    st.index = parseInt(rp.get("index"), 10);
    st.counter = parseInt(rp.get("counter"), 10);
    if (rp.has("balance")) st.balance = parseFloat(rp.get("balance"));
    if (rp.has("na")) st.na = rp.get("na");
    const w = rp.has("w") ? parseFloat(rp.get("w")) : null;
    return { ok: true, w, balance: st.balance, na: st.na };
  };

  const progressKey = `auto-slot-${tela}-plushiewins`;
  let sucesso = 0;
  let sessaoMorta = false;
  // Pedido do usuário 2026-08-10 (reportado: giro 1394/1501 deu "Runtime.
  // evaluate timed out" no meio de uma rodada longa — timeout de rede
  // pontual, não erro definitivo) — antes, QUALQUER exceção (inclusive um
  // timeout passageiro de proxy/rede) parava o loop inteiro, perdendo todos
  // os giros restantes. Timeout é retriável: tenta de novo o MESMO giro
  // (até 3 vezes, com pausa) antes de desistir de vez.
  let timeoutRetries = 0;
  const MAX_TIMEOUT_RETRIES = 3;
  for (let i = 1; i <= n; i++) {
    if (winShim.isDestroyed()) break;
    try {
      // Giro premiado deixa o servidor num estado "precisa recolher antes de
      // girar de novo" (na='c') — resolve isso primeiro, sem contar como um
      // dos N giros pedidos.
      if (st.na === "c") {
        const rc = await call("doCollect");
        if (!rc.ok) { logSystemProgress(progressKey, `Tela ${tela} — Plushie Wins: doCollect falhou — ${rc.reason || rc.error}`, { kind: "auto-slot-pp", tela }, "warning", "operacao-auto-slot"); break; }
      }
      const r = await call("doSpin");
      if (!r.ok) {
        logSystemProgress(progressKey, `Tela ${tela} — Plushie Wins: giro ${i}/${n} falhou — ${r.reason || r.error || "erro desconhecido"}`, { kind: "auto-slot-pp", tela, i, count: n }, "warning", "operacao-auto-slot");
        break;
      }
      timeoutRetries = 0;
      sucesso++;
      logSystemProgress(progressKey, `Tela ${tela} — Plushie Wins: giro ${i}/${n} — ganho R$${Number(r.w ?? 0).toFixed(2)} — saldo R$${Number(r.balance ?? 0).toFixed(2)}`, { kind: "auto-slot-pp", tela, i, count: n, ...r }, "info", "operacao-auto-slot");
      if (i >= n) { clearProgressLog(progressKey); logSystem(`Tela ${tela} — Plushie Wins: GIROS COMPLETOS`, { kind: "auto-slot-pp-completo", tela, i, count: n }, "success", "operacao-auto-slot"); }
    } catch (e) {
      // Sessão morta no meio da rodada (saiu do jogo/Home e voltou — pedido
      // do usuário 2026-08-08): limpa a referência velha e sinaliza pro
      // chrome:ppSpinRun que isso é RETRIÁVEL (vai aparecer "ainda não
      // capturado" na próxima tentativa, depois que uma sessão nova for
      // descoberta), em vez de ficar preso reportando erro definitivo.
      const morreu = /session closed|target closed|no target with given id/i.test(String(e?.message || ""));
      if (morreu) { sessaoMorta = true; if (winShim._ppSpinRef === ref) { ref.session = null; ref.state = null; } }
      const isTimeout = !morreu && /timed out|timeout/i.test(String(e?.message || ""));
      if (isTimeout && timeoutRetries < MAX_TIMEOUT_RETRIES) {
        timeoutRetries++;
        logSystemProgress(progressKey, `Tela ${tela} — Plushie Wins: giro ${i}/${n} — timeout de rede, tentando de novo (${timeoutRetries}/${MAX_TIMEOUT_RETRIES})...`, { kind: "auto-slot-pp", tela, i, count: n }, "warning", "operacao-auto-slot");
        i--; // repete o MESMO giro na próxima iteração
        await new Promise((res) => setTimeout(res, 1500));
        continue;
      }
      logSystemProgress(progressKey, `Tela ${tela} — Plushie Wins: giro ${i}/${n} — erro: ${e?.message}`, { kind: "auto-slot-pp", tela, i, count: n }, "warning", "operacao-auto-slot");
      break;
    }
    if (i < n) await new Promise((res) => setTimeout(res, delayMs));
  }
  if (sessaoMorta) return { ok: false, sucesso, total: n, reason: "estado da PP ainda não capturado (sessão anterior fechada, aguardando reentrar no jogo)" };
  return { ok: sucesso > 0, sucesso, total: n };
}

module.exports = {
  openRealChromiumWindows,
  openRealChromiumMulti,
  openRealChromiumForContas,
  closeRealChromiumWindows,
  openOneRealChromeWindow,
  openNewTabForWindow,
  showProxyIpOnRealChromeWindow,
  runApiSpinChain,
  runWgSpinChain,
  runPpSpinChain,
  reapplyWindowBounds,
  waitAndLogLoginRealizado,
};
