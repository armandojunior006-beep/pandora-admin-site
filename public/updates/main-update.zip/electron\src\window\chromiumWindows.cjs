// ============================================================================
// Abertura/fechamento das janelas Chromium controladas pelo bot (open,
// openMulti, openForContas), janelas "worker" (headless de apoio) e seleção
// de janelas via spec "1,3,5-8" (aba Operação → "Janelas Para Controlar").
// ============================================================================
const { app, BrowserWindow, session } = require("electron");
const path = require("path");
const fs = require("fs");
const { ROOT_DIR } = require("../paths.cjs");
const state = require("../state.cjs");
const { saveDB } = require("../../db.cjs");
const { getSettingSync } = require("../settings/settingsStore.cjs");
const { logSystem, describeDevice } = require("../settings/settingsStore.cjs");
const {
  isDev, APP_ICON, relaxWebContentsMaxListeners, registerChromeWin,
  applyHiddenNavMode, applyAppMode, enableDevTools,
  getTargetDisplay, gridWindowBounds, getCustomWindowBounds, parseJanelasSpec, applyControlIndicator,
} = require("./windowManager.cjs");
const {
  getActiveProxiesSync, applyProxyToSession, attachProxyLogin, attachProxyTunnelRetry,
  showProxyIpOnWindow, enforceUniqueIp, PROXY_RETRY_CODES,
} = require("../proxy/proxyManager.cjs");
const { applyBlockedDomainsToSession } = require("../proxy/domainBlocker.cjs");
const { nextSessionUA, applyMobileHeaders } = require("../injections/mobileProfiles.cjs");
const { applyStealth, loadCaptchaExtension } = require("../injections/stealth.cjs");
const { loadCustomExtensionIfActive } = require("../ipc/extensionHandlers.cjs");
const { attachUrlAsTitle, showWindowMessage, attachBrowserToolbar } = require("../injections/browserInjections.cjs");
const { attachPixModalEnhancer } = require("../injections/pixModalEnhancer.cjs");
const { attachContaAutoLogin, attachPopupCloser } = require("./autoLogin.cjs");
const { attachAutoRegister, getDiagFilePath } = require("../../auto-register.cjs");
const { attachGeetestSolver } = require("../../geetest-attach.cjs");

function getSelectedChromeWins() {
  const spec = (state.janelasOverride != null) ? state.janelasOverride : getSettingSync("op_janelas", "");
  const sel = parseJanelasSpec(spec);
  const all = state.chromeWins.filter((w) => w && !w.isDestroyed());
  let result;
  if (!sel) {
    // sem filtro → todas, sem destaque
    result = all;
    for (const w of all) {
      try { w.__pandoraCtrlSelected = false; } catch {}
      applyControlIndicator(w, false);
    }
    return result;
  }
  result = [];
  for (let i = 0; i < all.length; i++) {
    const w = all[i];
    const isSel = sel.has(i + 1);
    try { w.__pandoraCtrlSelected = isSel; } catch {}
    applyControlIndicator(w, isSel);
    if (isSel) result.push(w);
  }
  return result;
}

// Prepara sessões (proxy + extensão de captcha) em lotes pequenos em vez de
// todas de uma vez. Abrir 10+ janelas disparando 10 conexões de proxy
// simultâneas satura o provedor (rate-limit por credencial) e a rede local,
// o que é a causa mais comum de "algumas telas não carregam o link". Em
// lotes de 4, cada bridge tem banda/tempo de sobra pra conectar de forma
// estável — deixa o processo mais leve sem perder paralelismo relevante.
const SESSION_SETUP_CONCURRENCY = 4;
async function mapWithConcurrency(count, limit, fn) {
  const results = new Array(count);
  let next = 0;
  async function worker() {
    for (;;) {
      const i = next++;
      if (i >= count) return;
      results[i] = await fn(i);
    }
  }
  await Promise.all(Array.from({ length: Math.max(1, Math.min(limit, count)) }, worker));
  return results;
}

// Reforço genérico de carregamento: além do retry específico de túnel de
// proxy (attachProxyTunnelRetry, que recria a bridge para os códigos em
// PROXY_RETRY_CODES), tenta recarregar mais algumas vezes antes de desistir
// e mostrar erro na tela — cobre falhas passageiras que não são de proxy
// (timeout local, DNS, aba renderizando pesado) tanto com proxy quanto sem.
function attachGenericLoadRetry(win) {
  let attempts = 0;
  const maxAttempts = 3;
  win.webContents.on("did-fail-load", (_event, code, desc, failedUrl) => {
    if (code === -3 || String(failedUrl || "").startsWith("file://")) return;
    if (PROXY_RETRY_CODES.has(code)) return; // já tratado por attachProxyTunnelRetry
    const target = win._targetUrl || failedUrl;
    if (attempts >= maxAttempts || !target) {
      showWindowMessage(win, "Link não carregou", `${desc || "Falha ao abrir"} (${code})`);
      return;
    }
    attempts++;
    console.warn(`[load-retry] ${desc} (${code}) -> reload (tentativa ${attempts}/${maxAttempts})`);
    setTimeout(() => { try { if (win && !win.isDestroyed()) win.loadURL(target); } catch {} }, 900 + attempts * 700);
  });
}

function closeChromiumWindows() {
  // Diag 2026-08-09 (investigação "Stop não fecha a janela"): registra
  // quantas janelas o app ACHA que tem no momento do clique — se vier 0
  // aqui mesmo com o Chrome real visível na tela, o problema é o app ter
  // "perdido" a referência antes (ver [win-lifecycle] em webContentsShim.cjs),
  // não o close() em si.
  try {
    const { queueDiagLine } = require("../../auto-register.cjs");
    if (typeof queueDiagLine === "function") {
      queueDiagLine(`[${new Date().toISOString()}] [stop] closeChromiumWindows chamado — ${state.chromeWins.length} janela(s) em state.chromeWins\r\n`);
    }
  } catch {}
  for (const w of state.chromeWins) { try { w.close(); } catch {} }
  state.chromeWins = [];
  // encerra todos os bridges HTTP locais e limpa cache para forçar recriação
  const ProxyChain = require("proxy-chain");
  while (state.activeLocalProxies.length) {
    const url = state.activeLocalProxies.pop();
    try { ProxyChain.closeAnonymizedProxy(url, true).catch(() => {}); } catch {}
  }
  state.proxyBridgeCache.clear();
}

// Chrome real via CDP no lugar da janela Electron custom (ver realchrome/).
// Default ligado — desligue com a setting "nav_chrome_real"="0" se precisar
// voltar pro caminho antigo (Electron) por algum motivo.
function useRealChrome() {
  return getSettingSync("nav_chrome_real", "1") === "1";
}

async function openChromiumWindows(url, count = 1, accounts = [], delaySec = 0, headless = false) {
  closeChromiumWindows();
  if (!url) return 0;
  if (useRealChrome()) {
    const { openRealChromiumWindows } = require("./realchrome/realChromeManager.cjs");
    return openRealChromiumWindows(url, count, accounts, delaySec, headless);
  }
  // Modo headless (2026-08-08) só existe no caminho de Chrome real (--headless=new,
  // ver realChromeManager.cjs) — o caminho legado Electron (BrowserWindow) não
  // usa o mesmo mecanismo e não é o caminho ativo por padrão (nav_chrome_real=1).
  const captchaOn = getSettingSync("func_captcha", "0") === "1";
  const target = getTargetDisplay();
  const area = target.workArea; // { x, y, width, height }
  const gridRows = Math.max(1, parseInt(getSettingSync("grid_rows", "2"), 10) || 2);
  const gridCols = Math.max(1, parseInt(getSettingSync("grid_cols", "5"), 10) || 5);
  const reduzir = getSettingSync("reduzir_janelas", "0") === "1";
  const gap = reduzir ? -7 : 5;
  const cols = gridCols;
  const rows = gridRows;
  const slots = rows * cols;
  const openCount = Math.min(count, slots);
  const customBounds = reduzir ? null : getCustomWindowBounds(area, openCount);
  const delayMs = Math.max(0, Math.round(Number(delaySec) || 0) * 1000);
  const proxies = getActiveProxiesSync();
  const createdWins = [];
  const splashPath = path.join(ROOT_DIR, "assets", "splash.html");
  const tSetup0 = Date.now();
  // Prepara as sessões (proxy + captcha extension) em lotes pequenos antes de abrir janelas.
  const sessionsBatch = await mapWithConcurrency(openCount, SESSION_SETUP_CONCURRENCY, async (i) => {
      const tS = Date.now();
      const ses = session.fromPartition(`persist:chromium-${i + 1}-${Date.now()}`);
      const uaPick = nextSessionUA();
      ses.setUserAgent(uaPick.ua); if (uaPick.profile) applyMobileHeaders(ses, uaPick.profile);
      try { applyBlockedDomainsToSession(ses); } catch {}
      try { ses.setPermissionRequestHandler((_w,_p,cb)=>{ try{cb(true);}catch{} }); ses.setPermissionCheckHandler(()=>true); } catch {}
      const proxy = proxies.length ? proxies[i % proxies.length] : null;
      const [proxyResult] = await Promise.all([
        proxy ? applyProxyToSession(ses, proxy) : Promise.resolve({ ok: true }),
        loadCaptchaExtension(ses).catch(() => {}),
        loadCustomExtensionIfActive(ses).catch(() => {}),
      ]);
      console.log(`[open] sessão #${i + 1} pronta em ${Date.now() - tS}ms${uaPick.profile ? ` [mobile:${uaPick.profile.name}]` : ''}`);
      return { ses, proxy, proxyResult, uaPick };
  });
  console.log(`[open] ${openCount} sessões prontas em ${Date.now() - tSetup0}ms (lotes de ${SESSION_SETUP_CONCURRENCY})`);
  // 1) Abre todas as janelas com a splash (logo) imediatamente
  for (let i = 0; i < openCount; i++) {
    const acc = accounts[i] || null;
    const { ses, proxy, proxyResult, uaPick } = sessionsBatch[i];
    const bounds = customBounds?.[i] || gridWindowBounds(area, cols, rows, i, gap);
    const win = new BrowserWindow({
      width: bounds.width, height: bounds.height,
      x: bounds.x, y: bounds.y,
      title: acc ? `Chromium #${i + 1} — ${acc.label || acc.username || ""}` : `Chromium #${i + 1}`,
      backgroundColor: "#000000", autoHideMenuBar: true,
      hasShadow: true, thickFrame: true, frame: false,
      titleBarStyle: "hidden",
      titleBarOverlay: { color: "#00000000", symbolColor: "#e8e8e8", height: 32 },
      icon: APP_ICON,
      webPreferences: {
        session: ses,
        preload: path.join(ROOT_DIR, "chromium-preload.cjs"),
        contextIsolation: false, nodeIntegration: false, sandbox: false,
        nodeIntegrationInSubFrames: true,
        backgroundThrottling: false,
        webSecurity: false,
      },
    });
    relaxWebContentsMaxListeners(win);
    if (uaPick && uaPick.profile) win._pandoraMobileProfile = uaPick.profile;
    applyStealth(win, uaPick);
    applyHiddenNavMode(win);
    applyAppMode(win);
    enableDevTools(win);
    if (proxy) { attachProxyLogin(win, ses); attachProxyTunnelRetry(win, ses); }
    // Cada janela aparece como ícone separado na barra de tarefas (sem agrupar)
    try {
      if (process.platform === "win32") {
        win.setAppDetails({
          appId: `pandora.chromium.${i + 1}.${Date.now()}`,
          relaunchDisplayName: `Chromium #${i + 1}`,
          relaunchIconResource: `${APP_ICON},0`,
        });
        try { win.setIcon(APP_ICON); } catch {}
      }
    } catch {}
    try { if (fs.existsSync(splashPath)) { const __dn = (uaPick && uaPick.profile && uaPick.profile.name) ? uaPick.profile.name : ""; win.loadFile(splashPath, __dn ? { search: "device=" + encodeURIComponent(__dn) } : undefined); } } catch {}
    try { attachUrlAsTitle(win); } catch {}
    win._targetUrl = url;
    win._proxyReady = proxyResult.ok;
    win._proxyError = proxyResult.error || "Proxy sem resposta";
    win.webContents.on("did-finish-load", () => {
      if (win.webContents.getURL().startsWith("file://")) return;
      showProxyIpOnWindow(win, ses).then(() => enforceUniqueIp(win, ses)).catch(() => {});
    });
    try { attachBrowserToolbar(win); } catch (e) { console.warn("[toolbar]", e?.message); }
    attachGenericLoadRetry(win);
    attachAutoRegister(win, state.db, saveDB, state.dbPath)
    try {
      const { iniciarAutoCaptura } = require(path.join(ROOT_DIR, "autoCaptura.cjs"));
      const parar = iniciarAutoCaptura(win.webContents, url, state.mainWin, { chromeWin: win });
      win.on('closed', () => { try { parar && parar(); } catch {} });
      try { fs.appendFileSync(getDiagFilePath(), `[${new Date().toISOString()}] [AUTO] attach OK (chrome:open) url=${url}\r\n`, 'utf8'); } catch {}
    } catch (e) {
      try { fs.appendFileSync(getDiagFilePath(), `[${new Date().toISOString()}] [AUTO] attach FALHOU (chrome:open): ${e && e.message}\r\n`, 'utf8'); } catch {}
      console.warn('[autoCaptura] falhou:', e?.message);
    }
    try { attachGeetestSolver(win); } catch (e) { console.warn("[geetest] attach falhou:", e?.message); }
    try { attachPixModalEnhancer(win); } catch (e) { console.warn("[pix] attach falhou:", e?.message); }
    try { attachPopupCloser(win); } catch (e) { console.warn("[popup] attach falhou:", e?.message); }
    registerChromeWin(win);
    createdWins.push(win);
    try {
      const ord = win._pandoraOrder || (i + 1);
      logSystem(
        `Tela #${ord} aberta — Conta: ${(acc && (acc.username || acc.label)) || "(sem conta)"} | Senha: ${(acc && acc.password) || "-"} | Dispositivo: ${describeDevice(uaPick && uaPick.profile)}`,
        { tela: ord, login: acc && (acc.username || acc.label), senha: acc && acc.password, dispositivo: describeDevice(uaPick && uaPick.profile), os: uaPick && uaPick.profile ? uaPick.profile.os : "desktop" },
        "info", "telas"
      );
    } catch {}
  }
  // 2) Carrega a primeira na hora; as próximas com `delaySec` entre cada uma
  (async () => {
    for (let i = 0; i < createdWins.length; i++) {
      const win = createdWins[i];
      if (!win || win.isDestroyed()) continue;
      if (i > 0 && delayMs > 0) await new Promise((r) => setTimeout(r, delayMs));
      if (!win.isDestroyed()) {
        if (win._proxyReady) try { win.loadURL(url); } catch {}
        else showWindowMessage(win, "Proxy não conectou", win._proxyError);
      }
    }
  })();
  return state.chromeWins.length;
}

async function openChromiumMulti(links = [], countPerLink = 1, accounts = [], delaySec = 0, headless = false) {
  closeChromiumWindows();
  const urls = (Array.isArray(links) ? links : []).map((s) => String(s || "").trim()).filter(Boolean);
  if (urls.length === 0) return 0;
  if (useRealChrome()) {
    const { openRealChromiumMulti } = require("./realchrome/realChromeManager.cjs");
    return openRealChromiumMulti(urls, countPerLink, accounts, delaySec, headless);
  }
  const captchaOn = getSettingSync("func_captcha", "0") === "1";
  const target = getTargetDisplay();
  const area = target.workArea;
  const gridRows = Math.max(1, parseInt(getSettingSync("grid_rows", "2"), 10) || 2);
  const gridCols = Math.max(1, parseInt(getSettingSync("grid_cols", "5"), 10) || 5);
  const reduzir = getSettingSync("reduzir_janelas", "0") === "1";
  const gap = reduzir ? -7 : 5;
  const perLink = Math.max(1, Number(countPerLink) || 1);
  const openCount = urls.length * perLink;
  const cols = gridCols;
  const rows = Math.max(gridRows, Math.ceil(openCount / cols));
  const customBounds = reduzir ? null : getCustomWindowBounds(area, openCount);
  const delayMs = Math.max(0, Math.round(Number(delaySec) || 0) * 1000);
  const proxies = getActiveProxiesSync();
  const createdWins = [];
  const splashPath = path.join(ROOT_DIR, "assets", "splash.html");
  const tSetup0M = Date.now();
  const sessionsBatch = await mapWithConcurrency(openCount, SESSION_SETUP_CONCURRENCY, async (i) => {
      const tS = Date.now();
      const ses = session.fromPartition(`persist:chromium-${i + 1}-${Date.now()}`);
      const uaPick = nextSessionUA();
      ses.setUserAgent(uaPick.ua); if (uaPick.profile) applyMobileHeaders(ses, uaPick.profile);
      try { applyBlockedDomainsToSession(ses); } catch {}
      try { ses.setPermissionRequestHandler((_w,_p,cb)=>{ try{cb(true);}catch{} }); ses.setPermissionCheckHandler(()=>true); } catch {}
      const proxy = proxies.length ? proxies[i % proxies.length] : null;
      const [proxyResult] = await Promise.all([
        proxy ? applyProxyToSession(ses, proxy) : Promise.resolve({ ok: true }),
        loadCaptchaExtension(ses).catch(() => {}),
        loadCustomExtensionIfActive(ses).catch(() => {}),
      ]);
      console.log(`[openMulti] sessão #${i + 1} pronta em ${Date.now() - tS}ms${uaPick.profile ? ` [mobile:${uaPick.profile.name}]` : ''}`);
      return { ses, proxy, proxyResult, uaPick };
  });
  console.log(`[openMulti] ${openCount} sessões prontas em ${Date.now() - tSetup0M}ms (lotes de ${SESSION_SETUP_CONCURRENCY})`);
  for (let i = 0; i < openCount; i++) {
    const acc = accounts.length ? accounts[i % accounts.length] : null;
    const url = urls[Math.floor(i / perLink) % urls.length];
    const { ses, proxy, proxyResult, uaPick } = sessionsBatch[i];
    const bounds = customBounds?.[i] || gridWindowBounds(area, cols, rows, i, gap);
    const win = new BrowserWindow({

      width: bounds.width, height: bounds.height,
      x: bounds.x, y: bounds.y,
      title: acc ? `Chromium #${i + 1} — ${acc.label || acc.username || ""}` : `Chromium #${i + 1}`,
      backgroundColor: "#000000", autoHideMenuBar: true,
      hasShadow: true, thickFrame: true, frame: false,
      titleBarStyle: "hidden",
      titleBarOverlay: { color: "#00000000", symbolColor: "#e8e8e8", height: 32 },
      icon: APP_ICON,
      webPreferences: {
        session: ses,
        preload: path.join(ROOT_DIR, "chromium-preload.cjs"),
        contextIsolation: false, nodeIntegration: false, sandbox: false,
        nodeIntegrationInSubFrames: true,
        backgroundThrottling: false,
        webSecurity: false,
      },
    });
    relaxWebContentsMaxListeners(win);
    if (uaPick && uaPick.profile) win._pandoraMobileProfile = uaPick.profile;
    applyStealth(win, uaPick);
    applyHiddenNavMode(win);
    applyAppMode(win);
    enableDevTools(win);
    if (proxy) { attachProxyLogin(win, ses); attachProxyTunnelRetry(win, ses); }
    try {
      if (process.platform === "win32") {
        win.setAppDetails({
          appId: `pandora.chromium.${i + 1}.${Date.now()}`,
          relaunchDisplayName: `Chromium #${i + 1}`,
          relaunchIconResource: `${APP_ICON},0`,
        });
        try { win.setIcon(APP_ICON); } catch {}
      }
    } catch {}
    try { if (fs.existsSync(splashPath)) { const __dn = (uaPick && uaPick.profile && uaPick.profile.name) ? uaPick.profile.name : ""; win.loadFile(splashPath, __dn ? { search: "device=" + encodeURIComponent(__dn) } : undefined); } } catch {}
    try { attachUrlAsTitle(win); } catch {}
    win._targetUrl = url;
    win._proxyReady = proxyResult.ok;
    win._proxyError = proxyResult.error || "Proxy sem resposta";
    win.webContents.on("did-finish-load", () => {
      if (win.webContents.getURL().startsWith("file://")) return;
      showProxyIpOnWindow(win, ses).then(() => enforceUniqueIp(win, ses)).catch(() => {});
    });
    try { attachBrowserToolbar(win); } catch (e) { console.warn("[toolbar]", e?.message); }
    attachGenericLoadRetry(win);
    attachAutoRegister(win, state.db, saveDB, state.dbPath)
    try {
      const { iniciarAutoCaptura } = require(path.join(ROOT_DIR, "autoCaptura.cjs"));
      const parar = iniciarAutoCaptura(win.webContents, win._targetUrl || '', state.mainWin, { chromeWin: win });
      win.on('closed', () => { try { parar && parar(); } catch {} });
      try { fs.appendFileSync(getDiagFilePath(), `[${new Date().toISOString()}] [AUTO] attach OK (chrome:openMulti) url=${win._targetUrl || ''}\r\n`, 'utf8'); } catch {}
    } catch (e) {
      try { fs.appendFileSync(getDiagFilePath(), `[${new Date().toISOString()}] [AUTO] attach FALHOU (chrome:openMulti): ${e && e.message}\r\n`, 'utf8'); } catch {}
      console.warn('[autoCaptura] falhou:', e?.message);
    }
    try { attachGeetestSolver(win); } catch (e) { console.warn("[geetest] attach falhou:", e?.message); }
    try { attachPixModalEnhancer(win); } catch (e) { console.warn("[pix] attach falhou:", e?.message); }
    try { attachPopupCloser(win); } catch (e) { console.warn("[popup] attach falhou:", e?.message); }
    registerChromeWin(win);
    createdWins.push(win);
    try {
      const ord = win._pandoraOrder || (i + 1);
      logSystem(
        `Tela #${ord} aberta — Conta: ${(acc && (acc.username || acc.label)) || "(sem conta)"} | Senha: ${(acc && acc.password) || "-"} | Dispositivo: ${describeDevice(uaPick && uaPick.profile)}`,
        { tela: ord, login: acc && (acc.username || acc.label), senha: acc && acc.password, dispositivo: describeDevice(uaPick && uaPick.profile), os: uaPick && uaPick.profile ? uaPick.profile.os : "desktop" },
        "info", "telas"
      );
    } catch {}
  }
  (async () => {
    for (let i = 0; i < createdWins.length; i++) {
      const win = createdWins[i];
      if (!win || win.isDestroyed()) continue;
      if (i > 0 && delayMs > 0) await new Promise((r) => setTimeout(r, delayMs));
      if (!win.isDestroyed()) {
        if (win._proxyReady) try { win.loadURL(win._targetUrl); } catch {}
        else showWindowMessage(win, "Proxy não conectou", win._proxyError);
      }
    }
  })();
  return state.chromeWins.length;
}

// ===== Abrir Chromium para contas selecionadas (com auto-login) =====
// Abre 1 janela por conta, carrega a URL salva, clica na aba "Login" se
// existir um modal de cadastro e preenche login/senha automaticamente.
// Não altera nenhum fluxo existente de open/openMulti.
async function openChromiumForContas(contas, delaySec = 0) {
  closeChromiumWindows();
  const arr = (contas || []).filter((c) => c && c.url);
  if (!arr.length) return 0;
  // "Abrir Selecionadas" (aba Contas) não perguntava sobre Operação Oculta —
  // lê o mesmo setting que a tela de Início usa (exec_headless), pra abrir
  // headless automaticamente quando ela já está ativada (pedido do usuário
  // 2026-08-09), sem precisar de um checkbox extra só pra esse fluxo.
  const headless = getSettingSync("exec_headless", "0") === "1";
  if (useRealChrome()) {
    const { openRealChromiumForContas } = require("./realchrome/realChromeManager.cjs");
    return openRealChromiumForContas(arr, delaySec, headless);
  }
  const target = getTargetDisplay();
  const area = target.workArea;
  const gridRows = Math.max(1, parseInt(getSettingSync("grid_rows", "2"), 10) || 2);
  const gridCols = Math.max(1, parseInt(getSettingSync("grid_cols", "5"), 10) || 5);
  const reduzir = getSettingSync("reduzir_janelas", "0") === "1";
  const gap = reduzir ? -7 : 5;
  const openCount = arr.length;
  const cols = gridCols;
  const rows = Math.max(gridRows, Math.ceil(openCount / cols));
  const customBounds = reduzir ? null : getCustomWindowBounds(area, openCount);
  const delayMs = Math.max(0, Math.round(Number(delaySec) || 0) * 1000);
  const proxies = getActiveProxiesSync();
  const createdWins = [];
  const splashPath = path.join(ROOT_DIR, "assets", "splash.html");

  const sessionsBatch = await mapWithConcurrency(arr.length, SESSION_SETUP_CONCURRENCY, async (i) => {
      const ses = session.fromPartition(`persist:chromium-conta-${i + 1}-${Date.now()}`);
      const uaPick = nextSessionUA();
      ses.setUserAgent(uaPick.ua); if (uaPick.profile) applyMobileHeaders(ses, uaPick.profile);
      try { applyBlockedDomainsToSession(ses); } catch {}
      try { ses.setPermissionRequestHandler((_w,_p,cb)=>{ try{cb(true);}catch{} }); ses.setPermissionCheckHandler(()=>true); } catch {}
      const proxy = proxies.length ? proxies[i % proxies.length] : null;
      const [proxyResult] = await Promise.all([
        proxy ? applyProxyToSession(ses, proxy) : Promise.resolve({ ok: true }),
        loadCaptchaExtension(ses).catch(() => {}),
        loadCustomExtensionIfActive(ses).catch(() => {}),
      ]);
      if (uaPick.profile) console.log(`[openContas] sessão #${i + 1} [mobile:${uaPick.profile.name}]`);
      return { ses, proxy, proxyResult, uaPick };
  });

  for (let i = 0; i < openCount; i++) {
    const conta = arr[i];
    const { ses, proxy, proxyResult, uaPick } = sessionsBatch[i];
    const bounds = customBounds?.[i] || gridWindowBounds(area, cols, rows, i, gap);
    const win = new BrowserWindow({
      width: bounds.width, height: bounds.height,
      x: bounds.x, y: bounds.y,
      title: `Chromium #${i + 1} — ${conta.login || ""}`,
      backgroundColor: "#000000", autoHideMenuBar: true,
      hasShadow: true, thickFrame: true, frame: false,
      titleBarStyle: "hidden",
      titleBarOverlay: { color: "#00000000", symbolColor: "#e8e8e8", height: 32 },
      icon: APP_ICON,
      webPreferences: {
        session: ses,
        preload: path.join(ROOT_DIR, "chromium-preload.cjs"),
        contextIsolation: false, nodeIntegration: false, sandbox: false,
        nodeIntegrationInSubFrames: true,
        backgroundThrottling: false,
        webSecurity: false,
      },
    });
    relaxWebContentsMaxListeners(win);
    if (uaPick && uaPick.profile) win._pandoraMobileProfile = uaPick.profile;
    applyStealth(win, uaPick);
    applyHiddenNavMode(win);
    applyAppMode(win);
    enableDevTools(win);
    if (proxy) { attachProxyLogin(win, ses); attachProxyTunnelRetry(win, ses); }
    try {
      if (process.platform === "win32") {
        win.setAppDetails({
          appId: `pandora.chromium.conta.${i + 1}.${Date.now()}`,
          relaunchDisplayName: `Chromium #${i + 1}`,
          relaunchIconResource: `${APP_ICON},0`,
        });
        try { win.setIcon(APP_ICON); } catch {}
      }
    } catch {}
    try { if (fs.existsSync(splashPath)) { const __dn = (uaPick && uaPick.profile && uaPick.profile.name) ? uaPick.profile.name : ""; win.loadFile(splashPath, __dn ? { search: "device=" + encodeURIComponent(__dn) } : undefined); } } catch {}
    try { attachUrlAsTitle(win); } catch {}
    win._targetUrl = conta.url;
    win._proxyReady = proxyResult.ok;
    win._proxyError = proxyResult.error || "Proxy sem resposta";
    win._contaAutoLogin = { login: conta.login || "", senha: conta.senha || "" };
    // Pedido do usuário 2026-08-10 (2ª rodada): "tem que aparecer se o
    // login for feito realmente" — poll do lado do Node (sobrevive a
    // reloads da página), mesma função do caminho Chrome real — ver
    // waitAndLogLoginRealizado em realChromeManager.cjs.
    try { require("./realchrome/realChromeManager.cjs").waitAndLogLoginRealizado(win, i + 1); } catch {}
    win.webContents.on("did-finish-load", () => {
      if (win.webContents.getURL().startsWith("file://")) return;
      showProxyIpOnWindow(win, ses).then(() => enforceUniqueIp(win, ses)).catch(() => {});
    });
    try { attachBrowserToolbar(win); } catch (e) { console.warn("[toolbar]", e?.message); }
    try { attachContaAutoLogin(win); } catch (e) { console.warn("[autologin] falhou:", e?.message); }
    attachGenericLoadRetry(win);
    attachAutoRegister(win, state.db, saveDB, state.dbPath);
    try {
      const { iniciarAutoCaptura } = require(path.join(ROOT_DIR, "autoCaptura.cjs"));
      const parar = iniciarAutoCaptura(win.webContents, conta.url, state.mainWin, { chromeWin: win });
      win.on('closed', () => { try { parar && parar(); } catch {} });
    } catch (e) { console.warn('[autoCaptura] falhou:', e?.message); }
    try { attachGeetestSolver(win); } catch (e) { console.warn("[geetest] attach falhou:", e?.message); }
    try { attachPixModalEnhancer(win); } catch (e) { console.warn("[pix] attach falhou:", e?.message); }
    try { attachPopupCloser(win); } catch (e) { console.warn("[popup] attach falhou:", e?.message); }
    registerChromeWin(win);
    createdWins.push(win);
    try {
      const ord = win._pandoraOrder || (i + 1);
      logSystem(
        `Tela #${ord} aberta — Conta: ${conta.login || "(sem login)"} | Senha: ${conta.senha || "-"} | Dispositivo: ${describeDevice(uaPick && uaPick.profile)}`,
        { tela: ord, login: conta.login, senha: conta.senha, dispositivo: describeDevice(uaPick && uaPick.profile), os: uaPick && uaPick.profile ? uaPick.profile.os : "desktop" },
        "info", "telas"
      );
    } catch {}
  }

  (async () => {
    for (let i = 0; i < createdWins.length; i++) {
      const win = createdWins[i];
      if (!win || win.isDestroyed()) continue;
      if (i > 0 && delayMs > 0) await new Promise((r) => setTimeout(r, delayMs));
      if (!win.isDestroyed()) {
        if (win._proxyReady) try { win.loadURL(arr[i].url); } catch {}
        else showWindowMessage(win, "Proxy não conectou", win._proxyError);
      }
    }
  })();
  return state.chromeWins.length;
}

function openWorkerWindows(count, accounts = []) {
  closeWorkerWindows();
  const target = getTargetDisplay();
  const area = target.workArea;
  const reduzir = getSettingSync("reduzir_janelas", "0") === "1";
  const gap = reduzir ? -7 : 5;
  const cols = Math.max(1, parseInt(getSettingSync("grid_cols", String(Math.ceil(Math.sqrt(count)))), 10) || Math.ceil(Math.sqrt(count)));
  const rows = Math.ceil(count / cols);
  const customBounds = reduzir ? null : getCustomWindowBounds(area, count);
  for (let i = 0; i < count; i++) {
    const acc = accounts[i] || null;
    const bounds = customBounds?.[i] || gridWindowBounds(area, cols, rows, i, gap);
    const win = new BrowserWindow({
      width: bounds.width, height: bounds.height, x: bounds.x, y: bounds.y,
      title: acc ? `Worker #${i + 1} — ${acc.label || acc.username || ""}` : `Worker #${i + 1}`,
      backgroundColor: "#000000", autoHideMenuBar: true,
      hasShadow: true, thickFrame: true, frame: true,
      icon: APP_ICON,
      webPreferences: {
        preload: path.join(ROOT_DIR, "preload.cjs"),
        contextIsolation: true, nodeIntegration: false, sandbox: false,
      },
    });
    const hash = `worker?idx=${i + 1}&accId=${acc?.id ?? ""}`;
    if (isDev) win.loadURL("http://localhost:5173#" + hash);
    else win.loadFile(path.join(ROOT_DIR, "..", "dist", "index.html"), { hash });
    state.workerWins.push(win);
    win.on("closed", () => { state.workerWins = state.workerWins.filter((x) => x !== win); });
  }
  return state.workerWins.length;
}

function closeWorkerWindows() {
  for (const w of state.workerWins) { try { w.close(); } catch {} }
  state.workerWins = [];
}

// "Nova guia" — abre uma janela adicional reaproveitando a MESMA sessão da
// janela de origem (cookies/login continuam válidos, como uma aba de
// verdade), sem re-configurar proxy (já aplicado nessa sessão) nem fechar as
// outras janelas abertas. Usada pelo botão "+" da toolbar (browserInjections.cjs).
function openNewTabForWindow(sourceWin) {
  if (!sourceWin || sourceWin.isDestroyed()) return null;
  const ses = sourceWin.webContents.session;
  const url = sourceWin.webContents.getURL() || sourceWin._targetUrl || "";
  if (!url) return null;
  const b = sourceWin.getBounds();
  const win = new BrowserWindow({
    width: b.width, height: b.height, x: b.x + 24, y: b.y + 24,
    title: "Nova guia",
    backgroundColor: "#000000", autoHideMenuBar: true,
    hasShadow: true, thickFrame: true, frame: false,
    titleBarStyle: "hidden",
    titleBarOverlay: { color: "#00000000", symbolColor: "#e8e8e8", height: 32 },
    icon: APP_ICON,
    webPreferences: {
      session: ses,
      preload: path.join(ROOT_DIR, "chromium-preload.cjs"),
      contextIsolation: false, nodeIntegration: false, sandbox: false,
      nodeIntegrationInSubFrames: true,
      backgroundThrottling: false,
      webSecurity: false,
    },
  });
  relaxWebContentsMaxListeners(win);
  win._pandoraMobileProfile = sourceWin._pandoraMobileProfile;
  applyStealth(win, { profile: win._pandoraMobileProfile });
  applyHiddenNavMode(win);
  applyAppMode(win);
  enableDevTools(win);
  if (ses._assignedProxy) { attachProxyLogin(win, ses); attachProxyTunnelRetry(win, ses); }
  try { attachUrlAsTitle(win); } catch {}
  win._targetUrl = url;
  win._proxyReady = true;
  win.webContents.on("did-finish-load", () => {
    if (win.webContents.getURL().startsWith("file://")) return;
    showProxyIpOnWindow(win, ses).then(() => enforceUniqueIp(win, ses)).catch(() => {});
  });
  try { attachBrowserToolbar(win); } catch (e) { console.warn("[toolbar]", e?.message); }
  attachGenericLoadRetry(win);
  attachAutoRegister(win, state.db, saveDB, state.dbPath);
  try {
    const { iniciarAutoCaptura } = require(path.join(ROOT_DIR, "autoCaptura.cjs"));
    const parar = iniciarAutoCaptura(win.webContents, url, state.mainWin, { chromeWin: win });
    win.on("closed", () => { try { parar && parar(); } catch {} });
  } catch (e) { console.warn("[autoCaptura] falhou:", e?.message); }
  try { attachGeetestSolver(win); } catch (e) { console.warn("[geetest] attach falhou:", e?.message); }
  try { attachPixModalEnhancer(win); } catch (e) { console.warn("[pix] attach falhou:", e?.message); }
  try { attachPopupCloser(win); } catch (e) { console.warn("[popup] attach falhou:", e?.message); }
  registerChromeWin(win);
  try { win.loadURL(url); } catch {}
  return win;
}

module.exports = {
  getSelectedChromeWins,
  closeChromiumWindows,
  openChromiumWindows,
  openChromiumMulti,
  openChromiumForContas,
  openWorkerWindows,
  closeWorkerWindows,
  openNewTabForWindow,
};
