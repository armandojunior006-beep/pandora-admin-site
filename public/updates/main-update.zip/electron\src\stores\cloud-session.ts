import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface CloudSession {
  login: string;
  token: string | null;          // token bruto, usado pelo heartbeat
  plan_key: string | null;
  expires_at: string | null;     // ISO ou null (vitalício / não ativado)
  confirmed_at: string;          // quando o token foi confirmado neste device
}

interface State {
  session: CloudSession | null;
  setSession: (s: CloudSession | null) => void;
  clear: () => void;
}

export const useCloudSession = create<State>()(
  persist(
    (set) => ({
      session: null,
      setSession: (session) => set({ session }),
      clear: () => set({ session: null }),
    }),
    { name: "pandora-cloud-session" },
  ),
);

export function planLabel(plan_key: string | null | undefined): string {
  switch ((plan_key || "").toLowerCase()) {
    case "diario": case "daily": return "Diário";
    case "semanal": case "weekly": return "Semanal";
    case "mensal": case "monthly": return "Mensal";
    case "vitalicio": case "lifetime": return "Vitalício";
    default: return plan_key || "—";
  }
}

export function formatExpiry(iso: string | null | undefined): string {
  if (!iso) return "Vitalício";
  try {
    const d = new Date(iso);
    return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
  } catch { return "—"; }
}
