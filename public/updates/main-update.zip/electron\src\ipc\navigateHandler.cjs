// ============================================================================
// IPC: chrome:navigate — navega as janelas selecionadas para um path relativo
// à origin atual, com scripts especiais por rota: fechador de popups da Home,
// preenchimento automático da senha de segurança, "Valor Fixo" + confirmação
// no Saque e travamento de scroll na tela de Baús.
// ============================================================================
const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");
const {
  getWithdrawPin, buildSecurityPinScript, sendSecurityPinNative, scheduleSecurityPinFill,
} = require("../security/securityPin.cjs");

function registerNavigateHandler(ipcMain) {
  ipcMain.handle("chrome:navigate", (_e, urlOrPath) => {
    if (!urlOrPath) return 0;
    const input = String(urlOrPath);
    // Se vier URL absoluta, extrai apenas path+query+hash para usar o origin
    // da janela atual; assim funciona em qualquer domínio aberto.
    let pathPart = input;
    try {
      if (/^https?:\/\//i.test(input)) {
        const u = new URL(input);
        pathPart = u.pathname + u.search + u.hash;
      }
    } catch {}
    if (!pathPart.startsWith("/")) pathPart = "/" + pathPart;

    // Página de definição de senha de saque (security). Após navegar, injeta
    // a mesma senha de 6 dígitos nos dois grupos do ui-password-input.
    const isSecurity = /\/home\/security\b/.test(pathPart) || /[?&]active=5\b/.test(pathPart);
    const isHome = pathPart === "/" || pathPart === "" || /^\/(\?|#|$)/.test(pathPart);
    // 2026-08-09: TODA a lógica de "Relatório de Apostas" (isReport,
    // reportTabClicker, wiring de did-finish-load) foi removida a pedido do
    // usuário — várias tentativas (origin inválido, reportCurrent=1/3,
    // clique injetado na aba) não resolveram de forma confiável. O botão não
    // tem mais entrada no navMap (Operacao.tsx), então esse handler nunca
    // mais recebe pathPart="/home/report..." na prática. Reconstrução do
    // zero, sob comando do usuário.

    // Script que fecha apenas banners promocionais grandes da home e protege
    // o botão de fechar do diálogo de retenção contra cliques automatizados.
    const homePopupCloser = `
      (function(){
        if (window.__pandoraHomePopupCloser) return;
        window.__pandoraHomePopupCloser = true;
        let closed = 0;
        const t0 = Date.now();
        function injetarImunidadeCSS(){
          try {
            var estiloId = 'trava-antifecho-lembrete';
            if (document.getElementById(estiloId)) return;
            if (!document.head) { setTimeout(injetarImunidadeCSS, 50); return; }
            var style = document.createElement('style');
            style.id = estiloId;
            style.innerHTML = '._retention-dialog_tsbju_93, ._retention-dialog_tsbju_93 .ui-dialog-close-box, ._retention-dialog_tsbju_93 .ui-dialog-close-box__icon, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-dialog-close-box, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-dialog-close-box__icon { pointer-events: none !important; user-select: none !important; } ._retention-dialog_tsbju_93 .ui-button, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-button { pointer-events: auto !important; }';
            document.head.appendChild(style);
            console.log('-> [Spider Core] Imunidade CSS do Lembrete injetada.');
          } catch(e){}
        }
        injetarImunidadeCSS();
        function protegerFechamentoLembrete(){
          try {
            const popupRetencao = document.querySelector('._retention-dialog_tsbju_93');
            if (!popupRetencao) return;
            const botoes = popupRetencao.querySelectorAll('.ui-dialog-close-box, .ui-dialog-close-box__icon');
            botoes.forEach(function(botaoFecharLembrete){
              try {
                if (!botaoFecharLembrete || botaoFecharLembrete.hasAttribute('data-protegido')) return;
                console.log('-> [Spider Core] Alvo detetado: Protegendo o diálogo de retenção contra fecho automático.');
                botaoFecharLembrete.setAttribute('data-protegido', 'true');
                botaoFecharLembrete.addEventListener('click', function(e){
                  if (e && e.isTrusted) return;
                  try { e.preventDefault(); e.stopImmediatePropagation(); e.stopPropagation(); } catch(_e){}
                  console.log('-> [Spider Core] Tentativa de fecho automatizado bloqueada com sucesso.');
                }, true);
                botaoFecharLembrete.click = function(e) {
                  if (e && e.isTrusted) {
                    HTMLElement.prototype.click.call(this);
                  } else {
                    console.log('-> [Spider Core] Tentativa de fecho automatizado bloqueada com sucesso.');
                  }
                };
              } catch(e){}
            });
          } catch(e){}
        }
        function visivel(el){
          try {
            if (!el || !el.isConnected) return false;
            var r = el.getBoundingClientRect();
            if (r.width < 2 || r.height < 2) return false;
            var s = getComputedStyle(el);
            if (s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity||1) < 0.05) return false;
            return true;
          } catch(e){ return false; }
        }
        function ehModalSeguro(root){
          try {
            var hay = ((root && (root.innerText || root.textContent)) || '').toLowerCase();
            if (/dep[oó]sito|deposit|recarga|recarregar|sacar|saque|withdraw|pix|chave|senha de saque|security|pin de seguran|cadastr|registr|sign\\s*up|criar conta/i.test(hay)) return true;
            // BUG GRAVE real 2026-08-09 (mesma causa raiz do "Relatório de
            // Apostas" sempre em branco — ver isSafeModal em autoLogin.cjs,
            // fix idêntico aqui porque essa é uma SEGUNDA cópia da mesma
            // lógica): a tela de Conta/Apostas/Relatório/Recuperar o Saldo
            // tem uma seta "voltar" que bate nos seletores genéricos de
            // botão-de-fechar — sem essas palavras na lista segura, o
            // fechador da Home (ainda rodando 30s depois de uma navegação
            // pra Home, via SPA) escondia a tela inteira.
            if (/\\bconta\\b|relat[óo]rio de apostas|relat[óo]rio\\b|recuperar o saldo|recuperar saldo perdido|saldo atual|meus registros|minhas apostas|gest[ãa]o de saques/i.test(hay)) return true;
            var cls = ((root && root.className) || '') + '';
            if (/deposit|withdraw|recharge|security|pix|login|loginTab|register|signup|cadastro/i.test(cls)) return true;
            if (root && root.querySelector && root.querySelector('input[data-input-name="account"], input[data-input-name="userpass"], #loginTabButton')) return true;
          } catch(e){}
          return false;
        }
        function verificarEBloquear(){
          if (Date.now() - t0 > 30000 || closed >= 10) { clearInterval(iv); return; }
          try {
            injetarImunidadeCSS();
            protegerFechamentoLembrete();

            var botoesFechar = document.querySelectorAll('.ui-dialog-close-box, .ui-dialog-close-box__icon, [class*="close-box"], [class*="closeBox"], [class*="close-btn"], [class*="closeBtn"], .close-icon, .popup-close, [aria-label="Close" i], [aria-label="Fechar" i], [aria-label="close" i]');
            botoesFechar.forEach(function(botao){
              try {
                if (botao.hasAttribute('data-protegido') || botao.hasAttribute('data-pandora-tentei')) return;
                var conteinerPai = botao.closest('.ui-popup, .ui-dialog, .ui-overlay, [role="dialog"], [class*="popup"], [class*="dialog"], [class*="modal"], body > div');
                if (!conteinerPai || !visivel(conteinerPai)) return;
                var textoDoConteiner = (conteinerPai.textContent || "").toLowerCase();

                if (textoDoConteiner.includes("retornar") ||
                    textoDoConteiner.includes("continuar a pagar") ||
                    textoDoConteiner.includes("histórico de depósitos") ||
                    conteinerPai.querySelector('._retention-dialog_tsbju_93')) {
                  return;
                }
                if (ehModalSeguro(conteinerPai)) return;

                botao.setAttribute('data-pandora-tentei', '1');
                try { botao.click(); } catch(_e){}
                try {
                  var ev = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
                  botao.dispatchEvent(ev);
                } catch(_e){}
                setTimeout(function(){
                  try {
                    if (conteinerPai && conteinerPai.isConnected && visivel(conteinerPai) && !ehModalSeguro(conteinerPai)) {
                      conteinerPai.style.setProperty('display', 'none', 'important');
                    }
                  } catch(_e){}
                }, 400);
                closed++;
              } catch(e){}
            });
          } catch(e){}
        }

        try {
          const observer = new MutationObserver(verificarEBloquear);
          observer.observe(document.body, { childList: true, subtree: true });
        } catch(e){}
        const iv = setInterval(verificarEBloquear, 500);
        verificarEBloquear();
      })();
    `;


    // Página de Saque: ao detectar /home/withdraw, aguarda surgir o botão
    // "Tudo" (span._allAmount_*), clica e congela a sessão para o robô não
    // avançar sozinho.
    const isWithdraw = /\/home\/withdraw\b/.test(pathPart);
    const withdrawTudoHalter = `
      (function(){
        if (window.__PANDORA_VALOR_SAQUE_EXECUTADO__) return;
        if (!/\\/home\\/withdraw/i.test(window.location.href)) return;
        window.__PANDORA_VALOR_SAQUE_EXECUTADO__ = true;
        var VALOR_FIXO = '5000';
        try { console.log('__PANDORA_SAQUE__ Tela de saque detectada. Aguardando campo de valor para preencher ' + VALOR_FIXO + '...'); } catch(e){}

        function setarValorReact(input, valor){
          try {
            var proto = Object.getPrototypeOf(input);
            var setter = Object.getOwnPropertyDescriptor(proto, 'value') && Object.getOwnPropertyDescriptor(proto, 'value').set;
            if (setter) { setter.call(input, valor); } else { input.value = valor; }
          } catch(e){ try { input.value = valor; } catch(e2){} }
          try { input.dispatchEvent(new Event('input', { bubbles: true })); } catch(e){}
          try { input.dispatchEvent(new Event('change', { bubbles: true })); } catch(e){}
          try { input.dispatchEvent(new Event('blur', { bubbles: true })); } catch(e){}
        }

        function acharInputValor(){
          // ESTRITO: apenas inputs com placeholder Mínimo/Máximo. Nunca cair em
          // fallback genérico (.ui-input__input) — isso vazava o valor 5000
          // dentro do campo da chave PIX quando ele aparecia na tela.
          var BAD_NAME = /(pix|chave|key|cpf|cnpj|name|nome|userpass|password|phone|telefone|email|user|login|search|busca)/i;
          function ok(el){
            if (!el) return false;
            if ((el.type||'').toLowerCase() === 'password') return false;
            var meta = (el.getAttribute('data-input-name')||'') + ' ' + (el.name||'') + ' ' + (el.id||'') + ' ' + (el.getAttribute('aria-label')||'');
            if (BAD_NAME.test(meta)) return false;
            return true;
          }
          var nodes = document.querySelectorAll('section.ui-input__input-container input.ui-input__input, input.ui-input__input, input');
          for (var i=0; i<nodes.length; i++){
            var el = nodes[i];
            var ph = (el.getAttribute('placeholder') || '');
            if ((/M[ií]nimo/i.test(ph) || /M[aá]ximo/i.test(ph)) && ok(el)) return el;
          }
          return null;
        }

        var preenchido = false;
        var tentativas = 0;
        var iv = setInterval(function(){
          tentativas++;
          try {
            var input = acharInputValor();
            if (input) {
              try { input.focus(); } catch(e){}
              setarValorReact(input, VALOR_FIXO);
              // confirma após 200ms se o framework sobrescrever
              setTimeout(function(){
                try {
                  if ((input.value || '') !== VALOR_FIXO) setarValorReact(input, VALOR_FIXO);
                } catch(e){}
              }, 250);
              preenchido = true;
              try { window.__pandoraValorSaquePreenchido = Date.now(); } catch(e){}
              try { console.log('__PANDORA_SAQUE__ Valor ' + VALOR_FIXO + ' preenchido no campo de quantia.'); } catch(e){}
              clearInterval(iv);
              try { window.__pandoraAtivarParada = ativarParadaTotalSessao; } catch(e){}
            }
          } catch(e){}
          if (tentativas > 80) { clearInterval(iv); }
        }, 300);

        // Watcher: se o valor for limpo/alterado pelo site antes de confirmar, recoloca.
        setInterval(function(){
          try {
            if (!preenchido) return;
            var input = acharInputValor();
            if (input && (input.value || '') !== VALOR_FIXO) {
              setarValorReact(input, VALOR_FIXO);
              try { console.log('__PANDORA_SAQUE__ Valor reescrito (estava ' + (input.value||'') + ').'); } catch(e){}
            }
          } catch(e){}
        }, 600);

        // Após preencher, busca e clica em "Confirmar saque" quando o botão estiver habilitado
        var ivConfirm = setInterval(function(){
          try {
            if (!preenchido) return;
            var btn = null;
            var txts = document.querySelectorAll('.ui-button__text, button, div');
            for (var i=0; i<txts.length; i++){
              var t = ((txts[i].innerText || txts[i].textContent || '') + '').trim();
              if (/^Confirmar\\s+saque$/i.test(t)) {
                var cand = txts[i].closest('button, [role="button"], .ui-button, [class*="button"]') || txts[i].parentElement;
                if (cand) { btn = cand; break; }
              }
            }
            if (!btn) return;
            var disabled = btn.disabled || btn.getAttribute('disabled') != null
              || /disabled|is-disabled|--disabled/i.test(btn.className || '')
              || btn.getAttribute('aria-disabled') === 'true';
            if (disabled) return;
            try { btn.click(); } catch(e){}
            try { btn.dispatchEvent(new MouseEvent('click', { bubbles: true })); } catch(e){}
            try { console.log('__PANDORA_SAQUE__ Clicou em "Confirmar saque". Em 1s navega para /home/withdraw?active=3.'); } catch(e){}
            clearInterval(ivConfirm);
            setTimeout(function(){
              try {
                // NUNCA hardcoded um domínio absoluto aqui — o site roda em
                // vários domínios-espelho que trocam com o tempo (já vimos
                // voy-hallwaypg.com, voy-incensepg.com, 91-handsetpg.com...).
                // Usar location.origin garante ficar SEMPRE na mesma
                // plataforma que a janela já está, nunca pulando pra outra.
                var dest = window.location.origin + '/home/withdraw?active=3';
                try { console.log('__PANDORA_SAQUE__ Navegando para ' + dest); } catch(e){}
                try { window.location.replace(dest); } catch(e){
                  try { window.location.href = dest; } catch(e2){
                    try { window.location.reload(); } catch(e3){}
                  }
                }
              } catch(e){}
            }, 1000);
          } catch(e){}
        }, 400);

        function ativarParadaTotalSessao(){
          try {
            if (window.history && window.history.pushState) {
              window.history.pushState(null, null, window.location.href);
              window.onpopstate = function(){ window.history.go(1); };
            }
          } catch(e){}
          try { console.log('__PANDORA_SAQUE__ [HALT] Sessão estacionada após preencher valor.'); } catch(e){}
        }
      })();
    `;

    // 2026-08-09: TODA a lógica de "Página de Baús" (isBaus,
    // scrollTopLocker, wiring de did-start-loading/dom-ready/did-finish-load)
    // foi removida a pedido do usuário — arquivo próprio agora
    // (src/ipc/bausHandler.cjs), só com a navegação e nada mais.

    // Tentativa de espalhar a navegação no tempo (2026-08-09) foi testada e
    // REVERTIDA — piorou (5/5 telas em branco em vez de 4/5). Não era isso.
    //
    // 2026-08-09 (cont.): win.loadURL() engolia qualquer falha (timeout,
    // net::ERR_ABORTED etc.) em silêncio — não dava pra saber SE e POR QUÊ
    // uma tela ficava em branco no relatório. Agora loga o resultado real de
    // cada tela no diag log, sem awaitar nada aqui (mantém o disparo em
    // paralelo, idêntico ao comportamento atual — só adiciona visibilidade).
    const diagLine = (msg) => {
      try {
        const { queueDiagLine } = require("../../auto-register.cjs");
        if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [chrome:navigate] ${msg}\r\n`);
      } catch {}
    };
    let n = 0;
    let idx = 0;
    for (const win of getSelectedChromeWins()) {
      idx++;
      const telaNum = idx;
      try {
        if (!win || win.isDestroyed() || win._proxyReady === false) continue;
        // Bug real 2026-08-09: quando a janela está travada numa página de
        // erro do Chrome (chrome-error://chromewebdata/, ex.: proxy caiu
        // antes), `new URL(url).origin` NÃO lança e NÃO fica vazio — devolve
        // a STRING LITERAL "null" (é assim que o spec de URL trata origin de
        // esquemas não-especiais). Isso passava batido pelo `if (!origin)`
        // (que só pega vazio) e gerava um destino inválido
        // ("null/home/report?..."), rejeitado pelo CDP — a tela ficava
        // travada sem NENHUM aviso. Agora exige explicitamente http(s).
        let origin = "";
        try {
          const o = new URL(win.webContents.getURL()).origin;
          if (/^https?:\/\//i.test(o)) origin = o;
        } catch {}
        if (!origin) {
          try {
            const o = new URL(win._targetUrl || input).origin;
            if (/^https?:\/\//i.test(o)) origin = o;
          } catch {}
        }
        if (!origin) {
          diagLine(`tela #${telaNum} pulada — sem origin http(s) válido (getURL="${(() => { try { return win.webContents.getURL(); } catch { return "?"; } })()}", _targetUrl="${win._targetUrl || ""}")`);
          continue;
        }
        if (isSecurity) {
          scheduleSecurityPinFill(win, getWithdrawPin(win));
        }
        const dest = origin + pathPart;
        Promise.resolve(win.loadURL(dest)).then((ok) => {
          diagLine(`tela #${telaNum} -> ${dest} : ${ok === false ? "FALHOU (ver [webContentsShim] acima)" : "ok"}`);
        }).catch((e) => {
          diagLine(`tela #${telaNum} -> ${dest} : erro inesperado no loadURL: ${e?.message || e}`);
        });
        if (isHome) {
          const wc2 = win.webContents;
          const fire = () => { try { wc2.executeJavaScript(homePopupCloser, true).catch(()=>{}); } catch {} };
          const onDone = () => { try { wc2.__pandoraHomePopupCloser = false; } catch {} setTimeout(fire, 400); setTimeout(fire, 1500); setTimeout(fire, 4000); };
          wc2.once("did-finish-load", onDone);
        }
        if (isWithdraw) {
          const wc4 = win.webContents;
          const senhaSaqueW = getWithdrawPin(win);
          const fireW = () => { try { wc4.executeJavaScript(withdrawTudoHalter, true).catch(()=>{}); } catch {} };
          const firePin = () => {
            try { wc4.executeJavaScript(buildSecurityPinScript(senhaSaqueW), true).catch(()=>{}); } catch {}
            // Ver comentário em securityPin.cjs/scheduleSecurityPinFill — restrito
            // ao Electron antigo, senão digita os dígitos duplicado em Chrome real.
            if (!win._realChrome) {
              setTimeout(() => { try { sendSecurityPinNative(wc4, senhaSaqueW); } catch {} }, 500);
              setTimeout(() => { try { sendSecurityPinNative(wc4, senhaSaqueW); } catch {} }, 1500);
            }
          };
          // Watcher: assim que o buildSecurityPinScript marcar
          // __pandoraSecPinConfirmed = true (i.e. confirmou retirada), congela
          // imediatamente a sessão e força navegação para ?active=3 caso a
          // página não tenha transicionado sozinha.
          const watcherScript = `(function(){
            if (window.__pandoraSaqueWatcherOn) return;
            window.__pandoraSaqueWatcherOn = true;
            var t = setInterval(function(){
              try {
                if (window.__pandoraSecPinConfirmed === true) {
                  clearInterval(t);
                  try { console.log('__PANDORA_SAQUE__ Confirmar retirada detectado — aguardando 1s para recarregar e navegar.'); } catch(e){}
                  try { if (typeof window.__pandoraAtivarParada === 'function') window.__pandoraAtivarParada(); } catch(e){}
                  setTimeout(function(){
                    // Idem: nunca hardcoded — usa o domínio atual da janela.
                    var u = window.location.origin + '/home/withdraw?active=3';
                    try { console.log('__PANDORA_SAQUE__ Navegando para ' + u); } catch(e){}
                    try { window.location.replace(u); } catch(e){
                      try { window.location.href = u; } catch(e2){
                        try { window.location.reload(); } catch(e3){}
                      }
                    }
                  }, 1000);
                }
              } catch(e){}
            }, 50);
          })();`;
          const fireWatcher = () => { try { wc4.executeJavaScript(watcherScript, true).catch(()=>{}); } catch {} };
          const onDoneW = () => {
            setTimeout(fireW, 300);
            setTimeout(fireW, 1200);
            setTimeout(fireW, 3000);
            // dispara a senha após o clique em "Tudo" ter tempo de aplicar valor
            setTimeout(firePin, 2200);
            setTimeout(firePin, 5000);
            setTimeout(firePin, 9000);
            // Watcher: detecta clique em "Confirmar retirada" e, após 1s,
            // recarrega/navega para /home/withdraw?active=3
            setTimeout(fireWatcher, 500);
            setTimeout(fireWatcher, 2000);
            setTimeout(fireWatcher, 6000);

          };
          wc4.once("dom-ready", () => setTimeout(fireW, 100));
          wc4.once("did-finish-load", onDoneW);
        }
        n++;
      } catch {}
    }
    return n;
  });
}

module.exports = { registerNavigateHandler };
