import { create } from "zustand";

export type TabKey = "inicio" | "chaves" | "contas" | "proxies" | "telas" | "operacao" | "mercadopago";

interface UIState {
  activeTab: TabKey;
  setTab: (t: TabKey) => void;
  toast: { msg: string; tone: "success" | "error" | "info" } | null;
  showToast: (msg: string, tone?: "success" | "error" | "info") => void;
  running: boolean;
  setRunning: (v: boolean) => void;
}

export const useUI = create<UIState>((set) => ({
  activeTab: "inicio",
  setTab: (t) => set({ activeTab: t }),
  toast: null,
  showToast: (msg, tone = "info") => {
    set({ toast: { msg, tone } });
    setTimeout(() => set({ toast: null }), 3000);
  },
  running: false,
  setRunning: (running) => set({ running }),
}));
