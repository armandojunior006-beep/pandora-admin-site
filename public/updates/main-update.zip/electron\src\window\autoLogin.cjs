// ============================================================================
// Auto-login por conta (janelas abertas via "Abrir Selecionadas") e fechador
// automático de popups/banners (opção "Sem anúncios"). Ambos injetam script
// no DOM da página visitada e se reaplicam a cada navegação.
// ============================================================================
const { getSettingSync, logSystem } = require("../settings/settingsStore.cjs");

function attachContaAutoLogin(win) {
  if (!win || win.isDestroyed()) return;
  const wc = win.webContents;
  const apply = () => {
    try {
      const cred = win._contaAutoLogin || {};
      // BUG real 2026-08-10 (reportado pelo usuário: "Conta logada" nunca
      // aparece no log, nem os diagnósticos anteriores de erro de injeção/
      // botão não encontrado) — nenhum deles disparou, sinal de que a
      // função nem chega a tentar injetar nada. Loga bem no início, antes
      // de qualquer return, pra confirmar se apply() roda de verdade e com
      // que credenciais/URL.
      try {
        const { queueDiagLine } = require("../../auto-register.cjs");
        if (typeof queueDiagLine === "function") {
          queueDiagLine(`[${new Date().toISOString()}] [autologin] apply() chamado — url=${(() => { try { return wc.getURL(); } catch { return "?"; } })()} temLogin=${!!cred.login} temSenha=${!!cred.senha}\r\n`);
        }
      } catch {}
      if (!cred.login && !cred.senha) return;
      const url = wc.getURL() || "";
      if (url.startsWith("file://")) return;
      const payload = JSON.stringify({ login: String(cred.login || ""), senha: String(cred.senha || "") });
      const js = `(() => {
        try {
          if (window.__pandoraContaAutoLogin) return;
          window.__pandoraContaAutoLogin = true;
          var cred = ${payload};
          var done = false;
          var startedAt = Date.now();
          var TIMEOUT = 60000;
          function setVal(el, v){
            try {
              var proto = Object.getPrototypeOf(el);
              var d = Object.getOwnPropertyDescriptor(proto, 'value');
              if (d && d.set) d.set.call(el, v); else el.value = v;
              el.dispatchEvent(new Event('input', { bubbles: true }));
              el.dispatchEvent(new Event('change', { bubbles: true }));
            } catch(e){ try { el.value = v; } catch(e2){} }
          }
          function pickInputs(){
            // Prioriza seletores específicos do cassino (account/userpass).
            var loginEl = document.querySelector('input[data-input-name="account"], textarea[data-input-name="account"]');
            var senhaEl = document.querySelector('input[data-input-name="userpass"], textarea[data-input-name="userpass"]');
            if (loginEl && senhaEl && loginEl.offsetParent && senhaEl.offsetParent) {
              return { loginEl: loginEl, senhaEl: senhaEl };
            }
            // Fallback heurístico (qualquer site genérico).
            var inputs = Array.prototype.slice.call(document.querySelectorAll('input,textarea'));
            if (!loginEl || !loginEl.offsetParent) loginEl = null;
            if (!senhaEl || !senhaEl.offsetParent) senhaEl = null;
            for (var i=0;i<inputs.length;i++){
              var el = inputs[i];
              if (!el.offsetParent) continue;
              var t = (el.type||'').toLowerCase();
              if (t === 'password' && !senhaEl) senhaEl = el;
            }
            for (var j=0;j<inputs.length;j++){
              var el2 = inputs[j];
              if (!el2.offsetParent) continue;
              var t2 = (el2.type||'').toLowerCase();
              if (t2 === 'password' || t2 === 'hidden' || t2 === 'submit' || t2 === 'button') continue;
              if (!loginEl) { loginEl = el2; break; }
            }
            return { loginEl: loginEl, senhaEl: senhaEl };
          }
          function clickLoginTab(){
            try {
              var tab = document.getElementById('loginTabButton');
              if (tab) { tab.click(); return true; }
              var nodes = document.querySelectorAll('span,div,button,a');
              for (var i=0;i<nodes.length;i++){
                var el = nodes[i];
                var txt = (el.textContent||'').trim().toLowerCase();
                if (txt === 'login' || txt === 'entrar') {
                  var cls = (el.className||'')+'';
                  if (/tab|login/i.test(cls) || /tab|login/i.test(el.id||'')) {
                    try { el.click(); return true; } catch(e){}
                  }
                }
              }
            } catch(e){}
            return false;
          }
          function isVisible(el){
            try {
              if (!el || !el.isConnected) return false;
              var r = el.getBoundingClientRect();
              if (r.width < 2 || r.height < 2) return false;
              var s = getComputedStyle(el);
              if (s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity||1) < 0.05) return false;
              return true;
            } catch(e){ return false; }
          }
          function realClick(el){
            try { el.scrollIntoView({ block:'center', inline:'center' }); } catch(e){}
            try {
              var r = el.getBoundingClientRect();
              var x = r.left + Math.max(2, r.width/2), y = r.top + Math.max(2, r.height/2);
              var opts = { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0, buttons:1 };
              try { el.dispatchEvent(new PointerEvent('pointerdown', Object.assign({ pointerType:'mouse' }, opts))); } catch(e){}
              try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch(e){}
              try { el.dispatchEvent(new PointerEvent('pointerup', Object.assign({ pointerType:'mouse' }, opts, { buttons:0 }))); } catch(e){}
              try { el.dispatchEvent(new MouseEvent('mouseup', Object.assign({}, opts, { buttons:0 }))); } catch(e){}
              try { el.dispatchEvent(new MouseEvent('click', Object.assign({}, opts, { buttons:0 }))); } catch(e){}
            } catch(e){}
            try { el.click(); } catch(e){}
          }
          function clickSubmitLogin(){
            try {
              // 1) Procura .ui-button cujo .ui-button__text === "Login"/"Entrar"
              var btns = Array.prototype.slice.call(document.querySelectorAll('.ui-button, [class*="ui-button"]:not(.ui-button__content):not(.ui-button__text)'));
              // Inclui também button/div[role=button]/a para fallback
              btns = btns.concat(Array.prototype.slice.call(document.querySelectorAll('button, div[role="button"], a')));
              for (var i=0;i<btns.length;i++){
                var el = btns[i];
                if (!el || !isVisible(el)) continue;
                if (el.id === 'loginTabButton') continue;
                if (el.closest && el.closest('#loginTabButton')) continue;
                // Ignora .ui-button__content interno (vamos clicar no .ui-button pai)
                var cls0 = ((el.className||'')+'')+'';
                if (/ui-button__content|ui-button__text/.test(cls0)) continue;
                var txtNode = el.querySelector ? el.querySelector('.ui-button__text') : null;
                var txt = ((txtNode ? txtNode.textContent : el.textContent) || '').trim().toLowerCase();
                // Match exato "login"/"entrar" ou se for botão único com esse texto
                if (txt !== 'login' && txt !== 'entrar') continue;
                var cls = cls0.toLowerCase();
                if (/tab\b/.test(cls)) continue;
                if (el.disabled || el.getAttribute('disabled') !== null) continue;
                if (/disabled|is-disabled/.test(cls)) continue;
                realClick(el);
                return true;
              }
            } catch(e){}
            return false;
          }
          function tryFill(){
            if (done) return;
            // BUG real 2026-08-10 (reportado pelo usuário: nem "conta
            // logada" nem NENHUM outro log de auto-login aparecia, mesmo
            // com apply() confirmado rodando com login/senha certos) — o
            // timeout de 60s desistia em total silêncio, sem log nenhum;
            // se pickInputs() nunca achasse os campos, o loop rodava pra
            // sempre sem deixar rastro. Agora loga ao desistir por timeout
            // E periodicamente (a cada ~6s) enquanto ainda não achou nada,
            // com uma amostra dos inputs visíveis na tela nesse momento.
            if (Date.now() - startedAt > TIMEOUT) {
              done = true;
              try {
                var amostraFinal = Array.prototype.slice.call(document.querySelectorAll('input,textarea')).slice(0, 10)
                  .map(function (el) { return JSON.stringify({ tag: el.tagName, type: el.type||'', name: el.getAttribute('data-input-name')||'', visivel: !!el.offsetParent }); }).join(', ');
                console.log('[pandora-autologin] desistiu apos 60s sem achar campo de login/senha. Inputs na tela: ' + amostraFinal);
              } catch(e){}
              return;
            }
            // BUG CRÍTICO real 2026-08-10 (achado com o diagnóstico acima:
            // "nenhum input na página") — a conta reaberta já estava
            // logada de verdade (sessão/cookie salvos de antes), caindo
            // direto na Home — sem formulário de login pra encontrar, o
            // loop ficava esperando pra sempre por um campo que nunca ia
            // aparecer. Mesmo sinal já usado em auto-register.cjs
            // (jaLogado): barra "Começar/Perfil/Depósito" visível E nenhum
            // campo de conta na tela = já logado. Detecta isso primeiro e
            // trata como sucesso imediato, sem esperar timeout nenhum.
            try {
              var bodyTxt = ((document.body && document.body.innerText) || '').toLowerCase();
              var temBarraLogada = /come[çc]ar/.test(bodyTxt) && /perfil/.test(bodyTxt) && /dep[óo]sito/.test(bodyTxt);
              var temCampoConta = !!document.querySelector('input[data-input-name="account"], textarea[data-input-name="account"]');
              if (temBarraLogada && !temCampoConta) {
                done = true;
                try { console.log('[pandora-autologin] login concluido login=' + cred.login + ' (já estava logado — sessão salva)'); } catch(e){}
                return;
              }
            } catch(e){}
            if (!window.__pandoraAutoLoginTries) window.__pandoraAutoLoginTries = 0;
            window.__pandoraAutoLoginTries++;
            try { clickLoginTab(); } catch(e){}
            var f = pickInputs();
            if (!f.loginEl || !f.senhaEl) {
              if (window.__pandoraAutoLoginTries <= 3 || window.__pandoraAutoLoginTries % 10 === 1) {
                try {
                  var amostra = Array.prototype.slice.call(document.querySelectorAll('input,textarea')).slice(0, 10)
                    .map(function (el) { return JSON.stringify({ tag: el.tagName, type: el.type||'', name: el.getAttribute('data-input-name')||'', visivel: !!el.offsetParent }); }).join(', ');
                  // BUG real 2026-08-10 (2ª rodada — "nenhum input na
                  // página" persistia mesmo depois do fix de "já logado",
                  // que também não disparava) — loga MUITO mais nas 3
                  // primeiras tentativas (não só a cada 10), e agora
                  // também document.readyState + um trecho do texto da
                  // página, pra saber se ela está genuinamente em branco
                  // (ainda carregando/redirecionando) ou se tem conteúdo
                  // que só não bate com o texto esperado ("começar/perfil/
                  // depósito").
                  var bodySnippet = ((document.body && document.body.innerText) || '').replace(/\s+/g, ' ').trim().slice(0, 200);
                  console.log('[pandora-autologin] ainda procurando campo de login/senha (tentativa ' + window.__pandoraAutoLoginTries + '). readyState=' + document.readyState + ' url=' + location.href + ' texto="' + bodySnippet + '" Inputs na tela: ' + (amostra || '(nenhum input na página)'));
                } catch(e){}
              }
            }
            if (f.loginEl && f.senhaEl) {
              if (cred.login) setVal(f.loginEl, cred.login);
              if (cred.senha) setVal(f.senhaEl, cred.senha);
              done = true;
              try { console.log('[pandora-autologin] preenchido'); } catch(e){}
              var submitTries = 0;
              function watchLoginResult(){
                // Pedido do usuário 2026-08-09: quando o login em modo
                // headless/Operação Oculta terminar, deve aparecer "Login
                // concluído" no Log de Operações — só clicar em Enviar não
                // é garantia (senha errada, captcha etc.), então confirma
                // observando se os campos de login/senha SOMEM da tela
                // (indício real de que autenticou), até 20s.
                var t0 = Date.now();
                var iv = setInterval(function(){
                  try {
                    var a = document.querySelector('input[data-input-name="account"]');
                    var p = document.querySelector('input[data-input-name="userpass"]');
                    var aVisible = a && a.offsetParent;
                    var pVisible = p && p.offsetParent;
                    if (!aVisible && !pVisible) {
                      clearInterval(iv);
                      try { console.log('[pandora-autologin] login concluido login=' + cred.login); } catch(e){}
                      return;
                    }
                  } catch(e){}
                  if (Date.now() - t0 > 20000) { clearInterval(iv); try { console.log('[pandora-autologin] login sem confirmacao em 20s login=' + cred.login); } catch(e){} }
                }, 500);
              }
              function trySubmit(){
                submitTries++;
                if (clickSubmitLogin()) {
                  try { console.log('[pandora-autologin] submit clicado'); } catch(e){}
                  watchLoginResult();
                  return;
                }
                if (submitTries < 40) { setTimeout(trySubmit, 400); return; }
                // BUG real 2026-08-10 (reportado pelo usuário: "conta
                // logada" nunca aparece no log) — antes desistia em
                // silêncio depois de 40 tentativas sem NENHUM aviso; loga
                // os textos dos botões visíveis achados, pra saber se o
                // texto do botão de login desse site é diferente de
                // "login"/"entrar" (única coisa que clickSubmitLogin
                // reconhece hoje).
                try {
                  var candidatos = Array.prototype.slice.call(document.querySelectorAll('.ui-button, button, div[role="button"], a'))
                    .filter(function (el) { try { return isVisible(el); } catch (e) { return false; } })
                    .slice(0, 15)
                    .map(function (el) { return JSON.stringify((el.textContent || '').trim().slice(0, 30)); })
                    .join(', ');
                  console.log('[pandora-autologin] desistiu — botão de login não encontrado em 40 tentativas. Botões visíveis: ' + candidatos);
                } catch (e) { try { console.log('[pandora-autologin] desistiu — botão de login não encontrado'); } catch (e2) {} }
              }
              setTimeout(trySubmit, 500);
              return;
            }
            setTimeout(tryFill, 600);
          }
          if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', tryFill);
          } else {
            tryFill();
          }
        } catch(e){}
      })();`;
      // Reseta o guard a cada navegação real (não in-page) — feito via flag por URL
      wc.executeJavaScript("try{window.__pandoraContaAutoLogin=false;}catch(e){}", true).catch(() => {});
      // BUG real 2026-08-10 (reportado pelo usuário: "Abrindo contas"
      // aparece no log, mas "Conta logada" nunca aparece) — .catch(() => {})
      // engolia qualquer erro de injeção (ex.: syntax error no script)
      // completamente em silêncio, sem deixar rastro nenhum pra investigar.
      // Agora loga o erro real no diag file se a injeção falhar.
      wc.executeJavaScript(js, true).catch((e) => {
        try {
          const { queueDiagLine } = require("../../auto-register.cjs");
          if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [autologin] falha ao injetar script — ${e?.message || e}\r\n`);
        } catch {}
      });
    } catch {}
  };
  wc.on("did-finish-load", apply);
  wc.on("did-navigate", apply);
  wc.on("did-navigate-in-page", apply);
  // Captura o sinal "login concluido"/"sem confirmacao" do script acima
  // (console.log com tag [pandora-autologin]) e joga no Log de Operações —
  // aparece tanto em janela visível quanto em Operação Oculta, já que não
  // depende do usuário ver a tela (pedido do usuário 2026-08-09).
  if (!win._autoLoginLogAttached) {
    win._autoLoginLogAttached = true;
    wc.on("console-message", (_e, _level, message) => {
      try {
        if (typeof message !== "string" || !message.startsWith("[pandora-autologin]")) return;
        const tela = win._pandoraOrder || "?";
        if (message.includes("login concluido")) {
          // Pedido do usuário 2026-08-10: mensagem exata "conta logada tela
          // X" no Log de Operações.
          logSystem(`Conta logada — Tela ${tela}`, { kind: "auto-login", tela }, "success", "operacao-login");
        } else if (message.includes("login sem confirmacao")) {
          logSystem(`Tela ${tela} — Login enviado, sem confirmação em 20s (verifique manualmente)`, { kind: "auto-login", tela }, "warning", "operacao-login");
        } else if (message.includes("submit clicado")) {
          // Pedido do usuário 2026-08-10: "após concluir o preenchimento de
          // login e clicar em login na tela, ele envia para log de
          // operações" — loga direto no clique do botão, sem esperar a
          // confirmação (que depende de detectar os campos desaparecendo —
          // nem sempre confiável/rápido).
          logSystem(`Tela ${tela} — Login preenchido e enviado`, { kind: "auto-login", tela }, "info", "operacao-login");
        }
      } catch {}
    });
  }
}

// Fecha automaticamente banners/popups/anúncios quando a opção "Sem anúncios"
// (func_sem_envelopes) está ativa na aba Início. Aplica-se a TODAS as janelas
// Chromium (chrome:open, openMulti, Abrir Selecionadas). Re-injeta após cada
// navegação. Evita fechar modais de depósito/saque/PIX por padrão.
function attachPopupCloser(win) {
  if (!win || win.isDestroyed()) return;
  const wc = win.webContents;
  const POPUP_JS = `(() => {
    try {
      if (window.__pandoraPopupCloserOn) return;
      window.__pandoraPopupCloserOn = true;
      window.__pandoraPopupCloserEnabled = true;
      var closed = 0;
      var t0 = Date.now();
      var DUR = 600000;
      function visible(el){
        try {
          if (!el || !el.isConnected) return false;
          var r = el.getBoundingClientRect();
          if (r.width < 2 || r.height < 2) return false;
          var s = getComputedStyle(el);
          if (s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity||1) < 0.05) return false;
          return true;
        } catch(e){ return false; }
      }
      function isSafeModal(root){
        // Não fechar modais de depósito/saque/PIX/login/segurança/cadastro
        try {
          var hay = ((root && (root.innerText || root.textContent)) || '').toLowerCase();
          // Pedido do usuário 2026-08-19 (versopg.vip, print real): popup
          // "Parabéns, Cadastro Concluído!" (promocional pós-sucesso, só
          // "Baixar APP"/"Depositar agora", sem formulário nenhum) tinha as
          // palavras "cadastro"/"depósito" e caía direto no match genérico
          // abaixo, sendo protegido como se fosse um formulário de verdade.
          // Popup de sucesso não é formulário — deixa fechar mesmo citando
          // essas palavras.
          if (/parab[ée]ns.{0,60}(cadastro|registro).{0,30}conclu[ií]do|cadastro conclu[ií]do|registro conclu[ií]do/i.test(hay)) {
            // segue pras próximas barreiras (confirmação/conta/etc.) — não
            // marca como seguro só por isso.
          } else if (/dep[oó]sito|deposit|recarga|recarregar|sacar|saque|withdraw|pix|chave|senha de saque|security|pin de seguran|cadastr|registr|sign\s*up|criar conta/i.test(hay)) return true;
          // BUG real 2026-08-09 (reportado pelo usuário: clicar na seta de
          // voltar da tela de depósito/QR abre um popup de confirmação, e o
          // bot fica fechando esse popup sozinho — a pessoa nunca consegue
          // voltar de verdade) — QUALQUER diálogo que pede confirmação
          // "sim/não, confirmar/cancelar, tem certeza" é sempre uma decisão
          // de verdade do usuário, nunca propaganda/spam — protegido
          // independente de qual tela/URL a gente ACHA que está (evita
          // depender de acertar o gating por rota, que pode ter uma corrida
          // se a URL já mudou antes do popup terminar de aparecer).
          // "no"/"yes" sozinhos ficam de fora de propósito — são palavras
          // comuns demais em português ("no jogo", "no site"...), dariam
          // falso positivo em quase qualquer popup e quebrariam o "Sem
          // anúncios" de verdade. Só frases específicas o bastante pra não
          // se confundirem com texto normal de propaganda.
          if (/tem certeza|deseja (mesmo )?sair|deseja realmente|confirmar\b|cancelar\b|are you sure|do you want to leave/i.test(hay)) return true;
          // BUG GRAVE real 2026-08-09 (semanas de investigação do "Relatório
          // de Apostas" sempre em branco — "aparece e some quase no mesmo
          // instante" num F5 manual): a tela de Conta/Apostas/Relatório/
          // Recuperar o Saldo (/home/mine, /home/report) é renderizada como
          // body > div com uma seta "voltar" no topo — essa seta batia num
          // dos seletores genéricos de botão-de-fechar abaixo, e como
          // "Conta"/"Relatório"/"Saldo atual" não estavam nessa lista seguem,
          // o container INTEIRO era escondido (display:none) 400ms depois de
          // renderizar — o "sempre em branco" nunca foi bug de navegação,
          // clique ou anti-bot: era esse fechador de popup genérico demais
          // apagando a tela sozinho.
          if (/\\bconta\\b|relat[óo]rio de apostas|relat[óo]rio\\b|recuperar o saldo|recuperar saldo perdido|saldo atual|meus registros|minhas apostas|gest[ãa]o de saques/i.test(hay)) return true;
          var cls = ((root && root.className) || '') + '';
          if (/deposit|withdraw|recharge|security|pix|login|loginTab|register|signup|cadastro|confirm/i.test(cls)) return true;
          // Se contém input de login/senha, é o modal de cadastro/login — não mexer
          if (root && root.querySelector && root.querySelector('input[data-input-name="account"], input[data-input-name="userpass"], #loginTabButton')) return true;
        } catch(e){}
        return false;
      }
      function injetarImunidadeCSS(){
        try {
          var estiloId = 'trava-antifecho-lembrete';
          if (document.getElementById(estiloId)) return;
          if (!document.head) { setTimeout(injetarImunidadeCSS, 50); return; }
          var style = document.createElement('style');
          style.id = estiloId;
          style.innerHTML = '._retention-dialog_tsbju_93, ._retention-dialog_tsbju_93 .ui-dialog-close-box, ._retention-dialog_tsbju_93 .ui-dialog-close-box__icon, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-dialog-close-box, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-dialog-close-box__icon { pointer-events: none !important; user-select: none !important; } ._retention-dialog_tsbju_93 .ui-button, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-button { pointer-events: auto !important; }';
          document.head.appendChild(style);
          console.log('-> [Spider Core] Imunidade CSS do Lembrete injetada.');
        } catch(e){}
      }
      function protegerFechamentoLembrete(){
        try {
          var popupRetencao = document.querySelector('._retention-dialog_tsbju_93');
          if (!popupRetencao) return;
          var botoes = popupRetencao.querySelectorAll('.ui-dialog-close-box, .ui-dialog-close-box__icon');
          botoes.forEach(function(botaoFecharLembrete){
            try {
              if (!botaoFecharLembrete || botaoFecharLembrete.hasAttribute('data-protegido')) return;
              console.log('-> [Spider Core] Alvo detetado: Protegendo o diálogo de retenção contra fecho automático.');
              botaoFecharLembrete.setAttribute('data-protegido', 'true');
              botaoFecharLembrete.addEventListener('click', function(e){
                if (e && e.isTrusted) return;
                try { e.preventDefault(); e.stopImmediatePropagation(); e.stopPropagation(); } catch(_e){}
                console.log('-> [Spider Core] Tentativa de fecho automatizado bloqueada com sucesso.');
              }, true);
              botaoFecharLembrete.click = function(e){
                if (e && e.isTrusted) {
                  HTMLElement.prototype.click.call(this);
                } else {
                  console.log('-> [Spider Core] Tentativa de fecho automatizado bloqueada com sucesso.');
                }
              };
            } catch(e){}
          });
        } catch(e){}
      }

      function fecharPopupAutomatico(elementoPopup) {
        try {
          protegerFechamentoLembrete();
          injetarImunidadeCSS();

          // Pedido do usuário 2026-08-19 (voy-exhaustpg.com, popup atualizado):
          // novo botão de fechar veio como <i class="... _closeIcon_10372_95">
          // (CSS-module hasheado, "closeIcon" sem hífen) — não batia com
          // nenhum seletor genérico abaixo. Adicionado [class*="closeIcon"].
          var botoesFechar = Array.prototype.slice.call(document.querySelectorAll('.ui-dialog-close-box, .ui-dialog-close-box__icon, [class*="close-box"], [class*="closeBox"], [class*="closeIcon"], [class*="close-btn"], [class*="closeBtn"], .close-icon, .popup-close, [aria-label="Close" i], [aria-label="Fechar" i], [aria-label="close" i]'));
          // Pedido do usuário 2026-08-19 (versopg.vip, popup "Parabéns,
          // Cadastro Concluído!"): o X desse popup é um <svg><path> puro,
          // sem nenhuma classe/aria-label reconhecível pelos seletores
          // acima (confirmado pelo HTML real que o usuário colou). Casa
          // pelo início do atributo "d" do path (identifica o glifo do X
          // dessa lib de ícones) e clica no <svg> pai, que é o elemento
          // clicável de verdade.
          document.querySelectorAll('path[d^="M2.729 45.278a2.304 2.304 0 0 1-.666-1.11"]').forEach(function(p){
            var svgIcone = p.closest('svg') || p.parentElement;
            if (svgIcone) botoesFechar.push(svgIcone);
          });
          botoesFechar.forEach(function(botao){
            try {
              if (botao.hasAttribute('data-protegido') || botao.hasAttribute('data-pandora-tentei')) return;
              var conteinerPai = botao.closest('.ui-popup, .ui-dialog, .ui-overlay, [role="dialog"], [class*="popup"], [class*="dialog"], [class*="modal"], body > div');
              if (!conteinerPai || !visible(conteinerPai)) return;

              // BARREIRA 1: Lembrete de retenção (NUNCA fechar)
              var textoDoConteiner = (conteinerPai.textContent || "").toLowerCase();
              if (textoDoConteiner.includes("retornar") ||
                  textoDoConteiner.includes("continuar a pagar") ||
                  textoDoConteiner.includes("histórico de depósitos") ||
                  conteinerPai.querySelector('._retention-dialog_tsbju_93')) {
                return;
              }

              // BARREIRA 2: Modais funcionais (depósito/saque/PIX/login/cadastro/segurança)
              if (isSafeModal(conteinerPai)) return;

              // ALVO: qualquer outro popup visível — fecha agressivamente
              botao.setAttribute('data-pandora-tentei', '1');
              // Pedido do usuário 2026-08-19: log do que exatamente foi
              // clicado — sem isso não dá pra confirmar se é esse fechador
              // que está causando o scroll estranho ao entrar no site.
              try { console.log('[pandora-popupcloser] fechando botao=' + (botao.tagName||'') + '.' + (botao.className||'') + ' container=' + (conteinerPai.tagName||'') + '.' + (conteinerPai.className||'').toString().slice(0,120)); } catch(_e){}
              try { botao.click(); } catch(_e){}
              // fallback: dispara mouseup/mousedown nativos
              try {
                var ev = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
                botao.dispatchEvent(ev);
              } catch(_e){}
              // último recurso: esconde o container se permaneceu visível
              setTimeout(function(){
                try {
                  if (conteinerPai && conteinerPai.isConnected && visible(conteinerPai) && !isSafeModal(conteinerPai)) {
                    conteinerPai.style.setProperty('display', 'none', 'important');
                  }
                } catch(_e){}
              }, 400);
              closed++;
            } catch(e){}
          });
        } catch(e){}
      }

      function isLoggedOut(){
        try {
          var a = document.querySelector('input[data-input-name="account"]');
          var p = document.querySelector('input[data-input-name="userpass"]');
          var tab = document.getElementById('loginTabButton');
          if ((a && visible(a)) || (p && visible(p)) || (tab && visible(tab))) return true;
        } catch(e){}
        return false;
      }
      function tryClose(){
        // Checa a flag a CADA tick — permite desligar em tempo real (o
        // usuário desmarcou "Sem anúncios" enquanto essa janela já estava
        // aberta) sem depender de uma navegação nova pra parar. A flag
        // começa true (só injeta esse script quando a opção já estava
        // marcada) e pode ser virada false de fora via executeJavaScript
        // (ver setPopupCloserEnabledLive em autoLogin.cjs).
        if (window.__pandoraPopupCloserEnabled === false) { clearInterval(iv); return; }
        if (Date.now() - t0 > DUR) { clearInterval(iv); return; }
        if (isLoggedOut()) return;
        if (closed >= 30) { clearInterval(iv); return; }
        try {
          injetarImunidadeCSS();
          protegerFechamentoLembrete();
          fecharPopupAutomatico(document.body);
        } catch(e){}
      }

      try {
        var observer = new MutationObserver(function(){ tryClose(); });
        observer.observe(document.body, { childList: true, subtree: true });
      } catch(e){}
      var iv = setInterval(tryClose, 500);
      tryClose();
    } catch(e){}  })();`;
  const apply = () => {
    try {
      // Re-checa a opção a cada navegação — usuário pode ter desligado.
      if (getSettingSync("func_sem_envelopes", "0") !== "1") return;
      const url = wc.getURL() || "";
      if (url.startsWith("file://")) return;
      // Restringe estritamente à Home — popups/banners só aparecem lá.
      // Em /home/withdraw, /home/deposit, etc., o fechador NÃO pode rodar,
      // pois o "modal" da página é o próprio formulário (senha de saque, etc.).
      let isHome = false;
      try {
        const u = new URL(url);
        const p = (u.pathname || "").replace(/\/+$/, "").toLowerCase();
        isHome = p === "" || p === "/" || p === "/home" || p === "/home/index";
      } catch {}
      // Sempre desliga o fechador ao sair da Home — é SPA (não recarrega a
      // página ao trocar de tela), então o setInterval/MutationObserver
      // injetados na Home continuam rodando "por trás" mesmo depois de
      // navegar pra /home/withdraw etc. se ninguém desligar explicitamente.
      // BUG anterior: essa linha desligava __pandoraPopupCloserOn (só a
      // trava de "não injeta duas vezes"), não __pandoraPopupCloserEnabled
      // (a flag que o loop de verdade checa) — o loop nunca parava de fato
      // ao sair da Home, e por isso fechava popup até na tela de saque.
      // Também remove a CSS de "imunidade" injetada na Home (protege o
      // popup de retenção contra fechamento automático) — ela fica no
      // <head> pra sempre (SPA não recarrega), e uma das regras usa um
      // seletor genérico (.ui-dialog__header--undefined--title) que podia
      // acabar bloqueando o clique no X de OUTRO popup na tela de saque,
      // não só o de retenção da Home.
      wc.executeJavaScript(
        "try{window.__pandoraPopupCloserEnabled=false;window.__pandoraPopupCloserOn=false;document.getElementById('trava-antifecho-lembrete')?.remove();}catch(e){}",
        true
      ).catch(() => {});
      // Pedido do usuário 2026-08-09: "clico na setinha do QR pra voltar, o
      // popup de confirmação aparece, e o bot fecha — não pode fechar" — o
      // BUG real era essa função (apply) rodando de novo a cada navegação
      // (did-navigate-in-page inclusive, que dispara até em transições
      // internas de SPA como clicar em voltar) e REATIVANDO o fechador
      // sempre que a URL parecer "Home" de novo — sobrescrevendo o
      // desligamento que qrCapture.cjs já tinha feito na hora que achou o
      // QR. Uma vez que o QR foi capturado nessa janela, o fechador fica
      // desligado PRA SEMPRE nela (win._pandoraPopupCloserOff, setado em
      // qrCapture.cjs), não importa pra onde a SPA "pareça" ter navegado.
      if (win._pandoraPopupCloserOff) return;
      if (!isHome) return;
      wc.executeJavaScript(POPUP_JS, true).catch(() => {});
    } catch {}
  };
  wc.on("did-finish-load", apply);
  wc.on("did-navigate", apply);
  wc.on("did-navigate-in-page", apply);
}

// Chamado quando o usuário liga/desliga "Sem anúncios" na aba Início —
// avisa TODAS as janelas Chromium já abertas na hora, sem esperar uma
// navegação nova. Ligar não reinicia o fechador sozinho (só a próxima
// navegação injeta o script de verdade); desligar para o que já estiver
// rodando imediatamente.
function setPopupCloserEnabledLive(enabled) {
  try {
    const state = require("../state.cjs");
    const js = `try{window.__pandoraPopupCloserEnabled=${enabled ? "true" : "false"};}catch(e){}`;
    for (const win of state.chromeWins || []) {
      try {
        if (!win || win.isDestroyed()) continue;
        win.webContents.executeJavaScript(js, true).catch(() => {});
      } catch {}
    }
  } catch {}
}

module.exports = { attachContaAutoLogin, attachPopupCloser, setPopupCloserEnabledLive };
