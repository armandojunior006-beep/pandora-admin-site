// ============================================================================
// Auto-login por conta (janelas abertas via "Abrir Selecionadas") e fechador
// automático de popups/banners (opção "Sem anúncios"). Ambos injetam script
// no DOM da página visitada e se reaplicam a cada navegação.
// ============================================================================
const { getSettingSync, logSystem } = require("../settings/settingsStore.cjs");

function attachContaAutoLogin(win) {
  if (!win || win.isDestroyed()) return;
  const wc = win.webContents;
  const apply = () => {
    try {
      const cred = win._contaAutoLogin || {};
      // BUG real 2026-08-10 (reportado pelo usuário: "Conta logada" nunca
      // aparece no log, nem os diagnósticos anteriores de erro de injeção/
      // botão não encontrado) — nenhum deles disparou, sinal de que a
      // função nem chega a tentar injetar nada. Loga bem no início, antes
      // de qualquer return, pra confirmar se apply() roda de verdade e com
      // que credenciais/URL.
      try {
        const { queueDiagLine } = require("../../auto-register.cjs");
        if (typeof queueDiagLine === "function") {
          queueDiagLine(`[${new Date().toISOString()}] [autologin] apply() chamado — url=${(() => { try { return wc.getURL(); } catch { return "?"; } })()} temLogin=${!!cred.login} temSenha=${!!cred.senha}\r\n`);
        }
      } catch {}
      if (!cred.login && !cred.senha) return;
      const url = wc.getURL() || "";
      if (url.startsWith("file://")) return;
      const payload = JSON.stringify({ login: String(cred.login || ""), senha: String(cred.senha || "") });
      const js = `(() => {
        try {
          if (window.__pandoraContaAutoLogin) return;
          window.__pandoraContaAutoLogin = true;
          var cred = ${payload};
          var done = false;
          var startedAt = Date.now();
          var TIMEOUT = 60000;
          function setVal(el, v){
            try {
              var proto = Object.getPrototypeOf(el);
              var d = Object.getOwnPropertyDescriptor(proto, 'value');
              if (d && d.set) d.set.call(el, v); else el.value = v;
              el.dispatchEvent(new Event('input', { bubbles: true }));
              el.dispatchEvent(new Event('change', { bubbles: true }));
            } catch(e){ try { el.value = v; } catch(e2){} }
          }
          function pickInputs(){
            // Prioriza seletores específicos do cassino (account/userpass).
            var loginEl = document.querySelector('input[data-input-name="account"], textarea[data-input-name="account"]');
            var senhaEl = document.querySelector('input[data-input-name="userpass"], textarea[data-input-name="userpass"]');
            if (loginEl && senhaEl && loginEl.offsetParent && senhaEl.offsetParent) {
              return { loginEl: loginEl, senhaEl: senhaEl };
            }
            // Fallback heurístico (qualquer site genérico).
            var inputs = Array.prototype.slice.call(document.querySelectorAll('input,textarea'));
            if (!loginEl || !loginEl.offsetParent) loginEl = null;
            if (!senhaEl || !senhaEl.offsetParent) senhaEl = null;
            for (var i=0;i<inputs.length;i++){
              var el = inputs[i];
              if (!el.offsetParent) continue;
              var t = (el.type||'').toLowerCase();
              if (t === 'password' && !senhaEl) senhaEl = el;
            }
            for (var j=0;j<inputs.length;j++){
              var el2 = inputs[j];
              if (!el2.offsetParent) continue;
              var t2 = (el2.type||'').toLowerCase();
              if (t2 === 'password' || t2 === 'hidden' || t2 === 'submit' || t2 === 'button') continue;
              if (!loginEl) { loginEl = el2; break; }
            }
            return { loginEl: loginEl, senhaEl: senhaEl };
          }
          function clickLoginTab(){
            try {
              var tab = document.getElementById('loginTabButton');
              if (tab) { tab.click(); return true; }
              var nodes = document.querySelectorAll('span,div,button,a');
              for (var i=0;i<nodes.length;i++){
                var el = nodes[i];
                var txt = (el.textContent||'').trim().toLowerCase();
                if (txt === 'login' || txt === 'entrar') {
                  var cls = (el.className||'')+'';
                  if (/tab|login/i.test(cls) || /tab|login/i.test(el.id||'')) {
                    try { el.click(); return true; } catch(e){}
                  }
                }
              }
            } catch(e){}
            return false;
          }
          function isVisible(el){
            try {
              if (!el || !el.isConnected) return false;
              var r = el.getBoundingClientRect();
              if (r.width < 2 || r.height < 2) return false;
              var s = getComputedStyle(el);
              if (s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity||1) < 0.05) return false;
              return true;
            } catch(e){ return false; }
          }
          function realClick(el){
            try { el.scrollIntoView({ block:'center', inline:'center' }); } catch(e){}
            try {
              var r = el.getBoundingClientRect();
              var x = r.left + Math.max(2, r.width/2), y = r.top + Math.max(2, r.height/2);
              var opts = { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0, buttons:1 };
              try { el.dispatchEvent(new PointerEvent('pointerdown', Object.assign({ pointerType:'mouse' }, opts))); } catch(e){}
              try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch(e){}
              try { el.dispatchEvent(new PointerEvent('pointerup', Object.assign({ pointerType:'mouse' }, opts, { buttons:0 }))); } catch(e){}
              try { el.dispatchEvent(new MouseEvent('mouseup', Object.assign({}, opts, { buttons:0 }))); } catch(e){}
              try { el.dispatchEvent(new MouseEvent('click', Object.assign({}, opts, { buttons:0 }))); } catch(e){}
            } catch(e){}
            try { el.click(); } catch(e){}
          }
          function clickSubmitLogin(){
            try {
              // 1) Procura .ui-button cujo .ui-button__text === "Login"/"Entrar"
              var btns = Array.prototype.slice.call(document.querySelectorAll('.ui-button, [class*="ui-button"]:not(.ui-button__content):not(.ui-button__text)'));
              // Inclui também button/div[role=button]/a para fallback
              btns = btns.concat(Array.prototype.slice.call(document.querySelectorAll('button, div[role="button"], a')));
              for (var i=0;i<btns.length;i++){
                var el = btns[i];
                if (!el || !isVisible(el)) continue;
                if (el.id === 'loginTabButton') continue;
                if (el.closest && el.closest('#loginTabButton')) continue;
                // Ignora .ui-button__content interno (vamos clicar no .ui-button pai)
                var cls0 = ((el.className||'')+'')+'';
                if (/ui-button__content|ui-button__text/.test(cls0)) continue;
                var txtNode = el.querySelector ? el.querySelector('.ui-button__text') : null;
                var txt = ((txtNode ? txtNode.textContent : el.textContent) || '').trim().toLowerCase();
                // Match exato "login"/"entrar" ou se for botão único com esse texto
                if (txt !== 'login' && txt !== 'entrar') continue;
                var cls = cls0.toLowerCase();
                if (/tab\b/.test(cls)) continue;
                if (el.disabled || el.getAttribute('disabled') !== null) continue;
                if (/disabled|is-disabled/.test(cls)) continue;
                realClick(el);
                return true;
              }
            } catch(e){}
            return false;
          }
          function tryFill(){
            if (done) return;
            // BUG real 2026-08-10 (reportado pelo usuário: nem "conta
            // logada" nem NENHUM outro log de auto-login aparecia, mesmo
            // com apply() confirmado rodando com login/senha certos) — o
            // timeout de 60s desistia em total silêncio, sem log nenhum;
            // se pickInputs() nunca achasse os campos, o loop rodava pra
            // sempre sem deixar rastro. Agora loga ao desistir por timeout
            // E periodicamente (a cada ~6s) enquanto ainda não achou nada,
            // com uma amostra dos inputs visíveis na tela nesse momento.
            if (Date.now() - startedAt > TIMEOUT) {
              done = true;
              try {
                var amostraFinal = Array.prototype.slice.call(document.querySelectorAll('input,textarea')).slice(0, 10)
                  .map(function (el) { return JSON.stringify({ tag: el.tagName, type: el.type||'', name: el.getAttribute('data-input-name')||'', visivel: !!el.offsetParent }); }).join(', ');
                console.log('[pandora-autologin] desistiu apos 60s sem achar campo de login/senha. Inputs na tela: ' + amostraFinal);
              } catch(e){}
              return;
            }
            // BUG CRÍTICO real 2026-08-10 (achado com o diagnóstico acima:
            // "nenhum input na página") — a conta reaberta já estava
            // logada de verdade (sessão/cookie salvos de antes), caindo
            // direto na Home — sem formulário de login pra encontrar, o
            // loop ficava esperando pra sempre por um campo que nunca ia
            // aparecer. Mesmo sinal já usado em auto-register.cjs
            // (jaLogado): barra "Começar/Perfil/Depósito" visível E nenhum
            // campo de conta na tela = já logado. Detecta isso primeiro e
            // trata como sucesso imediato, sem esperar timeout nenhum.
            try {
              var bodyTxt = ((document.body && document.body.innerText) || '').toLowerCase();
              var temBarraLogada = /come[çc]ar/.test(bodyTxt) && /perfil/.test(bodyTxt) && /dep[óo]sito/.test(bodyTxt);
              var temCampoConta = !!document.querySelector('input[data-input-name="account"], textarea[data-input-name="account"]');
              if (temBarraLogada && !temCampoConta) {
                done = true;
                try { console.log('[pandora-autologin] login concluido login=' + cred.login + ' (já estava logado — sessão salva)'); } catch(e){}
                return;
              }
            } catch(e){}
            if (!window.__pandoraAutoLoginTries) window.__pandoraAutoLoginTries = 0;
            window.__pandoraAutoLoginTries++;
            try { clickLoginTab(); } catch(e){}
            var f = pickInputs();
            if (!f.loginEl || !f.senhaEl) {
              if (window.__pandoraAutoLoginTries <= 3 || window.__pandoraAutoLoginTries % 10 === 1) {
                try {
                  var amostra = Array.prototype.slice.call(document.querySelectorAll('input,textarea')).slice(0, 10)
                    .map(function (el) { return JSON.stringify({ tag: el.tagName, type: el.type||'', name: el.getAttribute('data-input-name')||'', visivel: !!el.offsetParent }); }).join(', ');
                  // BUG real 2026-08-10 (2ª rodada — "nenhum input na
                  // página" persistia mesmo depois do fix de "já logado",
                  // que também não disparava) — loga MUITO mais nas 3
                  // primeiras tentativas (não só a cada 10), e agora
                  // também document.readyState + um trecho do texto da
                  // página, pra saber se ela está genuinamente em branco
                  // (ainda carregando/redirecionando) ou se tem conteúdo
                  // que só não bate com o texto esperado ("começar/perfil/
                  // depósito").
                  var bodySnippet = ((document.body && document.body.innerText) || '').replace(/\s+/g, ' ').trim().slice(0, 200);
                  console.log('[pandora-autologin] ainda procurando campo de login/senha (tentativa ' + window.__pandoraAutoLoginTries + '). readyState=' + document.readyState + ' url=' + location.href + ' texto="' + bodySnippet + '" Inputs na tela: ' + (amostra || '(nenhum input na página)'));
                } catch(e){}
              }
            }
            if (f.loginEl && f.senhaEl) {
              if (cred.login) setVal(f.loginEl, cred.login);
              if (cred.senha) setVal(f.senhaEl, cred.senha);
              done = true;
              try { console.log('[pandora-autologin] preenchido'); } catch(e){}
              var submitTries = 0;
              function watchLoginResult(){
                // Pedido do usuário 2026-08-09: quando o login em modo
                // headless/Operação Oculta terminar, deve aparecer "Login
                // concluído" no Log de Operações — só clicar em Enviar não
                // é garantia (senha errada, captcha etc.), então confirma
                // observando se os campos de login/senha SOMEM da tela
                // (indício real de que autenticou), até 20s.
                var t0 = Date.now();
                var iv = setInterval(function(){
                  try {
                    var a = document.querySelector('input[data-input-name="account"]');
                    var p = document.querySelector('input[data-input-name="userpass"]');
                    var aVisible = a && a.offsetParent;
                    var pVisible = p && p.offsetParent;
                    if (!aVisible && !pVisible) {
                      clearInterval(iv);
                      try { console.log('[pandora-autologin] login concluido login=' + cred.login); } catch(e){}
                      return;
                    }
                  } catch(e){}
                  if (Date.now() - t0 > 20000) { clearInterval(iv); try { console.log('[pandora-autologin] login sem confirmacao em 20s login=' + cred.login); } catch(e){} }
                }, 500);
              }
              function trySubmit(){
                submitTries++;
                if (clickSubmitLogin()) {
                  try { console.log('[pandora-autologin] submit clicado'); } catch(e){}
                  watchLoginResult();
                  return;
                }
                if (submitTries < 40) { setTimeout(trySubmit, 400); return; }
                // BUG real 2026-08-10 (reportado pelo usuário: "conta
                // logada" nunca aparece no log) — antes desistia em
                // silêncio depois de 40 tentativas sem NENHUM aviso; loga
                // os textos dos botões visíveis achados, pra saber se o
                // texto do botão de login desse site é diferente de
                // "login"/"entrar" (única coisa que clickSubmitLogin
                // reconhece hoje).
                try {
                  var candidatos = Array.prototype.slice.call(document.querySelectorAll('.ui-button, button, div[role="button"], a'))
                    .filter(function (el) { try { return isVisible(el); } catch (e) { return false; } })
                    .slice(0, 15)
                    .map(function (el) { return JSON.stringify((el.textContent || '').trim().slice(0, 30)); })
                    .join(', ');
                  console.log('[pandora-autologin] desistiu — botão de login não encontrado em 40 tentativas. Botões visíveis: ' + candidatos);
                } catch (e) { try { console.log('[pandora-autologin] desistiu — botão de login não encontrado'); } catch (e2) {} }
              }
              setTimeout(trySubmit, 500);
              return;
            }
            setTimeout(tryFill, 600);
          }
          if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', tryFill);
          } else {
            tryFill();
          }
        } catch(e){}
      })();`;
      // DESLIGADO 2026-08-27: o preenchimento via este script JS (pickInputs com
      // document.querySelector simples) pegava o campo do REGISTRO (aba default
      // do 701win e afins) e preenchia lá. O preenchimento agora é 100% pelo
      // puppeteerLogin (poll abaixo) — tab-aware (#loginTabButton), elementFromPoint
      // (ignora campos duplicados/fora de tela), page.keyboard.type e read-back.
      // Ele também cobre casas ANTIGAS (sem aba → acha o campo visível e preenche).
      // 'js' segue montado só pra não quebrar referências; NÃO é mais injetado.
      void js;
    } catch {}
  };

  // ==========================================================================
  // NOVA PLATAFORMA W1 (2026-08-26): o form de login virou um framework que
  // ignora .value sintético e monta em outro contexto/página do browser. O path
  // JS acima (apply) continua servindo as casas antigas. Aqui, um caminho
  // PUPPETEER-NATIVO: varre TODAS as páginas/frames do browser, digita de VERDADE
  // (teclas reais que o framework honra) e clica no botão Login com clique real.
  // Dirigido por polling (o splash promo monta o login sem evento de navegação).
  // ==========================================================================
  // isVisible ESTRITO: além de display/visibility/opacity, exige que o centro do
  // elemento esteja DENTRO da viewport E que seja o elemento no topo ali
  // (elementFromPoint). Sem isso, campos duplicados da aba "Registro" (fora da
  // tela mas com rect>0) passavam e a gente digitava neles em vez da aba "Login".
  const __VISIBLE_FN = `function isVisible(el){ try{ if(!el||!el.isConnected) return false; var r=el.getBoundingClientRect(); if(r.width<2||r.height<2) return false; var s=getComputedStyle(el); if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity||1)<0.05) return false; var cx=r.left+r.width/2, cy=r.top+r.height/2; var vw=window.innerWidth||document.documentElement.clientWidth, vh=window.innerHeight||document.documentElement.clientHeight; if(cx<0||cy<0||cx>vw||cy>vh) return false; try{ var top=document.elementFromPoint(cx,cy); if(top && (top===document.body || top===document.documentElement)) return false; if(top && !(top===el || (el.contains&&el.contains(top)) || (top.contains&&top.contains(el)))) return false; }catch(e){} return true; }catch(e){return false;} }`;
  const __DEEP_FN = `function deepAll(sel){ var out=[],seen=[]; function walk(root){ if(!root||seen.indexOf(root)!==-1)return; seen.push(root); var m; try{m=root.querySelectorAll(sel);}catch(e){m=[];} for(var i=0;i<m.length;i++)out.push(m[i]); var all; try{all=root.querySelectorAll('*');}catch(e){all=[];} for(var j=0;j<all.length;j++){ if(all[j].shadowRoot) walk(all[j].shadowRoot);} } walk(document); return out; }`;
  // IIFE auto-invocadas: evaluateHandle(string) avalia a expressão e devolve um
  // handle pro resultado (o elemento, ou null). Não dá pra passar arg quando o
  // 1º é string, então o nome do campo entra embutido.
  // Acha os campos de login (usuário + senha). Prioriza os seletores
  // específicos do cassino (data-input-name), mas cai num fallback GENÉRICO
  // quando a plataforma não usa esse atributo (ex.: okokgrupo3.com — chegava
  // no Login mas não preenchia porque data-input-name não existe lá): pega o
  // input[type=password] visível e o campo de texto associado (o input de
  // texto visível imediatamente ANTES da senha no DOM — o padrão de todo form
  // de login). isVisible estrito (elementFromPoint) já garante que só o campo
  // da aba ATIVA passa, então não pega o da aba Registro por engano.
  // DESCARTA CAMPO DE CADASTRO (precisar777.vip, 2026-08-27, DOM inspecionado):
  // no form `.ui-tabs` embutido, os painéis Registro e Login coexistem no DOM com
  // os MESMOS `data-input-name` (account/userpass) — só a geometria separa. Quando
  // o hit-test escorrega (viewport pequena, animação do swiper no meio da troca de
  // aba, painel inativo ainda por cima), o localizador pegava o par do REGISTRO e
  // o bot digitava lá ("nem sempre preenche em Login"). Aqui o critério é
  // SEMÂNTICO e independe de geometria: se a caixa do campo (painel/form) contém
  // um "Confirmar senha"/"Nome real"/"Código de convite" VISÍVEL, é cadastro →
  // rejeita. Só conta campo de cadastro visível: casa de form ÚNICO que alterna
  // login/registro mantém o "confirmar" com display:none, então não é afetada.
  const __REGBOX_FN = `function isRegBox(el){ try{ if(!el||!el.closest) return false; var c=el.closest('.ui-tab__panel-wrapper')||el.closest('.ui-tab__panel')||el.closest('form'); if(!c||c===el) return false; var q; try{ q=c.querySelectorAll('input,textarea'); }catch(e){ return false; } for(var i=0;i<q.length;i++){ var f=q[i]; if(f===el) continue; var r=f.getBoundingClientRect(); if(r.width<2||r.height<2) continue; var s=getComputedStyle(f); if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity||1)<0.05) continue; var n=((f.getAttribute('data-input-name')||f.name||'')+'').toLowerCase(); var p=((f.placeholder||'')+'').toLowerCase(); if(/confirmpass|confirmpwd|repeatpass|realname|invit/.test(n)) return true; if(/confirmar senha|confirme a senha|repetir senha|repita a senha|nome real|c[óo]digo de convite/.test(p)) return true; } return false; }catch(e){ return false; } }`;
  const __FIND_FIELDS_FN = `function findLoginFields(){ ${__VISIBLE_FN} ${__DEEP_FN} ${__REGBOX_FN}
    function vis(arr){ var o=[]; for(var i=0;i<arr.length;i++){ if(isVisible(arr[i]) && !isRegBox(arr[i])) o.push(arr[i]); } return o; }
    function isText(el){ var t=((el.type||'')+'').toLowerCase(); return !(t==='hidden'||t==='checkbox'||t==='radio'||t==='submit'||t==='button'||t==='password'||t==='file'||t==='range'||t==='color'); }
    var accP = vis(deepAll('input[data-input-name="account"], textarea[data-input-name="account"]'));
    var pwP  = vis(deepAll('input[data-input-name="userpass"], textarea[data-input-name="userpass"]'));
    if (accP.length && pwP.length) return { acc: accP[0], pw: pwP[0] };
    var allInputs = deepAll('input, textarea');
    var pwEl = pwP[0] || (vis(deepAll('input[type="password"]'))[0] || null);
    var accEl = accP[0] || null;
    if (pwEl && !accEl){
      var pwIdx = allInputs.indexOf(pwEl);
      for (var i=pwIdx-1; i>=0; i--){ var el=allInputs[i]; if(isText(el) && isVisible(el) && !isRegBox(el)){ accEl=el; break; } }
      if (!accEl){ for (var j=0;j<allInputs.length;j++){ var e2=allInputs[j]; if(e2===pwEl) continue; if(isText(e2) && isVisible(e2) && !isRegBox(e2)){ accEl=e2; break; } } }
    }
    return { acc: accEl, pw: pwEl }; }`;
  const fieldExpr = (name) => `(() => { ${__FIND_FIELDS_FN} var f = findLoginFields(); return f ? (${name === "account" ? "f.acc" : "f.pw"} || null) : null; })()`;
  const loginBtnExpr = `(() => { ${__VISIBLE_FN} ${__DEEP_FN} var btns = deepAll('.ui-button, [class*="ui-button"], button, div[role="button"], a'); for (var i=0;i<btns.length;i++){ var el=btns[i]; if(!isVisible(el)) continue; if(el.id==='loginTabButton') continue; if(el.closest && el.closest('#loginTabButton')) continue; var cls=((el.className||'')+'').toLowerCase(); if(/ui-button__content|ui-button__text/.test(cls)) continue; if(/\\btab\\b/.test(cls)) continue; var tn=el.querySelector?el.querySelector('.ui-button__text'):null; var txt=((tn?tn.textContent:el.textContent)||'').trim().toLowerCase(); if(txt!=='login'&&txt!=='entrar') continue; if(el.disabled||/disabled|is-disabled/.test(cls)) continue; return el; } return null; })()`;
  let __ppBusy = false;
  const puppeteerLogin = async () => {
    if (__ppBusy) return;
    __ppBusy = true;
    try {
      if (win.isDestroyed() || win._contaLoginDone) return;
      const cred = win._contaAutoLogin || {};
      // DIAG uma-vez (2026-08-27): distingue "re-login nem tentou" (sem cred /
      // sem browser puppeteer) de "tentou e não achou os campos". Sem isso, um
      // early-return aqui deixava o log SEM nenhuma linha [re-login], impossível
      // saber se o fluxo sequer começou.
      try { if (!win.__reAttachDbg) { win.__reAttachDbg = true; const {queueDiagLine}=require("../../auto-register.cjs"); queueDiagLine(`[${new Date().toISOString()}] [re-login] iniciando temLogin=${!!cred.login} temSenha=${!!cred.senha} temBrowser=${!!(win._browser && typeof win._browser.pages === "function")} jaLogado=${!!win._contaLoginDone}\r\n`); } } catch {}
      if (!cred.login && !cred.senha) return;
      const browser = win._browser;
      if (!browser || typeof browser.pages !== "function") return;
      const withTO = (p, ms, tag) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error("timeout " + tag)), ms))]);
      // CAUSA-RAIZ okok (2026-08-27, confirmada por log): este await NÃO tinha
      // timeout. Durante a transição splash.html → site (targets CDP trocando),
      // browser.pages() PENDURAVA — e como está antes do gate, o __ppBusy ficava
      // travado em true pra sempre (o finally nunca rodava), então TODO poll
      // seguinte saía no `if(__ppBusy) return`. Sintoma no log: [re-login]
      // iniciando UMA vez e nunca mais nenhum gate/campos. Com timeout, uma trava
      // vira só um retry no próximo poll (250ms depois), quando o CDP já assentou.
      let pages = [];
      try { pages = await withTO(browser.pages(), 4000, "pages"); }
      catch (e) { try { if ((win.__rePagesDbg=(win.__rePagesDbg||0)+1) <= 5) { const {queueDiagLine}=require("../../auto-register.cjs"); queueDiagLine(`[${new Date().toISOString()}] [re-login] browser.pages() timeout — retry no próximo poll\r\n`); } } catch {} return; }
      // DIAG (2026-08-27): quantas pages/frames o pages() retornou. Se pages=0 o
      // loop nem roda (sem gate, sem timeout — bate com o log do okok). Diz se o
      // problema é "browser sem pages" vs "acha pages mas trava no frame".
      try { if ((win.__reFramesDbg=(win.__reFramesDbg||0)+1) <= 20) { const framesInfo = pages.map((p)=>{ try { return p.frames().length; } catch(_) { return "?"; } }).join(","); const urlsInfo = pages.map((p)=>{ try { return (p.url()||"").slice(0,40); } catch(_) { return "?"; } }).join(" | "); const {queueDiagLine}=require("../../auto-register.cjs"); queueDiagLine(`[${new Date().toISOString()}] [re-login] poll#${win.__reFramesDbg} pages=${pages.length} framesPorPage=[${framesInfo}] urls=[${urlsInfo}]\r\n`); } } catch {}
      for (const page of pages) {
        // TAP DE REDE (2026-08-27): guarda as últimas falhas de request e as
        // respostas não-2xx de chamadas de login/auth. O toast "conexão de rede
        // falhou" é texto do front e esconde a causa; com isto o diag mostra o
        // ERR_* do Chrome (DNS/timeout/reset) ou o status do servidor (403 de
        // WAF, 5xx). Anexa UMA vez por page (flag na própria page).
        try {
          if (!page.__pandoraNetTap) {
            page.__pandoraNetTap = true;
            // seq monotônica (não índice): o array tem teto e o shift deslocaria
            // as posições, fazendo a janela de observação comparar entradas erradas.
            const push = (s) => { try { const a = (win.__netTap = win.__netTap || []); a.push({ seq: (win.__netTapSeq = (win.__netTapSeq || 0) + 1), s }); if (a.length > 20) a.shift(); } catch (_) {} };
            page.on("requestfailed", (r) => { try { push(`${(r.failure() && r.failure().errorText) || "?"} ${new URL(r.url()).host}${new URL(r.url()).pathname.slice(0, 40)}`); } catch (_) {} });
            page.on("response", (r) => { try { const u = r.url(); if (r.status() >= 400 && /login|auth|signin|token|member/i.test(u)) push(`HTTP${r.status()} ${new URL(u).host}${new URL(u).pathname.slice(0, 40)}`); } catch (_) {} });
          }
        } catch (_) {}
        let frames = [];
        try { frames = page.frames(); } catch (_) { continue; }
        for (const frame of frames) {
          // Clica a aba "Login" ANTES de achar os campos: em casas onde "Registro"
          // é a aba ativa por padrão (ex.: 701win.vip), o campo visível no topo é
          // o do Registro e a gente preenchia lá. Alvo exato: #loginTabButton
          // (data-sensors-click) — clicado com eventos de PONTEIRO reais (só
          // el.click() não dispara o handler sensors). Fallback por texto (aba
          // estreita). Idempotente (em casas com Login já ativa, fica igual).
          // tabRes DECLARADO FORA do try: a linha do diag [re-login] gate lá
          // embaixo referencia tabRes; quando estava `let` DENTRO deste try,
          // ficava fora de escopo no diag → ReferenceError engolido pelo
          // try/catch do diag → o gate NUNCA logava (cegou o diagnóstico do okok).
          let tabRes = "none";
          try {
            // Clique NATIVO do puppeteer (mouse real por coordenada) no
            // #loginTabButton — o data-sensors-click não reage a evento sintético.
            let tabHandle = null;
            // findtab 1200ms (era 3000): okok não tem #loginTabButton e algum
            // frame cross-origin/detached pendurava o frame.$ até o timeout de 3s,
            // gastando ~3s POR FRAME (2 frames = ~6,75s por poll, observado no log).
            try { tabHandle = await withTO(frame.$("#loginTabButton"), 1200, "findtab"); } catch (_) {}
            if (tabHandle) {
              try { await withTO(tabHandle.click(), 3000, "tabclick"); tabRes = "native"; }
              catch (e) { try { await withTO(frame.evaluate((el) => { try{el.scrollIntoView({block:'center'});}catch(_){ } var r=el.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,o={bubbles:true,cancelable:true,clientX:x,clientY:y,button:0,buttons:1}; try{el.dispatchEvent(new PointerEvent('pointerdown',Object.assign({pointerType:'mouse'},o)));}catch(_){}try{el.dispatchEvent(new MouseEvent('mousedown',o));}catch(_){}try{el.dispatchEvent(new PointerEvent('pointerup',Object.assign({pointerType:'mouse'},o,{buttons:0})));}catch(_){}try{el.dispatchEvent(new MouseEvent('mouseup',Object.assign({},o,{buttons:0})));}catch(_){}try{el.dispatchEvent(new MouseEvent('click',Object.assign({},o,{buttons:0})));}catch(_){}try{el.click();}catch(_){} }, tabHandle), 3000, "tabsynth"); tabRes = "synth"; } catch (__) {} }
            }
            // SEMPRE tenta também a ABA .ui-tab — antes era `else` do
            // #loginTabButton. No precisar777.vip o #loginTabButton EXISTE (é o
            // <span> do rótulo dentro da própria aba) e o clique nativo pode
            // falhar por actionability (elemento fora da viewport da janela
            // pequena) sem que nada mais tentasse trocar a aba. Rodar os dois é
            // idempotente: com Login já ativa não existe aba Login inativa.
            {
              // FALLBACK ABA .ui-tab (701win.win, 2026-08-27, DOM inspecionado):
              // o mirror .win não tem #loginTabButton. O form Registro/Login é
              // um `.ui-tabs` embutido na home (Registro é a aba DEFAULT); a aba
              // ATIVA tem a classe `ui-tab--active`. A tentativa anterior (1º
              // "Login" por texto) pegava o botão "Login" do CABEÇALHO
              // (`_un-login_`), NÃO a aba do form → o form nunca trocava e o bot
              // preenchia o REGISTRO. Aqui o alvo é a ABA de verdade: um
              // `.ui-tab` com texto login/entrar SEM `--active`, clicado com
              // eventos de ponteiro reais. Idempotente (Login já ativa = não há
              // aba inativa com esse texto, não faz nada).
              try {
                const ok = await withTO(frame.evaluate(() => {
                  function isVis(el){ try{ if(!el||!el.isConnected) return false; var r=el.getBoundingClientRect(); if(r.width<2||r.height<2) return false; var s=getComputedStyle(el); if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity||1)<0.05) return false; return true; }catch(e){ return false; } }
                  var tabs=document.querySelectorAll('.ui-tab, [class*="ui-tab--"]'); var loginTab=null;
                  for (var i=0;i<tabs.length;i++){ var el=tabs[i]; if(!isVis(el)) continue; var cls=((el.className||'')+'').toLowerCase(); if(cls.indexOf('ui-tab--active')!==-1) continue; var t=(el.textContent||'').trim().toLowerCase(); if(/^(login|entrar|acessar)$/.test(t)){ loginTab=el; break; } }
                  if(!loginTab) return false;
                  try{ loginTab.scrollIntoView({block:'center'}); }catch(e){}
                  var r=loginTab.getBoundingClientRect(),x=r.left+r.width/2,y=r.top+r.height/2,o={bubbles:true,cancelable:true,clientX:x,clientY:y,button:0,buttons:1};
                  try{ loginTab.dispatchEvent(new PointerEvent('pointerdown',Object.assign({pointerType:'mouse'},o))); }catch(e){}
                  try{ loginTab.dispatchEvent(new MouseEvent('mousedown',o)); }catch(e){}
                  try{ loginTab.dispatchEvent(new PointerEvent('pointerup',Object.assign({pointerType:'mouse'},o,{buttons:0}))); }catch(e){}
                  try{ loginTab.dispatchEvent(new MouseEvent('mouseup',Object.assign({},o,{buttons:0}))); }catch(e){}
                  try{ loginTab.dispatchEvent(new MouseEvent('click',Object.assign({},o,{buttons:0}))); }catch(e){}
                  try{ loginTab.click(); }catch(e){}
                  return true;
                }), 2500, "tabtext");
                if (ok) tabRes = tabRes === "none" ? "tab" : tabRes + "+tab";
              } catch (_) {}
            }
          } catch (_) {}
          // GATE ROBUSTO (2026-08-27): só preenche quando a aba LOGIN está ATIVA.
          // Sinal definitivo = existe um BOTÃO DE SUBMIT grande com texto
          // "Login"/"Entrar" (no Registro o botão grande diz "Registro"). Não
          // depende de detectar "Confirmar senha" (elementFromPoint falha em input
          // com ícone). Só exige isso em casas que TÊM aba Registro (form com
          // tabs); casa antiga de form único (sem "Registro") preenche direto.
          // Poll adaptativo até ~6s (máquina lenta espera mais).
          const loginGate = () => frame.evaluate(() => {
            function isVis(el){ try{ if(!el||!el.isConnected) return false; var r=el.getBoundingClientRect(); if(r.width<2||r.height<2) return false; var s=getComputedStyle(el); if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity||1)<0.05) return false; var cx=r.left+r.width/2, cy=r.top+r.height/2; var vw=window.innerWidth||document.documentElement.clientWidth, vh=window.innerHeight||document.documentElement.clientHeight; if(cx<0||cy<0||cx>vw||cy>vh) return false; return true; }catch(e){return false;} }
            function deepAll(sel){ var out=[],seen=[]; function walk(root){ if(!root||seen.indexOf(root)!==-1)return; seen.push(root); var m; try{m=root.querySelectorAll(sel);}catch(e){m=[];} for(var i=0;i<m.length;i++)out.push(m[i]); var all; try{all=root.querySelectorAll('*');}catch(e){all=[];} for(var j=0;j<all.length;j++){ if(all[j].shadowRoot) walk(all[j].shadowRoot);} } walk(document); return out; }
            var els = deepAll('.ui-button,[class*="ui-button"],button,div[role="button"],a');
            var hasReg=false, loginBtn=false;
            for (var i=0;i<els.length;i++){ var el=els[i]; if(!isVis(el)) continue; var cls=((el.className||'')+'').toLowerCase(); var tn=el.querySelector?el.querySelector('.ui-button__text'):null; var t=((tn?tn.textContent:el.textContent)||'').trim().toLowerCase(); var rr=el.getBoundingClientRect();
              // Match por RADICAL (não exato): o botão de cadastro do okok pode
              // dizer "Registrar-se"/"Cadastre-se"/"Inscreva-se" — com igualdade
              // estrita hasReg dava false, o gate liberava pelo ramo !hasReg e o
              // bot preenchia o CADASTRO (bug "às vezes preenche em cadastro",
              // 2026-08-27). Regex cobre as variações; direção segura (bloqueia
              // mais cadastro, no pior caso não preenche em vez de preencher errado).
              if(/regist|cadastr|inscri|inscre/.test(t)) hasReg=true;
              if(/\b(login|entrar|acessar)\b/.test(t) && rr.width>=150 && el.id!=='loginTabButton' && !(el.closest&&el.closest('#loginTabButton')) && !/ui-button__content|ui-button__text|\btab\b/.test(cls)) loginBtn=true;
            }
            // ABA ATIVA (701win.win, 2026-08-27, DOM inspecionado): sinal
            // AUTORITATIVO em forms `.ui-tabs`. A aba ativa tem `ui-tab--active`.
            // `hasReg` sozinho NÃO serve (a aba "Registro" fica visível como aba
            // INATIVA mesmo com Login ativo → hasReg sempre true); e o 701win
            // não usa input[type=password] (pwCount inútil). regActive=1 só
            // quando a ABA ATIVA é a de cadastro → bloqueia até o clique trocar
            // pra Login. loginActive=1 quando a aba ativa é Login. Casa sem
            // `.ui-tab--active` (form único antigo) → ambos 0, cai no ramo
            // hasReg/loginBtn de sempre.
            var regActive=0, loginActive=0;
            var atabs=deepAll('.ui-tab--active, [class*="ui-tab--active"]');
            for (var a=0;a<atabs.length;a++){ if(!isVis(atabs[a])) continue; var at=(atabs[a].textContent||'').trim().toLowerCase(); if(/regist|cadastr|inscri|inscre/.test(at)) regActive=1; if(/\b(login|entrar|acessar)\b/.test(at)) loginActive=1; }
            return { hasReg: hasReg, loginBtn: loginBtn, regActive: regActive, loginActive: loginActive };
          });
          // Gate curto (~1.8s): se o Login não ativar nesse tempo, LIBERA e deixa
          // o poll re-clicar a aba logo (segurar o lock por muito tempo era o que
          // atrasava o clique na aba Login). Re-clicar é idempotente.
          let loginPronto = false; let gLast = null; let gErr = "";
          for (let w = 0; w < 12; w++) {
            let g = null;
            try { g = await withTO(loginGate(), 4000, "gate"); } catch (e) { gErr = (e && e.message) || String(e); }
            gLast = g;
            // Só BLOQUEIA quando detecta POSITIVAMENTE a aba Registro ativa
            // (hasReg && !loginBtn). Se o gate resolveu de qualquer outro jeito —
            // ou FALHOU (g=null, evaluate lento/instável no okok) — não trava:
            // segue pro localizador de campos (que tem visibilidade estrita e não
            // preenche a aba errada). Antes, g=null deixava pronto=false pra
            // sempre e o re-login nunca preenchia no okok.
            if (!g) { loginPronto = true; break; }
            // Aba ATIVA é a de Registro (`.ui-tab--active`) = bloqueia NA CERTEZA
            // até o clique trocar pra Login — vale mais que hasReg/loginBtn.
            if (g.regActive) { loginPronto = false; await new Promise((r) => setTimeout(r, 150)); continue; }
            // Aba Login ativa OU form de tab não detectado (regActive=0): libera
            // pelo ramo antigo (hasReg da aba inativa não bloqueia mais).
            if (g.loginActive || !g.hasReg || g.loginBtn) { loginPronto = true; break; }
            await new Promise((r) => setTimeout(r, 150));
          }
          // DIAG: decisão do gate (+ erro do evaluate, se houve).
          try { if ((win.__reDbg=(win.__reDbg||0)+1) <= 25) { const {queueDiagLine}=require("../../auto-register.cjs"); queueDiagLine(`[${new Date().toISOString()}] [re-login] gate tab=${tabRes} hasReg=${gLast&&gLast.hasReg} loginBtn=${gLast&&gLast.loginBtn} regAtiva=${gLast&&gLast.regActive} loginAtiva=${gLast&&gLast.loginActive} pronto=${loginPronto} gErr=${gErr||"-"} url=${(function(){try{return (frame.url()||"").slice(0,45);}catch(e){return "?";}})()}\r\n`); } } catch {}
          if (!loginPronto) { continue; }
          let acc = null, pw = null; let fErr = "";
          try { acc = (await withTO(frame.evaluateHandle(fieldExpr("account")), 4000, "findacc")).asElement(); } catch (e) { fErr = (e && e.message) || String(e); }
          try { pw = (await withTO(frame.evaluateHandle(fieldExpr("userpass")), 4000, "findpw")).asElement(); } catch (e) { if (!fErr) fErr = (e && e.message) || String(e); }
          try { if ((win.__reDbg2=(win.__reDbg2||0)+1) <= 25) { const {queueDiagLine}=require("../../auto-register.cjs"); queueDiagLine(`[${new Date().toISOString()}] [re-login] campos accFound=${!!acc} pwFound=${!!pw} fErr=${fErr||"-"}\r\n`); } } catch {}
          if (!acc || !pw) continue;
          try {
            // Digitação REAL sem travar: foca via DOM (frame.evaluate, não faz
            // hit-test/actionability) e digita com page.keyboard.type (manda
            // teclas pro elemento focado). ElementHandle.type() travava nos
            // inputs .ui-input__input size=1. Limpa o campo antes (seleciona tudo).
            const realType = async (h, val) => {
              await withTO(frame.evaluate((el) => { try { el.focus(); if ('value' in el) el.value=''; } catch(e){} }, h), 3000, "focus");
              // CONFIRMA o foco antes de digitar (senão as teclas do login se
              // perdem quando muitas telas abrem juntas e o foco ainda não firmou).
              let focado = false;
              for (let k = 0; k < 5; k++) {
                try { focado = await withTO(frame.evaluate((el) => document.activeElement === el, h), 1500, "chkfocus"); } catch (_) {}
                if (focado) break;
                try { await withTO(frame.evaluate((el) => { try { el.focus(); } catch(e){} }, h), 1500, "refocus"); } catch (_) {}
                await new Promise((r) => setTimeout(r, 60));
              }
              await withTO(page.keyboard.type(String(val || ""), { delay: 10 }), 7000, "kbd");
              // garante os eventos que o framework escuta
              await withTO(frame.evaluate((el) => { try { el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); } catch(e){} }, h), 3000, "evt").catch(() => {});
            };
            // page.keyboard digita no elemento focado DESTA página; se houver
            // páginas duplicadas (visível vs background), traz a certa pra frente.
            try { await withTO(page.bringToFront(), 3000, "front"); } catch (_) {}
            await realType(acc, cred.login);
            await realType(pw, cred.senha);
            await new Promise((r) => setTimeout(r, 250));
            // READ-BACK no HANDLE é FALSO-POSITIVO quando o Vue re-renderiza o
            // form ao trocar Registro→Login (2026-08-27, okok com tab=native): o
            // elemento preenchido vira ÓRFÃO (detached) e el.value nele AINDA
            // retorna o texto digitado, enquanto o campo VISÍVEL de verdade fica
            // vazio → login enviado em branco, erro vermelho "informe login e
            // senha". Por isso confere o campo VIVO (re-query pelo findLoginFields
            // = o que o usuário vê AGORA), não o handle antigo.
            let vAcc = "", vPw = "";
            try { vAcc = await withTO(frame.evaluate((el) => el.value || "", acc), 3000, "read-acc"); } catch (_) {}
            try { vPw = await withTO(frame.evaluate((el) => el.value || "", pw), 3000, "read-pw"); } catch (_) {}
            let liveA = "", liveP = "";
            try {
              const lv = await withTO(frame.evaluate(`(() => { ${__FIND_FIELDS_FN} var f = findLoginFields(); return f ? { a: (f.acc && f.acc.value) || "", p: (f.pw && f.pw.value) || "" } : { a: "", p: "" }; })()`), 3000, "verify-live");
              liveA = (lv && lv.a) || ""; liveP = (lv && lv.p) || "";
            } catch (_) {}
            try { const { queueDiagLine } = require("../../auto-register.cjs"); if ((win.__reVerifyDbg = (win.__reVerifyDbg || 0) + 1) <= 25) queueDiagLine(`[${new Date().toISOString()}] [re-login] verify handleAcc=${vAcc.length} handlePw=${vPw.length} liveAcc=${liveA.length} livePw=${liveP.length}\r\n`); } catch {}
            // Exige os campos VIVOS preenchidos (não só o handle). Se o campo
            // visível está vazio (re-render/órfão ou página duplicada), NÃO
            // conclui — o próximo poll re-acha os campos FRESCOS e re-preenche.
            if (!liveA || !liveP) { continue; }
            // ESCALONA O ENVIO (2026-08-28, medido): com 5 telas abertas juntas,
            // os 5 POST de login saem no mesmo instante do MESMO IP e o
            // Cloudflare da casa derruba o último — o diag da tela 5 pegou
            // ERR_FAILED em precisar777.app e .com e HTTP403 em .net (alias
            // bmsource-api.bulletspcf.com), enquanto as telas 1-4 passaram
            // limpas. Espalhar o clique por tela custa no máximo ~2s e tira a
            // rajada que dispara o anti-bot. O jitter evita que duas telas com o
            // mesmo número (janelas recriadas) voltem a coincidir.
            try {
              const ordem = parseInt(win._pandoraOrder, 10);
              if (Number.isFinite(ordem) && ordem > 1) {
                await new Promise((r) => setTimeout(r, ((ordem - 1) % 6) * 400 + Math.floor(Math.random() * 300)));
              }
            } catch (_) {}
            // Marca onde o tap de rede estava ANTES do clique: o que entrar daqui
            // pra frente é consequência DESTE envio (ver janela de observação).
            let tapBase = 0; try { tapBase = win.__netTapSeq || 0; } catch (_) {}
            // Clique no botão Login: clique real (com timeout) → fallback sintético.
            let clicked = false;
            try {
              const btn = (await withTO(frame.evaluateHandle(loginBtnExpr), 4000, "findbtn")).asElement();
              if (btn) {
                try { await withTO(btn.click(), 4000, "btnclick"); clicked = true; }
                catch (e) { try { await withTO(frame.evaluate((b) => { b.click(); }, btn), 4000, "btnsynth"); clicked = true; } catch (__) {} }
              }
            } catch (_) {}
            // RETRY em ERRO DE REDE (2026-08-27): a API de login do 701win às
            // vezes falha por rede — toast "A conexão de rede falhou, tente
            // novamente depois de mudar a rede" (comum no IPv6 residencial sem
            // proxy). Antes, `_contaLoginDone=true` era setado SEMPRE após o
            // clique → nunca reenviava. Agora, se detectar ESSE erro (só rede;
            // senha errada mostra outra msg e NÃO deve entrar em loop), NÃO
            // marca concluído: o poll de 250ms re-preenche+re-clica = reenvia o
            // login. Backoff progressivo dá tempo da rota IPv6 assentar; teto de
            // 6 tentativas evita martelar pra sempre.
            // JANELA DE OBSERVAÇÃO (2026-08-28, corrigido com o diag real): o
            // check ANTIGO era ÚNICO, 1,2s depois do clique — e o log das 5 telas
            // mostrou `PUPPETEER preencheu+clicou` em TODAS e ZERO `ERRO DE REDE`,
            // mesmo com o usuário vendo o erro na tela. Falha de rede por TIMEOUT
            // demora vários segundos pra virar toast: aos 1,2s ainda não havia
            // nada, o código marcava concluído e nunca reenviava. Agora observa
            // até 12s (a cada 500ms) e sai antes se der certo (campos de login
            // sumiram = logou). Também captura o TEXTO do toast pro diag, mesmo
            // quando não é de rede — se a regex não bater, o log mostra a frase
            // exata pra ajustar em vez de ficar cego de novo.
            let netErr = false; let toastTxt = ""; let netWhy = "";
            if (clicked) {
              const obsExpr = `(() => { ${__FIND_FIELDS_FN}
                function isVis(el){ try{ var r=el.getBoundingClientRect(); if(r.width<2||r.height<2) return false; var s=getComputedStyle(el); if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity||1)<0.05) return false; return true; }catch(e){return false;} }
                var els=document.querySelectorAll('div,span,p,li,section,[class*="toast"],[class*="message"],[class*="notice"]');
                var net=false, txt="";
                for (var i=0;i<els.length;i++){ var el=els[i]; if(!isVis(el)) continue; var t=(el.textContent||'').trim(); if(!t||t.length>140) continue; var lt=t.toLowerCase();
                  if(/conex[aã]o de rede falhou|falha de rede|erro de rede|network error|(tente novamente[^]{0,30}(rede|conex))|((rede|conex)[^]{0,30}tente novamente)|mudar a rede/.test(lt)){ net=true; txt=t.slice(0,120); break; }
                  if(!txt && /erro|falh|inv[áa]lid|incorret|tente novamente|time ?out|expirou/.test(lt)) txt=t.slice(0,120);
                }
                var f=null; try{ f=findLoginFields(); }catch(e){}
                return { net: net, txt: txt, gone: !(f && f.acc && f.pw) };
              })()`;
              const fim = Date.now() + 12000;
              while (Date.now() < fim) {
                await new Promise((r) => setTimeout(r, 500));
                let res = null;
                try { res = await withTO(frame.evaluate(obsExpr), 3000, "neterr"); } catch (_) {}
                // SINAL PRIMÁRIO = a chamada de login que falhou de verdade
                // (2026-08-28). Ler o toast não bastou: na tela 5 o form sumiu
                // antes de qualquer mensagem aparecer, o loop saiu por `gone` e
                // o envio foi dado como bom mesmo com os 3 espelhos recusando.
                // O tap não depende de texto na tela nem de timing de UI.
                try {
                  const novas = (win.__netTap || []).filter((o) => o && o.seq > tapBase).map((o) => o.s);
                  if (novas.some((s) => /login|auth|signin|token|member/i.test(s))) { netErr = true; netWhy = novas.join(" ~ "); break; }
                } catch (_) {}
                if (!res) continue;
                if (res.txt && !toastTxt) toastTxt = res.txt;
                if (res.net) { netErr = true; break; }
                if (res.gone) break; // form de login sumiu = entrou, não espera o resto
              }
            }
            if (netErr) {
              const n = (win.__reNetRetry = (win.__reNetRetry || 0) + 1);
              // CAUSA REAL da falha (2026-08-27): o toast é a mensagem do FRONT da
              // casa; ele não diz se foi DNS, timeout, WAF (403) ou 5xx. Medido
              // aqui nesta máquina: os domínios das casas NÃO têm registro AAAA
              // (só A) — logo o tráfego já é IPv4 e "trocar pra IPv4" não é o
              // conserto. Este tap loga o motivo verdadeiro da chamada que falhou
              // pra parar de chutar: errorText do Chrome (ERR_*) e status HTTP.
              let tap = netWhy;
              try { if (!tap) tap = (win.__netTap || []).slice(-4).map((o) => o && o.s).join(" ~ "); } catch {}
              try { const { queueDiagLine } = require("../../auto-register.cjs"); queueDiagLine(`[${new Date().toISOString()}] [re-login] ERRO DE REDE no envio (retry ${n}/8) — tela ${win._pandoraOrder || "?"} toast="${toastTxt}" rede=[${tap || "sem falha capturada"}]\r\n`); } catch {}
              if (n < 8) {
                // Backoff COM JITTER: sem ele, N telas que falharam juntas
                // reenviam todas no mesmo instante (thundering herd) e levam o
                // mesmo erro de novo. O jitter espalha os reenvios.
                await new Promise((r) => setTimeout(r, Math.min(9000, 1200 * n) + Math.floor(Math.random() * 1500)));
                continue; // NÃO marca done — próximo poll re-preenche+re-clica (reenvia o login)
              }
              try { const { queueDiagLine } = require("../../auto-register.cjs"); queueDiagLine(`[${new Date().toISOString()}] [re-login] desisti após ${n} tentativas (erro de rede persistente) — tela ${win._pandoraOrder || "?"}\r\n`); } catch {}
            }
            win._contaLoginDone = true;
            try {
              const { queueDiagLine } = require("../../auto-register.cjs");
              // toast/tap SEMPRE no log (2026-08-28): antes, um toast que a regex
              // de rede não pegasse sumia sem deixar rastro — foi exatamente o que
              // cegou o diagnóstico (5 telas "preencheu+clicou", zero pista).
              let tapOk = ""; try { tapOk = (win.__netTap || []).slice(-3).map((o) => o && o.s).join(" ~ "); } catch {}
              if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [autologin] PUPPETEER preencheu+${clicked ? "clicou" : "SEM clique"} — tela ${win._pandoraOrder || "?"}${toastTxt ? ` toast="${toastTxt}"` : ""}${tapOk ? ` rede=[${tapOk}]` : ""}\r\n`);
            } catch {}
            // "Login preenchido e enviado" saiu a pedido do usuário
            // (2026-09-02): o "Login realizado" já diz o que importa.
            return;
          } catch (e) {
            try {
              const { queueDiagLine } = require("../../auto-register.cjs");
              if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [autologin] PUPPETEER erro no fill — ${e && e.message || e}\r\n`);
            } catch {}
          }
        }
      }
    } catch (_) {} finally { __ppBusy = false; }
  };
  try {
    let __ppTries = 0;
    puppeteerLogin(); // 1ª tentativa IMEDIATA (não espera 1 tick do poll)
    // Poll rápido (250ms) — clica a aba Login e começa a preencher assim que o
    // form montar. O guard __ppBusy evita sobreposição.
    const __ppPoll = setInterval(() => {
      __ppTries++;
      if (win.isDestroyed() || win._contaLoginDone || __ppTries > 350) { clearInterval(__ppPoll); return; }
      puppeteerLogin();
    }, 250);
    wc.on("destroyed", () => { try { clearInterval(__ppPoll); } catch {} });
  } catch {}

  // Captura o sinal "login concluido"/"sem confirmacao" do script acima
  // (console.log com tag [pandora-autologin]) e joga no Log de Operações —
  // aparece tanto em janela visível quanto em Operação Oculta, já que não
  // depende do usuário ver a tela (pedido do usuário 2026-08-09).
  if (!win._autoLoginLogAttached) {
    win._autoLoginLogAttached = true;
    wc.on("console-message", (_e, _level, message) => {
      try {
        if (typeof message !== "string" || !message.startsWith("[pandora-autologin]")) return;
        const tela = win._pandoraOrder || "?";
        if (message.includes("login concluido")) {
          // Pedido do usuário 2026-08-10: mensagem exata "conta logada tela
          // X" no Log de Operações.
          logSystem(`Conta logada — Tela ${tela}`, { kind: "auto-login", tela }, "success", "operacao-login");
        } else if (message.includes("login sem confirmacao")) {
          logSystem(`Tela ${tela} — Login enviado, sem confirmação em 20s (verifique manualmente)`, { kind: "auto-login", tela }, "warning", "operacao-login");
        }
        // "submit clicado" não vira mais linha de log: o usuário pediu tirar
        // "Login preenchido e enviado" em 2026-09-02 ("quando aparece Login
        // realizado eu já sei que logou"). Foi pedido em 2026-08-10 e
        // desfeito aqui — se voltar a fazer falta, é só religar este ramo.
      } catch {}
    });
  }
}

// Fecha automaticamente banners/popups/anúncios quando a opção "Sem anúncios"
// (func_sem_envelopes) está ativa na aba Início. Aplica-se a TODAS as janelas
// Chromium (chrome:open, openMulti, Abrir Selecionadas). Re-injeta após cada
// navegação. Evita fechar modais de depósito/saque/PIX por padrão.
function attachPopupCloser(win) {
  if (!win || win.isDestroyed()) return;
  const wc = win.webContents;
  const POPUP_JS = `(() => {
    try {
      if (window.__pandoraPopupCloserOn) return;
      window.__pandoraPopupCloserOn = true;
      window.__pandoraPopupCloserEnabled = true;
      var closed = 0;
      var t0 = Date.now();
      var DUR = 600000;
      function visible(el){
        try {
          if (!el || !el.isConnected) return false;
          var r = el.getBoundingClientRect();
          if (r.width < 2 || r.height < 2) return false;
          var s = getComputedStyle(el);
          if (s.display === 'none' || s.visibility === 'hidden' || Number(s.opacity||1) < 0.05) return false;
          return true;
        } catch(e){ return false; }
      }
      function isSafeModal(root){
        // Não fechar modais de depósito/saque/PIX/login/segurança/cadastro
        try {
          var hay = ((root && (root.innerText || root.textContent)) || '').toLowerCase();
          // Pedido do usuário 2026-08-19 (versopg.vip, print real): popup
          // "Parabéns, Cadastro Concluído!" (promocional pós-sucesso, só
          // "Baixar APP"/"Depositar agora", sem formulário nenhum) tinha as
          // palavras "cadastro"/"depósito" e caía direto no match genérico
          // abaixo, sendo protegido como se fosse um formulário de verdade.
          // Popup de sucesso não é formulário — deixa fechar mesmo citando
          // essas palavras.
          if (/parab[ée]ns.{0,60}(cadastro|registro).{0,30}conclu[ií]do|cadastro conclu[ií]do|registro conclu[ií]do/i.test(hay)) {
            // segue pras próximas barreiras (confirmação/conta/etc.) — não
            // marca como seguro só por isso.
          } else if (/dep[oó]sito|deposit|recarga|recarregar|sacar|saque|withdraw|pix|chave|senha de saque|security|pin de seguran|cadastr|registr|sign\s*up|criar conta/i.test(hay)) return true;
          // BUG real 2026-08-09 (reportado pelo usuário: clicar na seta de
          // voltar da tela de depósito/QR abre um popup de confirmação, e o
          // bot fica fechando esse popup sozinho — a pessoa nunca consegue
          // voltar de verdade) — QUALQUER diálogo que pede confirmação
          // "sim/não, confirmar/cancelar, tem certeza" é sempre uma decisão
          // de verdade do usuário, nunca propaganda/spam — protegido
          // independente de qual tela/URL a gente ACHA que está (evita
          // depender de acertar o gating por rota, que pode ter uma corrida
          // se a URL já mudou antes do popup terminar de aparecer).
          // "no"/"yes" sozinhos ficam de fora de propósito — são palavras
          // comuns demais em português ("no jogo", "no site"...), dariam
          // falso positivo em quase qualquer popup e quebrariam o "Sem
          // anúncios" de verdade. Só frases específicas o bastante pra não
          // se confundirem com texto normal de propaganda.
          if (/tem certeza|deseja (mesmo )?sair|deseja realmente|confirmar\b|cancelar\b|are you sure|do you want to leave/i.test(hay)) return true;
          // BUG GRAVE real 2026-08-09 (semanas de investigação do "Relatório
          // de Apostas" sempre em branco — "aparece e some quase no mesmo
          // instante" num F5 manual): a tela de Conta/Apostas/Relatório/
          // Recuperar o Saldo (/home/mine, /home/report) é renderizada como
          // body > div com uma seta "voltar" no topo — essa seta batia num
          // dos seletores genéricos de botão-de-fechar abaixo, e como
          // "Conta"/"Relatório"/"Saldo atual" não estavam nessa lista seguem,
          // o container INTEIRO era escondido (display:none) 400ms depois de
          // renderizar — o "sempre em branco" nunca foi bug de navegação,
          // clique ou anti-bot: era esse fechador de popup genérico demais
          // apagando a tela sozinho.
          if (/\\bconta\\b|relat[óo]rio de apostas|relat[óo]rio\\b|recuperar o saldo|recuperar saldo perdido|saldo atual|meus registros|minhas apostas|gest[ãa]o de saques/i.test(hay)) return true;
          var cls = ((root && root.className) || '') + '';
          if (/deposit|withdraw|recharge|security|pix|login|loginTab|register|signup|cadastro|confirm/i.test(cls)) return true;
          // Se contém input de login/senha, é o modal de cadastro/login — não mexer
          if (root && root.querySelector && root.querySelector('input[data-input-name="account"], input[data-input-name="userpass"], #loginTabButton')) return true;
        } catch(e){}
        return false;
      }
      function injetarImunidadeCSS(){
        try {
          var estiloId = 'trava-antifecho-lembrete';
          if (document.getElementById(estiloId)) return;
          if (!document.head) { setTimeout(injetarImunidadeCSS, 50); return; }
          var style = document.createElement('style');
          style.id = estiloId;
          style.innerHTML = '._retention-dialog_tsbju_93, ._retention-dialog_tsbju_93 .ui-dialog-close-box, ._retention-dialog_tsbju_93 .ui-dialog-close-box__icon, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-dialog-close-box, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-dialog-close-box__icon { pointer-events: none !important; user-select: none !important; } ._retention-dialog_tsbju_93 .ui-button, .ui-popup:has(.ui-dialog__header--undefined--title) .ui-button { pointer-events: auto !important; }';
          document.head.appendChild(style);
          console.log('-> [Spider Core] Imunidade CSS do Lembrete injetada.');
        } catch(e){}
      }
      function protegerFechamentoLembrete(){
        try {
          var popupRetencao = document.querySelector('._retention-dialog_tsbju_93');
          if (!popupRetencao) return;
          var botoes = popupRetencao.querySelectorAll('.ui-dialog-close-box, .ui-dialog-close-box__icon');
          botoes.forEach(function(botaoFecharLembrete){
            try {
              if (!botaoFecharLembrete || botaoFecharLembrete.hasAttribute('data-protegido')) return;
              console.log('-> [Spider Core] Alvo detetado: Protegendo o diálogo de retenção contra fecho automático.');
              botaoFecharLembrete.setAttribute('data-protegido', 'true');
              botaoFecharLembrete.addEventListener('click', function(e){
                if (e && e.isTrusted) return;
                try { e.preventDefault(); e.stopImmediatePropagation(); e.stopPropagation(); } catch(_e){}
                console.log('-> [Spider Core] Tentativa de fecho automatizado bloqueada com sucesso.');
              }, true);
              botaoFecharLembrete.click = function(e){
                if (e && e.isTrusted) {
                  HTMLElement.prototype.click.call(this);
                } else {
                  console.log('-> [Spider Core] Tentativa de fecho automatizado bloqueada com sucesso.');
                }
              };
            } catch(e){}
          });
        } catch(e){}
      }

      function fecharPopupAutomatico(elementoPopup) {
        try {
          protegerFechamentoLembrete();
          injetarImunidadeCSS();

          // Pedido do usuário 2026-08-19 (voy-exhaustpg.com, popup atualizado):
          // novo botão de fechar veio como <i class="... _closeIcon_10372_95">
          // (CSS-module hasheado, "closeIcon" sem hífen) — não batia com
          // nenhum seletor genérico abaixo. Adicionado [class*="closeIcon"].
          var botoesFechar = Array.prototype.slice.call(document.querySelectorAll('.ui-dialog-close-box, .ui-dialog-close-box__icon, [class*="close-box"], [class*="closeBox"], [class*="closeIcon"], [class*="close-btn"], [class*="closeBtn"], .close-icon, .popup-close, [aria-label="Close" i], [aria-label="Fechar" i], [aria-label="close" i]'));
          // Pedido do usuário 2026-08-19 (versopg.vip, popup "Parabéns,
          // Cadastro Concluído!"): o X desse popup é um <svg><path> puro,
          // sem nenhuma classe/aria-label reconhecível pelos seletores
          // acima (confirmado pelo HTML real que o usuário colou). Casa
          // pelo início do atributo "d" do path (identifica o glifo do X
          // dessa lib de ícones) e clica no <svg> pai, que é o elemento
          // clicável de verdade.
          document.querySelectorAll('path[d^="M2.729 45.278a2.304 2.304 0 0 1-.666-1.11"]').forEach(function(p){
            var svgIcone = p.closest('svg') || p.parentElement;
            if (svgIcone) botoesFechar.push(svgIcone);
          });
          botoesFechar.forEach(function(botao){
            try {
              if (botao.hasAttribute('data-protegido') || botao.hasAttribute('data-pandora-tentei')) return;
              var conteinerPai = botao.closest('.ui-popup, .ui-dialog, .ui-overlay, [role="dialog"], [class*="popup"], [class*="dialog"], [class*="modal"], body > div');
              if (!conteinerPai || !visible(conteinerPai)) return;

              // BARREIRA 1: Lembrete de retenção (NUNCA fechar)
              var textoDoConteiner = (conteinerPai.textContent || "").toLowerCase();
              if (textoDoConteiner.includes("retornar") ||
                  textoDoConteiner.includes("continuar a pagar") ||
                  textoDoConteiner.includes("histórico de depósitos") ||
                  conteinerPai.querySelector('._retention-dialog_tsbju_93')) {
                return;
              }

              // BARREIRA 2: Modais funcionais (depósito/saque/PIX/login/cadastro/segurança)
              if (isSafeModal(conteinerPai)) return;

              // ALVO: qualquer outro popup visível — fecha agressivamente
              botao.setAttribute('data-pandora-tentei', '1');
              // Pedido do usuário 2026-08-19: log do que exatamente foi
              // clicado — sem isso não dá pra confirmar se é esse fechador
              // que está causando o scroll estranho ao entrar no site.
              try { console.log('[pandora-popupcloser] fechando botao=' + (botao.tagName||'') + '.' + (botao.className||'') + ' container=' + (conteinerPai.tagName||'') + '.' + (conteinerPai.className||'').toString().slice(0,120)); } catch(_e){}
              try { botao.click(); } catch(_e){}
              // fallback: dispara mouseup/mousedown nativos
              try {
                var ev = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
                botao.dispatchEvent(ev);
              } catch(_e){}
              // último recurso: esconde o container se permaneceu visível
              setTimeout(function(){
                try {
                  if (conteinerPai && conteinerPai.isConnected && visible(conteinerPai) && !isSafeModal(conteinerPai)) {
                    conteinerPai.style.setProperty('display', 'none', 'important');
                  }
                } catch(_e){}
              }, 400);
              closed++;
            } catch(e){}
          });
        } catch(e){}
      }

      function isLoggedOut(){
        try {
          var a = document.querySelector('input[data-input-name="account"]');
          var p = document.querySelector('input[data-input-name="userpass"]');
          var tab = document.getElementById('loginTabButton');
          if ((a && visible(a)) || (p && visible(p)) || (tab && visible(tab))) return true;
        } catch(e){}
        return false;
      }
      function tryClose(){
        // Checa a flag a CADA tick — permite desligar em tempo real (o
        // usuário desmarcou "Sem anúncios" enquanto essa janela já estava
        // aberta) sem depender de uma navegação nova pra parar. A flag
        // começa true (só injeta esse script quando a opção já estava
        // marcada) e pode ser virada false de fora via executeJavaScript
        // (ver setPopupCloserEnabledLive em autoLogin.cjs).
        if (window.__pandoraPopupCloserEnabled === false) { clearInterval(iv); return; }
        if (Date.now() - t0 > DUR) { clearInterval(iv); return; }
        if (isLoggedOut()) return;
        if (closed >= 30) { clearInterval(iv); return; }
        try {
          injetarImunidadeCSS();
          protegerFechamentoLembrete();
          fecharPopupAutomatico(document.body);
        } catch(e){}
      }

      try {
        var observer = new MutationObserver(function(){ tryClose(); });
        observer.observe(document.body, { childList: true, subtree: true });
      } catch(e){}
      var iv = setInterval(tryClose, 500);
      tryClose();
    } catch(e){}  })();`;
  const apply = () => {
    try {
      // Re-checa a opção a cada navegação — usuário pode ter desligado.
      if (getSettingSync("func_sem_envelopes", "0") !== "1") return;
      const url = wc.getURL() || "";
      if (url.startsWith("file://")) return;
      // Restringe estritamente à Home — popups/banners só aparecem lá.
      // Em /home/withdraw, /home/deposit, etc., o fechador NÃO pode rodar,
      // pois o "modal" da página é o próprio formulário (senha de saque, etc.).
      let isHome = false;
      try {
        const u = new URL(url);
        const p = (u.pathname || "").replace(/\/+$/, "").toLowerCase();
        isHome = p === "" || p === "/" || p === "/home" || p === "/home/index";
      } catch {}
      // Sempre desliga o fechador ao sair da Home — é SPA (não recarrega a
      // página ao trocar de tela), então o setInterval/MutationObserver
      // injetados na Home continuam rodando "por trás" mesmo depois de
      // navegar pra /home/withdraw etc. se ninguém desligar explicitamente.
      // BUG anterior: essa linha desligava __pandoraPopupCloserOn (só a
      // trava de "não injeta duas vezes"), não __pandoraPopupCloserEnabled
      // (a flag que o loop de verdade checa) — o loop nunca parava de fato
      // ao sair da Home, e por isso fechava popup até na tela de saque.
      // Também remove a CSS de "imunidade" injetada na Home (protege o
      // popup de retenção contra fechamento automático) — ela fica no
      // <head> pra sempre (SPA não recarrega), e uma das regras usa um
      // seletor genérico (.ui-dialog__header--undefined--title) que podia
      // acabar bloqueando o clique no X de OUTRO popup na tela de saque,
      // não só o de retenção da Home.
      wc.executeJavaScript(
        "try{window.__pandoraPopupCloserEnabled=false;window.__pandoraPopupCloserOn=false;document.getElementById('trava-antifecho-lembrete')?.remove();}catch(e){}",
        true
      ).catch(() => {});
      // Pedido do usuário 2026-08-09: "clico na setinha do QR pra voltar, o
      // popup de confirmação aparece, e o bot fecha — não pode fechar" — o
      // BUG real era essa função (apply) rodando de novo a cada navegação
      // (did-navigate-in-page inclusive, que dispara até em transições
      // internas de SPA como clicar em voltar) e REATIVANDO o fechador
      // sempre que a URL parecer "Home" de novo — sobrescrevendo o
      // desligamento que qrCapture.cjs já tinha feito na hora que achou o
      // QR. Uma vez que o QR foi capturado nessa janela, o fechador fica
      // desligado PRA SEMPRE nela (win._pandoraPopupCloserOff, setado em
      // qrCapture.cjs), não importa pra onde a SPA "pareça" ter navegado.
      if (win._pandoraPopupCloserOff) return;
      if (!isHome) return;
      wc.executeJavaScript(POPUP_JS, true).catch(() => {});
    } catch {}
  };
  wc.on("did-finish-load", apply);
  wc.on("did-navigate", apply);
  wc.on("did-navigate-in-page", apply);
}

// Chamado quando o usuário liga/desliga "Sem anúncios" na aba Início —
// avisa TODAS as janelas Chromium já abertas na hora, sem esperar uma
// navegação nova. Ligar não reinicia o fechador sozinho (só a próxima
// navegação injeta o script de verdade); desligar para o que já estiver
// rodando imediatamente.
function setPopupCloserEnabledLive(enabled) {
  try {
    const state = require("../state.cjs");
    const js = `try{window.__pandoraPopupCloserEnabled=${enabled ? "true" : "false"};}catch(e){}`;
    for (const win of state.chromeWins || []) {
      try {
        if (!win || win.isDestroyed()) continue;
        win.webContents.executeJavaScript(js, true).catch(() => {});
      } catch {}
    }
  } catch {}
}

module.exports = { attachContaAutoLogin, attachPopupCloser, setPopupCloserEnabledLive };
