// Multi Bot — gerenciador de perfis isolados.
// Cada perfil é um diretório próprio dentro de <BaseUserData>/profiles/<id>.
// Quando o app é spawnado com --profile-id=<id>, o main.cjs faz
// app.setPath('userData', <profile-dir>) antes de qualquer init, de modo que
// banco SQLite, contas.json, settings, cookies e cache do Chromium ficam
// 100% isolados sem precisar refatorar nenhum outro módulo.

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");

const PRINCIPAL_ID = "principal";

function ensureDirSync(p) {
  try { if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true }); } catch {}
}

function isMultiBotMode(argv = process.argv) {
  return argv.some((a) => a === "--multi-bot");
}

function getProfileIdFromArgv(argv = process.argv) {
  for (const a of argv) {
    if (typeof a !== "string") continue;
    if (a === "--multi-bot") continue;
    const m = a.match(/^--profile-id=(.+)$/);
    if (m) {
      const id = m[1].trim();
      if (/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return id;
    }
  }
  return null;
}

// Pasta-base do Multi Bot: %AppData%/<AppName>/multibot
// Recebe baseUserData explicitamente porque, em modo perfil, app.getPath
// ('userData') já foi sobrescrito para a pasta do perfil.
function getMultiBotRoot(baseUserData) {
  const root = path.join(baseUserData, "multibot");
  ensureDirSync(root);
  ensureDirSync(path.join(root, "profiles"));
  return root;
}

function getProfileDir(baseUserData, profileId) {
  if (profileId === PRINCIPAL_ID) {
    // Perfil PRINCIPAL = userData legado (não move dados existentes).
    return baseUserData;
  }
  return path.join(getMultiBotRoot(baseUserData), "profiles", profileId);
}

function getRegistryPath(baseUserData) {
  return path.join(getMultiBotRoot(baseUserData), "profiles.json");
}

function loadRegistry(baseUserData) {
  const p = getRegistryPath(baseUserData);
  let raw = null;
  try { raw = JSON.parse(fs.readFileSync(p, "utf8")); } catch {}
  const profiles = Array.isArray(raw?.profiles) ? raw.profiles : [];
  // Garante PRINCIPAL sempre presente em primeiro.
  if (!profiles.find((x) => x.id === PRINCIPAL_ID)) {
    profiles.unshift({
      id: PRINCIPAL_ID,
      name: "PRINCIPAL",
      createdAt: new Date().toISOString(),
      lastOpenedAt: null,
    });
    saveRegistry(baseUserData, profiles);
  }
  return profiles;
}

function saveRegistry(baseUserData, profiles) {
  const p = getRegistryPath(baseUserData);
  ensureDirSync(path.dirname(p));
  fs.writeFileSync(p, JSON.stringify({ profiles }, null, 2), "utf8");
}

function listProfiles(baseUserData) {
  return loadRegistry(baseUserData).map((p) => ({
    ...p,
    isPrincipal: p.id === PRINCIPAL_ID,
  }));
}

// Arquivos do perfil PRINCIPAL que fazem sentido herdar num perfil novo:
// o banco (settings/accounts/proxies/pix_keys/logs, tudo num arquivo só) e
// o contas.json (contasStore.cjs — a lista da aba "Contas", separada do SQL).
// Não copia sessão de login/cookies do Chromium de propósito — cada perfil
// deve logar suas PRÓPRIAS contas de cassino nas janelas dele.
const PRINCIPAL_IMPORT_FILES = ["onboarding.sqlite", "contas.json"];

function importFromPrincipal(baseUserData, profileDir) {
  for (const name of PRINCIPAL_IMPORT_FILES) {
    try {
      const src = path.join(baseUserData, name);
      if (fs.existsSync(src)) fs.copyFileSync(src, path.join(profileDir, name));
    } catch (e) { console.warn(`[multibot] falha ao importar ${name} do principal:`, e?.message || e); }
  }
}

function createProfile(baseUserData, name, importSettings) {
  const profiles = loadRegistry(baseUserData);
  const id = crypto.randomUUID().replace(/-/g, "").slice(0, 16);
  const trimmed = String(name || "").trim() || `Perfil ${profiles.length}`;
  const entry = {
    id,
    name: trimmed.slice(0, 40),
    createdAt: new Date().toISOString(),
    lastOpenedAt: null,
  };
  profiles.push(entry);
  const profileDir = getProfileDir(baseUserData, id);
  ensureDirSync(profileDir);
  if (importSettings) importFromPrincipal(baseUserData, profileDir);
  saveRegistry(baseUserData, profiles);
  return entry;
}

function renameProfile(baseUserData, id, name) {
  if (id === PRINCIPAL_ID) throw new Error("Não é possível renomear o perfil PRINCIPAL.");
  const profiles = loadRegistry(baseUserData);
  const idx = profiles.findIndex((p) => p.id === id);
  if (idx < 0) throw new Error("Perfil não encontrado.");
  const trimmed = String(name || "").trim();
  if (!trimmed) throw new Error("Nome inválido.");
  profiles[idx].name = trimmed.slice(0, 40);
  saveRegistry(baseUserData, profiles);
  return profiles[idx];
}

function deleteProfile(baseUserData, id) {
  if (id === PRINCIPAL_ID) throw new Error("Não é possível excluir o perfil PRINCIPAL.");
  const profiles = loadRegistry(baseUserData);
  const idx = profiles.findIndex((p) => p.id === id);
  if (idx < 0) return false;
  profiles.splice(idx, 1);
  saveRegistry(baseUserData, profiles);
  try {
    const dir = getProfileDir(baseUserData, id);
    // Sanity: só apaga dentro de multibot/profiles
    const safeRoot = path.join(getMultiBotRoot(baseUserData), "profiles");
    if (dir.startsWith(safeRoot) && fs.existsSync(dir)) {
      fs.rmSync(dir, { recursive: true, force: true });
    }
  } catch (e) { console.warn("[multibot] erro removendo dir do perfil:", e?.message || e); }
  return true;
}

function markOpened(baseUserData, id) {
  try {
    const profiles = loadRegistry(baseUserData);
    const p = profiles.find((x) => x.id === id);
    if (p) {
      p.lastOpenedAt = new Date().toISOString();
      saveRegistry(baseUserData, profiles);
    }
  } catch {}
}

// Nome do arquivo de handoff de sessão — uso único: escrito aqui antes do
// spawn, consumido (lido + apagado) pelo processo filho assim que a UI dele
// sobe (ver "multibot:consume-session" em multibotHandlers.cjs). Pedido do
// usuário 2026-08-09: já logou uma vez na tela do Multi Bot, não devia
// precisar logar de novo em cada perfil que abre a partir dali.
const SESSION_HANDOFF_FILE = ".mb-pending-session.json";

function writeSessionHandoff(profileDir, session) {
  if (!session || !session.token) return;
  try {
    fs.writeFileSync(path.join(profileDir, SESSION_HANDOFF_FILE), JSON.stringify(session), "utf8");
  } catch (e) { console.warn("[multibot] falha ao gravar handoff de sessão:", e?.message || e); }
}

// Chamado pelo processo FILHO (perfil já aberto) — lê e apaga na hora, então
// só funciona uma vez por spawn (se o perfil for reaberto depois, sem uma
// nova sessão sendo repassada, cai na tela de login normalmente).
function consumePendingSession(profileUserData) {
  const p = path.join(profileUserData, SESSION_HANDOFF_FILE);
  try {
    if (!fs.existsSync(p)) return null;
    const raw = fs.readFileSync(p, "utf8");
    fs.unlinkSync(p);
    const session = JSON.parse(raw);
    if (session && session.token) return session;
  } catch (e) { console.warn("[multibot] falha ao ler handoff de sessão:", e?.message || e); }
  return null;
}

// Spawna uma nova instância do próprio executável com --profile-id=<id>.
// Cada filho roda em processo separado, com lock de single-instance separado
// (pois requestSingleInstanceLock é por userData, que será diferente).
function openProfile(baseUserData, id, electronApp, session) {
  const profiles = loadRegistry(baseUserData);
  if (!profiles.find((p) => p.id === id)) throw new Error("Perfil não encontrado.");
  const profileDir = getProfileDir(baseUserData, id);
  ensureDirSync(profileDir);
  writeSessionHandoff(profileDir, session);
  markOpened(baseUserData, id);

  const exe = process.execPath;
  // Em dev (electron rodando script), precisa passar o script principal antes dos args.
  const isPackaged = electronApp ? electronApp.isPackaged : true;
  const args = [];
  if (!isPackaged) {
    // process.argv[1] aponta para o entry (main.cjs ou ./)
    if (process.argv[1]) args.push(process.argv[1]);
  }
  args.push(`--profile-id=${id}`);

  const child = spawn(exe, args, {
    detached: true,
    stdio: "ignore",
    env: { ...process.env, PANDORA_PROFILE_ID: id },
  });
  try { child.unref(); } catch {}
  return { ok: true, pid: child.pid };
}

module.exports = {
  PRINCIPAL_ID,
  isMultiBotMode,
  getProfileIdFromArgv,
  getMultiBotRoot,
  getProfileDir,
  listProfiles,
  createProfile,
  renameProfile,
  deleteProfile,
  openProfile,
  markOpened,
  consumePendingSession,
};
