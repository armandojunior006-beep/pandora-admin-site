// Hook Geetest v4: intercepta window.initGeetest4 antes do site chamar,
// captura o captchaObj (que normalmente fica em closure), chama o solver
// Python e injeta o resultado disparando os listeners de success.

const { solveGeetest } = require("./captcha-solver.cjs");

// ===== Lock global por instância de widget =====
// Chave = `captchaId:lot_number` — cada /load gera um lot_number único, então
// janelas diferentes (lot_numbers diferentes) resolvem em PARALELO.
// O lock só impede que a MESMA instância (mesmo lot) seja enviada para o
// solver duas vezes em paralelo (evita loops e cobranças duplicadas).
const GLOBAL_CAPTCHA_LOCKS = new Map(); // key -> { winId, since }
function acquireCaptchaLock(key, winId) {
  if (!key) return true;
  const cur = GLOBAL_CAPTCHA_LOCKS.get(key);
  const now = Date.now();
  if (cur && (cur.winId === winId || now - cur.since > 90000)) {
    GLOBAL_CAPTCHA_LOCKS.set(key, { winId, since: now });
    return true;
  }
  if (cur) return false;
  GLOBAL_CAPTCHA_LOCKS.set(key, { winId, since: now });
  return true;
}
function releaseCaptchaLock(key, winId) {
  if (!key) return;
  const cur = GLOBAL_CAPTCHA_LOCKS.get(key);
  if (!cur || cur.winId === winId) GLOBAL_CAPTCHA_LOCKS.delete(key);
}




// Injetado o mais cedo possível em CADA frame: redefine initGeetest4 como
// getter/setter. Quando o script do geetest atribui a função real, a gente
// embrulha. Quando o site chama initGeetest4(config, cb), interceptamos o cb
// pra guardar o captchaObj em window.__pandoraGeetest.
const HOOK_JS = `(() => {
  if (window.__pandoraGeetestHook) return 'already';
  window.__pandoraGeetestHook = true;
  function isLoadUrl(src) {
    try { const u = new URL(src, location.href); return /\\/load\\b/i.test(u.pathname) && /geetest|gcaptcha|gsensebot|geevisit/i.test(u.href); }
    catch(e) { return false; }
  }
  function rememberLoad(src, payload) {
    try {
      const u = new URL(src, location.href);
      const data = payload && payload.data ? payload.data : payload;
      if (!data || !data.lot_number) return;
      const detectedRisk = data.captcha_type || data.risk_type || ((data.imgs && data.ques) ? 'icon' : ((data.slice && data.bg) ? 'slide' : (data.ques ? 'gobang' : 'ai')));
      const state = window.__pandoraGeetest || {};
      window.__pandoraGeetest = {
        ...state,
        captchaId: data.captcha_id || u.searchParams.get('captcha_id') || state.captchaId,
        baseUrl: state.baseUrl,
        loadBaseUrl: u.protocol + '//' + u.host,
        loadData: data,
        riskType: detectedRisk,
        ready: true,
        ts: Date.now(),
      };
      console.log('[pandora] geetest load capturado', data.lot_number, data.captcha_type || data.risk_type || '');
    } catch(e) {}
  }
  function captureLoadText(src, text) {
    try {
      if (!isLoadUrl(src) || !text) return;
      const a = text.indexOf('(');
      const b = text.lastIndexOf(')');
      if (a < 0 || b <= a) return;
      rememberLoad(src, JSON.parse(text.slice(a + 1, b)));
    } catch(e) {}
  }
  function wrapJsonpCallback(src) {
    try {
      if (!isLoadUrl(src)) return;
      const cb = new URL(src, location.href).searchParams.get('callback');
      if (!cb) return;
      let tries = 0;
      const wrapNow = () => {
        const fn = window[cb];
        if (typeof fn !== 'function') return false;
        if (fn.__pandoraWrapped) return true;
        const wrapped = function(payload) {
          rememberLoad(src, payload);
          return fn.apply(this, arguments);
        };
        wrapped.__pandoraWrapped = true;
        window[cb] = wrapped;
        return true;
      };
      if (!wrapNow()) {
        const id = setInterval(() => { if (wrapNow() || ++tries > 30) clearInterval(id); }, 20);
      }
    } catch(e) {}
  }
  try {
    const origFetch = window.fetch;
    if (typeof origFetch === 'function') {
      window.fetch = function(input, init) {
        const src = typeof input === 'string' ? input : (input && input.url);
        return origFetch.apply(this, arguments).then((res) => {
          try { if (isLoadUrl(src)) res.clone().text().then((t) => captureLoadText(src, t)).catch(() => {}); } catch(e) {}
          return res;
        });
      };
    }
  } catch(e) {}
  try {
    const origOpen = XMLHttpRequest.prototype.open;
    const origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url) { this.__pandoraGeetestUrl = url; return origOpen.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function() {
      try {
        this.addEventListener('load', () => {
          try {
            const rt = this.responseType;
            if (rt === '' || rt === 'text') {
              captureLoadText(this.__pandoraGeetestUrl, this.responseText);
            } else if (rt === 'json') {
              try {
                const r = this.response;
                captureLoadText(this.__pandoraGeetestUrl, typeof r === 'string' ? r : JSON.stringify(r));
              } catch(e) {}
            }
            // blob/arraybuffer/document: ignorar (geetest usa json/text)
          } catch(e) {}
        });
      } catch(e) {}
      return origSend.apply(this, arguments);
    };
  } catch(e) {}
  try {
    const inspectNode = (node) => { try { if (node && String(node.tagName).toUpperCase() === 'SCRIPT' && node.src) wrapJsonpCallback(node.src); } catch(e) {} };
    const origAppend = Node.prototype.appendChild;
    const origInsert = Node.prototype.insertBefore;
    Node.prototype.appendChild = function(node) { inspectNode(node); return origAppend.apply(this, arguments); };
    Node.prototype.insertBefore = function(node) { inspectNode(node); return origInsert.apply(this, arguments); };
    const desc = Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype, 'src');
    if (desc && desc.set) {
      Object.defineProperty(HTMLScriptElement.prototype, 'src', {
        configurable: true,
        get: desc.get,
        set: function(v) { try { wrapJsonpCallback(v); } catch(e) {} return desc.set.call(this, v); },
      });
    }
  } catch(e) {}
  function wrap(realFn) {
    if (!realFn || realFn.__pandoraWrappedInit) return realFn;
    const wrappedInit = function(config, cb) {
      try {
        const baseUrl = (function(){
          try {
            const scr = Array.from(document.scripts).find(s => /gcaptcha4|geetest/i.test(s.src||''));
            if (scr && scr.src) { const u = new URL(scr.src); return u.protocol+'//'+u.host; }
          } catch(e){}
          return 'https://gcaptcha4-hrc.gsensebot.com';
        })();
        const wrappedCb = function(captchaObj) {
          try {
            const cid = (config && (config.captchaId || config.gt)) || (captchaObj && captchaObj.getCaptchaId && captchaObj.getCaptchaId());
            const state = window.__pandoraGeetest || {};
            state.successCallbacks = state.successCallbacks || [];
            window.__pandoraGeetest = {
              ...state,
              captchaId: cid,
              baseUrl: baseUrl,
              ready: true,
              ts: Date.now(),
            };
            window.__pandoraGeetestObj = captchaObj;
            if (captchaObj && typeof captchaObj.onSuccess === 'function' && !captchaObj.__pandoraOnSuccessWrapped) {
              const originalOnSuccess = captchaObj.onSuccess.bind(captchaObj);
              captchaObj.onSuccess = function(fn) {
                try {
                  if (typeof fn === 'function' && !window.__pandoraGeetest.successCallbacks.includes(fn)) {
                    window.__pandoraGeetest.successCallbacks.push(fn);
                  }
                } catch(e) {}
                return originalOnSuccess(fn);
              };
              captchaObj.__pandoraOnSuccessWrapped = true;
            }
            console.log('[pandora] initGeetest4 capturado', cid, baseUrl);
          } catch(e) { console.warn('[pandora] hook cb err', e); }
          try { return cb && cb(captchaObj); } catch(e) { console.warn('[pandora] orig cb err', e); }
        };
        return realFn.call(this, config, wrappedCb);
      } catch(e) {
        console.warn('[pandora] wrap err', e);
        return realFn.call(this, config, cb);
      }
    };
    wrappedInit.__pandoraWrappedInit = true;
    return wrappedInit;
  }
  let _real = wrap(window.initGeetest4);
  try {
    Object.defineProperty(window, 'initGeetest4', {
      configurable: true,
      get() { return _real; },
      set(v) { _real = (typeof v === 'function') ? wrap(v) : v; },
    });
  } catch(e) { console.warn('[pandora] defineProperty failed', e); }
  return 'installed';
})()`;

function isGeetestLoadUrl(raw) {
  try {
    const u = new URL(String(raw || ""));
    return /\/load\b/i.test(u.pathname)
      && /geetest|gcaptcha|gsensebot|geevisit/i.test(u.href)
      && !!u.searchParams.get("captcha_id");
  } catch { return false; }
}

function parseLoadPayload(text) {
  try {
    const raw = String(text || "").trim();
    if (!raw) return null;
    let parsed;
    if (raw.startsWith("{")) parsed = JSON.parse(raw);
    else {
      const a = raw.indexOf("(");
      const b = raw.lastIndexOf(")");
      if (a < 0 || b <= a) return null;
      parsed = JSON.parse(raw.slice(a + 1, b));
    }
    return parsed && parsed.data ? parsed.data : parsed;
  } catch { return null; }
}

function detectRiskType(data, fallback = "icon") {
  if (!data) return fallback || "icon";
  return data.captcha_type || data.risk_type
    || ((data.imgs && data.ques) ? "icon" : ((data.slice && data.bg) ? "slide" : (data.ques ? "gobang" : (fallback || "icon"))));
}

function rememberNetworkDetection(win, rawUrl, payload, source = "rede") {
  try {
    if (!win || win.isDestroyed() || !isGeetestLoadUrl(rawUrl)) return;
    const u = new URL(String(rawUrl));
    const data = payload && payload.data ? payload.data : payload;
    const captchaId = (data && data.captcha_id) || u.searchParams.get("captcha_id");
    if (!captchaId) return;
    const riskType = detectRiskType(data, u.searchParams.get("risk_type") || "icon");
    const loadBaseUrl = `${u.protocol}//${u.host}`;
    const state = {
      captchaId,
      baseUrl: loadBaseUrl,
      loadBaseUrl,
      riskType,
      ready: true,
      ts: Date.now(),
      source,
    };
    if (data && data.lot_number) state.loadData = data;
    if (win._geetestSolvedQuietUntil && Date.now() < win._geetestSolvedQuietUntil && !(data && data.lot_number)) return;
    if (win._geetestSolvedLots && data && data.lot_number && win._geetestSolvedLots.has(`${captchaId}:${data.lot_number}`)) return;
    win._geetestNetworkDetected = state;
    const key = `${captchaId}:${data && data.lot_number || "url"}`;
    if (win._geetestLastNetworkKey !== key) {
      win._geetestLastNetworkKey = key;
      const lot = data && data.lot_number ? ` lot=${data.lot_number}` : "";
      console.log(`[geetest] detectado por ${source}: captcha_id=${captchaId} risk=${riskType}${lot}`);
    }
  } catch {}
}

const WEBREQUEST_WATCHERS = new WeakMap();

function registerWebRequestWatcher(win) {
  try {
    if (!win || win.isDestroyed()) return;
    const ses = win.webContents && win.webContents.session;
    if (!ses || !ses.webRequest) return;
    let state = WEBREQUEST_WATCHERS.get(ses);
    if (!state) {
      state = { wins: new Map() };
      WEBREQUEST_WATCHERS.set(ses, state);
      ses.webRequest.onBeforeRequest({ urls: ["*://*/*"] }, (details, callback) => {
        try {
          const id = details && details.webContentsId;
          const target = state.wins.get(id);
          if (target && !target.isDestroyed() && isGeetestLoadUrl(details && details.url)) {
            rememberNetworkDetection(target, details.url, null, "webRequest");
          }
        } catch {}
        callback({});
      });
    }
    state.wins.set(win.webContents.id, win);
    win.on("closed", () => {
      try { state.wins.delete(win.webContents.id); } catch {}
    });
  } catch {}
}

function buildInjectJS(result) {
  const payload = JSON.stringify(result);
  return `(() => {
    try {
      const r = ${payload};
      const fake = {
        captcha_id: r.captcha_id,
        lot_number: r.lot_number,
        pass_token: r.pass_token,
        gen_time: r.gen_time,
        captcha_output: r.captcha_output,
      };
      const looksLikeCaptchaObj = (value) => {
        try {
          return value && typeof value === 'object' && (
            typeof value.getValidate === 'function' ||
            typeof value.onSuccess === 'function' ||
            typeof value.appendTo === 'function' ||
            typeof value.verify === 'function' ||
            typeof value.reset === 'function'
          );
        } catch(e) { return false; }
      };
      const findCaptchaObj = () => {
        if (looksLikeCaptchaObj(window.__pandoraGeetestObj)) return window.__pandoraGeetestObj;
        const seen = new WeakSet();
        const visit = (value, depth) => {
          if (!value || (typeof value !== 'object' && typeof value !== 'function') || depth > 2) return null;
          if (seen.has(value)) return null;
          seen.add(value);
          if (looksLikeCaptchaObj(value)) return value;
          let keys = [];
          try { keys = Object.keys(value).slice(0, 80); } catch(e) { return null; }
          for (const key of keys) {
            if (!/gee|captcha|gt|verify|success|obj|instance|widget/i.test(key)) continue;
            let child;
            try { child = value[key]; } catch(e) { continue; }
            const found = visit(child, depth + 1);
            if (found) return found;
          }
          return null;
        };
        let globalKeys = [];
        try { globalKeys = Object.keys(window).slice(-250); } catch(e) {}
        for (const key of globalKeys) {
          if (!/gee|captcha|gt|verify|widget/i.test(key)) continue;
          let value;
          try { value = window[key]; } catch(e) { continue; }
          const found = visit(value, 0);
          if (found) {
            try { window.__pandoraGeetestObj = found; } catch(e) {}
            return found;
          }
        }
        return null;
      };
      const obj = findCaptchaObj();
      const applyInputs = () => {
        let changed = 0;
        const pairs = [
          ['captcha_id', fake.captcha_id], ['geetest_captcha_id', fake.captcha_id],
          ['lot_number', fake.lot_number], ['geetest_lot_number', fake.lot_number],
          ['pass_token', fake.pass_token], ['geetest_pass_token', fake.pass_token],
          ['gen_time', fake.gen_time], ['geetest_gen_time', fake.gen_time],
          ['captcha_output', fake.captcha_output], ['geetest_captcha_output', fake.captcha_output],
        ];
        for (const [name, value] of pairs) {
          if (value == null) continue;
          const nodes = Array.from(document.querySelectorAll(
            'input[name="' + name + '"], textarea[name="' + name + '"], input[id="' + name + '"], textarea[id="' + name + '"]'
          ));
          for (const el of nodes) {
            try {
              el.value = String(value);
              el.setAttribute('value', String(value));
              el.dispatchEvent(new Event('input', { bubbles: true }));
              el.dispatchEvent(new Event('change', { bubbles: true }));
              changed++;
            } catch(e) {}
          }
        }
        return changed;
      };
      const inputs = applyInputs();
      window.__pandoraGeetestSolved = fake;
      window.__pandoraGeetestSolvedAt = Date.now();
      if (obj) {
        try { obj.getValidate = () => fake; } catch(e) {}
      }
      let fired = 0;
      let methods = 0;
      const called = new WeakSet();
      const call = (cb) => {
        if (typeof cb !== 'function') return;
        if (called.has(cb)) return;
        called.add(cb);
        try { cb(fake); fired++; return; } catch(e) {}
        try { cb(); fired++; } catch(e) {}
      };
      const state = window.__pandoraGeetest || {};
      if (Array.isArray(state.successCallbacks)) {
        for (const cb of state.successCallbacks) call(cb);
      }
      // Tenta vários nomes de listeners conhecidos do Geetest, mas sem chamar
      // obj.onSuccess(fake), porque no v4 onSuccess normalmente registra callback.
      if (obj) {
        const buckets = [obj.eventListeners, obj._eventListeners, obj.listeners, obj._events, obj.events];
        for (const b of buckets) {
          if (!b) continue;
          const list = b.success || b.onSuccess || b.complete || [];
          if (Array.isArray(list)) {
            for (const cb of list) call(cb);
          } else {
            call(list);
          }
        }
      }
      const visit = (value, depth, path) => {
        if (!value || depth > 4) return;
        if (typeof value === 'function') {
          if (/success|complete|done|finish/i.test(path) && !/onSuccess$/i.test(path)) call(value);
          return;
        }
        if (typeof value !== 'object') return;
        try {
          if (value instanceof Map) {
            for (const [k, v] of value.entries()) visit(v, depth + 1, path + '.' + String(k));
            return;
          }
          if (value instanceof Set) {
            let i = 0;
            for (const v of value.values()) visit(v, depth + 1, path + '.set' + (i++));
            return;
          }
          const keys = Array.isArray(value) ? value.keys() : Object.keys(value);
          for (const k of keys) {
            const key = String(k);
            if (key.length > 80) continue;
            let child;
            try { child = value[k]; } catch(e) { continue; }
            visit(child, depth + 1, path + '.' + key);
          }
        } catch(e) {}
      };
      if (obj) {
        visit(obj, 0, 'obj');
        for (const method of ['emit', 'trigger', 'fire', 'dispatch', '_emit', '_trigger', '_fire']) {
          if (typeof obj[method] !== 'function') continue;
          for (const eventName of ['success', 'complete', 'done']) {
            try { obj[method](eventName, fake); methods++; } catch(e) {}
            try { obj[method](eventName); methods++; } catch(e) {}
          }
        }
      }
      try { document.dispatchEvent(new CustomEvent('pandora-geetest-solved', { detail: fake })); } catch(e) {}
      try { window.dispatchEvent(new CustomEvent('pandora-geetest-solved', { detail: fake })); } catch(e) {}
      if (!obj && fired === 0 && methods === 0 && inputs === 0) return 'no-obj inputs=0 fired=0';
      return 'injected obj=' + (obj ? 'yes' : 'no') + ' fired=' + fired + ' methods=' + methods + ' inputs=' + inputs;
    } catch (e) { return 'err: ' + (e && e.message); }
  })()`;
}

function buildVisualPointsJS(result) {
  const payload = JSON.stringify(result);
  return `(() => {
    try {
      const r = ${payload};
      const state = window.__pandoraGeetest || {};
      const load = state.loadData || {};
      const filename = String(load.imgs || r.imgs || '').split('/').pop();
      const expected = { w: 300, h: 200 };
      const scoreCandidate = (el) => {
        try {
          const rect = el.getBoundingClientRect();
          if (!rect || rect.width < 120 || rect.height < 70 || rect.width > 900 || rect.height > 700) return null;
          const style = getComputedStyle(el);
          if (style.visibility === 'hidden' || style.display === 'none' || Number(style.opacity || 1) === 0) return null;
          let score = 0;
          const src = String(el.currentSrc || el.src || style.backgroundImage || '');
          const idc = String(el.id || '') + ' ' + String(el.className || '');
          if (filename && src.includes(filename)) score += 1000;
          if (/geetest|captcha|gt4/i.test(idc)) score += 80;
          if (el.tagName === 'CANVAS') score += 50;
          if (el.tagName === 'IMG') score += 30;
          const ratio = rect.width / rect.height;
          score += Math.max(0, 40 - Math.abs(ratio - 1.5) * 80);
          if (rect.width >= 240 && rect.width <= 420 && rect.height >= 140 && rect.height <= 300) score += 35;
          const naturalW = Number(el.naturalWidth || el.width || expected.w) || expected.w;
          const naturalH = Number(el.naturalHeight || el.height || expected.h) || expected.h;
          return { score, rect: { left: rect.left, top: rect.top, width: rect.width, height: rect.height }, naturalW, naturalH };
        } catch(e) { return null; }
      };
      let best = null;
      const selectors = 'img, canvas, [style], .geetest_box, .geetest_window, .geetest_panel, .geetest_bg, .geetest_item_wrap';
      for (const el of Array.from(document.querySelectorAll(selectors))) {
        const c = scoreCandidate(el);
        if (c && (!best || c.score > best.score)) best = c;
      }
      if (!best) return { ok: false, reason: 'no-target' };

      let offsetX = 0, offsetY = 0, rootKnown = true;
      try {
        let w = window;
        while (w && w.frameElement) {
          const fr = w.frameElement.getBoundingClientRect();
          offsetX += fr.left;
          offsetY += fr.top;
          w = w.parent;
        }
      } catch(e) { rootKnown = false; }
      const readPoints = (value) => {
        if (!value) return [];
        if (Array.isArray(value)) return value;
        if (typeof value === 'string') {
          try { return readPoints(JSON.parse(value)); } catch(e) {}
          const nums = value.match(/-?\\d+(?:\\.\\d+)?/g) || [];
          if (nums.length >= 2) {
            const pts = [];
            for (let i = 0; i + 1 < nums.length; i += 2) pts.push([Number(nums[i]), Number(nums[i + 1])]);
            return pts;
          }
        }
        if (typeof value === 'object') {
          if (Array.isArray(value.points)) return value.points;
          if (Array.isArray(value.userresponse)) return value.userresponse;
          if (Array.isArray(value.clicks)) return value.clicks;
        }
        return [];
      };
      const rawSource = r.userresponse || r.user_response || r.points || r.clicks || r.answers || r.answer;
      const raw = readPoints(rawSource);
      if (!raw.length) {
        let preview = '';
        try { preview = JSON.stringify(rawSource).slice(0, 200); } catch(e) { preview = String(rawSource).slice(0, 200); }
        return { ok: false, reason: 'no-userresponse', rect: best.rect, responseType: typeof r.userresponse, sourceType: typeof rawSource, sourcePreview: preview, keys: Object.keys(r).slice(0, 20) };
      }
      const naturalW = best.naturalW > 80 ? best.naturalW : expected.w;
      const naturalH = best.naturalH > 60 ? best.naturalH : expected.h;
      const points = raw.map((p) => {
        let x = Number(Array.isArray(p) ? p[0] : p && p.x);
        let y = Number(Array.isArray(p) ? p[1] : p && p.y);
        if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
        // O valor enviado ao /verify costuma vir em escala interna; converte
        // de volta para pixel da imagem visível para acionar as linhas do widget.
        if (x > naturalW * 1.25 || y > naturalH * 1.25) {
          x = x / 33;
          y = y / 49;
        }
        x = Math.max(0, Math.min(naturalW, x));
        y = Math.max(0, Math.min(naturalH, y));
        const frameX = Math.round(best.rect.left + (x / naturalW) * best.rect.width);
        const frameY = Math.round(best.rect.top + (y / naturalH) * best.rect.height);
        return { x: frameX, y: frameY, rootX: Math.round(frameX + offsetX), rootY: Math.round(frameY + offsetY) };
      }).filter(Boolean);
      return { ok: points.length > 0, points, rect: best.rect, score: best.score, rootKnown };
    } catch(e) { return { ok: false, reason: e && e.message || String(e) }; }
  })()`;
}

function buildVisualConfirmJS() {
  return `(() => {
    try {
      const visible = (el) => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        if (!r || r.width < 8 || r.height < 8) return false;
        const s = getComputedStyle(el);
        return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity || 1) > 0.05;
      };
      const candidates = Array.from(document.querySelectorAll(
        '.geetest_commit, .geetest_submit, .geetest_btn, .geetest_next, .geetest_confirm, button, [role=button], div, span'
      ));
      let best = null;
      for (const el of candidates) {
        if (!visible(el)) continue;
        const text = String(el.innerText || el.textContent || el.getAttribute('aria-label') || el.title || '').trim().toLowerCase();
        const idc = String(el.id || '') + ' ' + String(el.className || '');
        const hay = text + ' ' + idc.toLowerCase();
        let score = 0;
        if (/geetest_(commit|submit|confirm|next|btn)/i.test(idc)) score += 160;
        if (/confirm|submit|verify|ok|done|complete|next|concluir|confirmar|verificar|pr[oó]ximo/.test(hay)) score += 110;
        if (/refresh|close|fechar|cancel|cadastrar|registr|login|deposit|pix|recarregar/.test(hay)) score -= 180;
        const r = el.getBoundingClientRect();
        if (r.width >= 40 && r.height >= 24) score += 20;
        if (score > 80 && (!best || score > best.score)) best = { el, score, text, idc };
      }
      if (!best) return '';
      const r = best.el.getBoundingClientRect();
      const x = Math.round(r.left + r.width / 2), y = Math.round(r.top + r.height / 2);
      const targets = Array.from(new Set([best.el, document.elementFromPoint(x, y)].filter(Boolean)));
      for (const n of targets) {
        for (const type of ['pointermove','pointerdown','pointerup']) {
          try { n.dispatchEvent(new PointerEvent(type, { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y, pointerType:'mouse', button:0, buttons:type==='pointerdown'?1:0 })); } catch(e) {}
        }
        for (const type of ['mousedown','mouseup','click']) {
          try { n.dispatchEvent(new MouseEvent(type, { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y, button:0, buttons:type==='mousedown'?1:0 })); } catch(e) {}
        }
        try { n.click(); } catch(e) {}
      }
      return (best.text || best.idc || 'confirm').slice(0,80);
    } catch(e) { return ''; }
  })()`;
}

function buildStarterClickJS() {
  return `(() => {
    try {
      if (window.__pandoraGeetestClickAt && Date.now() - window.__pandoraGeetestClickAt < 2500) return '';
      const visible = (el) => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        if (!r || r.width < 18 || r.height < 18 || r.width > 720 || r.height > 520) return false;
        const s = getComputedStyle(el);
        return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity || 1) > 0.05;
      };
      const nodes = Array.from(document.querySelectorAll('button, [role=button], a, div, span, canvas, [class*="geetest" i], [id*="geetest" i], [class*="captcha" i], [id*="captcha" i], [class*="verify" i], [id*="verify" i]'));
      let best = null;
      for (const el of nodes) {
        if (!visible(el)) continue;
        const text = String(el.innerText || el.textContent || el.getAttribute('aria-label') || el.title || '').slice(0, 120).toLowerCase();
        const idc = (String(el.id || '') + ' ' + String(el.className || '') + ' ' + String(el.getAttribute('aria-label') || '')).toLowerCase();
        const tag = String(el.tagName || '').toLowerCase();
        let score = 0;
        const hay = text + ' ' + idc;
        if (/deposite|deposit|recarga|recarregar|pix|valor|saque|registerrechargebtn/i.test(hay)) continue;
        // Itens de menu/categoria do lobby (Popular, Slots, Favoritos...) às
        // vezes têm classes CSS com substrings que colidem por acaso com as
        // palavras-chave de captcha abaixo (ex.: algum badge "...verify..."
        // não relacionado) — passavam no filtro mesmo sem ter nada a ver com
        // captcha, e como nunca resolvia nada de verdade (não tinha captcha),
        // ficava clicando ali de novo a cada ~2s pra sempre, "resetando" a
        // tela pra aquela categoria. Exclui pelo TEXTO VISÍVEL do elemento
        // ser só o nome de uma categoria conhecida (texto exato/curto —
        // botões de captcha de verdade nunca têm só isso como texto).
        if (/^\s*(favoritos?|slots?|mini\s*jogos?|esportes?|pescaria|recentes?|populares?|group\s*\w*|cassino|casino|promo[cç][ãa]o|promo[cç][õo]es|in[íi]cio|home|lobby)\s*$/i.test(text)) continue;
        if (!/geetest|gt4|captcha|verify|verifica|verifica[cç][aã]o|concluir|complete|seguran[cç]a/i.test(hay)) continue;
        if (/geetest|gt4|captcha/.test(idc)) score += 90;
        if (/verify|verifica|verifica[cç][aã]o|captcha|concluir|complete|seguran[cç]a/.test(hay)) score += 70;
        if (/button/.test(tag) || el.getAttribute('role') === 'button') score += 20;
        if (/registr|cadastr|login|entrar|senha|password|user|phone|telefone/.test(hay)) score -= 120;
        const r = el.getBoundingClientRect();
        if (r.width >= 80 && r.height >= 28) score += 15;
        if (score > 80 && (!best || score > best.score)) best = { el, score, text, idc };
      }
      if (!best) return '';
      window.__pandoraGeetestClickAt = Date.now();
      const r = best.el.getBoundingClientRect();
      const x = r.left + r.width / 2, y = r.top + r.height / 2;
      try { best.el.scrollIntoView({ block: 'center', inline: 'center' }); } catch(e) {}
      const pointer = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
      for (const type of ['pointermove','pointerover','pointerdown','pointerup']) {
        try { best.el.dispatchEvent(new pointer(type, { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y, pointerId:1, pointerType:'mouse', isPrimary:true, button:0, buttons:type === 'pointerdown' ? 1 : 0 })); } catch(e) {}
      }
      for (const type of ['mousemove','mouseover','mousedown','mouseup','click']) {
        try { best.el.dispatchEvent(new MouseEvent(type, { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y, button:0, buttons:type === 'mousedown' ? 1 : 0 })); } catch(e) {}
      }
      try { best.el.click(); } catch(e) {}
      return (best.text || best.idc || best.el.tagName || 'captcha').slice(0, 80);
    } catch(e) { return ''; }
  })()`;
}

async function sleepMs(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

async function dispatchFrameClick(frame, x, y) {
  try {
    return await frame.executeJavaScript(`(() => {
      try {
        const x = ${JSON.stringify(x)}, y = ${JSON.stringify(y)};
        const target = document.elementFromPoint(x, y);
        if (!target) return false;
        const pointer = typeof PointerEvent === 'function' ? PointerEvent : MouseEvent;
        for (const type of ['pointermove', 'pointerover', 'pointerenter', 'pointerdown', 'pointerup']) {
          target.dispatchEvent(new pointer(type, {
            bubbles: true, cancelable: true, view: window,
            clientX: x, clientY: y, screenX: x, screenY: y,
            pointerId: 1, pointerType: 'mouse', isPrimary: true,
            button: 0, buttons: type === 'pointerdown' ? 1 : 0,
          }));
        }
        for (const type of ['mousemove', 'mouseover', 'mouseenter', 'mousedown', 'mouseup', 'click']) {
          target.dispatchEvent(new MouseEvent(type, {
            bubbles: true, cancelable: true, view: window,
            clientX: x, clientY: y, screenX: x, screenY: y,
            button: 0, buttons: type === 'mousedown' ? 1 : 0,
          }));
        }
        return true;
      } catch(e) { return false; }
    })()`, true);
  } catch { return false; }
}

function getAllFrames(win) {
  const frames = [];
  const push = (frame) => {
    if (!frame) return;
    frames.push(frame);
    try { for (const child of frame.frames || []) push(child); } catch {}
  };
  try { push(win.webContents.mainFrame); } catch {}
  return frames.length ? frames : [win.webContents];
}

async function runInAllFrames(win, js) {
  let last = null;
  for (const f of getAllFrames(win)) {
    try {
      const out = await f.executeJavaScript(js, true);
      if (out) last = out;
    } catch {}
  }
  return last;
}

async function getDetectedGeetest(win) {
  const js = "(window.__pandoraGeetest && window.__pandoraGeetest.ready) ? window.__pandoraGeetest : null";
  let best = null;
  const better = (candidate) => {
    if (!candidate || !candidate.det || !candidate.det.captchaId) return;
    if (!best) { best = candidate; return; }
    const cTs = Number(candidate.det.ts || 0);
    const bTs = Number(best.det.ts || 0);
    const cLot = !!(candidate.det.loadData && candidate.det.loadData.lot_number);
    const bLot = !!(best.det.loadData && best.det.loadData.lot_number);
    if (cLot && !bLot && Date.now() - cTs < 30000) { best = candidate; return; }
    if (!cLot && bLot && cTs - bTs < 4500) return;
    if (cTs > bTs) best = candidate;
  };
  for (const frame of getAllFrames(win)) {
    try {
      const det = await frame.executeJavaScript(js, true);
      better({ det, frame });
    } catch {}
  }
  if (win && win._geetestNetworkDetected && win._geetestNetworkDetected.captchaId) {
    better({ det: win._geetestNetworkDetected, frame: win.webContents });
  }
  return best || { det: null, frame: win.webContents };
}

function buildRefreshCaptchaJS(hard = false) {
  return `(() => {
    try {
      let did = 0;
      const obj = window.__pandoraGeetestObj;
      const methods = ${hard ? "['refresh','reset','showCaptcha','verify','destroy']" : "['refresh','reset','showCaptcha','verify']"};
      for (const method of methods) {
        try { if (obj && typeof obj[method] === 'function') { obj[method](); did++; } } catch(e) {}
      }
      const sels = ['.geetest_refresh', '.geetest_refresh_1', '[class*="refresh" i]', '[aria-label*="refresh" i]', '[aria-label*="atual" i]'];
      for (const sel of sels) {
        for (const el of Array.from(document.querySelectorAll(sel))) {
          try {
            const r = el.getBoundingClientRect();
            const s = getComputedStyle(el);
            if (r.width > 8 && r.height > 8 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.05) { el.click(); did++; }
          } catch(e) {}
        }
      }
      if (${hard ? "true" : "false"}) {
        // Reset agressivo: limpa estado interno do hook + recarrega iframes do geetest
        try {
          if (window.__pandoraGeetest) { window.__pandoraGeetest.ready = false; window.__pandoraGeetest.loadData = null; }
          window.__pandoraGeetestObj = null;
        } catch(e) {}
        for (const fr of Array.from(document.querySelectorAll('iframe'))) {
          try {
            const src = fr.src || '';
            if (/geetest|gcaptcha|gsensebot|geevisit/i.test(src)) { fr.src = src; did++; }
          } catch(e) {}
        }
      }
      return did;
    } catch(e) { return 0; }
  })()`;
}


function buildClearDetectedGeetestJS() {
  return `(() => {
    try {
      if (window.__pandoraGeetest) window.__pandoraGeetest.ready = false;
      return 1;
    } catch(e) { return 0; }
  })()`;
}

function buildForgetGeetestLotJS(captchaId, lotNumber) {
  const cid = JSON.stringify(String(captchaId || ''));
  const lot = JSON.stringify(String(lotNumber || ''));
  return `(() => {
    try {
      const st = window.__pandoraGeetest;
      if (!st) return 0;
      const data = st.loadData || {};
      const curLot = String(data.lot_number || data.challenge || '');
      const curCid = String(st.captchaId || data.captcha_id || '');
      const sameLot = ${lot} && curLot === ${lot};
      const sameCid = ${cid} && curCid === ${cid};
      if (sameLot || (!${lot} && sameCid)) {
        st.ready = false;
        st.loadData = null;
        st.ts = Date.now();
        return 1;
      }
      return 0;
    } catch(e) { return 0; }
  })()`;
}

function buildSolvingOverlayJS(state) {
  const show = state === true || state === 'show';
  return `(() => {
    try {
      const ID = '__pandora_captcha_solving_overlay__';
      const STYLE_ID = '__pandora_captcha_solving_style__';
      const remove = () => {
        const ex = document.getElementById(ID);
        if (ex) {
          if (ex.__pdRepoId) { try { clearInterval(ex.__pdRepoId); } catch {} }
          ex.style.opacity = '0';
          setTimeout(() => { try { ex.remove(); } catch {} }, 180);
        }
      };
      // Só renderiza no top frame para evitar overlay duplicado (main + iframes)
      const isTop = (() => { try { return window.top === window; } catch(e) { return false; } })();
      if (!isTop) { remove(); return 'skip-iframe'; }
      if (!${show ? 'true' : 'false'}) { remove(); return 'hidden'; }
      const panelSels = ['.geetest_panel_next','.geetest_panel','.geetest_panel_box','.geetest_box','.geetest_holder','.geetest_box_wrap','.geetest_panelshowclick','.geetest_widget','[class*="geetest_panel"]','[class*="geetest_box"]','iframe[src*="geetest"]','iframe[src*="captcha"]'];
      let panel = null;
      for (const s of panelSels) {
        const els = document.querySelectorAll(s);
        for (const el of els) {
          const r = el.getBoundingClientRect();
          if (r && r.width > 40 && r.height > 40 && r.bottom > 0 && r.right > 0 && r.top < (window.innerHeight||9999)) { panel = el; break; }
        }
        if (panel) break;
      }
      if (!document.getElementById(STYLE_ID)) {
        const st = document.createElement('style');
        st.id = STYLE_ID;
        st.textContent = \`
          @keyframes __pdspin { to { transform: rotate(360deg); } }
          #__pandora_captcha_solving_overlay__ {
            position: fixed; z-index: 2147483647;
            display: flex; flex-direction: column; align-items: center; justify-content: center;
            background: #000; color: #fff;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            border-radius: 8px; backdrop-filter: blur(4px);
            pointer-events: none; transition: opacity .18s ease; opacity: 1;
          }
          #__pandora_captcha_solving_overlay__ .__pd_spin {
            width: 42px; height: 42px; border-radius: 50%;
            border: 4px solid rgba(255,255,255,0.18);
            border-top-color: #4ade80;
            animation: __pdspin 1.1s linear infinite;
            margin-bottom: 12px;
            will-change: transform;
          }
          #__pandora_captcha_solving_overlay__ .__pd_txt { font-size: 14px; font-weight: 600; letter-spacing: .3px; }
          #__pandora_captcha_solving_overlay__ .__pd_sub { font-size: 11px; opacity: .7; margin-top: 4px; }
        \`;
        document.head.appendChild(st);
      }
      let ov = document.getElementById(ID);
      const isNew = !ov;
      if (!ov) {
        ov = document.createElement('div');
        ov.id = ID;
        document.body.appendChild(ov);
      }
      // Só seta innerHTML na criação — evita reiniciar a animação do spinner
      if (isNew) {
        ov.innerHTML = '<div class="__pd_spin"></div><div class="__pd_txt">Resolvendo captcha…</div><div class="__pd_sub">Aguarde, isso leva alguns segundos</div>';
      }
      ov.style.opacity = '1';

      const applyFallback = () => {
        ov.style.left = '50%';
        ov.style.top = '50%';
        ov.style.width = '280px';
        ov.style.height = '160px';
        ov.style.transform = 'translate(-50%,-50%)';
      };
      const reposition = () => {
        // Re-procura painel a cada tick caso ele apareça depois
        let p = panel;
        if (!p || !p.isConnected) {
          for (const s of panelSels) {
            const els = document.querySelectorAll(s);
            for (const el of els) {
              const r = el.getBoundingClientRect();
              if (r && r.width > 40 && r.height > 40 && r.bottom > 0 && r.right > 0 && r.top < (window.innerHeight||9999)) { p = el; break; }
            }
            if (p) break;
          }
          panel = p;
        }
        if (!p) { applyFallback(); }
        else {
          const r = p.getBoundingClientRect();
          const extraTop = 36;
          const extraBottom = 14;
          ov.style.transform = '';
          ov.style.left = (r.left) + 'px';
          ov.style.top = (r.top - extraTop) + 'px';
          ov.style.width = (r.width) + 'px';
          ov.style.height = (r.height + extraTop + extraBottom) + 'px';
        }
        // Garante que o overlay seja SEMPRE o último filho do body — assim
        // qualquer painel/iframe do GeeTest criado depois não fica por cima
        // (mesmo z-index empata e o último na ordem do DOM vence).
        try {
          if (ov.parentNode !== document.body) document.body.appendChild(ov);
          else if (document.body.lastElementChild !== ov) document.body.appendChild(ov);
        } catch {}
      };
      reposition();
      if (ov.__pdRepoId) clearInterval(ov.__pdRepoId);
      ov.__pdRepoId = setInterval(() => {
        if (!document.getElementById(ID)) { clearInterval(ov.__pdRepoId); return; }
        reposition();
      }, 120);

      return 'ok';
    } catch(e) { return 'err:'+(e&&e.message); }
  })()`;
}


function buildPostCaptchaDepositClickJS() {
  return `(() => {
    try {
      const now = Date.now();
      if (window.__pandoraDepositFinished) return '';
      if (window.__pandoraDepositKickAt && now - window.__pandoraDepositKickAt < 4500) return '';
      const visible = (el) => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        if (!r || r.width < 8 || r.height < 8) return false;
        const s = getComputedStyle(el);
        return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity || 1) > 0.05;
      };
      const hasDepositForm = () => Array.from(document.querySelectorAll('input[type="number"], input.ui-input__input'))
        .some(i => visible(i) && /m[ií]nimo|m[áa]ximo|valor/i.test(i.placeholder || ''));
      const hasQr = () => !!Array.from(document.querySelectorAll('canvas[title*="br.gov.bcb.pix"], canvas[title*="qrcode"], canvas[title*="QRCode"]')).find(visible);
      if (hasDepositForm() || hasQr()) { window.__pandoraDepositFinished = true; return ''; }
      const captchaOpen = () => !!Array.from(document.querySelectorAll('.geetest_panel, .geetest_panel_box, .geetest_box, .geetest_holder, iframe[src*="geetest"], iframe[src*="gcaptcha"], iframe[src*="gsensebot"]')).find(visible);
      if (captchaOpen()) return '';
      const candidates = Array.from(document.querySelectorAll('button.registerRechargeBtn, .registerRechargeBtn, button, [role=button], a, div'));
      let best = null;
      for (const raw of candidates) {
        const el = raw && raw.closest ? (raw.closest('button, [role=button], a') || raw) : raw;
        if (!visible(el) || el.disabled || el.getAttribute('aria-disabled') === 'true') continue;
        const text = String(el.innerText || el.textContent || el.getAttribute('aria-label') || '').trim().toLowerCase();
        const idc = String(el.className || '') + ' ' + String(el.id || '');
        let score = 0;
        if (/registerRechargeBtn/.test(idc)) score += 200;
        if (!/deposite agora|depositar agora|recarregar|deposit/i.test(text + ' ' + idc)) continue;
        if (/deposite agora|depositar agora/i.test(text)) score += 180;
        if (/recarregar|deposit/i.test(text + ' ' + idc)) score += 80;
        if (/confirmar|valor|m[ií]nimo|senha|registr|cadastr|captcha|geetest/.test(text + ' ' + idc)) score -= 160;
        if (score > 80 && (!best || score > best.score)) best = { el, score, text };
      }
      if (!best) return '';
      window.__pandoraDepositKickAt = now;
      try { best.el.scrollIntoView({ block:'center', inline:'center' }); } catch(e) {}
      const r = best.el.getBoundingClientRect();
      const x = r.left + r.width / 2, y = r.top + r.height / 2;
      const top = document.elementFromPoint(x, y);
      const targets = Array.from(new Set([best.el, top, top && top.closest && top.closest('button, [role=button], a')].filter(Boolean)));
      for (const n of targets) {
        for (const type of ['pointermove','pointerdown','pointerup']) {
          try { n.dispatchEvent(new PointerEvent(type, { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y, pointerType:'mouse', button:0, buttons:type==='pointerdown'?1:0 })); } catch(e) {}
        }
        for (const type of ['mousedown','mouseup','click']) {
          try { n.dispatchEvent(new MouseEvent(type, { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y, button:0, buttons:type==='mousedown'?1:0 })); } catch(e) {}
        }
        try { n.click(); } catch(e) {}
      }
      return (best.text || best.el.className || best.el.tagName || 'deposito').toString().slice(0,80);
    } catch(e) { return ''; }
  })()`;
}

function buildPostCaptchaRegisterClickJS() {
  return `(async () => {
    try {
      const now = Date.now();
      if (window.__pandoraRegisterKickAt && now - window.__pandoraRegisterKickAt < 2500) return '';
      const visible = (el) => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        if (!r || r.width < 8 || r.height < 8) return false;
        const s = getComputedStyle(el);
        return s.visibility !== 'hidden' && s.display !== 'none' && Number(s.opacity || 1) > 0.05;
      };
      const hasRegisterFields = !!(document.querySelector('input[data-input-name="account"], textarea[data-input-name="account"]')
        && document.querySelector('input[data-input-name="userpass"], textarea[data-input-name="userpass"]'));
      if (!hasRegisterFields) return '';
      const captchaOpen = !!Array.from(document.querySelectorAll('.geetest_panel, .geetest_panel_box, .geetest_box, .geetest_holder, .geetest_box_wrap, .geetest_panelshowclick, .geetest_widget, iframe[src*="geetest"], iframe[src*="gcaptcha"], iframe[src*="gsensebot"], iframe[src*="geevisit"]')).find(visible);
      if (captchaOpen && !(window.__pandoraGeetestSolvedAt && now - window.__pandoraGeetestSolvedAt < 30000)) return '';
      const candidates = Array.from(document.querySelectorAll('#insideRegisterSubmitClick, button[type="submit"], button, [role=button], input[type=submit], .ui-button, .van-button'));
      let best = null;
      for (const raw of candidates) {
        const el = raw && raw.closest ? (raw.closest('button, [role=button], input[type=submit]') || raw) : raw;
        if (!visible(el)) continue;
        const text = String(el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || '').trim().toLowerCase();
        const idc = String(el.id || '') + ' ' + String(el.className || '');
        let score = 0;
        if (/insideRegisterSubmitClick/.test(idc)) score += 220;
        if (/cadastr|registr|sign\s*up|criar conta|submit/i.test(text + ' ' + idc)) score += 160;
        if (/cadastrando|registrando|processando|enviando|loading|ui-button--loading|van-button--loading|is-loading/i.test(text + ' ' + idc)) score += 120;
        if (/login|entrar|deposit|recarregar|saque|pix|valor/i.test(text + ' ' + idc)) score -= 180;
        if (score > 100 && (!best || score > best.score)) best = { el, score, text };
      }
      if (!best) return '';
      window.__pandoraRegisterKickAt = now;
      try { best.el.disabled = false; } catch(e) {}
      try { best.el.removeAttribute('disabled'); } catch(e) {}
      try { best.el.removeAttribute('aria-disabled'); } catch(e) {}
      try { best.el.removeAttribute('aria-busy'); } catch(e) {}
      try {
        const cls = String(best.el.className || '');
        const cleaned = cls.split(/\s+/).filter(c => !/loading|spinner|disabled|busy/i.test(c)).join(' ');
        if (cleaned !== cls) best.el.className = cleaned;
      } catch(e) {}
      try { best.el.scrollIntoView({ block:'center', inline:'center' }); } catch(e) {}
      await new Promise(r => setTimeout(r, 80));
      const r = best.el.getBoundingClientRect();
      const x = Math.round(r.left + r.width / 2), y = Math.round(r.top + r.height / 2);
      if (typeof window.__pandoraHumanClick === 'function') {
        try { const res = await window.__pandoraHumanClick(x, y); if (res && res.ok) return (best.text || best.el.id || 'cadastrar').slice(0,80); } catch(e) {}
      }
      const targets = Array.from(new Set([best.el, document.elementFromPoint(x, y)].filter(Boolean)));
      for (const n of targets) {
        for (const type of ['pointermove','pointerdown','pointerup']) {
          try { n.dispatchEvent(new PointerEvent(type, { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y, pointerType:'mouse', button:0, buttons:type==='pointerdown'?1:0 })); } catch(e) {}
        }
        for (const type of ['mousedown','mouseup','click']) {
          try { n.dispatchEvent(new MouseEvent(type, { bubbles:true, cancelable:true, view:window, clientX:x, clientY:y, button:0, buttons:type==='mousedown'?1:0 })); } catch(e) {}
        }
        try { n.click(); } catch(e) {}
      }
      return (best.text || best.el.id || 'cadastrar').slice(0,80);
    } catch(e) { return ''; }
  })()`;
}

async function clickGeetestPoints(win, result, frame = win.webContents) {
  if (!win || win.isDestroyed() || !result) return false;
  const risk = String(result.risk_type || result.captcha_type || '').toLowerCase();
  if (risk === 'slide') return false;
  let info;
  try { info = await frame.executeJavaScript(buildVisualPointsJS(result), true); }
  catch (e) { console.warn('[geetest] pontos visuais falharam:', e && e.message || e); return false; }
  if (!info || !info.ok || !Array.isArray(info.points) || info.points.length === 0) {
    let dump = '';
    try { dump = JSON.stringify(info); } catch(e) { dump = String(info); }
    console.warn(`[geetest] pontos visuais indisponíveis: ${dump}`);
    // dump também o que o solver devolveu pra correlacionar com Python
    try {
      const resultDump = JSON.stringify({
        risk_type: result && result.risk_type,
        urType: typeof (result && result.userresponse),
        urIsArr: Array.isArray(result && result.userresponse),
        urLen: Array.isArray(result && result.userresponse) ? result.userresponse.length : (result && result.userresponse ? String(result.userresponse).length : 0),
        urPreview: (() => { try { return JSON.stringify(result && result.userresponse).slice(0, 240); } catch(e) { return String(result && result.userresponse).slice(0, 240); } })(),
        quesLen: Array.isArray(result && result.ques) ? result.ques.length : 0,
        hasImgs: !!(result && result.imgs),
        resultKeys: Object.keys(result || {}).slice(0, 30),
      });
      console.warn(`[geetest] solver result: ${resultDump}`);
    } catch(e) {}
    return false;
  }
  console.log(`[geetest] clicando ${info.points.length} ponto(s) para desenhar linhas`);
  for (const p of info.points) {
    if (win.isDestroyed()) return false;
    const x = Math.round(Number(p.x));
    const y = Math.round(Number(p.y));
    const rootX = Math.round(Number(p.rootX));
    const rootY = Math.round(Number(p.rootY));
    await dispatchFrameClick(frame, x, y);
    if (info.rootKnown && Number.isFinite(rootX) && Number.isFinite(rootY)) {
      win.webContents.sendInputEvent({ type: 'mouseMove', x: rootX, y: rootY });
      await sleepMs(40);
      win.webContents.sendInputEvent({ type: 'mouseDown', x: rootX, y: rootY, button: 'left', clickCount: 1 });
      await sleepMs(30);
      win.webContents.sendInputEvent({ type: 'mouseUp', x: rootX, y: rootY, button: 'left', clickCount: 1 });
    }
    await sleepMs(140 + Math.floor(Math.random() * 60));
  }
  try {
    await sleepMs(180);
    const confirmed = await frame.executeJavaScript(buildVisualConfirmJS(), true);
    if (confirmed) console.log(`[geetest] visual: confirmar (${String(confirmed).slice(0, 80)})`);
  } catch {}
  return true;
}

function installHook(win) {
  if (!win || win.isDestroyed()) return;
  const dbg = win.webContents.debugger;
  const attachedSessions = new Set();

  const captureDebuggerBody = (url, requestId, sessionId) => {
    if (!isGeetestLoadUrl(url) || !requestId) return;
    dbg.sendCommand("Network.getResponseBody", { requestId }, sessionId).then((body) => {
      const text = body && body.base64Encoded ? Buffer.from(body.body || "", "base64").toString("utf8") : (body && body.body);
      const payload = parseLoadPayload(text);
      rememberNetworkDetection(win, url, payload, "CDP");
    }).catch(() => rememberNetworkDetection(win, url, null, "CDP-url"));
  };

  const onTopMessage = (_event, method, params, eventSessionId) => {
    if (method === "Network.responseReceived") {
      const url = params && params.response && params.response.url;
      captureDebuggerBody(url, params && params.requestId, eventSessionId);
      return;
    }
    if (method !== "Target.attachedToTarget") return;
    const { sessionId, targetInfo } = params || {};
    if (!sessionId) return;
    attachedSessions.add(sessionId);
    const type = targetInfo && targetInfo.type;
    if (type !== "iframe" && type !== "page") return;
    // Registra o hook no novo target (OOPIF cross-origin do widget Geetest)
    dbg.sendCommand("Page.enable", {}, sessionId).catch(() => {});
    dbg.sendCommand("Runtime.enable", {}, sessionId).catch(() => {});
    dbg.sendCommand("Network.enable", {}, sessionId).catch(() => {});
    dbg.sendCommand("Page.addScriptToEvaluateOnNewDocument", { source: HOOK_JS }, sessionId).catch(() => {});
    dbg.sendCommand("Runtime.evaluate", { expression: HOOK_JS }, sessionId).catch(() => {});
    dbg.sendCommand("Target.setAutoAttach", {
      autoAttach: true, waitForDebuggerOnStart: false, flatten: true,
    }, sessionId).catch(() => {});
    try {
      const url = targetInfo && targetInfo.url;
      if (url) console.log(`[geetest] hook anexado em OOPIF: ${String(url).slice(0, 80)}`);
    } catch {}
  };

  try {
    if (!dbg.isAttached()) dbg.attach("1.3");
    dbg.on("message", onTopMessage);
    dbg.sendCommand("Page.enable").catch(() => {});
    dbg.sendCommand("Runtime.enable").catch(() => {});
    dbg.sendCommand("Network.enable").catch(() => {});
    dbg.sendCommand("Page.addScriptToEvaluateOnNewDocument", { source: HOOK_JS }).catch(() => {});
    // Auto-attach em todos os subtargets (inclui iframes cross-origin OOPIF)
    dbg.sendCommand("Target.setAutoAttach", {
      autoAttach: true, waitForDebuggerOnStart: false, flatten: true,
    }).catch((e) => console.warn("[geetest] setAutoAttach falhou:", e && e.message || e));
    console.log("[geetest] hook early-document + auto-attach OOPIF registrados");
  } catch (e) {
    console.warn("[geetest] hook early-document indisponível:", e && e.message || e);
  }
  const inject = (frame) => {
    try { (frame || win.webContents).executeJavaScript(HOOK_JS, true).catch(() => {}); } catch {}
  };
  const injectAllFrames = () => {
    for (const frame of getAllFrames(win)) inject(frame);
  };
  win.webContents.on("did-start-navigation", () => injectAllFrames());
  win.webContents.on("did-frame-navigate", (_e, _url, _code, _isMain, frameProc) => {
    try { frameProc && frameProc.executeJavaScript(HOOK_JS, true).catch(() => {}); } catch {}
  });
  win.webContents.on("frame-created", (_event, details) => {
    try { details && details.frame && details.frame.executeJavaScript(HOOK_JS, true).catch(() => {}); } catch {}
  });
  win.webContents.on("dom-ready", () => injectAllFrames());
  win.webContents.on("did-finish-load", () => injectAllFrames());
  win.webContents.on("devtools-reload-page", () => injectAllFrames());
  registerWebRequestWatcher(win);
  injectAllFrames();
}

// Religado 2026-08-18 (pedido do usuário: "resolver captcha... deve
// resolver o captcha que apareceu") — tinha sido desligado em 2026-08-06
// porque o site alvo de então não pedia mais GeeTest; o site novo
// (versopg.vip) pede, log real confirmou "captchaActive":true parado pra
// sempre (geetestReady nunca virava true) porque essa flag desativava o
// módulo inteiro antes mesmo de instalar o hook — resto do módulo já
// estava pronto, só faltava isso.
const GEETEST_SOLVER_ENABLED = true;

function isFuncCaptchaOn() {
  // Pedido do usuário 2026-08-18: o toggle "Resolver captcha" (aba Início)
  // não tinha NENHUM efeito aqui antes — o módulo só obedecia a constante
  // GEETEST_SOLVER_ENABLED acima. Agora o toggle manda de verdade.
  try {
    if (typeof global.__pandoraGetSetting === "function") {
      return global.__pandoraGetSetting("func_captcha", "0") === "1";
    }
  } catch {}
  return false;
}

function attachGeetestSolver(win) {
  if (!GEETEST_SOLVER_ENABLED || !isFuncCaptchaOn()) return;
  if (!win || win.isDestroyed()) return;
  if (win._geetestAttached) return;
  win._geetestAttached = true;

  installHook(win);
  console.log("[geetest] hook instalado na janela");

  let solving = false;
  let solvingSince = 0;
  let lastSolvedAt = 0;
  let lastStarterClickAt = 0;
  let lastRefreshAt = 0;
  let lastNoChallengeLogAt = 0;
  let lastUsedChallengeRefreshAt = 0;
  const seen = new Map(); // captcha_id/lot_number já resolvidos recentemente
  const solvedLots = new Set();
  win._geetestSolvedLots = solvedLots;

  const sweepSeen = () => {
    const now = Date.now();
    // Challenge do GeeTest é de uso único; manter por mais tempo evita o erro
    // "challenge cannot be submitted more than once" e força o widget a gerar outro lot.
    for (const [key, ts] of seen.entries()) {
      if (now - ts > 180000) seen.delete(key);
    }
    for (const key of Array.from(solvedLots)) {
      const ts = seen.get(key) || 0;
      if (!ts || now - ts > 180000) solvedLots.delete(key);
    }
  };

  let consecutiveSolverFails = 0;
  let lastHardRefreshAt = 0;
  let activeSolveTimeoutMs = 210000;
  // Backoff por captcha_id para ERROR_CAPTCHA_SOLVE_FAILED (1504)
  const solveFailures = new Map(); // captchaId -> { count, nextAttemptAt }
  const SOLVE_FAILED_MAX_RETRIES = 5;
  // Watchdog por janela
  let firstStuckDetectionAt = 0;
  let lastIframeReloadAt = 0;
  // Após 1001/1504, esperamos a página gerar um NOVO lot. Se o mesmo
  // lot continuar sendo detectado, forçamos reload do iframe (refresh suave
  // não funciona em alguns estados do GeeTest v4).
  let lastFailedKey = "";
  let lastFailedAt = 0;

  const reloadGeetestFrame = async (reason, opts = {}) => {
    const force = !!opts.force;
    if (!force && Date.now() - lastIframeReloadAt < 15000) return false;
    lastIframeReloadAt = Date.now();
    console.warn(`[geetest] watchdog: forçando reload do iframe (${reason})`);
    try {
      let reloaded = false;
      for (const f of getAllFrames(win)) {
        try {
          const url = f.url || '';
          if (/geetest|gcaptcha|geevisit|gsensebot/i.test(url) && f !== win.webContents.mainFrame) {
            try { await f.reload(); reloaded = true; } catch {}
          }
        } catch {}
      }
      if (!reloaded) {
        // fallback: força recriação do widget no DOM
        for (const f of getAllFrames(win)) {
          try { await f.executeJavaScript(buildRefreshCaptchaJS(true), true); } catch {}
        }
      }
      try { win._geetestNetworkDetected = null; } catch {}
      seen.clear();
      solveFailures.clear();
      firstStuckDetectionAt = 0;
      return true;
    } catch (e) {
      console.warn('[geetest] reloadGeetestFrame falhou:', e?.message);
      return false;
    }
  };

  const refreshCaptcha = async (reason, opts = {}) => {
    const hard = !!opts.hard;
    const force = !!opts.force;
    const minGap = hard ? 6000 : 2200;
    if (!force && Date.now() - lastRefreshAt < minGap) return;
    lastRefreshAt = Date.now();
    if (hard) lastHardRefreshAt = Date.now();
    console.log(`[geetest] solicitando novo challenge (${reason})${hard ? ' [hard]' : ''}`);
    for (const f of getAllFrames(win)) {
      try { await f.executeJavaScript(buildRefreshCaptchaJS(hard), true); } catch {}
    }
    if (hard) {
      try { win._geetestNetworkDetected = null; } catch {}
    }
  };


  const tick = async () => {
    if (win.isDestroyed()) return;
    sweepSeen();
    // Watchdog: captchas de imagem podem demorar até ~180s no CapSolver.
    // O limite antigo de 75s abortava a resolução no meio, causando várias
    // telas presas em "Cadastrando..." e reuso de challenge.
    if (solving && solvingSince && Date.now() - solvingSince > activeSolveTimeoutMs) {
      console.warn(`[geetest] watchdog: solving travado >${activeSolveTimeoutMs}ms, resetando`);
      solving = false;
      solvingSince = 0;
      lastSolvedAt = 0;
      seen.clear();
    }
    if (solving) return;
    if (Date.now() - lastSolvedAt < 2500) return;
    let det, frame;
    try {
      const detected = await getDetectedGeetest(win);
      det = detected.det;
      frame = detected.frame;
    } catch { return; }
    if (!det || !det.captchaId) {
      firstStuckDetectionAt = 0;
      if (Date.now() - lastSolvedAt < 45000) return;
      if (Date.now() - lastStarterClickAt > 2000) {
        lastStarterClickAt = Date.now();
        for (const f of getAllFrames(win)) {
          try {
            const hit = await f.executeJavaScript(buildStarterClickJS(), true);
            if (hit) {
              console.log(`[geetest] captcha acionado: ${String(hit).slice(0, 80)}`);
              break;
            }
          } catch {}
        }
      }
      return;
    }
    // Watchdog: detecção persistente sem resolução por 120s → reload do iframe
    if (!firstStuckDetectionAt) firstStuckDetectionAt = Date.now();
    if (Date.now() - firstStuckDetectionAt > 120000 && Date.now() - lastSolvedAt > 120000) {
      await reloadGeetestFrame('captcha persistente sem resolução');
      return;
    }
    // Backoff: respeita janela de espera após 1504
    const failInfo = solveFailures.get(det.captchaId);
    if (failInfo && failInfo.nextAttemptAt && Date.now() < failInfo.nextAttemptAt) {
      return;
    }
    const key = (det.loadData && det.loadData.lot_number)
      ? `${det.captchaId}:${det.loadData.lot_number}`
      : det.captchaId + ":" + Math.floor(det.ts / 30000);
    if (!(det.loadData && (det.loadData.lot_number || det.loadData.challenge))) {
      if (Date.now() - Number(det.ts || 0) > 6500 && Date.now() - lastNoChallengeLogAt > 12000) {
        lastNoChallengeLogAt = Date.now();
        await refreshCaptcha('aguardando challenge v3');
      }
      return;
    }
    if (seen.has(key)) {
      const solvedRecently = solvedLots.has(key) || Date.now() - lastSolvedAt < 30000;
      // Escalada pós-1504: se o MESMO lot que falhou ainda é o detectado
      // após poucos segundos, o refresh não gerou novo challenge → reload do iframe.
      if (!solvedRecently && lastFailedKey === key && Date.now() - lastFailedAt > 3000) {
        await reloadGeetestFrame('mesmo lot persiste após 1504', { force: true });
        lastFailedKey = "";
        return;
      }
      if (det.loadData && det.loadData.lot_number && !solvedRecently && Date.now() - lastUsedChallengeRefreshAt > 15000) {
        lastUsedChallengeRefreshAt = Date.now();
        await refreshCaptcha('challenge já usado');
      }
      return;
    }
    // Lot novo apareceu — limpa marcador de falha anterior
    if (lastFailedKey && lastFailedKey !== key) lastFailedKey = "";
    // Lock global pelo PAR (captcha_id + lot_number) — instâncias diferentes
    // de widget (lots distintos) resolvem em PARALELO entre janelas.
    const winId = win.webContents.id;
    const lockKey = key; // já é `${captchaId}:${lot_number}` quando há lot
    if (!acquireCaptchaLock(lockKey, winId)) {
      // Outra janela está resolvendo exatamente esta instância — raro, espera próximo tick
      return;
    }
    seen.set(key, Date.now());

    solving = true;
    solvingSince = Date.now();
    let solveSucceeded = false;
    console.log(`[geetest] detectado captcha_id=${det.captchaId} base=${det.baseUrl}`);
    // Dispara o solver imediatamente. Em paralelo, um watcher garante que o
    // overlay com spinner apareça assim que o painel do GeeTest for renderizado
    // e permaneça visível durante toda a resolução, sem atrasar o início do solve.
    const verifyOverlayJS = `(() => { try { const el = document.getElementById('__pandora_captcha_solving_overlay__'); if (!el) return 'missing'; const r = el.getBoundingClientRect(); return (r.width > 10 && r.height > 10) ? 'ok' : 'zero'; } catch(e) { return 'err'; } })()`;
    let overlayWatcherStop = false;
    (async () => {
      let confirmedLogged = false;
      while (!overlayWatcherStop) {
        try {
          for (const f of getAllFrames(win)) {
            try { await f.executeJavaScript(buildSolvingOverlayJS(true), true); } catch {}
          }
          if (!confirmedLogged) {
            for (const f of getAllFrames(win)) {
              try {
                const v = await f.executeJavaScript(verifyOverlayJS, true);
                if (v === 'ok') { console.log('[geetest] overlay com spinner confirmado no DOM'); confirmedLogged = true; break; }
              } catch {}
            }
          }
        } catch {}
        await sleepMs(400);
      }
    })();


    // riskct.geetest.com é endpoint de risk-control e não tem /load — descartar
    // e deixar o solver usar o default gcaptcha4.geevisit.com.
    const candidateBase = (det.loadBaseUrl && !/riskct\./i.test(det.loadBaseUrl)) ? det.loadBaseUrl : det.baseUrl;
    const safeBase = candidateBase && !/riskct\./i.test(candidateBase) ? candidateBase : undefined;
    try {
      let pageUrl = "";
      try { pageUrl = win.webContents.getURL() || ""; } catch {}
      const detectedRisk = String(det.riskType || "icon").toLowerCase();
      const imageLikeRisk = /icon|nine|ai|gobang|click|word|image|img|picture|9grid/.test(detectedRisk);
      activeSolveTimeoutMs = imageLikeRisk ? 210000 : 95000;
      const result = await solveGeetest({
        captchaId: det.captchaId,
        riskType: det.riskType || "icon",
        baseUrl: safeBase,
        pageUrl,
        loadData: det.loadData,
        timeoutMs: imageLikeRisk ? 180000 : 90000,
      });
      console.log(`[geetest] resolvido lot=${result.lot_number} pass=${(result.pass_token||'').slice(0,12)}…`);
      lastSolvedAt = Date.now();
      consecutiveSolverFails = 0;
      solveFailures.delete(det.captchaId);
      firstStuckDetectionAt = 0;
      if (result.lot_number) {
        const solvedKey = `${det.captchaId}:${result.lot_number}`;
        seen.set(solvedKey, Date.now());
        solvedLots.add(solvedKey);
      }
      win._geetestSolvedQuietUntil = Date.now() + 30000;

      if (!win.isDestroyed()) {
        const hasPoints = Array.isArray(result.userresponse) && result.userresponse.length > 0;
        if (hasPoints) {
          const clicked = await clickGeetestPoints(win, result, frame);
          console.log(`[geetest] visual: ${clicked ? 'clicado' : 'sem clique'}`);
        } else {
          console.log('[geetest] sem coordenadas (CapSolver) — pulando clique visual, injetando tokens');
        }
        await sleepMs(20);
        let out = await frame.executeJavaScript(buildInjectJS(result), true);
        if (String(out || '').startsWith('no-obj')) {
          for (const candidateFrame of getAllFrames(win)) {
            if (candidateFrame === frame) continue;
            try {
              const candidateOut = await candidateFrame.executeJavaScript(buildInjectJS(result), true);
              if (candidateOut && !String(candidateOut).startsWith('no-obj')) {
                out = candidateOut;
                frame = candidateFrame;
                break;
              }
            } catch {}
          }
        }
        console.log(`[geetest] inject: ${out}`);
        if (String(out || '').startsWith('no-obj')) {
          lastSolvedAt = 0;
          console.warn('[geetest] objeto do widget não encontrado; gerando novo challenge');
          await refreshCaptcha('objeto do widget não encontrado após solve', { hard: true, force: true });
        } else {
          solveSucceeded = true;
          try {
            await runInAllFrames(win, `(() => { try { window.__pandoraGeetestSolvedAt = Date.now(); window.dispatchEvent(new CustomEvent('pandora-geetest-solved', { detail: window.__pandoraGeetestSolved || null })); return 1; } catch(e) { return 0; } })()`);
          } catch {}
          try {
            for (const f of getAllFrames(win)) await f.executeJavaScript(buildClearDetectedGeetestJS(), true);
            if (win._geetestNetworkDetected) win._geetestNetworkDetected = null;
          } catch {}
          // Fecha o painel do captcha (botão X) após sucesso
          const closeJS = `(() => {
            try {
              const tryClose = () => {
                const sels = ['.geetest_close', '.geetest_close_b9e8f90d', '[aria-label="Fechar"]', '[aria-label="Close"]'];
                for (const sel of sels) {
                  const nodes = document.querySelectorAll(sel);
                  for (const n of nodes) {
                    try { n.click(); } catch(e) {}
                  }
                }
                for (const sel of ['.geetest_panel', '.geetest_panel_box', '.geetest_panelshowclick', '.geetest_holder', '.geetest_box_wrap']) {
                  document.querySelectorAll(sel).forEach(el => { try { el.style.display='none'; el.remove(); } catch(e){} });
                }
              };
              tryClose();
              setTimeout(tryClose, 500);
              setTimeout(tryClose, 1500);
              return 'close-scheduled';
            } catch(e) { return 'close-err:'+(e&&e.message); }
          })()`;
          try {
            await sleepMs(120);
            for (const f of getAllFrames(win)) {
              try { await f.executeJavaScript(closeJS, true); } catch {}
            }
            console.log('[geetest] painel fechado');
            for (let i = 0; i < 5; i++) {
              await sleepMs(i === 0 ? 120 : 500);
              const hitRegister = await runInAllFrames(win, buildPostCaptchaRegisterClickJS());
              if (hitRegister) console.log(`[geetest] pós-captcha: clique cadastrar (${String(hitRegister).slice(0, 80)})`);
            }
            for (let i = 0; i < 4; i++) {
              await sleepMs(i === 0 ? 120 : 450);
              const hit = await runInAllFrames(win, buildPostCaptchaDepositClickJS());
              if (hit) console.log(`[geetest] pós-captcha: clique depósito (${String(hit).slice(0, 80)})`);
            }
          } catch (e) {
            console.warn('[geetest] falha ao fechar painel:', e?.message);
          }
        }
      }
    } catch (e) {
      console.warn(`[geetest] falha: ${e && e.message || e}`);
      const msg = String(e && e.message || e || "");
      const isSolverRefused = /ERROR_CAPTCHA_SOLVE_FAILED|ERROR_CAPTCHA_INVALID|Failed to solve|1504/i.test(msg);
      const isUsedChallenge = /challenge cannot be submitted more than once|ERROR_INVALID_TASK_DATA/i.test(msg);
      if (isSolverRefused || isUsedChallenge) {
        seen.set(key, Date.now());
        if (isUsedChallenge && det.loadData && det.loadData.lot_number) {
          solvedLots.add(`${det.captchaId}:${det.loadData.lot_number}`);
        }
        if (isSolverRefused) {
          consecutiveSolverFails++;
          // Backoff exponencial específico por captcha_id para 1504
          const cur = solveFailures.get(det.captchaId) || { count: 0, nextAttemptAt: 0 };
          cur.count++;
          const backoffMs = Math.min(16000, 1500 * Math.pow(2, cur.count - 1)); // 1.5s, 3s, 6s, 12s, 16s
          cur.nextAttemptAt = Date.now() + backoffMs;
          solveFailures.set(det.captchaId, cur);
          console.warn(`[geetest] 1504 #${cur.count} captcha_id=${det.captchaId} backoff=${backoffMs}ms`);
          // Marca este lot como falho — se persistir sem novo lot, reloada o iframe.
          // Não entra em solvedLots: falhou no CapSolver, então precisa gerar outro challenge.
          lastFailedKey = key;
          lastFailedAt = Date.now();
          const failedLot = det.loadData && (det.loadData.lot_number || det.loadData.challenge);
          try {
            const nd = win._geetestNetworkDetected;
            const ndLot = nd && nd.loadData && (nd.loadData.lot_number || nd.loadData.challenge);
            if (failedLot && ndLot && String(ndLot) === String(failedLot)) win._geetestNetworkDetected = null;
          } catch {}
          if (failedLot) {
            try { await runInAllFrames(win, buildForgetGeetestLotJS(det.captchaId, failedLot)); } catch {}
          }
          if (cur.count >= SOLVE_FAILED_MAX_RETRIES) {
            console.warn(`[geetest] limite de ${SOLVE_FAILED_MAX_RETRIES} retries 1504 atingido → reload iframe`);
            solveFailures.delete(det.captchaId);
            consecutiveSolverFails = 0;
            await reloadGeetestFrame('limite de retries 1504', { force: true });
          } else {
            // troca challenge antes do próximo tick; em 1001/1504 o soft refresh pode
            // manter o mesmo lot preso, então usa hard refresh já na primeira falha.
            await refreshCaptcha(`solver 1504 (${cur.count}/${SOLVE_FAILED_MAX_RETRIES})`, { hard: true, force: true });
            consecutiveSolverFails = 0;
          }
        } else {
          await refreshCaptcha('challenge reutilizado');
        }
      } else {
        seen.delete(key);
      }

    } finally {
      overlayWatcherStop = true;
      try {
        for (const f of getAllFrames(win)) {
          try { await f.executeJavaScript(buildSolvingOverlayJS(false), true); } catch {}
        }
      } catch {}


      releaseCaptchaLock(key, win.webContents.id);
      solving = false;
      solvingSince = 0;
      activeSolveTimeoutMs = 210000;
    }
  };

  // Tick rápido (350ms) — cada janela tem seu próprio loop/estado, então
  // múltiplas janelas resolvem em paralelo de forma independente.
  const id = setInterval(tick, 350);
  win.on("closed", () => clearInterval(id));
}

module.exports = { attachGeetestSolver };
