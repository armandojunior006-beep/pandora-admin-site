// ============================================================================
// Ação do botão "Preencher Dados" (aba Operação). Arquivo PRÓPRIO, separado
// do navMap genérico de Operacao.tsx — regra do usuário 2026-08-09: cada
// botão/ação nova entra em arquivo dedicado.
//
// Chama window.api.preencherDadosChromium() (preload.cjs -> "chrome:
// preencherDados" -> src/ipc/preencherDadosHandler.cjs), que navega cada
// janela selecionada pra "<origin da janela>/home/setting" e preenche todos
// os campos do formulário com dados aleatórios, incluindo data de
// nascimento.
// ============================================================================
export async function clicarPreencherDados(): Promise<number> {
  const n = await (window as any).api?.preencherDadosChromium?.();
  return n || 0;
}
