import { useEffect, useRef, useState } from "react";
import { run, getSetting, setSetting, log } from "@/lib/api";
import { useAuth } from "@/stores/auth";
import { useUI } from "@/stores/ui";
import { CreditCard, Plus, Trash2, X, Play, Square, Download, UserX, Save, Power, PowerOff, Settings, PlusCircle } from "lucide-react";

// ============================================================================
// MERCADO PAGO — aba própria (pedido do usuário 2026-08-10: "não é para
// colocar na aba operação, é embaixo... proxy, telas, operação, mercado
// pago" — item de menu no mesmo nível das outras abas, não uma seção dentro
// de Operação). Réplica do que o bot do amigo do usuário faz (pasta
// Mercado_Pago do outro bot, inspecionada com autorização): cada "conta" é
// um login real no site do Mercado Pago, usado como fonte das chaves PIX.
//
// Automação real fica em src/window/mercadoPagoWindow.cjs (arquivo próprio,
// regra do usuário — ver [[pandorabot-one-file-per-feature]]); aqui é só a
// UI + persistência da lista de contas (JSON em settings, sem tabela SQL
// nova) e o "Copiar Chaves" grava na mesma tabela pix_keys que ChavesPix.tsx
// usa.
// ============================================================================

// Proxy digitada DIRETO na linha da conta (pedido do usuário 2026-08-10: "deixe
// um campo para colocar a proxy e do lado o botão de liga e desliga igual a
// aba proxy" — em vez de escolher uma proxy já cadastrada na aba Proxies,
// cada conta MP tem seu próprio campo de texto + toggle. Só usa a proxy se o
// toggle estiver ligado).
type MpConta = { id: string; nome: string; proxyLine: string; proxyEnabled: boolean; logged?: boolean };

// Pedido do usuário 2026-08-18: "remova todos os provedores e crie um
// chamado Spider SMS" — antes tinha 5 provedores na lista, mas só "SMS
// 24HR" tinha automação de verdade por trás (ver smsProviderApi.cjs, que
// SEMPRE chama a API do sms24h.org, independente do nome escolhido aqui —
// os outros 4 eram só rótulo, sem nenhum backend ligado). Agora só existe
// um provedor, "Spider SMS", com o mesmo campo/config que "SMS 24HR" tinha
// (mesma API por trás, só renomeado).
const PROVEDORES_PADRAO = ["Spider SMS"];

// Campos de configuração por provedor (pedido do usuário 2026-08-10: "ao
// lado de cada provedor vai ter uma engrenagem para configurar, com espaço
// pedindo API").
type CampoProvedor = { key: string; label: string; type?: string; placeholder?: string };
const PROVEDOR_CAMPOS: Record<string, CampoProvedor[]> = {
  "Spider SMS": [{ key: "apiKey", label: "API Key (sms24h.org/api)", type: "password", placeholder: "chave da sua conta em sms24h.org" }],
};

// Mesmo parser usado em Proxies.tsx (host:porta:usuario:senha, ou
// protocolo://usuario:senha@host:porta, ou só host:porta) — duplicado aqui
// de propósito (arquivo próprio por feature, regra do usuário) em vez de
// compartilhar módulo, pra essa aba não depender de mudanças na de Proxies.
function parseProxyLine(line: string) {
  let proto = "socks5", host = "", port = 0, u: string | null = null, pw: string | null = null;
  const m1 = line.match(/^(https?|socks5):\/\/(?:([^:@]+):([^@]+)@)?([^:]+):(\d+)$/);
  const m2 = line.match(/^([^:]+):(\d+):([^:]+):(.+)$/);
  const m3 = line.match(/^([^:]+):(\d+)$/);
  if (m1) { proto = m1[1]; u = m1[2] || null; pw = m1[3] || null; host = m1[4]; port = parseInt(m1[5], 10); }
  else if (m2) { host = m2[1]; port = parseInt(m2[2], 10); u = m2[3]; pw = m2[4]; }
  else if (m3) { host = m3[1]; port = parseInt(m3[2], 10); }
  else return null;
  if (!host || !port) return null;
  return { proto, host, port, u, pw };
}

export function MercadoPago() {
  const [contas, setContas] = useState<MpConta[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [novoNome, setNovoNome] = useState("");
  const [busyId, setBusyId] = useState<string | null>(null);
  // Pedido do usuário 2026-08-10: o botão Play vira Pause (vermelho) enquanto
  // a janela dessa conta estiver aberta — clicar de novo fecha. Sincronizado
  // com mp:janelaFechada (main process avisa quando a janela fecha por
  // QUALQUER motivo, inclusive o X do Chrome, não só pelo botão Pause).
  const [abertas, setAbertas] = useState<Set<string>>(new Set());
  // Pedido do usuário 2026-08-11: "quero parar a hora que eu quiser" —
  // enquanto uma criação de chave PIX está rodando (pode levar até 90s+
  // esperando o código SMS), o botão "+" vira um "parar" clicável em vez de
  // ficar desabilitado junto com o resto (busyId) sem nenhum jeito de sair.
  const [criandoChaveId, setCriandoChaveId] = useState<string | null>(null);
  // Ref espelhando criandoChaveId em tempo real — pedido do usuário
  // 2026-08-11 ("excluir chaves deve parar no mesmo instante de criar
  // chave"): deletarChaves precisa checar/esperar esse valor dentro de um
  // loop assíncrono, e fechos (closures) de função capturam o valor do
  // state no momento em que a função foi criada, não o valor atual — só a
  // ref reflete o valor de verdade a cada instante.
  const criandoChaveIdRef = useRef<string | null>(null);
  useEffect(() => { criandoChaveIdRef.current = criandoChaveId; }, [criandoChaveId]);
  const [provedoresMarcados, setProvedoresMarcados] = useState<Set<string>>(new Set());
  const [provedorConfig, setProvedorConfig] = useState<Record<string, Record<string, string>>>({});
  const [configAberto, setConfigAberto] = useState<string | null>(null);
  const [configForm, setConfigForm] = useState<Record<string, string>>({});
  const { user } = useAuth();
  const { showToast } = useUI();

  useEffect(() => {
    const off = (window as any).api?.onContaFechadaMP?.((data: { id: string }) => {
      setAbertas((prev) => { const next = new Set(prev); next.delete(String(data?.id)); return next; });
    });
    return () => { try { off?.(); } catch {} };
  }, []);

  async function load() {
    let contasCarregadas: MpConta[] = [];
    try {
      const raw = await getSetting("mp_contas", "");
      const arr = raw ? JSON.parse(raw) : [];
      if (Array.isArray(arr)) { contasCarregadas = arr; setContas(arr); }
    } catch {}
    // Pedido do usuário 2026-08-10 ("dei play e não apareceu o botão de
    // parar"): o ícone Play/Stop dependia só de estado React em memória
    // (abertas), que se perde ao trocar de aba/remontar a página — mesmo com
    // a janela de verdade ainda aberta. Sincroniza com o estado real do
    // backend (contaEstaAbertaMP) toda vez que a página carrega.
    try {
      const abertasSet = new Set<string>();
      await Promise.all(contasCarregadas.map(async (c) => {
        try {
          const r = await (window as any).api?.contaEstaAbertaMP?.({ id: c.id });
          if (r?.aberta) abertasSet.add(c.id);
        } catch {}
      }));
      setAbertas(abertasSet);
    } catch {}
    try {
      const raw = await getSetting("mp_provedores", "");
      const arr = raw ? JSON.parse(raw) : [];
      if (Array.isArray(arr)) setProvedoresMarcados(new Set(arr));
    } catch {}
    try {
      const raw = await getSetting("mp_provedores_config", "");
      const obj = raw ? JSON.parse(raw) : {};
      if (obj && typeof obj === "object") setProvedorConfig(obj);
    } catch {}
  }
  useEffect(() => { load(); }, []);

  // Pedido do usuário 2026-08-10: "nunca pode haver dois selecionados" —
  // seleção única (igual rádio), não múltipla. Marcar um desmarca qualquer
  // outro que estivesse marcado antes; clicar no já marcado desmarca ele,
  // ficando nenhum selecionado.
  async function toggleProvedor(nome: string) {
    const next = provedoresMarcados.has(nome) ? new Set<string>() : new Set([nome]);
    setProvedoresMarcados(next);
    await setSetting("mp_provedores", JSON.stringify([...next]));
  }

  function abrirConfigProvedor(nome: string) {
    setConfigForm(provedorConfig[nome] || {});
    setConfigAberto(nome);
  }

  async function salvarConfigProvedor() {
    if (!configAberto) return;
    const next = { ...provedorConfig, [configAberto]: configForm };
    setProvedorConfig(next);
    await setSetting("mp_provedores_config", JSON.stringify(next));
    setConfigAberto(null);
    logSilent(`Provedor "${configAberto}" — configuração salva`);
  }

  // Pedido do usuário 2026-08-11: "remova TODAS notificações do bot da aba
  // mercado pago" — nenhuma ação da aba usa mais toast (showToast), só fica
  // registrada no Log de Operações. doAction (com toast) foi removido daqui
  // de propósito; se precisar de volta, é só reintroduzir.
  function logSilent(msg: string) {
    log("info", "mercadopago", msg, null, user?.id).catch(() => {});
  }

  async function salvarContas(next: MpConta[]) {
    setContas(next);
    await setSetting("mp_contas", JSON.stringify(next));
  }

  function abrirModalNovaConta() {
    setNovoNome("");
    setModalOpen(true);
  }

  async function criarConta() {
    const nome = novoNome.trim();
    if (!nome) { showToast("Dê um nome pra conta (ex: PF, PJ)", "warning"); return; }
    const nova: MpConta = { id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, nome, proxyLine: "", proxyEnabled: false };
    await salvarContas([...contas, nova]);
    setModalOpen(false);
    logSilent(`Conta "${nome}" criada`);
  }

  async function removerConta(id: string, nome: string) {
    if (!confirm(`Remover a conta "${nome}"? A sessão salva dela some.`)) return;
    try { await (window as any).api?.fecharContaMP?.({ id }); } catch {}
    await salvarContas(contas.filter((c) => c.id !== id));
    logSilent(`Conta "${nome}" removida`);
  }

  // Só atualiza o texto localmente enquanto digita — persiste no onBlur
  // (persistProxyLine), pra não gravar em settings em toda tecla.
  function onProxyLineChange(id: string, value: string) {
    setContas((prev) => prev.map((c) => (c.id === id ? { ...c, proxyLine: value } : c)));
  }
  async function persistProxyLine() {
    await setSetting("mp_contas", JSON.stringify(contas));
  }
  async function toggleProxyEnabled(conta: MpConta) {
    await salvarContas(contas.map((c) => (c.id === conta.id ? { ...c, proxyEnabled: !c.proxyEnabled } : c)));
  }

  // Pedido do usuário 2026-08-10: "se estiver ativado vai abrir a janela com
  // a proxy" — só usa a proxy digitada se o toggle da conta estiver ligado.
  function resolveProxyForConta(conta: MpConta): any {
    if (!conta.proxyEnabled || !conta.proxyLine?.trim()) return null;
    const parsed = parseProxyLine(conta.proxyLine.trim());
    if (!parsed) return null;
    return { host: parsed.host, port: parsed.port, username: parsed.u, password: parsed.pw, protocol: parsed.proto };
  }

  async function abrirConta(conta: MpConta) {
    setBusyId(conta.id);
    try {
      const proxy = resolveProxyForConta(conta);
      const r = await (window as any).api?.abrirContaMP?.({ id: conta.id, nome: conta.nome, proxy });
      if (r?.ok) {
        setAbertas((prev) => new Set(prev).add(conta.id));
        logSilent(`Conta "${conta.nome}" — janela aberta${conta.logged ? "" : " (faça login manualmente na 1ª vez)"}`);
      } else {
        logSilent(`Conta "${conta.nome}" — falha ao abrir: ${r?.error || "desconhecida"}`);
      }
    } finally {
      setBusyId(null);
    }
  }

  async function fecharContaClick(conta: MpConta) {
    setBusyId(conta.id);
    try {
      await (window as any).api?.fecharContaMP?.({ id: conta.id });
      setAbertas((prev) => { const next = new Set(prev); next.delete(conta.id); return next; });
      logSilent(`Conta "${conta.nome}" — janela fechada`);
    } finally {
      setBusyId(null);
    }
  }

  // Botão "disquete" — a sessão já fica salva automaticamente no perfil do
  // Chrome dessa conta (persistente, ver mercadoPagoWindow.cjs), então essa
  // ação só CONFIRMA que o login foi feito de verdade (checa se ainda tem
  // campo de senha na tela) e marca a conta como "logada" (selo na lista) —
  // não precisa disso pra sessão persistir, é só a confirmação explícita
  // que o usuário pediu (igual o "Salvar Login" do bot do amigo dele).
  async function salvarLoginClick(conta: MpConta) {
    setBusyId(conta.id);
    try {
      const r = await (window as any).api?.salvarLoginMP?.({ id: conta.id });
      // Pedido do usuário 2026-08-11: "remova essa notificação [conta] —
      // Abra a conta primeiro..." — esse aviso específico (botão já
      // desabilitado quando a janela não está aberta; só dispara em janelas
      // de corrida rápidas) não precisa de toast, só fica no Log de
      // Operações.
      if (!r?.ok) { logSilent(`Conta "${conta.nome}" — ${r?.error || "falha ao confirmar login"}`); return; }
      await salvarContas(contas.map((c) => (c.id === conta.id ? { ...c, logged: true } : c)));
      if (r.provavelLogado === false) {
        logSilent(`Conta "${conta.nome}" — salvo, mas ainda parece estar na tela de login (confira antes de usar)`);
      } else {
        logSilent(`Conta "${conta.nome}" — login salvo! Próxima vez que abrir já entra logada.`);
      }
    } finally {
      setBusyId(null);
    }
  }

  // Botão "+" — CRIAR chave PIX nova na conta MP (diferente de "Copiar
  // Chaves", que só IMPORTA chaves já existentes): compra um número via API
  // do provedor selecionado (SMS 24HR) e cadastra ele como chave PIX tipo
  // Celular no site, confirmando o código SMS recebido — passo a passo
  // ditado pelo usuário 2026-08-11 com o HTML real de cada tela (ver
  // criarChavePix em src/window/mercadoPagoWindow.cjs).
  async function criarChavesPix(conta: MpConta) {
    // Seleção de provedor é única (rádio) — pega o que estiver marcado.
    // Esses dois avisos de configuração continuam com toast (não é spam,
    // só acontece se faltar configurar algo antes de nem começar).
    const provedorNome = [...provedoresMarcados][0];
    if (!provedorNome) {
      logSilent("Selecione um provedor (SMS 24HR, etc.) na seção Provedores antes de criar uma chave.");
      return;
    }
    const apiKey = (provedorConfig[provedorNome] || {}).apiKey || "";
    if (!apiKey) {
      logSilent(`Provedor "${provedorNome}" sem API Key configurada — clique na engrenagem dele e salve a chave.`);
      return;
    }
    setBusyId(conta.id);
    setCriandoChaveId(conta.id);
    setAbertas((prev) => new Set(prev).add(conta.id));
    // Pedido do usuário 2026-08-11: "quando cliquei no + o botão de play
    // não apareceu o STOP vermelho" — reforço defensivo: confirma com o
    // backend (que sabe a verdade) um instante depois de começar, caso a
    // atualização otimista acima não tenha "pego" por algum motivo.
    setTimeout(async () => {
      try {
        const r = await (window as any).api?.contaEstaAbertaMP?.({ id: conta.id });
        if (r?.aberta) setAbertas((prev) => new Set(prev).add(conta.id));
      } catch {}
    }, 1500);
    try {
      const proxy = resolveProxyForConta(conta);
      // Pedido do usuário 2026-08-11: "faça o processo tudo novamente" —
      // fica criando chave após chave sem parar (o backend já não volta
      // sozinho — só termina quando cancelado ou depois de muitas falhas
      // seguidas) — e "remova todas as notificações", por isso logSilent
      // em vez de doAction aqui (fica só no Log de Operações).
      logSilent(`Conta "${conta.nome}" — começando a criar chaves PIX via ${provedorNome} (sem parar até clicar em Parar)...`);
      const r = await (window as any).api?.criarChavePixMP?.({ id: conta.id, proxy, provedorNome, apiKey });
      const criadas = r?.criadas || 0;
      if (r?.cancelado) logSilent(`Conta "${conta.nome}" — parado (${criadas} chave(s) criada(s))`);
      else if (!r?.ok) logSilent(`Conta "${conta.nome}" — parou: ${r?.error || "desconhecida"} (${criadas} chave(s) criada(s) antes de parar)`);
      else logSilent(`Conta "${conta.nome}" — ${criadas} chave(s) criada(s)`);
    } finally {
      setBusyId(null);
      setCriandoChaveId(null);
    }
  }

  async function cancelarCriarChave(conta: MpConta) {
    logSilent(`Conta "${conta.nome}" — parando criação de chave...`);
    try { await (window as any).api?.cancelarCriarChavePixMP?.({ id: conta.id }); } catch {}
  }

  // Pedido do usuário 2026-08-10: "se eu clicar em excluir/copiar chaves
  // também é considerado como play" — Copiar/Deletar Chaves abrem a janela
  // da conta por baixo dos panos (se ainda não estiver aberta), então o
  // botão Play tem que virar Stop nesses casos também, não só clicando em
  // Abrir diretamente.
  // Pedido do usuário 2026-08-11: "quando eu clico em importar, deve parar
  // todas as funções e somente importar" — mesmo cuidado já aplicado em
  // deletarChaves: se essa conta estiver no meio do loop de Criar Chaves
  // PIX, cancela primeiro e ESPERA de verdade parar antes de importar (as
  // duas automações usam a mesma janela/página por baixo).
  async function copiarChaves(conta: MpConta) {
    if (criandoChaveIdRef.current === conta.id) {
      await cancelarCriarChave(conta);
      await new Promise<void>((resolve) => {
        const tempoLimite = Date.now() + 5000;
        const checar = () => {
          if (criandoChaveIdRef.current !== conta.id || Date.now() > tempoLimite) return resolve();
          setTimeout(checar, 100);
        };
        checar();
      });
    }
    setBusyId(conta.id);
    setAbertas((prev) => new Set(prev).add(conta.id));
    // Pedido do usuário 2026-08-11: "quando eu clicar em importar o botão
    // parar deve aparecer" — mesmo reforço defensivo já usado em
    // criarChavesPix: confirma com o backend um instante depois, caso a
    // atualização otimista acima não tenha "pego" por algum motivo (ex.:
    // reconexão numa janela que estava demorando pra responder).
    setTimeout(async () => {
      try {
        const r = await (window as any).api?.contaEstaAbertaMP?.({ id: conta.id });
        if (r?.aberta) setAbertas((prev) => new Set(prev).add(conta.id));
      } catch {}
    }, 1500);
    try {
      const proxy = resolveProxyForConta(conta);
      logSilent(`Conta "${conta.nome}" — copiando chaves...`);
      const r = await (window as any).api?.copiarChavesMP?.({ id: conta.id, proxy });
      if (!r?.ok) { logSilent(`Conta "${conta.nome}" — falha: ${r?.error || "desconhecida"}`); return; }
      let n = 0;
      for (const chave of r.chaves || []) {
        await run(`INSERT INTO pix_keys (key_type, key_value, status) VALUES (?,?,?)`, [chave.tipo, chave.valor, "active"]);
        n++;
      }
      logSilent(`Conta "${conta.nome}" — ${n} chave(s) copiada(s) pra Chaves PIX`);
    } finally {
      setBusyId(null);
    }
  }

  // Pedido do usuário 2026-08-10: "não deve pedir, deve já executar" — sem
  // confirm() antes de excluir.
  // Pedido do usuário 2026-08-11: "se eu clicar em excluir chaves pix deve
  // parar no mesmo instante de criar chave" — se essa conta estiver no meio
  // do loop de Criar Chaves PIX, cancela primeiro (mesmo caminho do botão
  // Parar) e ESPERA o loop terminar de verdade antes de seguir com a
  // exclusão — as duas automações usam a mesma janela/página por baixo, não
  // podem rodar ao mesmo tempo.
  async function deletarChaves(conta: MpConta) {
    if (criandoChaveIdRef.current === conta.id) {
      await cancelarCriarChave(conta);
      await new Promise<void>((resolve) => {
        const tempoLimite = Date.now() + 5000;
        const checar = () => {
          if (criandoChaveIdRef.current !== conta.id || Date.now() > tempoLimite) return resolve();
          setTimeout(checar, 100);
        };
        checar();
      });
    }
    setBusyId(conta.id);
    setAbertas((prev) => new Set(prev).add(conta.id));
    // Mesmo reforço defensivo de copiarChaves/criarChavesPix — garante que o
    // botão Parar apareça mesmo se a atualização otimista acima não "pegar".
    setTimeout(async () => {
      try {
        const r = await (window as any).api?.contaEstaAbertaMP?.({ id: conta.id });
        if (r?.aberta) setAbertas((prev) => new Set(prev).add(conta.id));
      } catch {}
    }, 1500);
    try {
      const proxy = resolveProxyForConta(conta);
      logSilent(`Conta "${conta.nome}" — excluindo chaves...`);
      const r = await (window as any).api?.deletarChavesMP?.({ id: conta.id, proxy });
      if (!r?.ok) { logSilent(`Conta "${conta.nome}" — falha: ${r?.error || "desconhecida"}`); return; }
      const extra = r.precisaCaptcha ? " — parou num captcha (precisa concluir manualmente na janela)" : "";
      logSilent(`Conta "${conta.nome}" — ${r.deletadas} excluída(s), ${r.falhas} falha(s)${extra}`);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="p-3 h-full flex flex-col overflow-y-auto">
      <header className="flex items-center justify-between mb-2">
        <div>
          <h1 className="text-base font-semibold flex items-center gap-1.5">
            <CreditCard className="w-4 h-4 text-amber-400" /> Mercado Pago
          </h1>
          <p className="text-[11px] text-muted">{contas.length} conta(s) cadastrada(s) · até 5 visíveis sem rolar</p>
        </div>
        <button className="btn-primary !px-2 !py-1 !text-xs" onClick={abrirModalNovaConta}>
          <Plus className="w-3.5 h-3.5" /> Nova conta
        </button>
      </header>

      {contas.length === 0 ? (
        <div className="card p-6 text-center text-muted text-xs">
          Nenhuma conta cadastrada. Cada conta é um login real no Mercado Pago — abra pra logar (uma vez, na mão) e depois use
          "Importar" pra trazer as chaves PIX dessa conta pra aba Chaves PIX, ou "Deletar Chaves" pra excluir no site de verdade.
        </div>
      ) : (
        // Pedido do usuário 2026-08-10: "deixe caber até 5 contas MP" — cada
        // linha tem ~52px, 5 linhas + cabeçalho ≈ 292px; a partir da 6ª conta
        // rola dentro da própria tabela, sem empurrar a seção de Provedores
        // pra fora da tela.
        <div className="card overflow-hidden">
          <div className="max-h-[292px] overflow-y-auto">
            <table className="w-full text-xs">
              <thead className="bg-panel2 text-muted text-[10px] uppercase sticky top-0">
                <tr>
                  <th className="text-left px-3 py-2">Conta</th>
                  <th className="text-left px-3 py-2">Proxy</th>
                  <th className="text-right px-3 py-2"></th>
                </tr>
              </thead>
              <tbody>
                {contas.map((c) => {
                  const aberta = abertas.has(c.id);
                  return (
                    <tr key={c.id} className="border-t border-border hover:bg-panel2/40">
                      <td className="px-3 py-2 font-semibold text-white whitespace-nowrap">
                        {c.nome}
                        {c.logged && <span className="ml-2 badge bg-success/15 text-success normal-case font-sans">logada</span>}
                      </td>
                      {/* Pedido do usuário 2026-08-10: campo de proxy direto na
                          linha + botão liga/desliga (igual a aba Proxies) —
                          antes era um dropdown escolhendo proxy já cadastrada. */}
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-1.5">
                          <input
                            className="input font-mono !py-1 !text-[11px] w-full"
                            placeholder="host:porta:usuario:senha"
                            value={c.proxyLine || ""}
                            onChange={(e) => onProxyLineChange(c.id, e.target.value)}
                            onBlur={persistProxyLine}
                          />
                          <button onClick={() => toggleProxyEnabled(c)} title={c.proxyEnabled ? "Proxy ativada — clique pra desativar" : "Proxy desativada — clique pra ativar"}
                            className="shrink-0">
                            {c.proxyEnabled ? <Power className="w-4 h-4 text-success" /> : <PowerOff className="w-4 h-4 text-muted" />}
                          </button>
                        </div>
                      </td>
                      <td className="px-3 py-2 text-right">
                        {/* Pedido do usuário 2026-08-10: ícones em vez de texto nos
                            botões de ação, mesmo estilo visual do bot do amigo dele
                            (botões quadrados com borda, ícone colorido, tooltip no
                            hover em vez de label escrito). Play vira Stop
                            (vermelho, pedido do usuário 2026-08-10 — trocado
                            de Pause pra Stop) enquanto a janela está aberta.
                            Pedido do usuário 2026-08-11: "enquanto estiver criando
                            chave não é só pra o stop estar disponível, é pra estar
                            disponível TODOS os botões" — nenhum botão da linha
                            desabilita mais por "busy" (só o Salvar Login continua
                            exigindo a janela aberta, isso é uma regra própria dele,
                            não do busy). */}
                        <div className="flex justify-end gap-1.5">
                          {aberta ? (
                            // O mesmo botão Parar (quadrado) que fecha a conta
                            // também cancela a criação de chave em andamento, em
                            // vez de duplicar isso num segundo botão (pedido do
                            // usuário: "já tem o PARAR do play").
                            <button
                              onClick={() => (criandoChaveId === c.id ? cancelarCriarChave(c) : fecharContaClick(c))}
                              title={criandoChaveId === c.id ? "Parar criação de chave" : "Parar"}
                              className="w-8 h-8 grid place-items-center rounded-md bg-panel2 border border-border text-danger hover:bg-panel2/70">
                              <Square className="w-4 h-4" />
                            </button>
                          ) : (
                            <button onClick={() => abrirConta(c)} title="Abrir"
                              className="w-8 h-8 grid place-items-center rounded-md bg-panel2 border border-border text-success hover:bg-panel2/70">
                              <Play className="w-4 h-4" />
                            </button>
                          )}
                          <button onClick={() => criarChavesPix(c)} title="Criar Chaves PIX"
                            className="w-8 h-8 grid place-items-center rounded-md bg-panel2 border border-border text-success hover:bg-panel2/70">
                            <PlusCircle className="w-4 h-4" />
                          </button>
                          <button disabled={!aberta} onClick={() => salvarLoginClick(c)} title="Salvar Login"
                            className="w-8 h-8 grid place-items-center rounded-md bg-panel2 border border-border text-success hover:bg-panel2/70 disabled:opacity-50">
                            <Save className="w-4 h-4" />
                          </button>
                          <button onClick={() => copiarChaves(c)} title="Importar"
                            className="w-8 h-8 grid place-items-center rounded-md bg-panel2 border border-border text-success hover:bg-panel2/70">
                            <Download className="w-4 h-4" />
                          </button>
                          <button onClick={() => deletarChaves(c)} title="Deletar Chaves"
                            className="w-8 h-8 grid place-items-center rounded-md bg-panel2 border border-border text-warning hover:bg-panel2/70">
                            <Trash2 className="w-4 h-4" />
                          </button>
                          <button onClick={() => removerConta(c.id, c.nome)} title="Remover conta"
                            className="w-8 h-8 grid place-items-center rounded-md bg-panel2 border border-border text-danger hover:bg-panel2/70">
                            <UserX className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ===== Provedores — pedido do usuário 2026-08-10: "embaixo vai ter
          Provedores" (SMS/e-mail pra verificação durante cadastro). Só
          guarda qual(is) estão marcados por enquanto, sem automação. ===== */}
      <section className="card overflow-hidden mt-3">
        <div className="bg-black text-white text-xs font-semibold py-1.5 px-3 border-b border-border">Provedores</div>
        <div className="p-2 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-1.5">
          {PROVEDORES_PADRAO.map((nome) => {
            const on = provedoresMarcados.has(nome);
            const configurado = Object.values(provedorConfig[nome] || {}).some((v) => (v || "").trim());
            return (
              <div key={nome}
                className="flex items-center gap-1.5 text-[11px] text-white bg-panel2 border border-border rounded-md px-2 py-1.5 hover:bg-panel2/70">
                <label onClick={() => toggleProvedor(nome)} className="flex items-center gap-1.5 cursor-pointer select-none flex-1 min-w-0">
                  {/* Seleção única (rádio) — nunca dois provedores marcados
                      ao mesmo tempo, pedido do usuário 2026-08-10. */}
                  <span className={`w-3.5 h-3.5 shrink-0 rounded-full border flex items-center justify-center ${on ? "border-success bg-success" : "border-neutral-600 bg-panel"}`}>
                    {on && <span className="w-1.5 h-1.5 bg-black rounded-full" />}
                  </span>
                  <span className="truncate">{nome}</span>
                </label>
                <button onClick={() => abrirConfigProvedor(nome)} title="Configurar API"
                  className={`shrink-0 p-0.5 rounded ${configurado ? "text-success" : "text-muted"} hover:text-white`}>
                  <Settings className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </section>

      {modalOpen && (
        <div className="fixed inset-0 bg-black/50 grid place-items-center p-2 z-50" onClick={() => setModalOpen(false)}>
          <div className="card p-0 w-full max-w-sm overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-panel2">
              <h2 className="font-semibold text-sm flex items-center gap-1.5"><CreditCard className="w-3.5 h-3.5" /> Nova conta Mercado Pago</h2>
              <button onClick={() => setModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="p-3 space-y-2">
              <div>
                <label className="label !mb-1">Nome (só pra identificar, ex: PF, PJ)</label>
                <input className="input w-full !py-1 !text-xs" value={novoNome} onChange={(e) => setNovoNome(e.target.value)} autoFocus />
              </div>
              <p className="text-[11px] text-muted">
                Depois de criar, defina a proxy (opcional) direto na linha da conta, clique em "Abrir" e faça login manualmente
                nessa janela (só na primeira vez) — a sessão fica salva pra próxima.
              </p>
            </div>
            <div className="flex justify-end gap-2 px-3 py-2 border-t border-border bg-panel2">
              <button className="btn-ghost !px-2 !py-1 !text-xs" onClick={() => setModalOpen(false)}>Cancelar</button>
              <button className="btn-primary !px-2 !py-1 !text-xs" onClick={criarConta}>Criar</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Modal: configurar API de um provedor ===== */}
      {configAberto && (
        <div className="fixed inset-0 bg-black/50 grid place-items-center p-2 z-50" onClick={() => setConfigAberto(null)}>
          <div className="card p-0 w-full max-w-sm overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-panel2">
              <h2 className="font-semibold text-sm flex items-center gap-1.5"><Settings className="w-3.5 h-3.5" /> Configurar {configAberto}</h2>
              <button onClick={() => setConfigAberto(null)}><X className="w-4 h-4" /></button>
            </div>
            <div className="p-3 space-y-2">
              {(PROVEDOR_CAMPOS[configAberto] || []).map((campo) => (
                <div key={campo.key}>
                  <label className="label !mb-1">{campo.label}</label>
                  <input
                    className="input w-full !py-1 !text-xs"
                    type={campo.type || "text"}
                    placeholder={campo.placeholder}
                    value={configForm[campo.key] || ""}
                    onChange={(e) => setConfigForm((prev) => ({ ...prev, [campo.key]: e.target.value }))}
                  />
                </div>
              ))}
              <p className="text-[11px] text-muted">
                Essa é a conta/API que já tem crédito no site do provedor — a compra do número/e-mail acontece aqui pelo bot via API.
              </p>
            </div>
            <div className="flex justify-end gap-2 px-3 py-2 border-t border-border bg-panel2">
              <button className="btn-ghost !px-2 !py-1 !text-xs" onClick={() => setConfigAberto(null)}>Cancelar</button>
              <button className="btn-primary !px-2 !py-1 !text-xs" onClick={salvarConfigProvedor}>Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
