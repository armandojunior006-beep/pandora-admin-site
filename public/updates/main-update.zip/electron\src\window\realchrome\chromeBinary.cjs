// ============================================================================
// Garante um binário do Chrome (Chrome for Testing, build oficial do Google)
// disponível localmente — baixa uma vez, cacheia em %LOCALAPPDATA%, reaproveita
// depois. Mesmo padrão já usado no projeto pro runtime Python embarcado
// (scripts/stage-win.cjs → ensurePyembed) e pro cache do Electron.
// ============================================================================
const path = require("path");
const fs = require("fs");
const os = require("os");
const { execFile } = require("child_process");

// Windows marca todo arquivo baixado da internet com um stream oculto
// "Zone.Identifier" (Mark of the Web) — quando o chrome.exe baixado tenta
// rodar, o SmartScreen intercepta e pede permissão ("Windows protegeu seu
// PC"), travando o app esperando o usuário clicar em "Executar assim mesmo"
// numa janela que pode nem aparecer em primeiro plano. Unblock-File remove
// essa marca (operação local, não precisa de admin) pra isso nunca aparecer.
function unblockDirectory(dir) {
  return new Promise((resolve) => {
    if (process.platform !== "win32") return resolve();
    const psCmd = `Get-ChildItem -Path '${dir}' -Recurse -File | Unblock-File -ErrorAction SilentlyContinue`;
    execFile("powershell", ["-NoProfile", "-Command", psCmd], { timeout: 60000 }, (err) => {
      if (err) console.warn("[realchrome] Unblock-File falhou (não crítico):", err.message);
      else console.log("[realchrome] Chrome desbloqueado (Mark-of-the-Web removido)");
      resolve();
    });
  });
}

const CACHE_DIR = path.join(
  process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local"),
  "SpiderBot", "chrome-cache"
);

let _cachedExecPath = "";
let _unblocked = false;

// Retorna o caminho do chrome.exe, baixando se necessário. Idempotente —
// chamadas concorrentes/repetidas reaproveitam o mesmo download em progresso.
let _ensurePromise = null;
async function ensureChromeBinary(onProgress) {
  if (_cachedExecPath && fs.existsSync(_cachedExecPath)) {
    if (!_unblocked) { _unblocked = true; await unblockDirectory(CACHE_DIR); }
    return _cachedExecPath;
  }
  if (_ensurePromise) return _ensurePromise;
  _ensurePromise = (async () => {
    // @puppeteer/browsers é ESM-only — precisa de import() dinâmico, require() falha.
    const { install, Browser, resolveBuildId, detectBrowserPlatform } = await import("@puppeteer/browsers");
    const platform = detectBrowserPlatform();
    if (!platform) throw new Error("Plataforma não suportada para download do Chrome");
    const buildId = await resolveBuildId(Browser.CHROME, platform, "stable");

    fs.mkdirSync(CACHE_DIR, { recursive: true });
    console.log(`[realchrome] verificando/baixando Chrome ${buildId} (${platform})...`);
    const result = await install({
      browser: Browser.CHROME,
      buildId,
      cacheDir: CACHE_DIR,
      downloadProgressCallback: onProgress || ((downloaded, total) => {
        if (total > 0 && downloaded === total) console.log(`[realchrome] download completo: ${(total / 1024 / 1024).toFixed(0)}MB`);
      }),
    });
    _cachedExecPath = result.executablePath;
    await unblockDirectory(CACHE_DIR);
    _unblocked = true;
    console.log(`[realchrome] Chrome pronto em: ${_cachedExecPath}`);
    return _cachedExecPath;
  })();
  try {
    return await _ensurePromise;
  } finally {
    _ensurePromise = null;
  }
}

// Verifica sem baixar — usado pra UI mostrar "precisa baixar (~200MB)" antes
// de abrir a primeira janela em modo Chrome real.
function isChromeBinaryReady() {
  if (_cachedExecPath && fs.existsSync(_cachedExecPath)) return true;
  // Checagem síncrona simples via fs (sem @puppeteer/browsers, que é ESM-only
  // e exigiria import() assíncrono) — procura chrome.exe dentro do cache.
  try {
    const chromeDir = path.join(CACHE_DIR, "chrome");
    if (!fs.existsSync(chromeDir)) return false;
    for (const entry of fs.readdirSync(chromeDir)) {
      const p = path.join(chromeDir, entry, "chrome-win64", "chrome.exe");
      if (fs.existsSync(p)) { _cachedExecPath = p; return true; }
    }
  } catch {}
  return false;
}

module.exports = { ensureChromeBinary, isChromeBinaryReady, CACHE_DIR };
