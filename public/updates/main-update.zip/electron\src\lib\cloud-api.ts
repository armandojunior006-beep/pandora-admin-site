// Cliente HTTP para o painel admin / token system (pandora-admin-site).
// Fixo no código (não depende de VITE_PANDORA_CLOUD_URL ser aplicada em
// tempo de build/dev) — ainda pode ser sobrescrito por env var se precisar
// apontar para outro ambiente (ex: testes locais do site em localhost:3000).
const CLOUD_URL =
  (import.meta as any).env?.VITE_PANDORA_CLOUD_URL ||
  "https://pandora-admin-site.vercel.app";

export interface Plan {
  key: string; label: string; price_cents: number; duration_days: number | null;
}

export interface DeviceInfo { hash: string; name: string; }

let _device: DeviceInfo | null = null;
export async function getDevice(): Promise<DeviceInfo> {
  if (_device) return _device;
  try {
    const r = await (window as any).pandoraCloud?.getDeviceId?.();
    if (r?.hash) { _device = r; return r; }
  } catch {}
  let raw = localStorage.getItem("__pandora_device_hash__");
  if (!raw) { raw = crypto.randomUUID(); localStorage.setItem("__pandora_device_hash__", raw); }
  _device = { hash: raw, name: navigator.userAgent.slice(0, 80) };
  return _device;
}

// Pede ao main process um HMAC do body. Em renderer puro (sem electron),
// devolve um par vazio — o servidor ainda aceita endpoints públicos sem
// assinatura para registro/login/etc, mas /api/public/auth/validate exige.
async function signPayload(bodyString: string): Promise<{ ts: string; sig: string } | null> {
  try {
    const r = await (window as any).pandoraCloud?.signPayload?.(bodyString);
    if (r && r.sig) return { ts: String(r.ts), sig: String(r.sig) };
  } catch {}
  return null;
}

async function cloudFetch(path: string, init?: RequestInit, opts?: { sign?: boolean }) {
  const headers: Record<string, string> = { "Content-Type": "application/json", ...(init?.headers as any || {}) };
  if (opts?.sign && typeof init?.body === "string") {
    const s = await signPayload(init.body);
    if (s) { headers["x-pandora-ts"] = s.ts; headers["x-pandora-sig"] = s.sig; }
  }
  // Timeout — sem isso, uma rede travada (proxy, firewall bloqueando o
  // processo de um perfil novo do Multi Bot, etc.) deixava a tela de login
  // "verificando" pra sempre, sem erro nenhum pra reagir.
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  let res: Response;
  try {
    res = await fetch(`${CLOUD_URL}${path}`, { ...init, headers, signal: controller.signal });
  } catch (e: any) {
    if (e?.name === "AbortError") throw new Error("Sem resposta do servidor (15s) — verifique sua conexão/proxy e tente de novo.");
    throw new Error(e?.message || "Falha de rede ao contatar o servidor.");
  } finally {
    clearTimeout(timeoutId);
  }
  const text = await res.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text }; }
  if (!res.ok) throw new Error(data?.error || `HTTP ${res.status}`);
  return data;
}

export async function fetchPlans(): Promise<Plan[]> {
  const r = await cloudFetch("/api/public/plans");
  return r.plans || [];
}

export async function registerAccount(login: string, password: string, cpf: string) {
  return cloudFetch("/api/public/auth/register", {
    method: "POST", body: JSON.stringify({ login, password, cpf }),
  });
}

export async function cloudLogin(login: string, password: string) {
  return cloudFetch("/api/public/auth/login", {
    method: "POST", body: JSON.stringify({ login, password }),
  });
}

export interface ConfirmTokenResult {
  ok: true; login: string; plan_key: string; expires_at: string | null;
}
export async function confirmToken(login: string, password: string, token: string): Promise<ConfirmTokenResult> {
  const dev = await getDevice();
  return cloudFetch("/api/public/auth/confirm-token", {
    method: "POST",
    body: JSON.stringify({
      login, password, token,
      device_hash: dev.hash, device_name: dev.name,
      user_agent: navigator.userAgent,
    }),
  });
}

export async function validateToken(token: string) {
  const dev = await getDevice();
  const body = JSON.stringify({ token, device_hash: dev.hash });
  return cloudFetch("/api/public/auth/validate", {
    method: "POST", body,
  }, { sign: true });
}

export interface CreatePaymentArgs {
  plan_key: string;
  login?: string; password?: string;
  new_login?: string; new_password?: string;
}
export async function createPayment(args: CreatePaymentArgs) {
  return cloudFetch("/api/public/payments/create", {
    method: "POST", body: JSON.stringify(args),
  });
}

// Segurança 2026-08-18: /status agora exige o poll_token devolvido por
// createPayment (ver IDOR corrigido no backend) — sem ele o servidor
// devolve 403 em vez do status/token de licença.
export async function getPaymentStatus(id: string, pollToken: string) {
  return cloudFetch(`/api/public/payments/${id}/status?token=${encodeURIComponent(pollToken)}`);
}
