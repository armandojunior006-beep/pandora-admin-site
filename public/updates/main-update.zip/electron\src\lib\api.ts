// Dev fallback when running outside Electron (browser preview) — uses sql.js in memory.
import "../types";

async function ensureBrowserApi() {
  if (typeof window === "undefined" || (window as any).api) return;
  const initSqlJs = (await import("sql.js")).default as any;
  const SQL = await initSqlJs({ locateFile: (f: string) => `https://sql.js.org/dist/${f}` });
  const KEY = "__onb_db_v2__";
  const raw = localStorage.getItem(KEY);
  const db = raw ? new SQL.Database(Uint8Array.from(atob(raw), (c) => c.charCodeAt(0))) : new SQL.Database();
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'operator', full_name TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL, holder_name TEXT, document TEXT, bank TEXT, agency TEXT, account_number TEXT, account_type TEXT, username TEXT, password TEXT, status TEXT NOT NULL DEFAULT 'active', notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')), updated_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS pix_keys (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER, key_type TEXT NOT NULL, key_value TEXT NOT NULL, holder_name TEXT, bank TEXT, status TEXT NOT NULL DEFAULT 'active', notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS proxies (id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT NOT NULL, protocol TEXT NOT NULL DEFAULT 'http', host TEXT NOT NULL, port INTEGER NOT NULL, username TEXT, password TEXT, country TEXT, enabled INTEGER NOT NULL DEFAULT 1, last_status TEXT, last_checked TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS operations (id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER, pix_key_id INTEGER, proxy_id INTEGER, type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued', amount REAL, payload_json TEXT, result_json TEXT, error TEXT, started_at TEXT, finished_at TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS logs (id INTEGER PRIMARY KEY AUTOINCREMENT, level TEXT NOT NULL DEFAULT 'info', source TEXT, message TEXT NOT NULL, context_json TEXT, user_id INTEGER, created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
  `);
  const r = db.exec("SELECT COUNT(*) FROM users");
  if ((r[0]?.values?.[0]?.[0] ?? 0) === 0) {
    const bcrypt = (await import("bcryptjs")).default;
    const hash = bcrypt.hashSync("admin", 10);
    db.run("INSERT INTO users (username, password_hash, role, full_name) VALUES (?,?,?,?)", ["admin", hash, "admin", "Administrador"]);
    db.exec("INSERT INTO settings (key, value) VALUES ('screen_count','4'),('concurrency','3'),('rate_limit_per_min','60'),('proxy_enabled','0'),('auto_assign_proxy','1')");
  }
  const save = () => {
    const data = db.export();
    let bin = ""; for (let i = 0; i < data.length; i++) bin += String.fromCharCode(data[i]);
    localStorage.setItem(KEY, btoa(bin));
  };
  (window as any).api = {
    query: async (sql: string, params: any[] = []) => {
      try {
        const stmt = db.prepare(sql); stmt.bind(params);
        const rows: any[] = []; while (stmt.step()) rows.push(stmt.getAsObject()); stmt.free();
        return { ok: true, rows };
      } catch (e) { return { ok: false, error: String(e) }; }
    },
    run: async (sql: string, params: any[] = []) => {
      try {
        const stmt = db.prepare(sql); stmt.run(params); stmt.free();
        const lastIdRow = db.exec("SELECT last_insert_rowid()");
        save();
        return { ok: true, changes: db.getRowsModified(), lastId: lastIdRow[0]?.values?.[0]?.[0] as number };
      } catch (e) { return { ok: false, error: String(e) }; }
    },
    openFile: async () => new Promise((resolve) => {
      const input = document.createElement("input"); input.type = "file";
      input.onchange = () => {
        const f = input.files?.[0]; if (!f) return resolve(null);
        const reader = new FileReader();
        reader.onload = () => {
          const b64 = btoa(String.fromCharCode(...new Uint8Array(reader.result as ArrayBuffer)));
          resolve({ path: f.name, name: f.name, data: b64 });
        };
        reader.readAsArrayBuffer(f);
      };
      input.click();
    }),
    saveFile: async (_o: any, contentBase64: string) => {
      const blob = new Blob([Uint8Array.from(atob(contentBase64), (c) => c.charCodeAt(0))]);
      const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "export.bin"; a.click();
      return "export.bin";
    },
    startWorkers: async (count: number) => {
      alert(`[Dev preview] No Electron, abriria ${count} janela(s) worker. Use \`npm run dev\` na pasta electron-app para testar.`);
      return count;
    },
    stopWorkers: async () => true,
    countWorkers: async () => 0,
    installUpdate: async () => ({ ok: false, error: "Atualização automática disponível apenas no aplicativo instalado" }),
    appInfo: async () => ({ version: "dev-preview", platform: "browser", userData: "localStorage", dbPath: "memory" }),
  };
}

export async function getApi() {
  await ensureBrowserApi();
  return window.api;
}

export async function q<T = any>(sql: string, params: any[] = []) {
  const api = await getApi();
  const r = await api.query<T>(sql, params);
  if (!r.ok) throw new Error(r.error);
  return r.rows || [];
}

export async function run(sql: string, params: any[] = []) {
  const api = await getApi();
  const r = await api.run(sql, params);
  if (!r.ok) throw new Error(r.error);
  return r;
}

export async function log(level: string, source: string, message: string, ctx?: any, userId?: number) {
  // context_json é NOT NULL no schema de db.cjs — inserir null quebrava com
  // "NOT NULL constraint failed: logs.context_json" (bug real 2026-08-22).
  // Sem contexto grava '{}' (o mesmo DEFAULT do schema), não null.
  await run("INSERT INTO logs (level, source, message, context_json, user_id) VALUES (?,?,?,?,?)", [
    level, source, message, ctx ? JSON.stringify(ctx) : "{}", userId ?? null,
  ]);
}

export async function getSetting(key: string, fallback = ""): Promise<string> {
  const rows = await q<{ value: string }>("SELECT value FROM settings WHERE key=?", [key]);
  return rows[0]?.value ?? fallback;
}

export async function setSetting(key: string, value: string) {
  await run("INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", [key, value]);
}
