// ============================================================================
// Gerenciamento de janelas: janela principal, registro/ordenação das janelas
// Chromium controladas, modos "Esconder Navegação" / "Modo Aplicativo",
// indicador visual de seleção (borda verde) e cálculo de posições de grid.
// ============================================================================
const { app, screen, BrowserWindow } = require("electron");
const path = require("path");
const { ROOT_DIR } = require("../paths.cjs");
const state = require("../state.cjs");
const { getSettingSync } = require("../settings/settingsStore.cjs");
const { hardenWindowAgainstDevTools } = require("../../security.cjs");
const { setAccountsChangeNotifier } = require("../../auto-register.cjs");

const isDev = !app.isPackaged;
const APP_ICON = path.join(ROOT_DIR, "assets", "icon.ico");

// URL remota opcional: se definida em settings (remote_url) ou via env REMOTE_URL,
// o app carrega de lá em vez do dist local. Padrão vazio = usa a UI local empacotada.
const DEFAULT_REMOTE_URL = process.env.REMOTE_URL || "";

function relaxWebContentsMaxListeners(win, min = 40) {
  try {
    const wc = win && win.webContents;
    if (!wc || typeof wc.setMaxListeners !== "function") return;
    const cur = typeof wc.getMaxListeners === "function" ? wc.getMaxListeners() : 10;
    if (!cur || cur < min) wc.setMaxListeners(min);
  } catch {}
}

// ============================================================================
// ORDEM SEQUENCIAL ESTÁVEL DAS JANELAS CHROMIUM
// ----------------------------------------------------------------------------
// Toda janela aberta recebe `_pandoraOrder` (1-based) refletindo sua posição
// na sequência global. Ao fechar uma janela a sequência é compactada
// automaticamente (sem buracos: 1,2,3...N). A ordem RELATIVA de criação é
// preservada — não embaralhamos janelas existentes, apenas atualizamos o
// número quando alguma é fechada.
// ============================================================================
function reindexChromeWins() {
  state.chromeWins = state.chromeWins.filter((w) => w && !w.isDestroyed());
  for (let i = 0; i < state.chromeWins.length; i++) {
    try { state.chromeWins[i]._pandoraOrder = i + 1; } catch {}
  }
  try { global.__pandoraChromeOrder = state.chromeWins.length; } catch {}
}

function registerChromeWin(win) {
  if (!win || state.chromeWins.includes(win)) return;
  state.chromeWins.push(win);
  reindexChromeWins();
  win.on("closed", () => {
    state.chromeWins = state.chromeWins.filter((x) => x !== win);
    reindexChromeWins();
    // Se o mestre do espelho foi fechado, reavalia (sem embaralhar seguidores).
    try {
      if (state.mirrorMaster === win) {
        state.mirrorMaster = null;
        if (state.mirrorEnabled) {
          const { applyMirrorState } = require("./mirrorMode.cjs");
          Promise.resolve().then(() => applyMirrorState()).catch(() => {});
        }
      }
    } catch {}
  });
}

// Modo "Esconder Navegação": apenas move a janela para fora da área visível.
// NÃO altera webContents, sessão, partition, preload, UA, permissões nem qualquer
// lógica de captcha/registro/depósito. Apenas reduz a exposição visual.
function applyHiddenNavMode(win) {
  try {
    if (getSettingSync("esconder_navegacao", "0") !== "1") return;
    // Mantém tamanho realista para que layouts/captcha renderizem normalmente,
    // só joga a janela para coordenadas fora dos monitores visíveis.
    try { win.setBounds({ x: -32000, y: -32000, width: 1280, height: 800 }); } catch {}
    try { win.setSkipTaskbar(true); } catch {}
    try { win.setOpacity(0); } catch {}
    win.on("show", () => { try { win.setBounds({ x: -32000, y: -32000, width: 1280, height: 800 }); } catch {} });
  } catch {}
}

// "Modo Aplicativo" — faz com que sites detectem o ambiente como PWA/app instalado.
// Não basta esconder a toolbar: muitas casas (Pixbet, Esportes da Sorte, etc.) só
// liberam recursos como push, geolocalização persistente, deeplinks e webviews quando
// `display-mode: standalone` e o `document.referrer` indicam que veio do app oficial.
const __APP_MODE_SCRIPT = `(() => {
  if (window.__pandoraAppMode) return;
  try { Object.defineProperty(window, '__pandoraAppMode', { value: true, writable: false, configurable: false }); } catch(_) { window.__pandoraAppMode = true; }
  try {
    const _mm = window.matchMedia ? window.matchMedia.bind(window) : null;
    if (_mm) {
      window.matchMedia = function(q){
        const s = String(q||'').toLowerCase();
        const r = _mm(q);
        if (s.indexOf('display-mode: standalone') >= 0
            || s.indexOf('display-mode: fullscreen') >= 0
            || s.indexOf('display-mode: minimal-ui') >= 0) {
          try { Object.defineProperty(r, 'matches', { get: () => true, configurable: true }); } catch(_){}
        }
        if (s.indexOf('display-mode: browser') >= 0) {
          try { Object.defineProperty(r, 'matches', { get: () => false, configurable: true }); } catch(_){}
        }
        return r;
      };
    }
  } catch(_) {}
  try { Object.defineProperty(navigator, 'standalone', { get: () => true, configurable: true }); } catch(_) {}
  try { Object.defineProperty(document, 'referrer', { get: () => 'android-app://com.android.chrome/', configurable: true }); } catch(_) {}
  try {
    if (window.Notification && Notification.permission !== 'granted') {
      try { Object.defineProperty(Notification, 'permission', { get: () => 'granted', configurable: true }); } catch(_) {}
    }
  } catch(_) {}
})();`;

function applyAppMode(win) {
  try {
    if (getSettingSync("nav_modo_android", "0") !== "1") return;
    const wc = win.webContents;
    const inject = () => {
      try { wc.executeJavaScript(__APP_MODE_SCRIPT, true).catch(() => {}); } catch {}
      try {
        for (const f of (wc.mainFrame ? (wc.mainFrame.framesInSubtree || []) : [])) {
          try { f.executeJavaScript(__APP_MODE_SCRIPT, true).catch(() => {}); } catch {}
        }
      } catch {}
    };
    wc.on("did-start-navigation", inject);
    wc.on("dom-ready", inject);
    wc.on("did-frame-finish-load", inject);
    wc.on("did-navigate", inject);
    wc.on("did-navigate-in-page", inject);
    try {
      wc.on("frame-created", (_e, details) => {
        const frame = details && details.frame;
        if (!frame) return;
        try { frame.executeJavaScript(__APP_MODE_SCRIPT, true).catch(() => {}); } catch {}
        try { frame.once("dom-ready", () => { try { frame.executeJavaScript(__APP_MODE_SCRIPT, true).catch(() => {}); } catch {} }); } catch {}
      });
    } catch {}
    inject();
  } catch {}
}

function loadMain(win) {
  const hash = global.__pandoraIsMultiBotLauncher ? "multi-bot" : undefined;
  const remote = getSettingSync("remote_url", DEFAULT_REMOTE_URL);
  if (remote) {
    try { win.webContents.session.clearCache(); } catch {}
    const sep = remote.includes("?") ? "&" : "?";
    const tail = hash ? `#${hash}` : "";
    win.loadURL(`${remote}${sep}_t=${Date.now()}${tail}`);
    return;
  }
  const rendererUpdatePath = getSettingSync("renderer_update_path", "");
  const rendererUpdateAppVer = getSettingSync("renderer_update_app_version", "");
  if (rendererUpdatePath && rendererUpdateAppVer && rendererUpdateAppVer === app.getVersion()
      && require("fs").existsSync(path.join(rendererUpdatePath, "index.html"))) {
    win.loadFile(path.join(rendererUpdatePath, "index.html"), hash ? { hash } : undefined);
    return;
  }
  if (isDev) win.loadURL("http://localhost:5173" + (hash ? `#${hash}` : ""));
  else {
    // BUG real 2026-08-10 (reportado pelo usuário: "Mercado Pago" não
    // aparecia na lateral mesmo depois de redeploy + reabrir o app) — o
    // cache HTTP/disco do Chromium (session padrão, persiste em disco no
    // userData entre reaberturas do app) servia o index.html/JS ANTIGO
    // pela MESMA URL file://, mesmo com o arquivo já trocado no disco.
    // clearCache() só rodava no ramo "remote_url" (que também usa um "_t="
    // de cache-busting na query) — o carregamento local nunca limpava, E
    // clearCache() sozinho não é suficiente mesmo assim: é assíncrono
    // (devolve Promise) e aqui era chamado sem esperar terminar antes do
    // loadFile seguinte — corrida real, o load podia disparar antes da
    // limpeza terminar. Fix definitivo: em vez de confiar em limpar cache
    // certinho, muda a própria URL a cada abertura (query "_t=timestamp",
    // igual o ramo remote_url já fazia) — o Chromium cacheia por URL
    // completa (com query), então uma URL nova nunca bate em cache antigo,
    // não importa timing.
    try { win.webContents.session.clearCache(); } catch {}
    win.loadFile(path.join(ROOT_DIR, "..", "dist", "index.html"), { hash, query: { _t: String(Date.now()) } });
  }
}

function enableDevTools(win) {
  // DevTools liberadas (F12 / Ctrl+Shift+I) em dev E produção para diagnóstico.
  try {
    if (!win || win.isDestroyed() || win._pandoraDevToolsAttached) return;
    win._pandoraDevToolsAttached = true;
    const wc = win.webContents;
    wc.on("before-input-event", (event, input) => {
      if (input.type !== "keyDown") return;
      const key = (input.key || "").toLowerCase();
      // F12 abre/fecha DevTools
      if (key === "f12") {
        if (wc.isDevToolsOpened()) wc.closeDevTools();
        else wc.openDevTools({ mode: "detach" });
        event.preventDefault();
        return;
      }
      // Ctrl+Shift+I também abre
      if (input.control && input.shift && key === "i") {
        if (wc.isDevToolsOpened()) wc.closeDevTools();
        else wc.openDevTools({ mode: "detach" });
        event.preventDefault();
      }
    });
  } catch {}
}

function createMainWindow() {
  const area = screen.getPrimaryDisplay().workArea;
  const width = Math.min(1200, area.width);
  // 500 cortava "Slot para Buscar"/"Janelas Para Controlar", 600 ficou
  // grande demais, 550 sobrou um pouco de espaço embaixo — ajuste fino.
  const height = Math.min(540, area.height);
  state.__fullMinSize = { width, height };
  state.mainWin = new BrowserWindow({
    width, height, minWidth: width, minHeight: height,
    // Frameless: a UI desenha a própria barra de título (min/expandir/max/
    // fechar) — necessário pro botão de modo compacto ficar ao lado do
    // minimizar (2026-08-22). Ver TitleBar.tsx + win:* handlers.
    frame: false,
    x: area.x + Math.max(0, Math.floor((area.width - width) / 2)),
    y: area.y + Math.max(0, Math.floor((area.height - height) / 2)),
    backgroundColor: "#000000", autoHideMenuBar: true,
    icon: APP_ICON,
    // Pedido do usuário 2026-08-09: abrir o PandoraBot.exe direto (sem passar
    // pelo Multi Bot) já É o perfil PRINCIPAL por definição — getProfileDir()
    // devolve o userData padrão pra id "principal" (ver multibot.cjs), o
    // mesmo userData que um launch direto usa. O título deixa isso explícito
    // em vez de só "Pandora Bot" (o que gerava dúvida se era "outro" perfil).
    title: global.__pandoraIsMultiBotLauncher
      ? "Spider Multi Bot"
      : (global.__pandoraProfileId
          ? `Spider Bot — ${global.__pandoraProfileName || `Perfil ${String(global.__pandoraProfileId).slice(0, 6)}`}`
          : "Spider Bot — PRINCIPAL"),
    webPreferences: {
      preload: path.join(ROOT_DIR, "preload.cjs"),
      contextIsolation: true, nodeIntegration: false, sandbox: false,
    },
  });
  const mainWin = state.mainWin;
  try {
    mainWin.on("page-title-updated", (e) => { e.preventDefault(); });
  } catch {}
  enableDevTools(mainWin);
  hardenWindowAgainstDevTools(mainWin, app);
  mainWin.webContents.on("did-finish-load", () => {
    try { mainWin.webContents.setZoomFactor(0.96); } catch {}
    try {
      mainWin.webContents.executeJavaScript(`
        document.documentElement.style.overflow = 'auto';
        document.body.style.overflow = 'auto';
      `).catch(() => {});
    } catch {}
    // Fecha a splash de inicialização assim que a janela principal terminou de carregar
    try { require("../updater/updater.cjs").closeStartupSplash(); } catch {}
  });
  loadMain(mainWin);
  // Encaminha eventos de mudança em contas (insert/update pelo bot) para a aba Contas
  try {
    setAccountsChangeNotifier((info) => {
      try {
        if (state.mainWin && !state.mainWin.isDestroyed()) {
          state.mainWin.webContents.send("accounts:changed", { ...info, via: "auto-register" });
          console.log(`[contas-db] broadcast accounts:changed → ${JSON.stringify(info)}`);
        }
      } catch (e) { console.warn("[contas-db] broadcast falhou:", e?.message || e); }
    });
  } catch {}
}

function getTargetDisplay() {
  const displays = screen.getAllDisplays();
  const idx = parseInt(getSettingSync("monitor_index", "0"), 10) || 0;
  return displays[Math.min(Math.max(idx, 0), displays.length - 1)] || screen.getPrimaryDisplay();
}

function gridWindowBounds(area, cols, rows, index, gap) {
  const col = index % cols;
  const row = Math.floor(index / cols);
  const left = area.x + Math.round((area.width * col) / cols);
  const right = area.x + Math.round((area.width * (col + 1)) / cols);
  const top = area.y + Math.round((area.height * row) / rows);
  const bottom = area.y + Math.round((area.height * (row + 1)) / rows);
  return {
    x: left + gap,
    y: top + gap,
    width: Math.max(80, right - left - gap * 2),
    height: Math.max(80, bottom - top - gap * 2),
  };
}

function getCustomWindowBounds(area, total) {
  if (getSettingSync("use_custom_positions", "0") !== "1") return null;
  try {
    const arr = JSON.parse(getSettingSync("custom_positions", ""));
    if (!Array.isArray(arr) || arr.length === 0) return null;
    return Array.from({ length: total }, (_, i) => {
      const p = arr[i];
      if (!p || typeof p !== "object") return null;
      const width = Math.max(80, Math.min(area.width, Math.round(Number(p.w) || 0)));
      const height = Math.max(80, Math.min(area.height, Math.round(Number(p.h) || 0)));
      const x = area.x + Math.max(0, Math.min(area.width - width, Math.round(Number(p.x) || 0)));
      const y = area.y + Math.max(0, Math.min(area.height - height, Math.round(Number(p.y) || 0)));
      return { x, y, width, height };
    });
  } catch { return null; }
}

// Seleção manual de "janelas para controlar" (aba Operação): aceita lista/faixas
// como "1,3,5-8". Vazio = sem filtro (todas as janelas).
function parseJanelasSpec(spec) {
  const s = String(spec || "").trim();
  if (!s) return null;
  const out = new Set();
  for (const partRaw of s.split(",")) {
    const part = partRaw.trim();
    if (!part) continue;
    const m = part.match(/^(\d+)\s*-\s*(\d+)$/);
    if (m) {
      let a = parseInt(m[1], 10), b = parseInt(m[2], 10);
      if (!isFinite(a) || !isFinite(b)) continue;
      if (a > b) { const t = a; a = b; b = t; }
      for (let i = a; i <= b; i++) out.add(i);
    } else if (/^\d+$/.test(part)) {
      const n = parseInt(part, 10);
      if (n > 0) out.add(n);
    }
  }
  return out.size ? out : null;
}

// CSS para destacar visualmente as janelas controladas pelo bot (borda neon verde).
// Implementado via <style id="__pandora_ctrl_style__"> injetado por JS para
// que a remoção seja idempotente e resiliente a navegações de página (não
// depende de chaves retornadas por insertCSS, que podem ficar órfãs).
const __PANDORA_CTRL_STYLE_ID = "__pandora_ctrl_style__";
const __PANDORA_CTRL_CSS_BODY = `
  html::before {
    content: '';
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 2147483647;
    border: 3px solid #00ff88;
    box-shadow:
      inset 0 0 12px rgba(0,255,136,.55),
      inset 0 0 28px rgba(0,255,136,.25),
      0 0 14px rgba(0,255,136,.35);
    border-radius: 4px;
  }
`;
const __PANDORA_CTRL_APPLY_JS = `
  (function(){
    try {
      var id='${__PANDORA_CTRL_STYLE_ID}';
      var el=document.getElementById(id);
      if(!el){
        el=document.createElement('style');
        el.id=id;
        (document.head||document.documentElement).appendChild(el);
      }
      el.textContent=${JSON.stringify(__PANDORA_CTRL_CSS_BODY)};
    } catch(e){}
  })();
`;
const __PANDORA_CTRL_REMOVE_JS = `
  (function(){
    try {
      var nodes=document.querySelectorAll('#${__PANDORA_CTRL_STYLE_ID}');
      for(var i=0;i<nodes.length;i++){ nodes[i].remove(); }
    } catch(e){}
  })();
`;

function applyControlIndicator(win, isSelected) {
  if (!win || win.isDestroyed()) return;
  const wc = win.webContents;
  try {
    // Hook único de re-aplicação após navegações.
    if (!win._pandoraCtrlReapplyHooked) {
      win._pandoraCtrlReapplyHooked = true;
      wc.on("did-finish-load", () => {
        try {
          const js = win.__pandoraCtrlSelected ? __PANDORA_CTRL_APPLY_JS : __PANDORA_CTRL_REMOVE_JS;
          wc.executeJavaScript(js, true).catch(() => {});
        } catch {}
      });
    }
    const js = isSelected ? __PANDORA_CTRL_APPLY_JS : __PANDORA_CTRL_REMOVE_JS;
    wc.executeJavaScript(js, true).catch(() => {});
  } catch {}
}

module.exports = {
  isDev,
  APP_ICON,
  DEFAULT_REMOTE_URL,
  relaxWebContentsMaxListeners,
  reindexChromeWins,
  registerChromeWin,
  applyHiddenNavMode,
  applyAppMode,
  loadMain,
  enableDevTools,
  createMainWindow,
  getTargetDisplay,
  gridWindowBounds,
  getCustomWindowBounds,
  parseJanelasSpec,
  applyControlIndicator,
};
