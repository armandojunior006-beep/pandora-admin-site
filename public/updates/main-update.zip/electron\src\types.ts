export type Role = "admin" | "manager" | "operator" | "viewer";

export interface User {
  id: number; username: string; role: Role; full_name: string | null;
  active: number; created_at: string;
}

export interface Account {
  id: number; label: string; holder_name: string | null; document: string | null;
  bank: string | null; agency: string | null; account_number: string | null;
  account_type: string | null; username: string | null; password: string | null;
  status: string; notes: string | null; created_at: string; updated_at: string;
}

export interface PixKey {
  id: number; account_id: number | null; key_type: "cpf" | "cnpj" | "email" | "phone" | "evp";
  key_value: string; holder_name: string | null; bank: string | null;
  status: string; notes: string | null; created_at: string;
}

export interface Proxy {
  id: number; label: string; protocol: "http" | "https" | "socks5";
  host: string; port: number; username: string | null; password: string | null;
  country: string | null; enabled: number; last_status: string | null;
  last_checked: string | null; created_at: string;
}

export interface Operation {
  id: number; account_id: number | null; pix_key_id: number | null; proxy_id: number | null;
  type: string; status: "queued" | "running" | "done" | "failed" | "cancelled";
  amount: number | null; payload_json: string | null; result_json: string | null;
  error: string | null; started_at: string | null; finished_at: string | null; created_at: string;
}

export interface LogEntry {
  id: number; level: "debug" | "info" | "warn" | "error";
  source: string | null; message: string; context_json: string | null;
  user_id: number | null; created_at: string;
}

declare global {
  interface Window {
    api: {
      query: <T = any>(sql: string, params?: any[]) => Promise<{ ok: boolean; rows?: T[]; error?: string }>;
      run: (sql: string, params?: any[]) => Promise<{ ok: boolean; changes?: number; lastId?: number; error?: string }>;
      openFile: (opts?: any) => Promise<{ path: string; name: string; data: string } | null>;
      saveFile: (opts: any, contentBase64: string) => Promise<string | null>;
      startWorkers: (count: number, accounts?: any[]) => Promise<number>;
      stopWorkers: () => Promise<boolean>;
      countWorkers: () => Promise<number>;
      openChromium?: (url: string, count: number, accounts?: any[], delaySec?: number, headless?: boolean) => Promise<number>;
      openChromiumMulti?: (links: string[], count: number, accounts?: any[], delaySec?: number, headless?: boolean) => Promise<number>;
      closeChromium?: () => Promise<boolean>;
      navigateChromium?: (url: string) => Promise<number>;
      cadastrarPixChromium?: (url: string, keys: string[], tipo?: string) => Promise<{ ok: boolean; windows?: number; keys?: number; error?: string }>;
      cadastrarPixV2?: () => Promise<{ ok: boolean; windows?: number; sucesso?: number; error?: string }>;
      sacarV2?: () => Promise<{ ok: boolean; windows?: number; sucesso?: number; error?: string }>;
      openExternal?: (url: string) => Promise<boolean>;
      reload?: () => Promise<boolean>;
      checkUpdate?: () => Promise<{ ok: boolean; hasUpdate?: boolean; version?: string; url?: string; note?: string; error?: string }>;
      installUpdate?: () => Promise<{ ok: boolean; hasUpdate?: boolean; version?: string; restarting?: boolean; note?: string; error?: string }>;
      onUpdateProgress?: (callback: (data: { percent: number; message: string }) => void) => () => void;
      appInfo: () => Promise<{ version: string; platform: string; userData: string; dbPath: string }>;
      listMonitors?: () => Promise<Array<{ index: number; id?: number; label: string; width: number; height: number; scaleFactor?: number; primary?: boolean }>>;
    };
  }
}
