// ============================================================================
// Proxies (HTTP rotativa)
// ----------------------------------------------------------------------------
// Extraído do main.cjs original sem alterar nenhuma lógica: cria bridges HTTP
// locais via proxy-chain para cada upstream (http/socks5), aplica a sessão do
// Electron, testa IP de saída, faz retry de túnel e garante que duas janelas
// nunca operem com o mesmo IP simultaneamente (proxy rotativa).
// ============================================================================
const { BrowserWindow, net } = require("electron");
const ProxyChain = require("proxy-chain");
const state = require("../state.cjs");
const { getSettingSync, setSettingSync } = require("../settings/settingsStore.cjs");

function getActiveProxiesSync() {
  try {
    const res = state.db.exec("SELECT host,port,username,password,protocol FROM proxies WHERE enabled=1 ORDER BY id");
    if (!res || !res[0]) return [];
    return res[0].values.map((r) => ({
      host: r[0], port: r[1], username: r[2], password: r[3], protocol: r[4] || (r[2] ? "socks5" : "http"),
    }));
  } catch { return []; }
}

function normalizeProxyProtocol(protocol) {
  const p = String(protocol || "http").toLowerCase().replace(/:$/, "");
  if (p === "socks5" || p === "socks4" || p === "http" || p === "https") return p;
  return "http";
}

function proxyProtocolCandidates(proxy) {
  const preferred = normalizeProxyProtocol(proxy && proxy.protocol);
  const out = [preferred];
  // Compatibilidade: versões anteriores salvaram/importaram proxies SOCKS5 como HTTP.
  // Se o túnel HTTP falhar, tenta SOCKS5 automaticamente antes de desistir.
  if (preferred === "http" && (proxy?.username || proxy?.password)) out.push("socks5");
  if (preferred === "socks5") out.push("http");
  return Array.from(new Set(out));
}

function buildUpstreamProxyUrl(proxy, protocol) {
  const auth = proxy.username
    ? `${encodeURIComponent(proxy.username)}:${encodeURIComponent(proxy.password || "")}@`
    : "";
  return `${protocol}://${auth}${proxy.host}:${proxy.port}`;
}

// Cria (ou reaproveita do cache) o bridge HTTP local pra um proxy upstream,
// sem aplicar em nenhuma sessão do Electron — usado tanto pelas janelas
// Electron (applyProxyToSession abaixo) quanto pelo Chrome real via CDP
// (realchrome/realChromeManager.cjs), que passa a localUrl como
// --proxy-server na hora de abrir o processo em vez de ses.setProxy().
async function getOrCreateProxyBridge(proxy, protocol) {
  const upstream = buildUpstreamProxyUrl(proxy, protocol);
  let localUrl = state.proxyBridgeCache.get(upstream) || "";
  if (!localUrl) {
    const tBridge = Date.now();
    localUrl = await ProxyChain.anonymizeProxy(upstream);
    state.proxyBridgeCache.set(upstream, localUrl);
    state.activeLocalProxies.push(localUrl);
    console.log(`[proxy] bridge criada ${protocol}://${proxy.host}:${proxy.port} em ${Date.now() - tBridge}ms`);
  }
  return localUrl;
}

async function applyProxyToSession(ses, proxy) {
  if (!proxy || !proxy.host || !proxy.port) return { ok: true };
  const t0 = Date.now();
  let lastError = "";
  for (const protocol of proxyProtocolCandidates(proxy)) {
    const upstream = buildUpstreamProxyUrl(proxy, protocol);
    let fromCache = state.proxyBridgeCache.has(upstream);
    let localUrl = "";
    try {
    localUrl = await getOrCreateProxyBridge(proxy, protocol);
    const tSet = Date.now();
    await ses.setProxy({
      mode: "fixed_servers",
      proxyRules: localUrl,
      proxyBypassRules: "*.geetest.com;*.gsensebot.com;*.geevisit.com;*.geetest.net",
    });
    try { await ses.forceReloadProxyConfig(); } catch {}
    try { await ses.closeAllConnections(); } catch {}
    ses._assignedProxy = proxy;
    ses._localProxyUrl = localUrl;
    ses._proxyProtocol = protocol;
    ses._proxyDisabled = false;
    // Timeout maior + 1 retry no teste de IP: com várias janelas abrindo em
    // paralelo, o bridge local pode demorar a responder por saturação
    // momentânea de rede/proxy — não é motivo pra descartar um proxy bom.
    let ip = await fetchProxyIp(ses, 9000);
    if (!ip) ip = await fetchProxyIp(ses, 9000);
    if (!ip) throw new Error(`sem resposta no teste (${protocol})`);
    ses._proxyIp = ip || "";
    console.log(`[proxy] aplicado ${protocol}://${proxy.host}:${proxy.port} ip=${ip} cache=${fromCache} setProxy=${Date.now() - tSet}ms total=${Date.now() - t0}ms`);
    return { ok: true, localUrl, protocol };
  } catch (e) {
      lastError = e?.message || String(e);
      console.warn(`[proxy] falha ${protocol}://${proxy.host}:${proxy.port}:`, lastError);
      // Bridge ruim — descarta cache para forçar recriação no próximo protocolo/tentativa.
      try { state.proxyBridgeCache.delete(upstream); } catch {}
      try { await ses.setProxy({ mode: "direct" }); } catch {}
      try { await ses.forceReloadProxyConfig(); } catch {}
      try { await ses.closeAllConnections(); } catch {}
    }
  }
  return { ok: false, error: lastError || "Proxy sem resposta" };
}

function attachProxyLogin(_win, _ses) { /* não é mais necessário com o bridge local */ }

// Erros típicos de túnel/proxy que merecem retry automático. Além dos códigos
// específicos de túnel/SSL, inclui falhas de conexão genéricas que na prática
// quase sempre vêm do proxy (timeout, conexão recusada/resetada, proxy
// indisponível) — sem isso, janelas com essas falhas ficavam paradas sem
// nenhuma tentativa de recuperação.
const PROXY_RETRY_CODES = new Set([
  -2, -7, -21, -100, -101, -102, -105, -106, -111, -118, -130, -137, -138,
  -202, -310, -324, -338, -345, -352, -358,
]);
function attachProxyTunnelRetry(win, ses) {
  if (!win || !ses) return;
  let attempts = 0;
  const maxAttempts = 8;
  let cooldownUntil = 0;
  const retryNav = async (reason) => {
    if (!win || win.isDestroyed()) return;
    if (attempts >= maxAttempts) return;
    const now = Date.now();
    if (now < cooldownUntil) return;
    cooldownUntil = now + Math.min(400 + attempts * 300, 2500);
    attempts++;
    const target = win._targetUrl || win.webContents.getURL();
    if (!target || target.startsWith("file://")) return;
    console.warn(`[proxy-retry] ${reason} -> reload (tentativa ${attempts}/${maxAttempts})`);
    // A partir da 3ª tentativa, recria o bridge upstream
    if (attempts >= 3 && ses._assignedProxy) {
      try { state.proxyBridgeCache.delete(buildUpstreamProxyUrl(ses._assignedProxy, ses._proxyProtocol || "socks5")); } catch {}
      try { await applyProxyToSession(ses, ses._assignedProxy); } catch {}
    }
    try { if (!win.isDestroyed()) { win.webContents.stop(); win.loadURL(target); } } catch {}
  };
  win.webContents.on("did-fail-load", (_e, code, desc, failedUrl, isMain) => {
    if (!isMain) return;
    if (String(failedUrl || "").startsWith("file://")) return;
    if (PROXY_RETRY_CODES.has(code)) retryNav(`did-fail-load ${code} ${desc}`);
  });
  win.webContents.on("did-finish-load", async () => {
    try {
      const u = win.webContents.getURL();
      if (!u || u.startsWith("file://")) return;
      const hit = await win.webContents.executeJavaScript(
        `(function(){var t=(document.title||'')+' '+((document.body&&document.body.innerText)||'').slice(0,200);return /Upstream\\s+Error|ERR_TUNNEL_CONNECTION_FAILED/i.test(t);})()`
      );
      if (hit) retryNav("Upstream Error text");
    } catch {}
  });
}

// Liga/desliga proxy em tempo real numa sessão já preparada.
// Quando "enabled=false" coloca a sessão em modo direto (sem proxy) mantendo
// o bridge HTTP local em ses._localProxyUrl pra poder reativar instantaneamente.
async function setSessionProxyEnabled(ses, enabled) {
  if (!ses) return false;
  try {
    if (enabled) {
      const localUrl = ses._localProxyUrl;
      if (!localUrl) {
        if (ses._assignedProxy) {
          const r = await applyProxyToSession(ses, ses._assignedProxy);
          return !!r.ok;
        }
        // Sem proxy original — força modo direto e sai.
        await ses.setProxy({ mode: "direct" });
        try { await ses.forceReloadProxyConfig(); } catch {}
        try { await ses.closeAllConnections(); } catch {}
        ses._proxyDisabled = false;
        return false;
      }
      await ses.setProxy({
        mode: "fixed_servers",
        proxyRules: localUrl,
        proxyBypassRules: "*.geetest.com;*.gsensebot.com;*.geevisit.com;*.geetest.net",
      });
      try { await ses.forceReloadProxyConfig(); } catch {}
      try { await ses.closeAllConnections(); } catch {}
      ses._proxyDisabled = false;
      return true;
    } else {
      await ses.setProxy({ mode: "direct" });
      try { await ses.forceReloadProxyConfig(); } catch {}
      try { await ses.closeAllConnections(); } catch {}
      ses._proxyDisabled = true;
      return true;
    }
  } catch (e) {
    console.warn("[proxy] toggle falhou:", e?.message || e);
    return false;
  }
}

function fetchProxyIp(ses, timeoutMs = 12000) {
  return new Promise((resolve) => {
    try {
      const req = net.request({ url: "https://api.ipify.org?format=json", session: ses });
      let data = "";
      const timer = setTimeout(() => { try { req.abort(); } catch {} resolve(""); }, timeoutMs);
      req.on("response", (res) => {
        res.on("data", (c) => { data += c.toString(); });
        res.on("end", () => {
          clearTimeout(timer);
          try { resolve((JSON.parse(data).ip || "").trim()); } catch { resolve(data.trim()); }
        });
      });
      req.on("error", () => { clearTimeout(timer); resolve(""); });
      req.end();
    } catch { resolve(""); }
  });
}

async function showProxyIpOnWindow(win, ses, opts = {}) {
  if (!win || win.isDestroyed()) return;
  const rawTitle = (() => { try { return win.getTitle(); } catch { return ""; } })();
  if (!win._baseTitleForIp) {
    win._baseTitleForIp = rawTitle.replace(/\s*·\s*(IP|SEM PROXY)\s+[\d.]+/g, "").trim();
  }
  const baseTitle = win._baseTitleForIp || rawTitle;
  const disabled = !!ses._proxyDisabled;
  // Quando proxy é desativado/reativado, força refetch para refletir o IP real/atual.
  if (opts.force) { ses._proxyIp = ""; }
  const ip = ses._proxyIp || await fetchProxyIp(ses);
  if (!ip || win.isDestroyed()) return;
  ses._proxyIp = ip;
  const suffix = disabled ? "SEM PROXY" : "IP";
  // Não sobrescreve o título da janela com IP — título mostra apenas a URL/host.

  const bg = disabled ? "rgba(180,0,0,0.85)" : "rgba(0,0,0,0.55)";
  const border = disabled ? "rgba(255,80,80,0.9)" : "rgba(255,255,255,0.15)";
  const label = disabled ? `⚠ ${ip}` : ip;
  const safeLabel = String(label).replace(/[\\'"<>]/g, "");
  try {
    await win.webContents.executeJavaScript(`(() => {
      try {
        const id = '__pandora_ip_badge__';
        document.getElementById(id)?.remove();
        const el = document.createElement('div');
        el.id = id;
        el.textContent = '${safeLabel}';
        Object.assign(el.style, {
          position: 'fixed', bottom: '8px', left: '8px', zIndex: 2147483647,
          background: '${bg}', color: '#ffffff',
          font: '700 11px system-ui,sans-serif', padding: '4px 8px',
          borderRadius: '6px', border: '1px solid ${border}',
          pointerEvents: 'none', letterSpacing: '0.3px',
          backdropFilter: 'blur(4px)',
        });
        (document.body || document.documentElement).appendChild(el);
      } catch(e){}
    })();`);
  } catch {}
}

// ============ Anti-IP-duplicado (proxy rotativa) ============
// Se a janela compartilhar o mesmo IP de saída com outra janela aberta,
// força nova rotação do proxy (descarta bridge upstream, recria a sessão de
// proxy e refaz o teste de IP) até obter um IP único. É proibido duas
// janelas operarem com o mesmo IP simultaneamente.
async function enforceUniqueIp(win, ses, opts = {}) {
  if (!win || win.isDestroyed() || !ses) return;
  if (!ses._assignedProxy || ses._proxyDisabled) return;
  if (state.ipRotationInFlight.has(ses)) return;
  state.ipRotationInFlight.add(ses);
  const maxAttempts = opts.maxAttempts || 6;
  try {
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      if (!win || win.isDestroyed()) return;
      const myIp = ses._proxyIp;
      if (!myIp) return;
      let duplicateWith = null;
      for (const w of BrowserWindow.getAllWindows()) {
        if (!w || w === win || w.isDestroyed()) continue;
        let s;
        try { s = w.webContents.session; } catch { continue; }
        if (!s || s === ses) continue;
        if (s._proxyDisabled) continue;
        const otherIp = s._proxyIp;
        if (otherIp && otherIp === myIp) { duplicateWith = otherIp; break; }
      }
      if (!duplicateWith) return;
      console.warn(`[proxy] IP duplicado (${myIp}) — rotacionando (tentativa ${attempt + 1}/${maxAttempts})`);
      // Derruba a bridge upstream atual para forçar nova conexão TCP no proxy rotativo
      try {
        const upstream = buildUpstreamProxyUrl(ses._assignedProxy, ses._proxyProtocol || "socks5");
        state.proxyBridgeCache.delete(upstream);
      } catch {}
      try {
        const old = ses._localProxyUrl;
        if (old) {
          const i = state.activeLocalProxies.indexOf(old);
          if (i >= 0) state.activeLocalProxies.splice(i, 1);
          try { ProxyChain.closeAnonymizedProxy(old, true).catch(() => {}); } catch {}
        }
      } catch {}
      ses._proxyIp = "";
      ses._localProxyUrl = "";
      try { await ses.closeAllConnections(); } catch {}
      try { await applyProxyToSession(ses, ses._assignedProxy); } catch {}
      // Pequeno backoff progressivo para dar tempo do upstream rotacionar
      await new Promise((r) => setTimeout(r, 250 + attempt * 200));
    }
    if (!win.isDestroyed()) {
      try { await showProxyIpOnWindow(win, ses, { force: true }); } catch {}
    }
  } finally {
    state.ipRotationInFlight.delete(ses);
    // Atualiza o badge com o IP final
    try { if (!win.isDestroyed()) await showProxyIpOnWindow(win, ses, { force: true }); } catch {}
  }
}

// Liga/desliga proxy em massa nas janelas Chromium indicadas (por padrão, todas).
async function setProxyEnabledForWindows(enabled, wins = state.chromeWins.filter((w) => w && !w.isDestroyed())) {
  const target = !!enabled;
  const all = state.chromeWins.filter((w) => w && !w.isDestroyed());
  const proxies = target ? getActiveProxiesSync() : [];
  let affected = 0;
  const indexes = [];
  for (const win of wins) {
    try {
      if (!win || win.isDestroyed()) continue;
      if (win._realChrome) {
        // Chrome real: o --proxy-server aponta sempre pro bridge toggleável
        // (toggleableBridge.cjs) — trocar "a quente" é só virar essa flag em
        // memória, sem relançar o Chrome.
        if (win._proxyToggle) {
          win._proxyToggle.setEnabled(target);
          affected++;
          const idx = all.indexOf(win) + 1;
          if (idx > 0) indexes.push(idx);
          // Atualiza o badge de IP — sem proxy some o IP antigo (deixa de
          // passar por ele) e o badge deve refletir isso (força re-fetch).
          try {
            const { showProxyIpOnRealChromeWindow } = require("../window/realchrome/realChromeManager.cjs");
            showProxyIpOnRealChromeWindow(win, { force: true }).catch(() => {});
          } catch {}
        } else {
          console.warn("[proxy] janela de Chrome real sem proxy atribuído — F8 não afeta");
        }
        continue;
      }
      const ses = win.webContents.session;
      const idx = all.indexOf(win) + 1;
      if (target && !ses._assignedProxy && proxies.length) {
        ses._assignedProxy = proxies[Math.max(0, idx - 1) % proxies.length];
      }
      const ok = await setSessionProxyEnabled(ses, target);
      if (ok || target === false) {
        affected++;
        if (idx > 0) indexes.push(idx);
      }
      showProxyIpOnWindow(win, ses, { force: true }).then(() => enforceUniqueIp(win, ses)).catch(() => {});
    } catch {}
  }
  return { ok: true, affected, enabled: target, indexes };
}

// Atalho global F8: alterna bloqueio de proxy em todas as janelas Chromium.
async function toggleProxyFromShortcut() {
  const wasBlocked = getSettingSync("op_bloquear_proxy", "0") === "1";
  const nextBlocked = !wasBlocked;
  await setSettingSync("op_bloquear_proxy", nextBlocked ? "1" : "0");
  const result = await setProxyEnabledForWindows(!nextBlocked);
  const acao = nextBlocked ? "DESATIVADA" : "ATIVADA";
  console.log(`[proxy] F8 ${acao} em ${result.affected} janela(s) [${(result.indexes || []).join(",")}]`);
  try { if (state.mainWin && !state.mainWin.isDestroyed()) state.mainWin.webContents.send("chrome:proxyToggled", { blocked: nextBlocked, ...result }); } catch {}
  return result;
}

module.exports = {
  getActiveProxiesSync,
  normalizeProxyProtocol,
  proxyProtocolCandidates,
  buildUpstreamProxyUrl,
  getOrCreateProxyBridge,
  applyProxyToSession,
  attachProxyLogin,
  attachProxyTunnelRetry,
  setSessionProxyEnabled,
  fetchProxyIp,
  showProxyIpOnWindow,
  enforceUniqueIp,
  setProxyEnabledForWindows,
  toggleProxyFromShortcut,
  PROXY_RETRY_CODES,
};
