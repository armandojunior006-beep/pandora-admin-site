import { useEffect, useState } from "react";
import { q, run, log } from "@/lib/api";
import { useAuth } from "@/stores/auth";
import { useUI } from "@/stores/ui";
import type { Proxy } from "@/types";
import { Plus, Pencil, Trash2, X, Network, Upload, Power, PowerOff, Bug } from "lucide-react";
import { getApi } from "@/lib/api";

export function Proxies() {
  const [list, setList] = useState<Proxy[]>([]);
  const [editing, setEditing] = useState<Partial<Proxy> | null>(null);
  const [singleLine, setSingleLine] = useState("");
  const { user } = useAuth();
  const { showToast } = useUI();

  function parseProxyLine(line: string) {
    let proto = "socks5", host = "", port = 0, u: string | null = null, pw: string | null = null;
    const m1 = line.match(/^(https?|socks5):\/\/(?:([^:@]+):([^@]+)@)?([^:]+):(\d+)$/);
    const m2 = line.match(/^([^:]+):(\d+):([^:]+):(.+)$/);
    const m3 = line.match(/^([^:]+):(\d+)$/);
    // usuario:senha@host:porta (sem protocolo na frente) — faltava, era o
    // único dos 4 formatos que o time pede que a gente ainda não aceitava.
    const m4 = line.match(/^([^:@]+):([^@]+)@([^:@]+):(\d+)$/);
    if (m1) { proto = m1[1]; u = m1[2] || null; pw = m1[3] || null; host = m1[4]; port = parseInt(m1[5], 10); }
    else if (m2) { host = m2[1]; port = parseInt(m2[2], 10); u = m2[3]; pw = m2[4]; }
    else if (m4) { u = m4[1]; pw = m4[2]; host = m4[3]; port = parseInt(m4[4], 10); }
    else if (m3) { host = m3[1]; port = parseInt(m3[2], 10); }
    else return null;
    if (!host || !port) return null;
    return { proto, host, port, u, pw };
  }

  async function load() {
    setList(await q("SELECT * FROM proxies ORDER BY id DESC"));
  }
  useEffect(() => { load(); }, []);

  async function detectCountry(host: string): Promise<string> {
    try {
      const r = await fetch(`https://ipwho.is/${encodeURIComponent(host)}?fields=country,country_code,success`);
      const j = await r.json();
      if (j && j.success !== false && j.country) return j.country_code ? `${j.country} (${j.country_code})` : j.country;
    } catch {}
    try {
      const r = await fetch(`https://ipapi.co/${encodeURIComponent(host)}/json/`);
      const j = await r.json();
      if (j && j.country_name) return j.country_code ? `${j.country_name} (${j.country_code})` : j.country_name;
    } catch {}
    return "Brasil";
  }

  async function save() {
    // Se for novo proxy: usa o input de linha única no formato host:porta:usuario:senha (socks5 rotativo)
    if (!editing?.id) {
      const line = singleLine.trim();
      if (!line) { showToast("Cole a proxy no formato host:porta:usuario:senha", "error"); return; }
      const parsed = parseProxyLine(line);
      if (!parsed) { showToast("Formato inválido. Use host:porta:usuario:senha", "error"); return; }
      const label = `${parsed.host}:${parsed.port}`;
      const country = await detectCountry(parsed.host);
      await run(`INSERT INTO proxies (label, protocol, host, port, username, password, country, enabled) VALUES (?,?,?,?,?,?,?,1)`,
        [label, parsed.proto, parsed.host, parsed.port, parsed.u, parsed.pw, country]);
      await log("info", "proxy", `Salvou proxy ${label} (${country})`, null, user?.id);
      setEditing(null); setSingleLine(""); showToast(`Proxy salvo · ${country}`, "success"); load();
      return;
    }
    // Edição mantém o formulário detalhado
    if (!editing.host) return;
    if (!editing.label) editing.label = `${editing.host}:${editing.port || ""}`;
    if (!editing.label || !editing.host || !editing.port) return;
    await run(`UPDATE proxies SET label=?, protocol=?, host=?, port=?, username=?, password=?, country=?, enabled=? WHERE id=?`,
      [editing.label, editing.protocol||"socks5", editing.host, editing.port, editing.username||null, editing.password||null, editing.country||null, editing.enabled?1:0, editing.id]);
    await log("info", "proxy", `Editou proxy ${editing.label}`, null, user?.id);
    setEditing(null); showToast("Proxy atualizado", "success"); load();
  }

  async function toggle(p: Proxy) {
    await run("UPDATE proxies SET enabled=? WHERE id=?", [p.enabled ? 0 : 1, p.id]);
    load();
  }
  async function remove(id: number) {
    if (!confirm("Excluir proxy?")) return;
    await run("DELETE FROM proxies WHERE id=?", [id]); load();
  }

  // Importação rápida em formato user:pass@host:port ou host:port:user:pass por linha
  async function importBulk() {
    const api = await getApi();
    const file = await api.openFile({ filters: [{ name: "Lista", extensions: ["txt","csv"] }] });
    if (!file) return;
    const text = atob(file.data);
    let ok = 0;
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim(); if (!line) continue;
      const parsed = parseProxyLine(line);
      if (!parsed) continue;
      await run(`INSERT INTO proxies (label, protocol, host, port, username, password) VALUES (?,?,?,?,?,?)`,
        [`${parsed.host}:${parsed.port}`, parsed.proto, parsed.host, parsed.port, parsed.u, parsed.pw]);
      ok++;
    }
    await log("info", "proxy", `Importou ${ok} proxy(ies)`, null, user?.id);
    showToast(`${ok} proxy(ies) importado(s)`, "success"); load();
  }

  return (
    <div className="p-8">
      <header className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2"><Network className="w-6 h-6 text-accent2" /> Proxies</h1>
          <p className="text-sm text-muted">{list.length} proxy(ies) cadastrado(s) · {list.filter(p=>p.enabled).length} ativo(s)</p>
        </div>
        <div className="flex gap-2">
          <button className="btn-ghost border border-border" onClick={importBulk}><Upload className="w-4 h-4" /> Importar lista</button>
          {/* Pedido do usuário 2026-08-18: botão "Spider Proxy" ao lado de
              Importar lista — por enquanto só o placeholder (sem provedor/
              API definida ainda); ligar a ação de verdade quando o usuário
              passar a lógica. */}
          <button className="btn-ghost border border-border" onClick={() => showToast("Spider Proxy — em breve", "info")}><Bug className="w-4 h-4" /> Spider Proxy</button>
          <button className="btn-ghost border border-border" onClick={() => { setSingleLine(""); setEditing({ protocol: "socks5", enabled: 1 }); }}><Plus className="w-4 h-4" /> Novo proxy</button>
        </div>
      </header>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-panel2 text-muted text-xs uppercase">
            <tr>
              <th className="px-4 py-3"></th>
              <th className="text-left px-4 py-3">Label</th>
              <th className="text-left px-4 py-3">Protocolo</th>
              <th className="text-left px-4 py-3">Endereço</th>
              <th className="text-left px-4 py-3">Auth</th>
              <th className="text-left px-4 py-3">País</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <tr key={p.id} className="border-t border-border hover:bg-panel2/40">
                <td className="px-4 py-3">
                  <button onClick={() => toggle(p)} title={p.enabled ? "Desativar" : "Ativar"}>
                    {p.enabled ? <Power className="w-4 h-4 text-success" /> : <PowerOff className="w-4 h-4 text-muted" />}
                  </button>
                </td>
                <td className="px-4 py-3 font-medium">{p.label}</td>
                <td className="px-4 py-3 text-muted uppercase">{p.protocol}</td>
                <td className="px-4 py-3 font-mono text-xs">{p.host}:{p.port}</td>
                <td className="px-4 py-3 text-muted text-xs">{p.username ? "✓ autenticado" : "anônimo"}</td>
                <td className="px-4 py-3 text-muted">{p.country || "—"}</td>
                <td className="px-4 py-3 text-right">
                  <button className="btn-ghost" onClick={() => setEditing(p)}><Pencil className="w-4 h-4" /></button>
                  <button className="btn-ghost text-danger" onClick={() => remove(p.id)}><Trash2 className="w-4 h-4" /></button>
                </td>
              </tr>
            ))}
            {list.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-muted">Nenhum proxy.</td></tr>}
          </tbody>
        </table>
      </div>

      {editing && (
        <div className="fixed inset-0 bg-black/50 grid place-items-center p-4 z-50" onClick={() => setEditing(null)}>
          <div className="card p-6 w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold">{editing.id ? "Editar proxy" : "Novo proxy"}</h2>
              <button onClick={() => setEditing(null)}><X className="w-4 h-4" /></button>
            </div>
            <div className="space-y-3">
              {!editing.id ? (
                <div>
                  <label className="label">Proxy (SOCKS5 ou HTTP)*</label>
                  <input
                    className="input font-mono text-sm"
                    placeholder="host:porta:usuario:senha ou http://usuario:senha@host:porta"
                    value={singleLine}
                    onChange={(e) => setSingleLine(e.target.value)}
                    autoFocus
                  />
                  <p className="text-xs text-muted mt-1">
                    Formato: <code className="text-success">host:porta:usuario:senha</code> (assume SOCKS5) ou{" "}
                    <code className="text-success">http://usuario:senha@host:porta</code> / <code className="text-success">socks5://...</code> pra escolher o protocolo.
                  </p>
                </div>
              ) : (
                <>
                  <div><label className="label">Label*</label><input className="input" value={editing.label||""} onChange={(e)=>setEditing({...editing,label:e.target.value})} /></div>
                  <div className="grid grid-cols-3 gap-3">
                    <div><label className="label">Protocolo</label>
                      <select className="input" value={editing.protocol||"socks5"} onChange={(e)=>setEditing({...editing,protocol:e.target.value as any})}>
                        <option value="http">http</option><option value="https">https</option><option value="socks5">socks5</option>
                      </select>
                    </div>
                    <div className="col-span-2"><label className="label">Host*</label><input className="input" value={editing.host||""} onChange={(e)=>setEditing({...editing,host:e.target.value})} /></div>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    <div><label className="label">Porta*</label><input type="number" className="input" value={editing.port||""} onChange={(e)=>setEditing({...editing,port:parseInt(e.target.value)||0})} /></div>
                    <div><label className="label">Usuário</label><input className="input" value={editing.username||""} onChange={(e)=>setEditing({...editing,username:e.target.value})} /></div>
                    <div><label className="label">Senha</label><input type="password" className="input" value={editing.password||""} onChange={(e)=>setEditing({...editing,password:e.target.value})} /></div>
                  </div>
                  <div><label className="label">País</label><input className="input" value={editing.country||""} onChange={(e)=>setEditing({...editing,country:e.target.value})} /></div>
                  <label className="flex items-center gap-2 text-sm pt-1"><input type="checkbox" checked={!!editing.enabled} onChange={(e)=>setEditing({...editing,enabled:e.target.checked?1:0})} /> Ativado</label>
                </>
              )}
            </div>
            <div className="flex justify-end gap-2 mt-5">
              <button className="btn-ghost" onClick={() => setEditing(null)}>Cancelar</button>
              <button className="btn-primary" onClick={save}>Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
