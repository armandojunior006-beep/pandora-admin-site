// ============================================================================
// IPC: chrome:searchSlot — pesquisa e abre um slot pelo nome na tela
// /home/subgame (categoria "Slots"): preenche o campo de busca via DOM,
// localiza o primeiro card de resultado e clica (DOM + sendInputEvent nativo).
// ============================================================================
const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");

function registerSlotHandler(ipcMain) {
  // TEMPORÁRIO — investigação de API de aposta (2026-08-07). Dispara N
  // giros encadeados via API pura (sem clicar em nada) em cada janela
  // selecionada, usando o motor exposto pelo __API_INSPECT_SCRIPT dentro
  // do iframe do jogo (ver runApiSpinChain em realChromeManager.cjs).
  ipcMain.handle("chrome:apiSpinRun", async (_e, { count, opts } = {}) => {
    const { runApiSpinChain } = require("../window/realchrome/realChromeManager.cjs");
    const n = Math.max(1, parseInt(count, 10) || 10); // 2026-08-10: limite de 1000 removido a pedido do usuário — jogos não podem ter teto de giros
    // Retry POR JANELA (o jogo pode ainda estar carregando quando o clique
    // em IR chega aqui) — e TODAS as janelas em paralelo (Promise.all), não
    // uma esperando a outra terminar todos os giros pra só então começar a
    // próxima (bug corrigido em 2026-08-07: antes era sequencial, uma
    // janela com 350 giros configurados travava as outras por minutos).
    const runOneWithRetry = async (win) => {
      // 26*1.5s ≈ 39s (era 13*1.5s≈19,5s — curto demais quando a proxy
      // demora mais pra carregar o slot; pedido do usuário 2026-08-08:
      // continuar tentando em vez de desistir cedo). Mesmo valor usado
      // pra WG/PP (ver chrome:wgSpinRun/ppSpinRun logo abaixo).
      const tentativas = 40; // ~40*1.5s=60s — margem extra pra proxy lenta (pedido do usuário 2026-08-08)
      const intervaloMs = 1500;
      for (let i = 0; i < tentativas; i++) {
        await new Promise((r) => setTimeout(r, intervaloMs));
        try {
          const r = await runApiSpinChain(win, n, opts || {});
          if (r?.ok) return r;
          if (r?.reason === "estado incompleto" || r?.reason?.includes?.("frame do jogo")) continue;
          return r; // erro definitivo
        } catch (e) {
          // tenta de novo
        }
      }
      return { ok: false, reason: "tempo esgotado esperando o jogo carregar" };
    };
    const wins = getSelectedChromeWins().filter((w) => w && !w.isDestroyed() && w._realChrome);
    const results = await Promise.all(wins.map((win) => runOneWithRetry(win).catch((e) => ({ ok: false, reason: e?.message }))));
    return results;
  });

  // Auto Slot via API pura pra WG (Lucky Dog) — ver runWgSpinChain em
  // realChromeManager.cjs. Mesmo padrão de retry+paralelismo do
  // chrome:apiSpinRun acima (o motor pode ainda não ter sido achado na
  // árvore de cena quando o clique em IR chega aqui).
  ipcMain.handle("chrome:wgSpinRun", async (_e, { count, opts } = {}) => {
    const { runWgSpinChain } = require("../window/realchrome/realChromeManager.cjs");
    const n = Math.max(1, parseInt(count, 10) || 10); // 2026-08-10: limite de 1000 removido a pedido do usuário — jogos não podem ter teto de giros
    const runOneWithRetry = async (win) => {
      // 26*1.5s ≈ 39s (era 13*1.5s≈19,5s — curto demais quando várias
      // telas carregam em paralelo, causando "tempo esgotado" falso mesmo
      // quando o jogo ia terminar de carregar segundos depois).
      const tentativas = 40; // ~40*1.5s=60s — margem extra pra proxy lenta (pedido do usuário 2026-08-08)
      const intervaloMs = 1500;
      for (let i = 0; i < tentativas; i++) {
        await new Promise((r) => setTimeout(r, intervaloMs));
        try {
          const r = await runWgSpinChain(win, n, opts || {});
          if (r?.ok) return r;
          if (r?.reason?.includes?.("ainda não encontrado")) continue;
          return r; // erro definitivo
        } catch (e) {
          // tenta de novo
        }
      }
      return { ok: false, reason: "tempo esgotado esperando o motor da WG carregar" };
    };
    const wins = getSelectedChromeWins().filter((w) => w && !w.isDestroyed() && w._realChrome);
    const results = await Promise.all(wins.map((win) => runOneWithRetry(win).catch((e) => ({ ok: false, reason: e?.message }))));
    return results;
  });

  // Auto Slot via API pura pra PP (Pragmatic Play — Plushie Wins e outros).
  // Ver runPpSpinChain em realChromeManager.cjs. Mesmo padrão de
  // retry+paralelismo dos outros dois acima — o doInit que semeia o estado
  // roda sozinho quando o jogo carrega (nenhum clique necessário), mas pode
  // levar alguns segundos depois do IR.
  ipcMain.handle("chrome:ppSpinRun", async (_e, { count, opts } = {}) => {
    const { runPpSpinChain } = require("../window/realchrome/realChromeManager.cjs");
    const n = Math.max(1, parseInt(count, 10) || 10); // 2026-08-10: limite de 1000 removido a pedido do usuário — jogos não podem ter teto de giros
    const runOneWithRetry = async (win) => {
      // 26*1.5s ≈ 39s — mesmo ajuste do WG acima.
      const tentativas = 40; // ~40*1.5s=60s — margem extra pra proxy lenta (pedido do usuário 2026-08-08)
      const intervaloMs = 1500;
      for (let i = 0; i < tentativas; i++) {
        await new Promise((r) => setTimeout(r, intervaloMs));
        try {
          const r = await runPpSpinChain(win, n, opts || {});
          if (r?.ok) return r;
          if (r?.reason?.includes?.("ainda não capturado")) continue;
          return r; // erro definitivo
        } catch (e) {
          // tenta de novo
        }
      }
      return { ok: false, reason: "tempo esgotado esperando o jogo da PP carregar" };
    };
    const wins = getSelectedChromeWins().filter((w) => w && !w.isDestroyed() && w._realChrome);
    const results = await Promise.all(wins.map((win) => runOneWithRetry(win).catch((e) => ({ ok: false, reason: e?.message }))));
    return results;
  });

  ipcMain.handle("chrome:searchSlot", (_e, slotName, cardIndex) => {
    const name = String(slotName || "").trim();
    if (!name) return 0;
    const pathPart = "/home/subgame?gameCategoryId=3&platformId=3999";
    // cardIndex: qual resultado da busca clicar (0 = primeiro, padrão).
    // Existe pra casos tipo "Lucky Dog" x "Lucky Doggy" — a busca por
    // "Lucky Dog" também acha "Lucky Doggy" (é substring), então precisa
    // pular pro 2º card em vez do 1º.
    const idx = Math.max(0, parseInt(cardIndex, 10) || 0);

    const buildFillScript = (slot) => {
      const safe = JSON.stringify(slot);
      const safeIdx = JSON.stringify(idx);
      return `(() => {
        try {
          const slot = ${safe};
          const cardIndex = ${safeIdx};
          const now = Date.now();
          // LOCK GLOBAL: se já clicamos com sucesso neste slot, não faz mais nada.
          if (window.__pandoraSlotClick && window.__pandoraSlotClick.slot === slot && window.__pandoraSlotClick.done) {
            try { console.log('[pandora][slot] já concluído — bloqueando novas tentativas (slot=' + slot + ')'); } catch(e){}
            return { clicked: false, alreadyDone: true };
          }
          if (!window.__pandoraSlotFill || window.__pandoraSlotFill.slot !== slot) {
            window.__pandoraSlotFill = { slot, done: false, tries: 0, startedAt: now, doneAt: 0 };
            window.__pandoraSlotClick = { slot, tries: 0, startedAt: now, lastNativeAt: 0, domClicks: 0, done: false, doneAt: 0, pointConsumed: false };
            try { console.log('[pandora][slot] iniciado slot="' + slot + '"'); } catch(e){}
          }
          const setNativeValue = (el, value) => {
            try {
              const proto = Object.getPrototypeOf(el);
              const desc = Object.getOwnPropertyDescriptor(proto, 'value')
                        || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
              if (desc && desc.set) desc.set.call(el, value);
              else el.value = value;
            } catch { el.value = value; }
          };
          const findInput = () => {
            const sels = [
              'input.ui-input__input[placeholder="Pesquisar"]',
              'input.ui-input__input[placeholder*="esquisar" i]',
              'input.ui-input__input[placeholder*="earch" i]',
              'input[placeholder*="esquisar" i]',
              'input[placeholder*="earch" i]',
              'input.ui-input__input',
              'input[type="search"]',
              'input[type="text"]',
            ];
            for (const s of sels) {
              const list = Array.from(document.querySelectorAll(s));
              const el = list.find((inp) => {
                const r = inp.getBoundingClientRect();
                return r.width > 80 && r.height > 18 && r.bottom > 38 && r.top < innerHeight && inp.offsetParent !== null;
              });
              if (el) return el;
            }
            return null;
          };
          const typeIntoInput = (inp, text) => {
            try { inp.focus(); } catch {}
            try { inp.click(); } catch {}
            try {
              setNativeValue(inp, '');
              inp.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
            } catch {}
            setNativeValue(inp, text);
            try { inp.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: text })); } catch { try { inp.dispatchEvent(new Event('input', { bubbles: true })); } catch {} }
            try { inp.dispatchEvent(new Event('change', { bubbles: true })); } catch {}
            try {
              const last = text.slice(-1) || ' ';
              inp.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: last }));
              inp.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, key: last }));
              inp.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: last }));
            } catch {}
          };
          const inputValueOk = (inp) => {
            try { return String(inp.value || '').trim() === slot; } catch { return false; }
          };
          const fillInput = () => {
            const stC = window.__pandoraSlotClick;
            if (stC && stC.done) return; // STOP loop após clique concluído
            const st = window.__pandoraSlotFill;
            if (!st) return;
            st.tries++;
            const inp = findInput();
            if (inp) {
              if (!inputValueOk(inp)) {
                typeIntoInput(inp, slot);
              }
              if (inputValueOk(inp)) {
                if (!st.done) { st.done = true; st.doneAt = Date.now(); }
                try { inp.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 })); } catch {}
                try { inp.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 })); } catch {}
                try { inp.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter', code: 'Enter', keyCode: 13, which: 13 })); } catch {}
              } else {
                st.done = false;
              }
            } else {
              st.done = false;
            }
            if (st.tries < 120) setTimeout(fillInput, 300);
          };


          const visible = (el) => {
            if (!el) return false;
            const r = el.getBoundingClientRect();
            const style = getComputedStyle(el);
            return r.width >= 58 && r.height >= 58 && r.bottom > 44 && r.top < innerHeight - 6 && r.right > 0 && r.left < innerWidth && style.visibility !== 'hidden' && style.display !== 'none' && style.opacity !== '0';
          };
          const bad = (el) => {
            const cls = String(el.className || '');
            const bg = String(el.style && el.style.backgroundImage || '');
            const txt = String(el.innerText || el.getAttribute('aria-label') || el.getAttribute('title') || '');
            return /circle-star|star-icon|btn_|sc_off|favorite|collect|provider|category|banner|avatar|logo|wallet|deposit|search|tab|nav|menu/i.test(cls + ' ' + bg + ' ' + txt);
          };
          const scoreCard = (el) => {
            if (!visible(el) || bad(el)) return -9999;
            const r = el.getBoundingClientRect();
            const cls = String(el.className || '');
            const bg = String(el.style && el.style.backgroundImage || '');
            let score = 0;
            if (/poster-image/i.test(cls)) score += 90;
            if (/poster-box/i.test(cls)) score += 80;
            if (/lobby-image/i.test(cls)) score += 25;
            if (el.hasAttribute('data-id')) score += 20;
            if (/game_pic|game|slot|poster/i.test(bg + ' ' + cls)) score += 30;
            if (r.width >= 80 && r.height >= 80) score += 20;
            if (r.width > innerWidth * 0.85 || r.height > innerHeight * 0.55) score -= 120;
            if (r.top < 70) score -= 45;
            return score;
          };
          const findCard = () => {
            const sels = [
              '.poster-image.lobby-image[data-id]',
              '.poster-image[data-id]',
              '[class*="poster-image"][data-id]',
              '[class*="poster-box"] .lobby-image[data-id]',
              '[class*="poster-box"] [data-id]',
              '[data-id] [class*="poster-image"]',
              '[data-id] .poster-image',
              '.lobby-image.poster-image',
              '[class*="poster-image"]',
              '.lobby-image[data-id]',
            ];
            const seen = new Set();
            const cards = [];
            for (const s of sels) {
              for (const el of Array.from(document.querySelectorAll(s))) {
                if (seen.has(el)) continue;
                seen.add(el);
                const sc = scoreCard(el);
                if (sc > 0) cards.push({ el, sc, r: el.getBoundingClientRect() });
              }
            }
            cards.sort((a, b) => (b.sc - a.sc) || (a.r.top - b.r.top) || (a.r.left - b.r.left));
            if (!cards.length) return null;
            const chosen = cards[cardIndex] || cards[cards.length - 1];
            return chosen.el;
          };
          const naturalTarget = (card) => {
            let target = card;
            try {
              const clickable = card.closest('a,button,[role="button"],[onclick],[class*="game"],[class*="item"],[class*="card"],[class*="poster-box"],[data-id]');
              if (clickable && visible(clickable) && !bad(clickable)) target = clickable;
            } catch {}
            return target || card;
          };
          const clickFirstResult = () => {
            const stClick = window.__pandoraSlotClick = window.__pandoraSlotClick || { slot, tries: 0, startedAt: Date.now(), lastNativeAt: 0, domClicks: 0, done: false, doneAt: 0, pointConsumed: false };
            // STOP: já clicamos — bloqueia qualquer nova tentativa.
            if (stClick.done) return null;
            const stFill = window.__pandoraSlotFill;
            stClick.tries++;
            const inpNow = findInput();
            const valOk = inpNow && String(inpNow.value || '').trim() === slot;
            if (!stFill || !stFill.done || !valOk) {
              if (inpNow && !valOk) { try { typeIntoInput(inpNow, slot); } catch {} }
              if (stClick.tries < 320) setTimeout(clickFirstResult, 220);
              return null;
            }
            const readyAt = stFill.doneAt || stClick.startedAt;
            if (Date.now() - readyAt < 600) {
              setTimeout(clickFirstResult, 180);
              return null;
            }

            const card = findCard();
            if (!card) {
              if (stClick.tries < 320) setTimeout(clickFirstResult, 220);
              return null;
            }
            // Pedido do usuário 2026-08-10: "encontra o slot e já entra,
            // muito rápido — após encontrar aguarde 1,5s e entra". Marca o
            // instante em que o card foi achado pela PRIMEIRA vez e só
            // segue pro clique depois de 1500ms — se ainda não passou,
            // reagenda sem clicar (não reconta o tempo a cada chamada).
            if (!stClick.cardFoundAt) {
              stClick.cardFoundAt = Date.now();
              try { console.log('[pandora][slot] slot encontrado, aguardando 1.5s antes de clicar'); } catch(e){}
            }
            if (Date.now() - stClick.cardFoundAt < 1500) {
              setTimeout(clickFirstResult, 150);
              return null;
            }
            let target = naturalTarget(card);
            try { target.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
            const r = target.getBoundingClientRect();
            let x = Math.max(2, Math.min(innerWidth - 2, r.left + r.width / 2));
            let y = Math.max(46, Math.min(innerHeight - 2, r.top + r.height / 2));
            try {
              const topEl = document.elementFromPoint(x, y);
              if (topEl && target.contains(topEl)) target = topEl;
            } catch {}
            try { console.log('[pandora][slot] card encontrado data-id=' + (card.getAttribute && card.getAttribute('data-id') || '?') + ' @ (' + (x|0) + ',' + (y|0) + ')'); } catch(e){}
            const opts = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y, button: 0, buttons: 1 };
            try { target.dispatchEvent(new PointerEvent('pointerover', { ...opts, pointerType: 'mouse' })); } catch {}
            try { target.dispatchEvent(new MouseEvent('mouseover', opts)); } catch {}
            try { target.dispatchEvent(new PointerEvent('pointermove', { ...opts, pointerType: 'mouse' })); } catch {}
            try { target.dispatchEvent(new MouseEvent('mousemove', opts)); } catch {}
            try { target.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerType: 'mouse', isPrimary: true })); } catch {}
            try { target.dispatchEvent(new MouseEvent('mousedown', opts)); } catch {}
            try { target.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerType: 'mouse', isPrimary: true, buttons: 0 })); } catch {}
            try { target.dispatchEvent(new MouseEvent('mouseup', { ...opts, buttons: 0 })); } catch {}
            try { target.dispatchEvent(new MouseEvent('click', { ...opts, buttons: 0 })); } catch {}
            try { target.click && target.click(); } catch {}
            stClick.domClicks++;
            stClick.lastPoint = { x, y, at: Date.now() };
            // TRAVA: marca como concluído após o primeiro clique. Não reagenda.
            stClick.done = true;
            stClick.doneAt = Date.now();
            try { console.log('[pandora][slot] CLIQUE executado — etapa concluída, bloqueando novas tentativas'); } catch(e){}
            return { clicked: true, x, y };
          };
          fillInput();
          setTimeout(clickFirstResult, 260);
          return clickFirstResult();
        } catch (e) { return null; }
      })();`;
    };

    const sendNativeSlotClick = (win, point) => {
      try {
        if (!win || win.isDestroyed() || !point) return;
        const wc = win.webContents;
        const x = Math.max(1, Math.round(Number(point.x) || 1));
        const y = Math.max(1, Math.round(Number(point.y) || 1));
        const now = Date.now();
        // Throttle curto para não saturar, mas permitir múltiplas tentativas.
        if (now - (win._lastSlotNativeClickAt || 0) < 250) return;
        win._lastSlotNativeClickAt = now;
        try { wc.focus(); } catch {}
        try { if (typeof win.focusOnWebView === 'function') win.focusOnWebView(); } catch {}
        // Sequência completa: move -> down -> up -> click duplicado por segurança.
        const fire = () => {
          try {
            wc.sendInputEvent({ type: 'mouseMove', x, y, movementX: 0, movementY: 0 });
            wc.sendInputEvent({ type: 'mouseDown', x, y, button: 'left', clickCount: 1 });
            setTimeout(() => {
              try { if (!win.isDestroyed()) wc.sendInputEvent({ type: 'mouseUp', x, y, button: 'left', clickCount: 1 }); } catch {}
            }, 40);
          } catch {}
        };
        fire();
        // Re-tenta após 180ms — janelas em background às vezes ignoram o primeiro evento.
        setTimeout(() => { try { if (!win.isDestroyed()) fire(); } catch {} }, 180);
      } catch {}
    };


    let n = 0;
    for (const win of getSelectedChromeWins()) {
      try {
        if (!win || win.isDestroyed()) continue;
        const wc = win.webContents;
        let currentUrl = "";
        try { currentUrl = wc.getURL() || ""; } catch {}
        if (!currentUrl) currentUrl = win._targetUrl || "";
        let origin = "";
        try { origin = new URL(currentUrl).origin; } catch {}
        if (!origin) continue;

        // Detecta roteamento por hash (#/...) usado por alguns espelhos SPA.
        const useHash = /#\//.test(currentUrl);
        const targetUrl = useHash
          ? origin + "/#" + pathPart
          : origin + pathPart;

        // Limpa flag anterior para garantir nova execução.
        try {
          wc.executeJavaScript("try{delete window.__pandoraSlotFill;delete window.__pandoraSlotClick}catch(e){}", true).catch(() => {});
        } catch {}

        const inject = () => {
          if (win.isDestroyed() || win._slotDone) return;
          try {
            wc.executeJavaScript(buildFillScript(name), true)
              .then((res) => {
                if (res && res.alreadyDone) { win._slotDone = true; return; }
                if (res && res.clicked) { sendNativeSlotClick(win, res); win._slotDone = true; }
              })
              .catch(() => {});
          } catch {}
        };

        let nativePollTicks = 0;
        const pollNativeClick = () => {
          if (win.isDestroyed() || nativePollTicks++ > 240) return;
          if (win._nativeClickFired) return; // disparou apenas uma vez
          try {
            wc.executeJavaScript(`(() => {
              try {
                const st = window.__pandoraSlotClick;
                if (!st || !st.lastPoint || st.pointConsumed) return null;
                if (Date.now() - st.lastPoint.at > 2500) return null;
                st.pointConsumed = true;
                return st.lastPoint;
              } catch(e) { return null; }
            })();`, true)
              .then((point) => {
                if (point) {
                  win._nativeClickFired = true;
                  sendNativeSlotClick(win, point);
                  win._slotDone = true;
                  try { console.log('[pandora][slot] native click enviado uma única vez @ (' + point.x + ',' + point.y + ')'); } catch {}
                }
              })
              .catch(() => {});
          } catch {}
          if (!win._nativeClickFired) setTimeout(pollNativeClick, 250);
        };


        const onceEvt = (evt) => { try { wc.once(evt, () => setTimeout(() => { if (!win._slotDone) inject(); }, 400)); } catch {} };
        onceEvt("did-finish-load");
        onceEvt("did-navigate");
        onceEvt("did-navigate-in-page");
        onceEvt("dom-ready");

        // reset por janela ao iniciar nova busca
        win._slotDone = false;
        win._nativeClickFired = false;

        try { win.loadURL(targetUrl).catch(() => {}); } catch {}

        for (const ms of [700, 1400, 2300, 3500, 5000, 7000, 10000, 14000]) {
          setTimeout(() => { if (!win._slotDone) inject(); }, ms);
        }
        setTimeout(pollNativeClick, 900);
        n++;
      } catch {}
    }
    return n;
  });
}

module.exports = { registerSlotHandler };
