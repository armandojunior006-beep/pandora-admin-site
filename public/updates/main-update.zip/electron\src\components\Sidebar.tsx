import { useUI, type TabKey } from "@/stores/ui";
import { useAuth } from "@/stores/auth";
import pandoraLogo from "@/assets/logo.png";
import {
  LogOut,
  Home,
  KeyRound,
  Users,
  Globe,
  MonitorSmartphone,
  PlayCircle,
  CreditCard,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";
import { useState, useEffect } from "react";
import { getApi } from "@/lib/api";
import clsx from "clsx";

const TABS: { key: TabKey; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: "inicio", label: "Início", icon: Home },
  { key: "chaves", label: "Chaves PIX", icon: KeyRound },
  { key: "contas", label: "Contas", icon: Users },
  { key: "proxies", label: "Proxy", icon: Globe },
  { key: "telas", label: "Telas", icon: MonitorSmartphone },
  { key: "operacao", label: "Operação", icon: PlayCircle },
  { key: "mercadopago", label: "Mercado Pago", icon: CreditCard },
];

export function Sidebar() {
  const { activeTab, setTab } = useUI();
  const { user, logout } = useAuth();
  const [collapsed, setCollapsed] = useState(false);
  const [appVersion, setAppVersion] = useState<string>("");
  useEffect(() => {
    (async () => {
      try { const api = await getApi(); const info = await api.appInfo(); setAppVersion(String(info?.version || "")); } catch {}
    })();
  }, []);

  return (
    <aside
      className={clsx(
        "h-screen sticky top-0 shrink-0 border-r border-border bg-panel flex flex-col transition-[width] duration-200 ease-out",
        collapsed ? "w-[68px]" : "w-[244px]"
      )}
    >
      {/* Brand */}
      <div className="px-4 pt-5 pb-4 flex items-center gap-3 border-b border-border">
        <img src={pandoraLogo} alt="Spider Bot" className="w-9 h-9 rounded-lg object-contain bg-black shrink-0" />
        {!collapsed && (
          <div className="leading-tight overflow-hidden">
            <p className="text-[13px] font-semibold text-white tracking-tight truncate">Spider Bot</p>
            <p className="text-[9px] text-muted uppercase tracking-[0.22em]">v{appVersion || "—"}</p>
          </div>
        )}
      </div>

      {/* Section label */}
      {!collapsed && (
        <p className="px-5 pt-4 pb-2 text-[9px] uppercase tracking-[0.22em] text-muted">Funções</p>
      )}

      {/* Nav */}
      <nav className="flex-1 px-2 py-2 space-y-1 overflow-hidden">
        {TABS.map((t) => {
          const active = activeTab === t.key;
          const Icon = t.icon;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              title={collapsed ? t.label : undefined}
              className={clsx(
                "group w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors relative",
                active
                  ? "text-accent2 font-medium"
                  : "text-neutral-400 hover:text-white"
              )}
            >
              <Icon className={clsx("w-[18px] h-[18px] shrink-0", active ? "text-accent2" : "")} />
              {!collapsed && <span className="truncate">{t.label}</span>}
              {!collapsed && active && (
                <span className="ml-auto text-[9px] tracking-[0.18em] uppercase text-accent2">●</span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer / user */}
      <div className="border-t border-border p-3 space-y-2">
        {!collapsed ? (
          <div className="flex items-center gap-2.5 px-2 py-2 rounded-md bg-panel2 border border-border">
            <div className="w-8 h-8 rounded-md bg-white/10 grid place-items-center text-[11px] font-semibold text-white">
              {(user?.full_name || user?.username || "?").slice(0, 2).toUpperCase()}
            </div>
            <div className="flex-1 leading-tight min-w-0">
              <p className="text-[12px] text-white font-medium truncate">{user?.full_name || user?.username}</p>
              <p className="text-[10px] text-muted capitalize truncate">{user?.role}</p>
            </div>
            <button onClick={logout} title="Sair" className="p-1.5 rounded hover:bg-white/10 text-mutedStrong hover:text-white">
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <button onClick={logout} title="Sair" className="w-full p-2 rounded-md hover:bg-white/[0.06] text-mutedStrong hover:text-white grid place-items-center">
            <LogOut className="w-4 h-4" />
          </button>
        )}

        <button
          onClick={() => setCollapsed((v) => !v)}
          className="w-full flex items-center justify-center gap-2 px-2 py-1.5 rounded-md text-[10px] uppercase tracking-[0.18em] text-mutedStrong hover:text-white hover:bg-white/[0.04] transition-colors"
        >
          {collapsed ? <ChevronsRight className="w-3.5 h-3.5" /> : <><ChevronsLeft className="w-3.5 h-3.5" /> Recolher</>}
        </button>
      </div>
    </aside>
  );
}
