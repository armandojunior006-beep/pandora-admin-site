// Pandora security primitives:
//  1. Integrity check (SHA-256 dos arquivos críticos do main process)
//  2. Anti-DevTools em produção (F12 / Ctrl+Shift+I / devtools-opened)
//  3. HMAC request signing (compartilhado com servidor /api/public/auth/validate)
//
// Observação: este arquivo TAMBÉM faz parte do conjunto verificado por
// integridade — qualquer edição quebra o hash e o app se recusa a abrir.

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const https = require("https");

// ⚠ Segredo compartilhado com o servidor. Não é "secret" no sentido criptográfico
// — é embedded no binário — mas evita que scripts curl simulem o cliente.
// A proteção forte continua sendo o HWID binding no servidor.
const HMAC_SECRET = "3879c1a87ff052f55b5fe117aab630a9a1156887ef01a2af300687ef87e6c1eb";

// Arquivos do main process que devem ter integridade verificada.
const CRITICAL_FILES = ["main.cjs", "preload.cjs", "auto-register.cjs", "security.cjs"];

function sha256File(p) {
  const buf = fs.readFileSync(p);
  return crypto.createHash("sha256").update(buf).digest("hex");
}

function readIntegrityManifest(baseDir) {
  const f = path.join(baseDir, "integrity.json");
  if (!fs.existsSync(f)) return null;
  try { return JSON.parse(fs.readFileSync(f, "utf8")); } catch { return null; }
}

// Reporta violação ao servidor de forma "best-effort" (sem await crítico).
function reportIntegrityViolation(payload) {
  try {
    const data = JSON.stringify(payload);
    const req = https.request({
      method: "POST",
      host: "pandora-wonder-box.lovable.app",
      path: "/api/public/security/report",
      headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data) },
      timeout: 4000,
    });
    req.on("error", () => {});
    req.write(data); req.end();
  } catch {}
}

// Roda no startup do main.cjs.
// - Em dev (não-packaged) só loga avisos, não bloqueia.
// - Em produção, qualquer divergência → reporta + bloqueia o app.
function verifyIntegrityOrDie(app, dialog) {
  const baseDir = __dirname;
  const manifest = readIntegrityManifest(baseDir);
  const packaged = !!(app && app.isPackaged);

  if (!manifest || !manifest.files) {
    if (packaged) {
      reportIntegrityViolation({ kind: "manifest_missing", platform: process.platform });
      try { dialog.showErrorBox("Pandora Bot", "Arquivos do app foram alterados. Reinstale o app."); } catch {}
      app.exit(1);
    } else {
      console.warn("[security] integrity.json ausente (dev) — pulando.");
    }
    return;
  }

  const mismatches = [];
  for (const name of CRITICAL_FILES) {
    const full = path.join(baseDir, name);
    if (!fs.existsSync(full)) { mismatches.push({ file: name, reason: "missing" }); continue; }
    let actual;
    try { actual = sha256File(full); } catch (e) { mismatches.push({ file: name, reason: "read_error" }); continue; }
    const expected = manifest.files[name];
    if (!expected) { mismatches.push({ file: name, reason: "unmanaged_in_manifest", actual }); continue; }
    if (expected !== actual) mismatches.push({ file: name, reason: "hash_mismatch", expected, actual });
  }

  if (mismatches.length === 0) {
    console.log("[security] integridade OK (" + CRITICAL_FILES.length + " arquivos)");
    return;
  }

  console.error("[security] INTEGRIDADE VIOLADA", mismatches);
  reportIntegrityViolation({
    kind: "integrity_violation",
    platform: process.platform,
    mismatches,
    appVersion: (() => { try { return app.getVersion(); } catch { return ""; } })(),
  });
  if (packaged) {
    try { dialog.showErrorBox("Pandora Bot", "Arquivos do app foram modificados. Reinstale o app para continuar."); } catch {}
    app.exit(1);
  }
}

// Anti-DevTools em produção: bloqueia atalhos e fecha a janela se DevTools abrirem.
// DevTools LIBERADAS para diagnóstico — função vira no-op.
function hardenWindowAgainstDevTools(_win, _app) {
  return;
}

// HMAC do payload usado pelo /api/public/auth/validate.
// Formato: sig = hex(HMAC_SHA256(secret, ts + "." + bodyString))
function signPayload(bodyString) {
  const ts = Date.now().toString();
  const sig = crypto.createHmac("sha256", HMAC_SECRET).update(ts + "." + String(bodyString || "")).digest("hex");
  return { ts, sig };
}

module.exports = {
  HMAC_SECRET,
  CRITICAL_FILES,
  sha256File,
  verifyIntegrityOrDie,
  hardenWindowAgainstDevTools,
  signPayload,
  reportIntegrityViolation,
};
