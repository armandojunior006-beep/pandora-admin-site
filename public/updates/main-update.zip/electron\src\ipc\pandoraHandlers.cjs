// ============================================================================
// IPC: pandora:device-id / pandora:sign-payload / pandora:human-click —
// integração com a Pandora Cloud (HWID + HMAC) e cliques humanizados nativos.
// ============================================================================
const { signPayload } = require("../../security.cjs");
const { getDeviceId } = require("../license/deviceId.js");
const { humanClickSequence } = require("../lib/humanClick.cjs");

function registerPandoraHandlers(ipcMain) {
  ipcMain.handle("pandora:device-id", async () => {
    return getDeviceId();
  });

  // === HMAC signing para chamadas autenticadas à Cloud ======================
  // Renderer envia o body serializado e recebe { ts, sig } para anexar como
  // headers x-pandora-ts / x-pandora-sig. O segredo nunca sai do main process.
  ipcMain.handle("pandora:sign-payload", async (_e, bodyString) => {
    try { return signPayload(String(bodyString || "")); }
    catch (e) { return { ts: "", sig: "", error: String(e?.message || e) }; }
  });

  // === Pandora: clique humanizado via sendInputEvent =========================
  // Recebe coordenadas CSS (relativas ao viewport do webContents) e dispara uma
  // sequência realista: trajetória curva de mouseMove + hover + mouseDown + hold + mouseUp.
  // Isso preserva event.target/closest nativos (não é dispatchEvent sintético) e
  // satisfaz handlers de framework (Vue/Geetest) que validam o tipo do MouseEvent.
  ipcMain.handle("pandora:human-click", async (e, payload) => {
    try {
      const wc = e && e.sender;
      if (!wc || wc.isDestroyed()) return { ok: false, error: "no-webcontents" };
      const dispatch = async (type, x, y) => {
        if (type === "mouseMove") wc.sendInputEvent({ type, x, y });
        else wc.sendInputEvent({ type, x, y, button: "left", clickCount: 1 });
      };
      return await humanClickSequence(dispatch, payload?.x, payload?.y);
    } catch (err) {
      return { ok: false, error: err?.message || String(err) };
    }
  });
}

module.exports = { registerPandoraHandlers };
