import { useEffect, useMemo, useRef, useState } from "react";
import { getSetting, setSetting, log, getApi } from "@/lib/api";
import { useAuth } from "@/stores/auth";
import { useUI } from "@/stores/ui";
import { Monitor, Save, Settings2, RefreshCw, X, RotateCcw } from "lucide-react";
import spiderLogoBg from "@/assets/logo-bg.png";

type PosicaoJanela = { x: number; y: number; w: number; h: number };

type MonitorInfo = {
  index: number;
  id?: number;
  label: string;
  width: number;
  height: number;
  primary?: boolean;
};

export function Telas() {
  const [gpu, setGpu] = useState("GPU");
  const [perfil, setPerfil] = useState("Perfil 1");
  const [monitors, setMonitors] = useState<MonitorInfo[]>([]);
  const [monitorIdx, setMonitorIdx] = useState(0);
  const [ativo, setAtivo] = useState(true);
  const [rows, setRows] = useState(2);
  const [cols, setCols] = useState(5);
  const [reduzir, setReduzir] = useState(false);
  const [esconderNav, setEsconderNav] = useState(false);
  const { user } = useAuth();
  const { showToast } = useUI();

  async function detectMonitors() {
    const api = await getApi();
    let list: MonitorInfo[] = [];
    if (api?.listMonitors) {
      try { list = await api.listMonitors(); } catch {}
    }
    if (!list || list.length === 0) {
      // Fallback (browser preview): usa screen do navegador
      list = [{
        index: 0,
        label: `Monitor 1 (Principal): ${window.screen.width}x${window.screen.height}`,
        width: window.screen.width,
        height: window.screen.height,
        primary: true,
      }];
    }
    setMonitors(list);
    return list;
  }

  useEffect(() => {
    (async () => {
      const list = await detectMonitors();
      const savedGpu = await getSetting("gpu_mode", "GPU");
      setGpu(savedGpu === "CPU" ? "CPU" : "GPU");
      setPerfil(await getSetting("screen_profile", "Perfil 1"));
      const savedIdx = parseInt(await getSetting("monitor_index", "0"), 10) || 0;
      setMonitorIdx(Math.min(savedIdx, list.length - 1));
      setAtivo((await getSetting("monitor_active", "1")) === "1");
      setRows(parseInt(await getSetting("grid_rows", "2")) || 2);
      setCols(parseInt(await getSetting("grid_cols", "5")) || 5);
      setReduzir((await getSetting("reduzir_janelas", "0")) === "1");
      setEsconderNav((await getSetting("esconder_navegacao", "0")) === "1");
    })();
  }, []);

  const total = rows * cols;
  const cells = useMemo(() => Array.from({ length: total }, (_, i) => i + 1), [total]);
  const current = monitors[monitorIdx];
  const resolution = current ? `${current.width}x${current.height}` : "—";

  async function saveGrid() {
    const safeRows = Math.max(1, Math.min(8, rows));
    const safeCols = Math.max(1, Math.min(10, cols));
    const safeTotal = safeRows * safeCols;
    await setSetting("gpu_mode", gpu);
    await setSetting("screen_profile", perfil);
    await setSetting("monitor_index", String(monitorIdx));
    await setSetting("monitor_info", current?.label || "");
    await setSetting("monitor_active", ativo ? "1" : "0");
    await setSetting("grid_rows", String(safeRows));
    await setSetting("grid_cols", String(safeCols));
    await setSetting("reduzir_janelas", reduzir ? "1" : "0");
    await setSetting("esconder_navegacao", esconderNav ? "1" : "0");
    await setSetting("screen_count", String(safeTotal));
    setRows(safeRows);
    setCols(safeCols);
    await log("info", "telas", `Configurações de telas salvas: ${safeRows}x${safeCols} (${safeTotal} telas), reduzir=${reduzir ? "sim" : "não"}, monitor=${current?.label || "?"}`, null, user?.id);
    showToast(`Configurações salvas: ${safeRows} × ${safeCols} = ${safeTotal} telas`, "success");
  }

  const [posOpen, setPosOpen] = useState(false);
  const [posicoes, setPosicoes] = useState<PosicaoJanela[]>([]);
  const [savingPos, setSavingPos] = useState(false);

  function defaultPositionFor(i: number): PosicaoJanela {
    if (!current) return { x: 0, y: 0, w: 400, h: 600 };
    const row = Math.floor(i / cols);
    const col = i % cols;
    const w = Math.floor(current.width / cols);
    const h = Math.floor(current.height / rows);
    return { x: col * w, y: row * h, w, h };
  }

  async function customPositions() {
    const raw = await getSetting("custom_positions", "");
    let arr: PosicaoJanela[] = [];
    try { arr = raw ? JSON.parse(raw) : []; } catch { arr = []; }
    const next: PosicaoJanela[] = Array.from({ length: total }, (_, i) => arr[i] || defaultPositionFor(i));
    setPosicoes(next);
    setPosOpen(true);
  }

  async function salvarPosicoes() {
    setSavingPos(true);
    try {
      await setSetting("custom_positions", JSON.stringify(posicoes));
      await setSetting("use_custom_positions", "1");
      await log("info", "telas", `Posições personalizadas salvas para ${posicoes.length} janela(s)`, null, user?.id);
      showToast("Posições personalizadas salvas", "success");
      setPosOpen(false);
    } catch (e) { showToast(String(e), "error"); }
    finally { setSavingPos(false); }
  }

  function resetarPosicoes() {
    setPosicoes(Array.from({ length: total }, (_, i) => defaultPositionFor(i)));
  }


  return (
    <div className="p-6 max-w-[1200px] mx-auto">
      <header className="mb-4 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <label className="text-xs uppercase tracking-wider text-muted">Renderização:</label>
          <select className="input !w-auto !py-1.5 !px-3" value={gpu} onChange={(e) => setGpu(e.target.value)}>
            <option value="GPU">GPU</option>
            <option value="CPU">CPU</option>
          </select>
        </div>

        <div className="px-4 py-1.5 rounded border border-success/40 bg-success/5 text-success text-sm font-medium tracking-wide">
          CALIBRADOR: {resolution} [GRADE]
        </div>

        <div className="flex items-center gap-3">
          <label className="text-xs uppercase tracking-wider text-success">PERFIL DE TELA:</label>
          <select className="input !w-auto !py-1.5 !px-3" value={perfil} onChange={(e) => setPerfil(e.target.value)}>
            <option>Perfil 1</option>
            <option>Perfil 2</option>
            <option>Perfil 3</option>
          </select>
        </div>
      </header>

      <div
        className={`card grid bg-black/40 ${reduzir ? "p-0 gap-0" : "p-3 gap-2"}`}
        style={{
          gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
          gridTemplateRows: `repeat(${rows}, minmax(110px, 1fr))`,
          minHeight: `${rows * 140}px`,
        }}
      >
        {cells.map((n) => (
          <div
            key={n}
            className="relative border border-success/30 bg-gradient-to-b from-zinc-900 to-black flex items-center justify-center bg-center bg-no-repeat"
            style={{ backgroundImage: `url(${spiderLogoBg})`, backgroundSize: "62%" }}
          >
            <span className="absolute top-1 left-1/2 -translate-x-1/2 text-[11px] text-success font-medium">{n}</span>
            <div className="w-14 h-14 rounded-full border-2 border-success/60 flex items-center justify-center text-success text-xs font-bold bg-black/50">
              #{n}
            </div>
            <span className="absolute bottom-1 left-1/2 -translate-x-1/2 text-[11px] text-success font-medium">{n}</span>
          </div>
        ))}
      </div>

      <footer className="mt-3 card p-3 flex items-center gap-3 flex-wrap text-sm">
        <label className="text-xs uppercase tracking-wider text-muted">MONITOR:</label>
        <select
          className="input !w-auto !py-1.5 !px-3 min-w-[260px]"
          value={monitorIdx}
          onChange={(e) => setMonitorIdx(parseInt(e.target.value, 10))}
        >
          {monitors.map((m) => (
            <option key={m.index} value={m.index}>{m.label}</option>
          ))}
        </select>
        <button
          onClick={detectMonitors}
          className="inline-flex items-center gap-1 px-2 py-1.5 rounded border border-border bg-panel2 text-white text-xs hover:bg-panel2/70"
          title="Detectar monitores novamente"
        >
          <RefreshCw className="w-3 h-3" /> Detectar
        </button>
        <span className="text-xs text-muted">({monitors.length} detectado{monitors.length === 1 ? "" : "s"})</span>

        <label className="flex items-center gap-2">
          <input type="checkbox" className="accent-success" checked={ativo} onChange={(e) => setAtivo(e.target.checked)} />
          <span className="text-success">Ativo</span>
        </label>

        <span className="text-xs uppercase tracking-wider text-success ml-2">GRADE:</span>
        <input
          type="number" min={1} max={8}
          className="input !w-16 !py-1.5 !px-2 text-center"
          value={rows}
          onChange={(e) => setRows(parseInt(e.target.value) || 1)}
        />
        <span className="text-muted">×</span>
        <input
          type="number" min={1} max={10}
          className="input !w-16 !py-1.5 !px-2 text-center"
          value={cols}
          onChange={(e) => setCols(parseInt(e.target.value) || 1)}
        />
        <span className="text-xs text-muted">= {total} telas</span>

        <label className="flex items-center gap-2 ml-auto">
          <input type="checkbox" className="accent-success" checked={reduzir} onChange={(e) => setReduzir(e.target.checked)} />
          <span className="text-white">Reduzir Janelas</span>
        </label>

        <button className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-success text-white font-semibold text-sm hover:bg-success/90" onClick={saveGrid}>
          <Save className="w-4 h-4" /> Salvar
        </button>
        <button className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-panel2 border border-border text-white font-semibold text-sm hover:bg-panel2/70" onClick={customPositions}>
          <Settings2 className="w-4 h-4" /> Posições Personalizadas
        </button>
      </footer>

      <p className="text-xs text-muted mt-3">
        Ao clicar no botão <span className="text-success font-medium">Play</span>, o app abrirá <b>{total}</b> janela(s) — uma para cada célula da grade — no <b>{current?.label || "monitor selecionado"}</b>.
      </p>

      <div className="hidden"><Monitor /></div>

      {/* ============ Modal Posições Personalizadas (preview interativo) ============ */}
      {posOpen && (
        <PreviewPosicoes
          posicoes={posicoes}
          setPosicoes={setPosicoes}
          monitorW={current?.width || 1920}
          monitorH={current?.height || 1080}
          monitorLabel={current?.label || "monitor"}
          onClose={() => setPosOpen(false)}
          onReset={resetarPosicoes}
          onSave={salvarPosicoes}
          saving={savingPos}
        />
      )}
    </div>
  );
}

// ===================== Preview interativo (drag + resize) =====================

type PosicaoJanelaProps = {
  posicoes: PosicaoJanela[];
  setPosicoes: React.Dispatch<React.SetStateAction<PosicaoJanela[]>>;
  monitorW: number;
  monitorH: number;
  monitorLabel: string;
  onClose: () => void;
  onReset: () => void;
  onSave: () => void;
  saving: boolean;
};

function PreviewPosicoes(props: PosicaoJanelaProps) {
  const { posicoes, setPosicoes, monitorW, monitorH, monitorLabel, onClose, onReset, onSave, saving } = props;
  const canvasRef = useRef<HTMLDivElement>(null);
  const [canvasW, setCanvasW] = useState(800);
  const [selected, setSelected] = useState<number | null>(0);

  useEffect(() => {
    function update() {
      if (canvasRef.current) setCanvasW(canvasRef.current.clientWidth);
    }
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const scale = canvasW / monitorW;
  const canvasH = Math.round(monitorH * scale);

  function clamp(p: PosicaoJanela): PosicaoJanela {
    const w = Math.max(80, Math.min(monitorW, p.w));
    const h = Math.max(80, Math.min(monitorH, p.h));
    const x = Math.max(0, Math.min(monitorW - w, p.x));
    const y = Math.max(0, Math.min(monitorH - h, p.y));
    return { x, y, w, h };
  }

  function startDrag(e: React.PointerEvent, i: number, mode: "move" | "resize") {
    e.preventDefault();
    e.stopPropagation();
    setSelected(i);
    const start = { x: e.clientX, y: e.clientY };
    const initial = { ...posicoes[i] };
    const onMove = (ev: PointerEvent) => {
      const dxPx = (ev.clientX - start.x) / scale;
      const dyPx = (ev.clientY - start.y) / scale;
      setPosicoes((arr) =>
        arr.map((p, idx) => {
          if (idx !== i) return p;
          if (mode === "move") {
            return clamp({ ...initial, x: initial.x + dxPx, y: initial.y + dyPx });
          }
          return clamp({ ...initial, w: initial.w + dxPx, h: initial.h + dyPx });
        })
      );
    };
    const onUp = () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
  }

  function updateField(i: number, k: keyof PosicaoJanela, v: string) {
    const n = Math.max(0, parseInt(v, 10) || 0);
    setPosicoes((arr) => arr.map((p, idx) => (idx === i ? clamp({ ...p, [k]: n }) : p)));
  }

  const sel = selected != null ? posicoes[selected] : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <div
        className="w-[1100px] max-w-[98vw] max-h-[95vh] bg-panel border border-border rounded-lg shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-3 py-2 bg-panel2 border-b border-border">
          <div className="flex items-center gap-2 text-white text-sm font-semibold">
            <Settings2 className="w-4 h-4 text-success" />
            Posições Personalizadas — {posicoes.length} janela(s) em {monitorLabel}
          </div>
          <button onClick={onClose} className="text-muted hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <p className="text-xs text-muted">
            Arraste cada janela para mover e use o canto inferior-direito para redimensionar.
            Monitor selecionado: <b>{monitorW}×{monitorH}px</b>.
          </p>

          {/* Canvas preview */}
          <div
            ref={canvasRef}
            className="relative bg-black/60 border border-success/30 rounded overflow-hidden mx-auto"
            style={{ width: "100%", height: canvasH }}
            onClick={() => setSelected(null)}
          >
            {posicoes.map((p, i) => {
              const isSel = selected === i;
              return (
                <div
                  key={i}
                  onPointerDown={(e) => startDrag(e, i, "move")}
                  className={`absolute flex items-center justify-center text-[11px] font-bold select-none cursor-move ${
                    isSel
                      ? "bg-success/30 border-2 border-success text-white z-10"
                      : "bg-zinc-800/80 border border-success/40 text-success hover:bg-zinc-700/80"
                  }`}
                  style={{
                    left: p.x * scale,
                    top: p.y * scale,
                    width: p.w * scale,
                    height: p.h * scale,
                  }}
                  title={`#${i + 1} — ${p.w}×${p.h}px em (${p.x}, ${p.y})`}
                >
                  #{i + 1}
                  {/* Resize handle */}
                  <div
                    onPointerDown={(e) => startDrag(e, i, "resize")}
                    className="absolute right-0 bottom-0 w-3 h-3 bg-success cursor-se-resize"
                    title="Redimensionar"
                  />
                </div>
              );
            })}
          </div>

          {/* Editor da janela selecionada */}
          {sel && selected != null && (
            <div className="card p-3 bg-panel2/40 border border-border">
              <div className="text-xs text-success font-semibold mb-2">
                Editando janela #{selected + 1}
              </div>
              <div className="grid grid-cols-4 gap-2">
                <div>
                  <label className="label">X</label>
                  <input type="number" className="input !py-1 !px-2 text-center" value={sel.x}
                    onChange={(e) => updateField(selected, "x", e.target.value)} />
                </div>
                <div>
                  <label className="label">Y</label>
                  <input type="number" className="input !py-1 !px-2 text-center" value={sel.y}
                    onChange={(e) => updateField(selected, "y", e.target.value)} />
                </div>
                <div>
                  <label className="label">Largura</label>
                  <input type="number" className="input !py-1 !px-2 text-center" value={sel.w}
                    onChange={(e) => updateField(selected, "w", e.target.value)} />
                </div>
                <div>
                  <label className="label">Altura</label>
                  <input type="number" className="input !py-1 !px-2 text-center" value={sel.h}
                    onChange={(e) => updateField(selected, "h", e.target.value)} />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2 p-3 border-t border-border bg-panel2/40">
          <button
            onClick={onReset}
            className="inline-flex items-center gap-2 px-3 py-2 rounded-md bg-panel2 border border-border text-white font-semibold text-xs hover:bg-panel2/70"
          >
            <RotateCcw className="w-3.5 h-3.5" /> Resetar pela grade
          </button>
          <div className="ml-auto flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-2 rounded-md bg-panel2 border border-border text-white text-xs hover:bg-panel2/70"
            >
              Cancelar
            </button>
            <button
              onClick={onSave}
              disabled={saving}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-success text-black font-bold text-xs hover:bg-success/90 disabled:opacity-50"
            >
              <Save className="w-3.5 h-3.5" /> {saving ? "Salvando..." : "Salvar Posições"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
