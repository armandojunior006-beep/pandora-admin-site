// ============================================================================
// Bloqueio de domínios (webRequest)
// ============================================================================
const state = require("../state.cjs");
const { getSettingSync, setSettingSync } = require("../settings/settingsStore.cjs");

const DEFAULT_BLOCKED_DOMAINS = [
  "global.esport001.com",
  "global.esport002.com",
  "esport001.com",
  "esport002.com",
  "googlesyndication.com",
  "google-analytics.com",
  "clarity.ms",
];

function loadBlockedDomainsFromSettings() {
  try {
    const raw = getSettingSync("op_blocked_domains", "");
    if (!raw) {
      state.blockedDomains = DEFAULT_BLOCKED_DOMAINS.slice();
      setSettingSync("op_blocked_domains", JSON.stringify(state.blockedDomains)).catch(() => {});
      return;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      state.blockedDomains = parsed.map((s) => String(s || "").trim().toLowerCase()).filter(Boolean);
      // Mescla defaults novos em listas já existentes
      const set = new Set(state.blockedDomains);
      let changed = false;
      for (const d of DEFAULT_BLOCKED_DOMAINS) {
        if (!set.has(d)) { state.blockedDomains.push(d); set.add(d); changed = true; }
      }
      if (changed) setSettingSync("op_blocked_domains", JSON.stringify(state.blockedDomains)).catch(() => {});
    }
  } catch {
    state.blockedDomains = DEFAULT_BLOCKED_DOMAINS.slice();
  }
}

function isBlockedUrl(url) {
  if (!state.blockedDomains.length) return false;
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    for (const d of state.blockedDomains) {
      if (!d) continue;
      if (host === d || host.endsWith("." + d) || host.includes(d)) return true;
    }
  } catch {}
  return false;
}

function applyBlockedDomainsToSession(ses) {
  if (!ses || state.sessionsWithBlock.has(ses)) return;
  try {
    ses.webRequest.onBeforeRequest({ urls: ["<all_urls>"] }, (details, cb) => {
      if (isBlockedUrl(details.url)) {
        return cb({ cancel: true });
      }
      cb({ cancel: false });
    });
    state.sessionsWithBlock.add(ses);
  } catch (e) {
    console.warn("[block] falha ao registrar webRequest:", e?.message || e);
  }
}

module.exports = {
  DEFAULT_BLOCKED_DOMAINS,
  loadBlockedDomainsFromSettings,
  isBlockedUrl,
  applyBlockedDomainsToSession,
};
