// ============================================================================
// IPC: workers:start/stop/count — janelas "worker" (apoio, sem Chromium extra).
// ============================================================================
const state = require("../state.cjs");
const { openWorkerWindows, closeWorkerWindows, openChromiumWindows } = require("../window/chromiumWindows.cjs");

function registerWorkerHandlers(ipcMain) {
  ipcMain.handle("workers:start", (_e, count, accounts) => openWorkerWindows(count, accounts));
  ipcMain.handle("workers:stop", () => { closeWorkerWindows(); return true; });
  ipcMain.handle("workers:count", () => state.workerWins.length);
  ipcMain.handle("chrome:open", async (_e, url, count, accounts, delaySec, headless) => await openChromiumWindows(url, count || 1, accounts || [], delaySec || 0, !!headless));
}

module.exports = { registerWorkerHandlers };
