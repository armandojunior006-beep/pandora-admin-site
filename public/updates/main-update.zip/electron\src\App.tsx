import { useEffect, useState } from "react";
import { useUI } from "@/stores/ui";
import { useAuth } from "@/stores/auth";
import { useCloudSession } from "@/stores/cloud-session";
import { validateToken } from "@/lib/cloud-api";
import { setSetting } from "@/lib/api";
import { Login } from "@/components/Login";
import { Sidebar } from "@/components/Sidebar";
import { Inicio } from "@/pages/Inicio";
import { ChavesPix } from "@/pages/ChavesPix";
import { Contas } from "@/pages/Contas";
import { Proxies } from "@/pages/Proxies";
import { Telas } from "@/pages/Telas";
import { Operacao } from "@/pages/Operacao";
import { MercadoPago } from "@/pages/MercadoPago";
import { Worker } from "@/pages/Worker";
import { MultiBot } from "@/pages/MultiBot";
import { TitleBar } from "@/components/TitleBar";
import { CompactBar } from "@/components/CompactBar";
import pandoraLogoBg from "@/assets/logo-bg.png";


export default function App() {
  const user = useAuth((s) => s.user);
  const { activeTab, toast } = useUI();
  const [compact, setCompact] = useState(false);

  async function toggleCompact() {
    const next = !compact;
    setCompact(next);
    try { await (window as any).api?.winSetCompact?.(next); } catch {}
  }

  // Handoff de sessão do Multi Bot (pedido do usuário 2026-08-09): um perfil
  // recém-aberto a partir da tela "Pandora Multi Bot" já teve login validado
  // ali — não deve pedir login/senha de novo. O launcher grava a sessão num
  // arquivo de uso único antes do spawn (ver multibot.cjs), e aqui a gente
  // consome (lê + aplica + apaga) assim que a janela sobe, antes de decidir
  // se mostra <Login/>. Se não houver handoff pendente (app aberto
  // normalmente, fora do Multi Bot), resolve imediatamente sem efeito.
  const [handoffChecked, setHandoffChecked] = useState(false);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const r = await (window as any).multibotAPI?.consumeSession?.();
        const session = r?.ok ? r.session : null;
        if (!cancelled && session?.token) {
          useCloudSession.getState().setSession(session);
          await useAuth.getState().login("admin", "admin07982176");
        }
      } catch {}
      if (!cancelled) setHandoffChecked(true);
    })();
    return () => { cancelled = true; };
  }, []);

  // Garante foco da janela principal sempre que o usuário clica em qualquer lugar
  // (evita o bug em que a janela perde o foco do teclado após operações com janelas Chromium)
  //
  // BUG real 2026-08-10 (reportado pelo usuário: caixa de texto "Vários
  // Links" — colar em massa — não aceitava digitar/colar nada, a ponto de
  // precisar reiniciar o app) — esse reforço de foco rodava em TODO
  // mousedown da tela inteira, incluindo cliques dentro de inputs/textarea.
  // (window as any).api.focusMain() chama win.show()+win.focus()+
  // webContents.focus() no processo Electron (appHandlers.cjs) — um
  // reforço criado pro cenário de clicar de volta no app DEPOIS de mexer em
  // janelas Chromium (perde foco do teclado nesse caso). Só que rodando
  // pra QUALQUER clique, inclusive o próprio clique que foca um campo de
  // texto, o webContents.focus() (que chega um instante depois, via IPC)
  // podia atropelar o foco que o navegador já tinha dado ao campo,
  // devolvendo o foco pro documento/janela em vez de deixar no campo —
  // digitar não "pegava". Agora pula esse reforço quando o clique for
  // dentro de um campo de texto de verdade (input/textarea/contenteditable)
  // — esses já ganham foco só com o clique normal, não precisam do reforço;
  // mantém o comportamento original pra outros elementos (botões, listas
  // etc.), que era o cenário do bug que isso resolvia.
  // BUG real 2026-08-10 (2ª rodada — reportado pelo usuário: campo de nome
  // de perfil no Multi Bot parava de aceitar digitar depois de abrir/fechar
  // um perfil — só voltava a funcionar reiniciando o app inteiro) — pular o
  // reforço pra QUALQUER clique em campo de texto (fix anterior) removeu
  // também o único mecanismo que recupera o foco de VERDADE da janela
  // depois de operações com outra janela (ex.: abrir um perfil do Multi
  // Bot spawna outro processo/janela; ao voltar pra essa janela, ela pode
  // ter perdido o foco real do sistema, não só o foco do React) — exatamente
  // o cenário que esse reforço foi criado pra resolver originalmente.
  // Agora só pula o reforço quando a janela JÁ tem foco (document.hasFocus())
  // — nesse caso o clique nativo já resolve sozinho, sem precisar de nada;
  // se a janela NÃO tem foco (voltando de outra janela), continua chamando
  // o reforço mesmo em campo de texto — recupera o foco real da janela
  // (o clique em si pode não "pegar" a tempo, mas o PRÓXIMO clique já
  // funciona, porque a essa altura a janela já está com foco de verdade).
  useEffect(() => {
    const isTextField = (el: EventTarget | null) => {
      const t = el as HTMLElement | null;
      if (!t) return false;
      const tag = t.tagName;
      return tag === "INPUT" || tag === "TEXTAREA" || t.isContentEditable;
    };
    const onDown = (e: MouseEvent) => {
      const textField = isTextField(e.target);
      if (document.hasFocus() && textField) return;
      // BUG real 2026-08-11 (reportado no campo "Nome" da nova conta
      // Mercado Pago — mesma classe do bug já corrigido antes no campo de
      // nome de perfil do Multi Bot): quando a janela ainda NÃO tem foco
      // (ex.: usuário clicando de volta depois de olhar a janela do Chrome
      // real do Mercado Pago) e o clique é num campo de texto,
      // webContents.focus() (foca o documento inteiro) chegava via IPC
      // assíncrono e vencia a corrida contra o foco natural que o próprio
      // clique já estava dando ao campo — resultado: campo nunca ficava
      // focado de verdade, não aceitava digitar nada. Nesse caso só traz a
      // janela pra frente (window.focus(), sem IPC, sem atropelar nada) e
      // deixa o clique focar o campo sozinho; o reforço completo
      // (focusMain) continua só pra cliques FORA de campo de texto.
      try { window.focus(); } catch {}
      if (textField) {
        // BUG real 2026-08-18 (reportado pelo usuário: campos "Delay" e
        // "Valores Para Depósito" — mesma classe de bug, mas o "torcer pro
        // clique focar sozinho" acima nem sempre ganha a corrida contra o
        // foco de janela do SO ainda assentando; quando perde, o campo
        // clicado fica com foco visual só no DOM, mas não no
        // webContents/SO — digitar não "pega" até um 2º clique). Reforça
        // com um refocus explícito NESSE MESMO elemento (não no documento
        // inteiro, não repete o bug original) depois que o window.focus()
        // acima já teve tempo de assentar.
        const alvo = e.target as HTMLElement;
        setTimeout(() => { try { alvo.focus(); } catch {} }, 60);
        return;
      }
      try { (window as any).api?.focusMain?.(); } catch {}
    };
    window.addEventListener("mousedown", onDown, true);
    return () => window.removeEventListener("mousedown", onDown, true);
  }, []);

  // Listener global de reset de speedhack: garante que a configuração persistida
  // volte a 1x mesmo quando a aba "Operação" não está montada, para que ao
  // reabrir a aba a UI já apareça em 1x sincronizada com o bot.
  useEffect(() => {
    const off = (window as any).api?.onChromiumSpeedReset?.(() => {
      try { setSetting("op_speed", "1"); } catch {}
    });
    return () => { try { off && off(); } catch {} };
  }, []);

  // Heartbeat server-side: revalida o token a cada 5 min. Se servidor disser
  // que o token não é mais válido (expirado, bloqueado, ou em uso em outro
  // HWID), encerra a sessão Cloud + a sessão local e devolve à tela de login.
  useEffect(() => {
    let cancelled = false;
    async function check() {
      try {
        const s = useCloudSession.getState().session;
        if (!s?.token) return;
        const r: any = await validateToken(s.token);
        if (cancelled) return;
        if (!r || r.valid === false) {
          try { useCloudSession.getState().clear(); } catch {}
          try { useAuth.getState().logout(); } catch {}
        }
      } catch {/* offline: não desloga */}
    }
    check();
    const id = setInterval(check, 5 * 60 * 1000);
    return () => { cancelled = true; clearInterval(id); };
  }, []);



  // Worker windows open at /#worker?... — render the Worker shell directly.
  if (typeof window !== "undefined" && window.location.hash.startsWith("#worker")) {
    return <Worker />;
  }

  // Aguarda a checagem de handoff de sessão (acima) antes de decidir mostrar
  // <Login/> — sem isso, um perfil do Multi Bot piscava a tela de login por
  // uma fração de segundo mesmo quando a sessão ia ser aplicada logo em seguida.
  if (!handoffChecked) return null;

  // Multi Bot launcher mode — exige login Cloud (mesmo fluxo) e mostra hub de perfis.
  const isMulti = typeof window !== "undefined" && window.location.hash.startsWith("#multi-bot");
  const canCompact = !!user && !isMulti;

  let content: React.ReactNode;
  if (isMulti) content = user ? <MultiBot /> : <Login />;
  else if (!user) content = <Login />;
  else if (compact) content = <CompactBar />;
  else content = (
    <div className="h-full flex app-bg overflow-hidden">
      <Sidebar />
      <main
        className="flex-1 min-w-0 h-full overflow-hidden app-bg-logo"
        style={{ ["--pandora-logo-bg" as any]: `url(${pandoraLogoBg})` }}
      >
        <div className="h-full overflow-hidden">
          {activeTab === "inicio" && <Inicio />}
          {activeTab === "chaves" && <ChavesPix />}
          {activeTab === "contas" && <Contas />}
          {activeTab === "proxies" && <Proxies />}
          {activeTab === "telas" && <Telas />}
          {activeTab === "operacao" && <Operacao />}
          {activeTab === "mercadopago" && <MercadoPago />}
        </div>
      </main>
    </div>
  );

  return (
    // h-full, não h-screen: com o zoom 0.82 do Login no body, 100vh vira
    // ~82% da janela e sobrava faixa preta embaixo; height:100% em cascata
    // (html→body→#root, ver styles.css) escala certo sob zoom.
    <div className="h-full flex flex-col app-bg overflow-hidden">
      <TitleBar
        compact={compact}
        onToggleCompact={toggleCompact}
        title={compact ? "Spiderzinho" : "Spider Bot"}
        showCompact={canCompact}
      />
      <div className="flex-1 min-h-0 overflow-hidden">{content}</div>
      {toast && (
        <div
          className={`fixed bottom-6 right-6 px-4 py-3 rounded-lg text-sm shadow-2xl border z-50 backdrop-blur ${
            toast.tone === "success"
              ? "bg-white text-black border-white"
              : toast.tone === "error"
              ? "bg-black text-white border-white/40"
              : "bg-panel2 border-border text-neutral-200"
          }`}
        >
          {toast.msg}
        </div>
      )}
    </div>
  );
}
