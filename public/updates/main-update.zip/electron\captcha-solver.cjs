// Resolve Geetest v4 — APENAS via CapSolver.
// Nenhum outro resolvedor (Python local, 2Captcha, AntiCaptcha, CapMonster,
// NoCaptchaAI etc.) é suportado: múltiplos provedores geravam divergência.
//
// Onde guardar a chave do CapSolver:
//   - Setting no banco: chave 'capsolver_api_key' (tabela settings)
//   - Ou variável de ambiente: CAPSOLVER_API_KEY

const https = require("https");

// ---------------- CapSolver ----------------

// Chave embutida (Pandora) — todos os clientes consomem desta conta.
// Não expor na UI. Fallback final caso não haja env nem setting.
const EMBEDDED_CAPSOLVER_KEY = "CAP-1BF847C2BDB0DAB81A20B6F79475C6471A993D92428ACE8922F4BEC54D99CCF8";

function getCapsolverKey() {
  try {
    if (process.env.CAPSOLVER_API_KEY && process.env.CAPSOLVER_API_KEY.trim()) {
      return process.env.CAPSOLVER_API_KEY.trim();
    }
    if (typeof global.__pandoraGetSetting === "function") {
      const v = String(global.__pandoraGetSetting("capsolver_api_key", "") || "").trim();
      if (v) return v;
    }
  } catch {}
  return EMBEDDED_CAPSOLVER_KEY;
}

function httpPostJson(url, body, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(url); } catch (e) { return reject(e); }
    const data = Buffer.from(JSON.stringify(body), "utf8");
    const req = https.request({
      method: "POST",
      hostname: u.hostname,
      port: u.port || 443,
      path: u.pathname + u.search,
      headers: {
        "Content-Type": "application/json",
        "Content-Length": data.length,
        "User-Agent": "PandoraBot/1.0",
      },
    }, (res) => {
      const chunks = [];
      res.on("data", (d) => chunks.push(d));
      res.on("end", () => {
        const text = Buffer.concat(chunks).toString("utf8");
        try { resolve(JSON.parse(text)); }
        catch { reject(new Error(`resposta inválida (${res.statusCode}): ${text.slice(0, 200)}`)); }
      });
    });
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => { try { req.destroy(new Error("timeout HTTP")); } catch {} });
    req.write(data);
    req.end();
  });
}

// CapSolver aceita estes captchaType para Geetest v4
const CAPSOLVER_RISK_TYPES = new Set(["slide", "icon", "gobang", "ai", "nine", "click", "word"]);

function normalizeRiskType(riskType, loadData) {
  let r = String(riskType || "").toLowerCase().trim();
  // Aliases comuns que o servidor pode devolver
  if (r === "iconcrush" || r === "icon_crush" || r === "icons") r = "icon";
  if (r === "ninetype" || r === "nine_type" || r === "9grid") r = "nine";
  if (r === "image" || r === "imgs" || r === "picture") {
    // É um captcha por imagem — detecta entre nine/icon a partir do payload
    if (loadData && Array.isArray(loadData.imgs) && loadData.imgs.length >= 9) r = "nine";
    else r = "icon";
  }
  if (r === "slide_v2") r = "slide";
  // Se ainda assim não for um tipo aceito, tenta inferir pelo loadData
  if (!CAPSOLVER_RISK_TYPES.has(r) && loadData) {
    if (loadData.imgs && loadData.ques) r = "icon";
    else if (loadData.slice && loadData.bg) r = "slide";
    else if (loadData.ques) r = "gobang";
  }
  return CAPSOLVER_RISK_TYPES.has(r) ? r : "";
}

async function pollCapsolverTask(apiKey, taskId, effectiveTimeout) {
  const deadline = Date.now() + effectiveTimeout;
  let lastStatus = "";
  let polls = 0;
  // Primeiro poll quase imediato; polling agressivo (120ms) para consumir
  // o resultado no instante em que o CapSolver marcar ready.
  await new Promise((r) => setTimeout(r, 20));
  while (Date.now() < deadline) {
    polls++;
    const res = await httpPostJson("https://api.capsolver.com/getTaskResult", { clientKey: apiKey, taskId });
    if (res.errorId) {
      const err = new Error(`capsolver getTaskResult: ${res.errorCode || ""} ${res.errorDescription || JSON.stringify(res)}`.trim());
      err.capsolverResponse = res;
      err.polls = polls;
      throw err;
    }
    lastStatus = res.status || lastStatus;
    if (res.status === "ready") {
      console.log(`[capsolver] ready em ${polls} polls — lot=${res.solution && res.solution.lot_number} pass=${String((res.solution && res.solution.pass_token) || '').slice(0,10)}…`);
      return { solution: res.solution || {}, polls };
    }
    if (polls % 25 === 0) console.log(`[capsolver] polling… status=${lastStatus} (${polls})`);
    await new Promise((r) => setTimeout(r, 80));
  }
  throw new Error(`capsolver timeout após ${polls} polls (último status: ${lastStatus || "n/a"})`);
}

function isCapsolverSolveFailed(err) {
  return /ERROR_CAPTCHA_SOLVE_FAILED|Failed to solve|SOLVE_FAILED|1001|1002|1504/i.test(String(err && err.message || err || ""));
}

async function solveViaCapsolver({ apiKey, captchaId, pageUrl, riskType, timeoutMs, loadData, baseUrl, useCapturedChallenge = true }) {
  if (!pageUrl) throw new Error("pageUrl ausente (necessário para CapSolver)");
  const lot = useCapturedChallenge && loadData && (loadData.lot_number || loadData.challenge);
  if (!lot) throw new Error("challenge v3 ausente: aguardando novo /load do GeeTest antes de chamar CapSolver");
  // CapSolver Geetest v4 — docs: https://docs.capsolver.com/guide/captcha/Geetestv4.html
  const normRisk = normalizeRiskType(riskType, loadData);
  const isImageRisk = normRisk === "icon" || normRisk === "nine" || normRisk === "ai" || normRisk === "gobang";
  const baseTask = {
    type: "GeeTestTaskProxyLess",
    websiteURL: pageUrl,
    captchaId: captchaId,
    version: 4,
  };
  try {
    if (baseUrl) {
      const h = new URL(baseUrl).hostname;
      if (h) baseTask.geetestApiServerSubdomain = h;
    }
  } catch {}
  // NÃO enviar captchaType para v4: o CapSolver tem melhor taxa de sucesso
  // detectando sozinho. Forçar 'nine'/'icon' estava causando ERROR_CAPTCHA_SOLVE_FAILED (1002).
  // (Mantemos normRisk apenas para log e para o retorno final.)
  const effectiveTimeout = isImageRisk ? Math.max(timeoutMs || 0, 180000) : (timeoutMs || 120000);

  // Primeiro tenta o modo V4 realmente automático: captchaId + URL, sem captchaType
  // e sem lot/challenge. Em alguns widgets o lot capturado vem preso ao browser/site
  // e derruba o CapSolver com 1002. Se o automático falhar, aí sim tentamos com o lot.
  // Múltiplas variantes para maximizar precisão: alternamos challenge/sub-dominio
  // para que um SOLVE_FAILED em uma combinação seja recuperado pela próxima.
  const variants = [
    { label: "auto", task: { ...baseTask } },
    { label: "auto+challenge", task: { ...baseTask, challenge: String(lot) } },
    { label: "auto+nosub", task: (() => { const t = { ...baseTask }; delete t.geetestApiServerSubdomain; return t; })() },
    { label: "auto+challenge+nosub", task: (() => { const t = { ...baseTask, challenge: String(lot) }; delete t.geetestApiServerSubdomain; return t; })() },
    { label: "retry-auto", task: { ...baseTask } },
    { label: "retry-auto+challenge", task: { ...baseTask, challenge: String(lot) } },
  ];
  let lastErr = null;
  for (let i = 0; i < variants.length; i++) {
    const { label, task } = variants[i];
    console.log(`[capsolver] createTask captchaId=${captchaId} mode=${label} risk=auto (detected=${normRisk||'?'}, raw=${riskType||'?'}) challenge=${task.challenge ? String(lot) : 'omitido'} sub=${task.geetestApiServerSubdomain||'-'} image=${isImageRisk}`);
    const create = await httpPostJson("https://api.capsolver.com/createTask", { clientKey: apiKey, task });
    if (create.errorId) {
      const err = new Error(`capsolver createTask: ${create.errorCode || ""} ${create.errorDescription || JSON.stringify(create)}`.trim());
      lastErr = err;
      if (i + 1 < variants.length && /invalid|unsupport|challenge|SOLVE_FAILED|1001|1002|1504/i.test(err.message)) {
        console.log(`[capsolver] retry ${variants[i + 1].label} após createTask (${err.message})`);
        await new Promise((r) => setTimeout(r, 120));
        continue;
      }
      throw err;
    }
    const taskId = create.taskId;
    if (!taskId) throw new Error(`capsolver: sem taskId. resposta=${JSON.stringify(create).slice(0,300)}`);

    try {
      const { solution: s } = await pollCapsolverTask(apiKey, taskId, effectiveTimeout);
      return {
        captcha_id: s.captcha_id || captchaId,
        lot_number: s.lot_number,
        pass_token: s.pass_token,
        gen_time: s.gen_time,
        captcha_output: s.captcha_output,
        // Mantém o tipo NORMALIZADO. Antes voltava o tipo bruto do site
        // (ex.: image/iconcrush/9grid), e o injetor visual só clicava quando
        // vinha exatamente "icon". Isso fazia alguns captchas de imagem serem
        // resolvidos no CapSolver, mas não aplicados no widget.
        risk_type: normRisk || riskType || "icon",
        captcha_type: normRisk || undefined,
        userresponse: s.userresponse || s.user_response || s.points || s.clicks || [],
      };
    } catch (err) {
      lastErr = err;
      if (i + 1 < variants.length && isCapsolverSolveFailed(err)) {
        console.warn(`[capsolver] ${label} falhou (${String(err.message || err).slice(0, 160)}) — tentando ${variants[i + 1].label}`);
        await new Promise((r) => setTimeout(r, 150));
        continue;
      }
      throw err;
    }
  }
  throw lastErr || new Error("capsolver: falha desconhecida");
}

// ---------------- API pública ----------------

// ---------------- SolveCaptcha / 2Captcha (mesmo protocolo in.php/res.php) ----------------

function getSolveCaptchaKey() {
  try {
    if (process.env.SOLVECAPTCHA_API_KEY && process.env.SOLVECAPTCHA_API_KEY.trim()) {
      return process.env.SOLVECAPTCHA_API_KEY.trim();
    }
    if (typeof global.__pandoraGetSetting === "function") {
      const v = String(global.__pandoraGetSetting("solvecaptcha_api_key", "") || "").trim();
      if (v) return v;
    }
  } catch {}
  return "";
}

function get2CaptchaKey() {
  try {
    if (process.env.TWOCAPTCHA_API_KEY && process.env.TWOCAPTCHA_API_KEY.trim()) {
      return process.env.TWOCAPTCHA_API_KEY.trim();
    }
    if (typeof global.__pandoraGetSetting === "function") {
      const v = String(global.__pandoraGetSetting("twocaptcha_api_key", "") || "").trim();
      if (v) return v;
    }
  } catch {}
  return "";
}

function httpGetText(url, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(url); } catch (e) { return reject(e); }
    const req = https.request({
      method: "GET",
      hostname: u.hostname,
      port: u.port || 443,
      path: u.pathname + u.search,
      headers: { "User-Agent": "PandoraBot/1.0" },
    }, (res) => {
      const chunks = [];
      res.on("data", (d) => chunks.push(d));
      res.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    });
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => { try { req.destroy(new Error("timeout HTTP")); } catch {} });
    req.end();
  });
}

// solvecaptcha.com / 2captcha.com — protocolo idêntico
async function solveViaInPhp({ provider, apiKey, captchaId, pageUrl, baseUrl, timeoutMs }) {
  if (!pageUrl) throw new Error(`${provider}: pageUrl ausente`);
  const host = provider === "2captcha" ? "2captcha.com" : "solvecaptcha.com";
  const params = new URLSearchParams({
    key: apiKey,
    method: "geetest_v4",
    captcha_id: captchaId,
    pageurl: pageUrl,
    json: "1",
  });
  try {
    if (baseUrl) {
      const h = new URL(baseUrl).hostname;
      if (h) params.set("api_server", h);
    }
  } catch {}
  console.log(`[${provider}] createTask captchaId=${captchaId}`);
  const inUrl = `https://${host}/in.php?${params.toString()}`;
  const inText = await httpGetText(inUrl, 25000);
  let inJson;
  try { inJson = JSON.parse(inText); }
  catch { throw new Error(`${provider} in.php resposta inválida: ${inText.slice(0, 200)}`); }
  if (Number(inJson.status) !== 1) {
    throw new Error(`${provider} in.php: ${inJson.request || JSON.stringify(inJson)}`);
  }
  const taskId = String(inJson.request);
  const deadline = Date.now() + (timeoutMs || 180000);
  // Política do provedor: aguardar ~15s antes do 1º poll, depois 5s entre polls.
  await new Promise((r) => setTimeout(r, 8000));
  let polls = 0;
  while (Date.now() < deadline) {
    polls++;
    const resUrl = `https://${host}/res.php?key=${encodeURIComponent(apiKey)}&action=get&id=${encodeURIComponent(taskId)}&json=1`;
    const resText = await httpGetText(resUrl, 20000);
    let resJson;
    try { resJson = JSON.parse(resText); }
    catch { throw new Error(`${provider} res.php resposta inválida: ${resText.slice(0, 200)}`); }
    if (Number(resJson.status) === 1) {
      // request pode vir como objeto ou JSON-string
      let sol = resJson.request;
      if (typeof sol === "string") {
        try { sol = JSON.parse(sol); } catch {}
      }
      if (!sol || typeof sol !== "object") {
        throw new Error(`${provider}: resposta sem solution: ${String(resJson.request).slice(0, 200)}`);
      }
      console.log(`[${provider}] ready em ${polls} polls — lot=${sol.lot_number} pass=${String(sol.pass_token||'').slice(0,10)}…`);
      return {
        captcha_id: sol.captcha_id || captchaId,
        lot_number: sol.lot_number,
        pass_token: sol.pass_token,
        gen_time: sol.gen_time,
        captcha_output: sol.captcha_output,
        risk_type: "icon",
        userresponse: [],
      };
    }
    const req = String(resJson.request || "");
    if (req === "CAPCHA_NOT_READY") {
      if (polls % 6 === 0) console.log(`[${provider}] polling… (${polls})`);
      await new Promise((r) => setTimeout(r, 5000));
      continue;
    }
    throw new Error(`${provider} res.php: ${req || JSON.stringify(resJson)}`);
  }
  throw new Error(`${provider} timeout após ${polls} polls`);
}

// ---------------- API pública ----------------

function isCapsolverRetryableFailure(err) {
  const msg = String(err && err.message || err || "");
  return /SOLVE_FAILED|timeout|1001|1002|1504|ERROR_|capsolver/i.test(msg);
}

/**
 * Tenta CapSolver → SolveCaptcha → 2Captcha. Pula qualquer provedor sem
 * chave configurada. Só lança erro se TODOS os provedores configurados
 * falharem (ou se nenhum estiver configurado).
 * @param {{captchaId:string, riskType?:string, baseUrl?:string, pageUrl?:string, timeoutMs?:number, loadData?:object}} opts
 */
async function solveGeetest(opts) {
  const capsolverKey = getCapsolverKey();
  const solveCaptchaKey = getSolveCaptchaKey();
  const twoCaptchaKey = get2CaptchaKey();

  if (!capsolverKey && !solveCaptchaKey && !twoCaptchaKey) {
    throw new Error(
      "Nenhuma API key de captcha configurada. Vá em Início → Funcionalidades → 'API Key CapSolver' " +
      "(ou SolveCaptcha / 2Captcha) e cole sua chave."
    );
  }

  const errors = [];

  if (capsolverKey) {
    try {
      console.log("[geetest] tentando CapSolver…");
      return await solveViaCapsolver({
        apiKey: capsolverKey,
        captchaId: opts.captchaId,
        pageUrl: opts.pageUrl,
        riskType: opts.riskType,
        timeoutMs: opts.timeoutMs || 120000,
        loadData: opts.loadData,
        baseUrl: opts.baseUrl,
      });
    } catch (err) {
      console.warn(`[geetest] CapSolver falhou: ${String(err && err.message || err).slice(0, 200)}`);
      errors.push(`CapSolver: ${err && err.message || err}`);
      if (!isCapsolverRetryableFailure(err) && !solveCaptchaKey && !twoCaptchaKey) throw err;
    }
  }

  if (solveCaptchaKey) {
    try {
      console.log("[geetest] tentando SolveCaptcha (fallback)…");
      return await solveViaInPhp({
        provider: "solvecaptcha",
        apiKey: solveCaptchaKey,
        captchaId: opts.captchaId,
        pageUrl: opts.pageUrl,
        baseUrl: opts.baseUrl,
        timeoutMs: Math.max(opts.timeoutMs || 0, 180000),
      });
    } catch (err) {
      console.warn(`[geetest] SolveCaptcha falhou: ${String(err && err.message || err).slice(0, 200)}`);
      errors.push(`SolveCaptcha: ${err && err.message || err}`);
    }
  }

  if (twoCaptchaKey) {
    try {
      console.log("[geetest] tentando 2Captcha (último fallback)…");
      return await solveViaInPhp({
        provider: "2captcha",
        apiKey: twoCaptchaKey,
        captchaId: opts.captchaId,
        pageUrl: opts.pageUrl,
        baseUrl: opts.baseUrl,
        timeoutMs: Math.max(opts.timeoutMs || 0, 180000),
      });
    } catch (err) {
      console.warn(`[geetest] 2Captcha falhou: ${String(err && err.message || err).slice(0, 200)}`);
      errors.push(`2Captcha: ${err && err.message || err}`);
    }
  }

  throw new Error(`Todos os solvers falharam — ${errors.join(" | ")}`);
}


module.exports = { solveGeetest };

