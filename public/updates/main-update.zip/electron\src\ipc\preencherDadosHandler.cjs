// ============================================================================
// IPC: chrome:preencherDados — botão "Preencher Dados" (aba Operação).
// Arquivo PRÓPRIO (regra do usuário 2026-08-09: cada botão/ação nova entra
// em arquivo dedicado — ver [[pandorabot-one-file-per-feature]]).
//
// Navega cada janela selecionada pra "<origin da própria janela>/home/setting"
// e preenche os campos do formulário com dados aleatórios (letras E números
// misturados nos campos livres). Pedido do usuário 2026-08-10.
//
// Data de nascimento: DELIBERADAMENTE não é tocada — é um seletor por
// clique (componente Vant van-picker) difícil de automatizar de forma
// confiável sem ver a página de verdade (chegou a ficar "Invalid Date", e
// depois uma tentativa de clicar em ancestrais pra abrir o seletor bugou a
// página, navegando pra outro lugar por engano). O usuário decidiu
// completar esse campo à mão — por isso também NÃO clica em Salvar no
// final (salvaria a página com a data ainda vazia).
// ============================================================================
const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");

const SETTING_PATH = "/home/setting";

const NOMES = ["Lucas", "Mariana", "Bruno", "Camila", "Pedro", "Ana", "Rafael", "Juliana", "Felipe", "Larissa", "Gustavo", "Beatriz", "Thiago", "Carolina", "Diego", "Patricia"];
const SOBRENOMES = ["Silva", "Souza", "Oliveira", "Santos", "Pereira", "Lima", "Costa", "Almeida", "Rodrigues", "Ferreira", "Gomes", "Martins", "Araujo", "Ribeiro"];

function buildPreencherDadosScript() {
  const nomesJson = JSON.stringify(NOMES);
  const sobrenomesJson = JSON.stringify(SOBRENOMES);
  return `(async () => {
    try {
      if (window.__pandoraPreencherDadosBusy) return { ok: false, reason: 'já rodando' };
      window.__pandoraPreencherDadosBusy = true;
      const NOMES = ${nomesJson};
      const SOBRENOMES = ${sobrenomesJson};
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const rnd = (arr) => arr[Math.floor(Math.random() * arr.length)];
      const rndInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
      const randDigits = (n) => { let s = ''; for (let i = 0; i < n; i++) s += rndInt(0, 9); return s; };
      const randAlnum = (n) => { const c = 'abcdefghijklmnopqrstuvwxyz0123456789'; let s = ''; for (let i = 0; i < n; i++) s += c[rndInt(0, c.length - 1)]; return s; };
      // Pedido do usuário 2026-08-10: TODO campo livre (texto) preenchido
      // precisa ter letra E número misturados, nunca só um dos dois — randAlnum
      // sozinho já mistura mas por sorte podia sair só letra ou só número
      // (chance pequena, mas existe); randMixed garante pelo menos 1 de cada.
      const randMixed = (n) => {
        let s = randAlnum(Math.max(2, n));
        if (!/[a-z]/.test(s)) s = 'x' + s.slice(1);
        if (!/[0-9]/.test(s)) s = s.slice(0, -1) + '7';
        return s;
      };
      const randNome = () => rnd(NOMES) + ' ' + rnd(SOBRENOMES) + rndInt(10, 99);
      const randEmail = () => randMixed(9) + '@gmail.com';
      const randPhoneBR = () => '11' + '9' + randDigits(8); // DDD 11 fixo + 9 + 8 dígitos

      const visible = (el) => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return false;
        const s = getComputedStyle(el);
        return s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.05;
      };
      // BUG real 2026-08-10 (reportado pelo usuário com print: seletor de
      // data — Vant Picker, mesmo componente do teclado numérico desse
      // site — não reagia ao clique) — el.click() sozinho só dispara o
      // evento 'click', SEM mousedown/mouseup/pointerdown/pointerup antes.
      // Componentes de picker/wheel costumam usar essa sequência completa
      // pra reconhecer "toque em item" (e diferenciar de um arrasto pra
      // rolar a roda) — sem ela, o clique sintético não registra nada.
      // Mesmo padrão de clique real já usado em bausHandler.cjs/
      // slotHandler.cjs.
      const realClick = (el) => {
        if (!el) return;
        try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
        const r = el.getBoundingClientRect();
        const x = r.left + Math.max(2, r.width / 2), y = r.top + Math.max(2, r.height / 2);
        const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0, view: window };
        try { el.dispatchEvent(new PointerEvent('pointerover', { ...opts, pointerType: 'mouse', buttons: 0, isPrimary: true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseover', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerType: 'mouse', buttons: 1, isPrimary: true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerType: 'mouse', buttons: 0, isPrimary: true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseup', opts)); } catch {}
        try { el.dispatchEvent(new MouseEvent('click', opts)); } catch {}
        try { el.click(); } catch {}
      };
      const setNative = (el, val) => {
        try {
          const proto = Object.getPrototypeOf(el);
          const desc = Object.getOwnPropertyDescriptor(proto, 'value') || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
          if (desc && desc.set) desc.set.call(el, val); else el.value = val;
        } catch { try { el.value = val; } catch (e) {} }
        try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: String(val) })); } catch { try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch (e) {} }
        try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
        try { el.blur(); } catch (e) {}
      };
      const describe = (el) => ((el.placeholder || '') + ' ' + (el.name || '') + ' ' + (el.id || '') + ' ' + (el.getAttribute('data-input-name') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();

      // Espera o formulário aparecer (pelo menos 1 input/select visível).
      const dl = Date.now() + 15000;
      let campos = [];
      while (Date.now() < dl) {
        campos = Array.from(document.querySelectorAll('input, select, textarea')).filter(visible);
        if (campos.length) break;
        await sleep(300);
      }
      if (!campos.length) { window.__pandoraPreencherDadosBusy = false; return { ok: false, reason: 'nenhum campo encontrado em /home/setting' }; }
      await sleep(500);
      campos = Array.from(document.querySelectorAll('input, select, textarea')).filter(visible);

      let preenchidos = 0;
      const usados = new Set(); // evita preencher o mesmo elemento 2x (ex.: parte de um grupo de data já tratado)

      // 1) Data de nascimento — trata primeiro e separado, porque pode ser
      // UM input (type=date OU texto com máscara dd/mm/aaaa) OU TRÊS selects
      // (dia/mês/ano) lado a lado.
      const findByText = (regex) => Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible)
        .find((b) => regex.test((b.innerText || b.textContent || '').trim()) && !b.disabled);

      const isBirthLike = (el) => /nascimento|birth|data de nasc/i.test(describe(el));
      const birthEls = campos.filter(isBirthLike);
      // BUG real 2026-08-10 (reportado pelo usuário: campo ficava "Invalid
      // Date"; depois, mesmo tentando abrir o seletor de várias formas,
      // "não clicou" — chegou a clicar em ancestral errado e bugar a
      // página) — o campo de nascimento é um SELETOR por clique (tipo
      // "roda"/coluna, componente Vant van-picker), difícil de automatizar
      // de forma confiável sem ver a página de verdade. Pedido do usuário:
      // "está bom, eu faço na mão a data de nascimento" — desiste de
      // automatizar esse campo específico, deixa ELE intocado (nem clica,
      // nem tenta setar valor nenhum) — só marca como "usado" pra não cair
      // no preenchimento genérico da seção 2 também.
      for (const el of birthEls) usados.add(el);

      // 2) Demais campos — por tipo/contexto (nome, email, telefone, CPF,
      // endereço) com fallback genérico pro que não reconhecer.
      for (const el of campos) {
        if (usados.has(el)) continue;
        usados.add(el);
        const tag = el.tagName;
        const type = (el.type || '').toLowerCase();
        if (type === 'hidden' || type === 'submit' || type === 'button' || el.disabled || el.readOnly) continue;
        const label = describe(el);
        if (tag === 'SELECT') {
          const opts = Array.from(el.options).filter((o) => o.value !== '' && !o.disabled);
          if (opts.length) { el.value = rnd(opts).value; el.dispatchEvent(new Event('change', { bubbles: true })); preenchidos++; }
          continue;
        }
        if (type === 'checkbox' || type === 'radio') continue; // não força marcação de opções binárias/grupo
        let valor;
        if (/nome|nickname|apelido|usu[aá]rio/i.test(label)) valor = randNome();
        else if (/e-?mail/i.test(label)) valor = randEmail();
        else if (/telefone|celular|phone|whats/i.test(label)) valor = randPhoneBR();
        else if (/\\bcpf\\b/i.test(label)) valor = randDigits(11);
        else if (/cep/i.test(label)) valor = randDigits(8);
        else if (/endere[çc]o|rua|logradouro/i.test(label)) valor = 'Rua ' + randMixed(6) + ', ' + rndInt(1, 999);
        else if (/bairro/i.test(label)) valor = 'Centro ' + rndInt(10, 99);
        else if (/cidade/i.test(label)) valor = 'São Paulo ' + rndInt(10, 99);
        else if (type === 'number') valor = String(rndInt(1, 999));
        else valor = randMixed(8);
        setNative(el, valor);
        preenchidos++;
      }

      // Pedido do usuário 2026-08-10 (3ª rodada): a data de nascimento
      // acabou preenchida certinho mesmo sem automação (o próprio usuário
      // completa/já vinha preenchida) — volta a clicar em "Salvar" no
      // final, mas só depois de esperar 1,5s pra ter certeza que tudo
      // (inclusive a data, que pode levar um instante extra pra assentar
      // no componente) já foi preenchido de verdade antes de salvar.
      await sleep(1500);
      const salvarBtn = findByText(/^salvar/i);
      const salvou = !!salvarBtn;
      if (salvarBtn) realClick(salvarBtn);

      window.__pandoraPreencherDadosBusy = false;
      return { ok: preenchidos > 0, preenchidos, totalCampos: campos.length, salvou };
    } catch (e) {
      try { window.__pandoraPreencherDadosBusy = false; } catch {}
      return { ok: false, reason: 'erro: ' + (e && e.message ? e.message : String(e)) };
    }
  })();`;
}

function registerPreencherDadosHandler(ipcMain) {
  ipcMain.handle("chrome:preencherDados", async () => {
    const diagLine = (msg) => {
      try {
        const { queueDiagLine } = require("../../auto-register.cjs");
        if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [chrome:preencherDados] ${msg}\r\n`);
      } catch {}
    };
    const runOne = async (win, telaNum) => {
      if (!win || win.isDestroyed() || win._proxyReady === false) return false;
      const wc = win.webContents;
      try {
        let origin = "";
        try {
          const o = new URL(wc.getURL()).origin;
          if (/^https?:\/\//i.test(o)) origin = o;
        } catch {}
        if (!origin) { diagLine(`tela #${telaNum} pulada — sem origin http(s) válido`); return false; }
        const dest = origin + SETTING_PATH;
        const ok = await wc.loadURL(dest).catch(() => false);
        if (ok === false) { diagLine(`tela #${telaNum} -> ${dest} : FALHOU ao navegar`); return false; }
        await new Promise((r) => setTimeout(r, 1000));
        const res = await wc.executeJavaScript(buildPreencherDadosScript(), true);
        if (res && res.ok) {
          diagLine(`tela #${telaNum} -> ${dest} : ${res.preenchidos}/${res.totalCampos} campo(s) preenchidos — Salvar ${res.salvou ? "clicado" : "NÃO encontrado"}`);
          return true;
        }
        diagLine(`tela #${telaNum} : FALHOU — ${(res && res.reason) || "sem detalhe"}`);
        return false;
      } catch (e) {
        diagLine(`tela #${telaNum} : erro inesperado: ${e?.message || e}`);
        return false;
      }
    };
    const wins = getSelectedChromeWins();
    const results = await Promise.all(wins.map((win, i) => runOne(win, i + 1)));
    return results.filter(Boolean).length;
  });
}

module.exports = { registerPreencherDadosHandler };
