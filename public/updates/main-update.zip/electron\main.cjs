// ============================================================================
// Pandora BOT — Electron main process (ponto de entrada)
// ----------------------------------------------------------------------------
// Este arquivo cuida apenas do BOOTSTRAP do processo principal: flags/estado
// que precisam rodar antes de tudo (multibot, integridade, stealth flags),
// o ciclo de vida do app (single instance, whenReady, shutdown) e a chamada
// inicial que liga IPC + janela principal. Toda a lógica de negócio vive
// nos módulos sob ./src — ver README/estrutura abaixo:
//
//   src/state.cjs                  estado mutável compartilhado (db, janelas...)
//   src/paths.cjs                  raiz do projeto (equivalente ao antigo __dirname)
//   src/settings/settingsStore.cjs SQLite settings + log do sistema
//   src/proxy/proxyManager.cjs     bridges HTTP locais (proxy-chain), IP, retry
//   src/proxy/domainBlocker.cjs    bloqueio de domínios (webRequest)
//   src/injections/*               scripts injetados nas janelas Chromium
//   src/window/windowManager.cjs   janela principal + utilitários de janela
//   src/window/chromiumWindows.cjs abrir/fechar janelas Chromium e workers
//   src/window/autoLogin.cjs       auto-login por conta + fechador de popups
//   src/window/mirrorMode.cjs      modo espelho (CDP)
//   src/security/securityPin.cjs   senha de saque/segurança (6+6 dígitos)
//   src/updater/updater.cjs        auto-update (renderer/main/full)
//   src/ipc/*                      handlers ipcMain.handle, um arquivo por grupo
// ============================================================================
const { app, BrowserWindow, dialog, globalShortcut, nativeTheme } = require("electron");
try { nativeTheme.themeSource = "dark"; } catch {}
const path = require("path");
const fs = require("fs");
const http = require("http");
const https = require("https");

// Tuning de performance do bridge HTTP local do proxy-chain.
// Sem isto, cada request abre um novo socket TCP para o upstream — o que
// torna toda a navegação visivelmente lenta quando a proxy está ativa.
// keepAlive + pool grande reaproveita conexões e remove o handshake TLS
// repetido em quase todas as requisições subsequentes.
try {
  http.globalAgent.keepAlive = true;
  http.globalAgent.keepAliveMsecs = 30000;
  http.globalAgent.maxSockets = Infinity;
  http.globalAgent.maxFreeSockets = 256;
  https.globalAgent.keepAlive = true;
  https.globalAgent.keepAliveMsecs = 30000;
  https.globalAgent.maxSockets = Infinity;
  https.globalAgent.maxFreeSockets = 256;
} catch {}

const { verifyIntegrityOrDie } = require("./security.cjs");
const multibot = require("./multibot.cjs");

// ============ MULTI BOT — detecção de modo (deve rodar ANTES de qualquer
// init de DB/sessão/lock para que cada perfil tenha seu userData próprio).
const __pandoraBaseUserData = app.getPath("userData");
const __pandoraProfileId = multibot.getProfileIdFromArgv();
const __pandoraIsMultiBotLauncher = multibot.isMultiBotMode() && !__pandoraProfileId;
try {
  if (__pandoraProfileId) {
    const profileDir = multibot.getProfileDir(__pandoraBaseUserData, __pandoraProfileId);
    if (!fs.existsSync(profileDir)) fs.mkdirSync(profileDir, { recursive: true });
    app.setPath("userData", profileDir);
    console.log(`[multibot] modo perfil id=${__pandoraProfileId} userData=${profileDir}`);
  } else if (__pandoraIsMultiBotLauncher) {
    const launcherDir = path.join(__pandoraBaseUserData, "multibot", "launcher");
    if (!fs.existsSync(launcherDir)) fs.mkdirSync(launcherDir, { recursive: true });
    app.setPath("userData", launcherDir);
    console.log(`[multibot] modo launcher userData=${launcherDir}`);
  }
} catch (e) { console.error("[multibot] erro ao configurar userData:", e); }
global.__pandoraBaseUserData = __pandoraBaseUserData;
global.__pandoraProfileId = __pandoraProfileId;
global.__pandoraIsMultiBotLauncher = __pandoraIsMultiBotLauncher;

// Nome do perfil (pra título da janela) — pedido do usuário 2026-08-09: um
// perfil novo abria com "Pandora Bot — Perfil d24a75" (id truncado) em vez
// do nome de verdade que foi dado a ele na criação. Busca no registro
// (multibot/profiles.json, já lido/escrito por multibot.cjs) pelo id atual.
if (__pandoraProfileId) {
  try {
    const profiles = multibot.listProfiles(__pandoraBaseUserData);
    const p = profiles.find((x) => x.id === __pandoraProfileId);
    global.__pandoraProfileName = p?.name || null;
  } catch (e) { console.warn("[multibot] falha ao resolver nome do perfil:", e?.message || e); }
}

// Verificação de integridade dos arquivos críticos. Em produção, qualquer
// edição nos .cjs do app faz o app se recusar a abrir e reportar a violação
// ao servidor.
try { verifyIntegrityOrDie(app, dialog); } catch (e) { console.error("[security] init falhou:", e); }

// Não derruba o app por exceção não tratada (ex.: falha de extensão ou sessão)
process.on("uncaughtException", (err) => {
  try { console.error("[uncaught]", err && err.stack || err); } catch {}
});
process.on("unhandledRejection", (reason) => {
  try { console.error("[unhandledRejection]", reason); } catch {}
});

// Stealth flags de linha de comando do Chromium — precisa rodar antes de
// app.whenReady(). O módulo aplica as flags como efeito colateral do require.
require("./src/injections/stealthFlags.cjs");

const state = require("./src/state.cjs");
const { initDB, setSettingSync } = require("./src/settings/settingsStore.cjs");
const { loadBlockedDomainsFromSettings } = require("./src/proxy/domainBlocker.cjs");
const { toggleProxyFromShortcut } = require("./src/proxy/proxyManager.cjs");
const { createMainWindow } = require("./src/window/windowManager.cjs");
const { closeChromiumWindows, closeWorkerWindows } = require("./src/window/chromiumWindows.cjs");
const { registerIpc } = require("./src/ipc/index.cjs");

// Garante apenas UMA instância do Pandora rodando. Se já houver uma janela
// aberta e o usuário tentar abrir de novo (duplo clique, atalho, etc.),
// só traz a janela existente pra frente em vez de criar uma segunda.
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (state.mainWin) {
      if (state.mainWin.isMinimized()) state.mainWin.restore();
      try { state.mainWin.show(); } catch {}
      try { state.mainWin.focus(); } catch {}
    }
  });

  app.whenReady().then(async () => {
    try { nativeTheme.themeSource = "dark"; } catch {}
    // Se foi reiniciado após atualização, mostra a splash IMEDIATAMENTE
    // e fecha quando a janela principal terminar de carregar (sem tempo fixo).
    let postUpdate = false;
    try {
      const flag = path.join(app.getPath("temp"), "pandora-post-update.flag");
      if (fs.existsSync(flag)) {
        postUpdate = true;
        try { fs.unlinkSync(flag); } catch {}
      }
    } catch {}
    const { showStartupSplash, closeStartupSplash } = require("./src/updater/updater.cjs");
    if (postUpdate) {
      try { showStartupSplash(); } catch {}
    }
    // Auto-permite armazenamento/persistência (IndexedDB/WebSQL/Notifications)
    // para evitar "sqlite_open returned null" do geeGuard/Geetest.
    try {
      const { session } = require("electron");
      session.defaultSession.setPermissionRequestHandler((_wc, _perm, cb) => { try { cb(true); } catch {} });
      session.defaultSession.setPermissionCheckHandler(() => true);
    } catch (e) { console.warn("[perm] falha ao registrar handler default:", e?.message || e); }
    await initDB();
    // Sempre abre com a proxy ATIVA — "op_bloquear_proxy" é só o estado do
    // botão/atalho F8 na aba Operação (liga/desliga proxy sem relançar o
    // Chrome); ficava salvo de uma sessão pra outra, então se o usuário
    // tinha desativado a proxy pra testar algo e esqueceu, o bot abria de
    // novo já com "Ativar Proxy" escrito (proxy desligada) sem ele perceber.
    // Reseta pro padrão seguro (proxy ativa) toda vez que o app abre.
    try { await setSettingSync("op_bloquear_proxy", "0"); } catch {}
    try { loadBlockedDomainsFromSettings(); } catch {}
    registerIpc();
    try { require("./src/window/accountBalance.cjs").startBalanceTracking(); } catch (e) { console.warn("[saldo-track] falha ao iniciar:", e?.message || e); }
    try {
      globalShortcut.register("F8", () => { toggleProxyFromShortcut().catch((e) => console.warn("[proxy] F8 falhou:", e?.message || e)); });
    } catch (e) { console.warn("[proxy] falha ao registrar F8:", e?.message || e); }
    createMainWindow();
    // Segurança: se did-finish-load nunca disparar, fecha em 60s
    if (postUpdate) {
      setTimeout(() => { try { closeStartupSplash(); } catch {} }, 60000);
    }
    app.on("activate", () => {
      if (BrowserWindow.getAllWindows().length === 0) createMainWindow();
    });
  });
}

app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });
app.on("will-quit", () => { try { globalShortcut.unregisterAll(); } catch {} });

// Fechamento limpo: garante que nenhuma janela controlada fique órfã ao sair do bot.
let _pandoraQuitCleanupDone = false;
app.on("before-quit", () => {
  if (_pandoraQuitCleanupDone) return;
  _pandoraQuitCleanupDone = true;
  const chromeCount = state.chromeWins.filter((w) => w && !w.isDestroyed()).length;
  const workerCount = state.workerWins.filter((w) => w && !w.isDestroyed()).length;
  try { closeChromiumWindows(); } catch {}
  try { closeWorkerWindows(); } catch {}
  try {
    for (const w of BrowserWindow.getAllWindows()) {
      if (w === state.mainWin) continue;
      try { if (!w.isDestroyed()) w.destroy(); } catch {}
    }
  } catch {}
  try { console.log(`[pandora] [shutdown] Fechando bot — ${chromeCount} janela(s) Chromium e ${workerCount} worker(s) encerradas.`); } catch {}
  // saveDB (SQLite) e o arquivo de diagnóstico (diag-auto-register.txt)
  // agora são ambos debounced/enfileirados (ver db.cjs e auto-register.cjs)
  // — garante que a última gravação pendente (logs dos últimos instantes)
  // não se perca ao fechar.
  try { require("./db.cjs").flushSaveDB(); } catch {}
  try { require("./auto-register.cjs").flushDiagQueueSync(); } catch {}
});
