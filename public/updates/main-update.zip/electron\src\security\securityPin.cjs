// ============================================================================
// Senha de saque / segurança (6+6 dígitos): geração/leitura do PIN, scripts
// de preenchimento (via DOM e via sendInputEvent nativo do Electron) e o
// watcher que detecta a confirmação e redireciona para a tela correta.
// ============================================================================
const { getSettingSync, setSettingSync } = require("../settings/settingsStore.cjs");
const { executeInAllFrames } = require("../injections/browserInjections.cjs");
const { getDiagFilePath, queueDiagLine } = require("../../auto-register.cjs");

function getWithdrawPin(win) {
  const raw = String(getSettingSync("senha_saque", "")).replace(/\D/g, "").slice(0, 6);
  if (raw.length === 6) {
    if (win && !win.isDestroyed?.()) win._withdrawPin = raw;
    try {
      const tag = "config:" + raw;
      if (!win || win.__pandoraLastPinDiag !== tag) {
        if (win) win.__pandoraLastPinDiag = tag;
        appendSecDiag("senha de saque carregada das configurações (6 dígitos)");
      }
    } catch {}
    return raw;
  }
  // Sem pin global configurado — usa/gera um pin aleatório de 6 dígitos por janela
  // para manter consistência entre todas as etapas (security fill, saque, salvar conta).
  if (win && !win.isDestroyed?.() && typeof win._withdrawPin === "string" && /^\d{6}$/.test(win._withdrawPin)) {
    return win._withdrawPin;
  }
  if (typeof global.__pandoraAutoWithdrawPin === "string" && /^\d{6}$/.test(global.__pandoraAutoWithdrawPin)) {
    if (win && !win.isDestroyed?.()) win._withdrawPin = global.__pandoraAutoWithdrawPin;
    return global.__pandoraAutoWithdrawPin;
  }
  let s = "";
  for (let i = 0; i < 6; i++) s += Math.floor(Math.random() * 10);
  if (win && !win.isDestroyed?.()) win._withdrawPin = s;
  global.__pandoraAutoWithdrawPin = s;
  try { setSettingSync("senha_saque", s).catch(() => {}); } catch {}
  try { appendSecDiag("senha de saque não configurada; gerada e salva automaticamente (6 dígitos)"); } catch {}
  return s;
}
global.__pandoraGetWithdrawPin = getWithdrawPin;

function buildSecurityPinScript(pin) {
  return `(() => {
    const PWD = ${JSON.stringify(String(pin).replace(/\D/g, "").slice(0, 6))};
    if (!PWD || PWD.length !== 6) return;
    if (window.__pandoraSecPinBusy) return; window.__pandoraSecPinBusy = true;
    const log = (m) => console.log('__PANDORA_SEC_FILL__', m);
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const visible = (el) => {
      if (!el || !el.isConnected) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
    };
    const realClick = (el) => {
      if (!el) return;
      try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
      const r = el.getBoundingClientRect();
      const x = r.left + Math.max(2, r.width / 2), y = r.top + Math.max(2, r.height / 2);
      try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles:true, cancelable:true, pointerType:'mouse', clientX:x, clientY:y, button:0, buttons:1 })); } catch {}
      try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0 })); } catch {}
      try { el.focus && el.focus({ preventScroll:true }); } catch {}
      try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles:true, cancelable:true, pointerType:'mouse', clientX:x, clientY:y, button:0, buttons:0 })); } catch {}
      try { el.dispatchEvent(new MouseEvent('mouseup', { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0 })); } catch {}
      try { el.dispatchEvent(new MouseEvent('click', { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0 })); } catch {}
      try { el.click(); } catch {}
    };
    const setInput = (el, val) => {
      if (!el) return false;
      try {
        const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
        try { el.focus({ preventScroll:true }); } catch {}
        setter.call(el, '');
        el.dispatchEvent(new InputEvent('input', { bubbles:true, composed:true, inputType:'deleteContentBackward' }));
        for (const ch of val) {
          const cur = String(el.value || '');
          const kc = 48 + Number(ch);
          el.dispatchEvent(new KeyboardEvent('keydown', { bubbles:true, cancelable:true, key:ch, code:'Digit'+ch, keyCode:kc, which:kc }));
          el.dispatchEvent(new InputEvent('beforeinput', { bubbles:true, cancelable:true, composed:true, inputType:'insertText', data:ch }));
          setter.call(el, cur + ch);
          el.dispatchEvent(new InputEvent('input', { bubbles:true, composed:true, inputType:'insertText', data:ch }));
          el.dispatchEvent(new KeyboardEvent('keyup', { bubbles:true, key:ch, code:'Digit'+ch, keyCode:kc, which:kc }));
        }
        el.dispatchEvent(new Event('change', { bubbles:true, composed:true }));
        return String(el.value || '').replace(/\D/g,'').endsWith(val);
      } catch { return false; }
    };
    const setAnyInput = (el, val) => {
      if (!el) return false;
      try {
        const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
        try { el.removeAttribute('readonly'); el.removeAttribute('disabled'); } catch {}
        try { el.focus({ preventScroll:true }); } catch {}
        if (setter) setter.call(el, val); else el.value = val;
        try { el.dispatchEvent(new InputEvent('input', { bubbles:true, composed:true, inputType:'insertReplacementText', data:val })); } catch { el.dispatchEvent(new Event('input', { bubbles:true, composed:true })); }
        el.dispatchEvent(new Event('change', { bubbles:true, composed:true }));
        try { el.blur && el.blur(); } catch {}
        return String(el.value || '').replace(/\D/g,'').includes(val);
      } catch { return false; }
    };
    const paintItems = (_items, _val) => { /* não pinta dots falsos: precisa refletir o estado real */ };
    const findKeyboardKey = (ch) => {
      const sel = '.ui-number-keyboard__key, .van-number-keyboard .van-key, .van-key, [class*="number-keyboard"] [class*="key"], [class*="keyboard"] button, [data-key]';
      const keys = Array.from(document.querySelectorAll(sel)).filter(visible);
      return keys.find(k => {
        const t = String((k.innerText || k.textContent || k.getAttribute('data-key') || k.getAttribute('aria-label') || '')).trim();
        return t === String(ch);
      });
    };
    const waitForKeyboard = async (timeout) => {
      const end = Date.now() + (timeout || 1500);
      while (Date.now() < end) {
        if (findKeyboardKey('1') || findKeyboardKey('0')) return true;
        await sleep(60);
      }
      return false;
    };
    const clickKeyboardDigit = async (ch) => {
      const k = findKeyboardKey(ch);
      if (!k) return false;
      try { k.dispatchEvent(new PointerEvent('pointerdown', { bubbles:true, cancelable:true })); } catch {}
      try { k.dispatchEvent(new MouseEvent('mousedown', { bubbles:true, cancelable:true, button:0 })); } catch {}
      try { k.dispatchEvent(new TouchEvent('touchstart', { bubbles:true, cancelable:true })); } catch {}
      try { k.dispatchEvent(new PointerEvent('pointerup', { bubbles:true, cancelable:true })); } catch {}
      try { k.dispatchEvent(new MouseEvent('mouseup', { bubbles:true, cancelable:true, button:0 })); } catch {}
      try { k.dispatchEvent(new TouchEvent('touchend', { bubbles:true, cancelable:true })); } catch {}
      try { k.dispatchEvent(new MouseEvent('click', { bubbles:true, cancelable:true, button:0 })); } catch {}
      try { k.click && k.click(); } catch {}
      await sleep(80);
      return true;
    };
    const fireDigit = async (ch) => {
      const kc = 48 + Number(ch);
      const target = document.activeElement || document.body;
      try { target.dispatchEvent(new KeyboardEvent('keydown', { bubbles:true, cancelable:true, key:ch, code:'Digit'+ch, keyCode:kc, which:kc })); } catch {}
      try { target.dispatchEvent(new KeyboardEvent('keypress', { bubbles:true, cancelable:true, key:ch, code:'Digit'+ch, keyCode:kc, which:kc, charCode:kc })); } catch {}
      try { document.execCommand && document.execCommand('insertText', false, ch); } catch {}
      try { target.dispatchEvent(new InputEvent('input', { bubbles:true, composed:true, inputType:'insertText', data:ch })); } catch {}
      try { target.dispatchEvent(new KeyboardEvent('keyup', { bubbles:true, key:ch, code:'Digit'+ch, keyCode:kc, which:kc })); } catch {}
      const keys = Array.from(document.querySelectorAll('button, [role="button"], .van-key, .ui-number-keyboard__key, [class*="keyboard"] [class*="key"], [data-key]')).filter(visible);
      const key = keys.find(k => ((k.innerText || k.textContent || k.getAttribute('data-key') || k.getAttribute('aria-label') || '') + '').trim() === ch);
      if (key) realClick(key);
      await sleep(80);
    };
    const groups = () => {
      const lis = Array.from(document.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).filter(visible);
      const parents = [];
      for (const li of lis) {
        const p = li.parentElement;
        if (p && !parents.includes(p) && Array.from(p.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).length >= 6) parents.push(p);
      }
      if (parents.length >= 2) return parents.slice(0, 2).map(p => Array.from(p.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).filter(visible).slice(0, 6));
      if (lis.length >= 12) return [lis.slice(0, 6), lis.slice(6, 12)];
      if (lis.length >= 6) return [lis.slice(0, 6)];
      const boxes = Array.from(document.querySelectorAll('[class*="password"] input, [class*="Password"] input, input[type="password"], input[inputmode="numeric"], input[pattern*="0-9"], input[maxlength="6"], input[maxlength="12"]')).filter(el => el && el.isConnected);
      const usable = boxes.filter(el => {
        const t = ((el.type||'') + ' ' + (el.name||'') + ' ' + (el.id||'') + ' ' + (el.placeholder||'') + ' ' + (el.className||'')).toLowerCase();
        return !/(search|busca|amount|valor|phone|telefone|cpf|user|login|email)/i.test(t);
      });
      if (usable.length >= 2) return usable.slice(0, 2).map(x => [x]);
      if (usable.length === 1) return [[usable[0]]];
      return [];
    };
    const fillGroup = async (items, idx) => {
      if (!items || !items.length) return false;
      // Caso de input nativo único
      if (items.length === 1 && /^(INPUT|TEXTAREA)$/i.test(items[0].tagName || '')) {
        const v = items[0].getAttribute('maxlength') === '12' ? PWD + PWD : PWD;
        return setInput(items[0], v) || setAnyInput(items[0], v);
      }
      // 1) clica no primeiro LI para abrir o teclado numérico do site
      realClick(items[0]);
      await sleep(160);
      const hasKbd = await waitForKeyboard(2000);
      log('grupo ' + idx + ' teclado=' + hasKbd);
      if (hasKbd) {
        let typed = 0;
        for (const ch of PWD) {
          const ok = await clickKeyboardDigit(ch);
          if (ok) typed++;
          else break;
        }
        log('grupo ' + idx + ' dígitos clicados=' + typed);
        if (typed >= PWD.length) return true;
      }
      // 2) Fallback: tenta achar o input escondido e setar valor
      const root = items[0].closest('.ui-password-input, .van-password-input, [class*="password-input"]') || items[0].parentElement?.parentElement || items[0].parentElement;
      const inputs = root ? Array.from(root.querySelectorAll('input, textarea')) : [];
      const input = inputs[idx] || inputs[0];
      if (input) {
        if (setInput(input, PWD) || setAnyInput(input, PWD)) return true;
      }
      // 3) Último recurso: eventos de teclado no activeElement
      for (const ch of PWD) await fireDigit(ch);
      return false;
    };
    (async () => {
      // TUDO dentro de try/finally: sem isso, qualquer exceção não prevista
      // no meio do preenchimento (DOM mudou de estrutura, elemento ficou
      // stale, etc.) deixava __pandoraSecPinBusy travado em true PRA SEMPRE
      // — e como o topo do script (linha 47) recusa rodar de novo enquanto
      // essa flag estiver true, NENHUMA das tentativas seguintes agendadas
      // (kickoff chama run() várias vezes, em 200ms/1500ms/9000ms/...)
      // conseguia fazer nada, deixando a janela travada ali em silêncio —
      // exatamente o "algumas telas não vão" relatado. Agora, não importa
      // o que dê errado no meio, a flag sempre libera no final.
      try {
      const deadline = Date.now() + 35000;
      let gs = [];
      while (Date.now() < deadline) {
        gs = groups();
        if (gs.length >= 1) break;
        await sleep(60);
      }
      if (!gs.length) { log('campos não encontrados'); return; }
      log('preenchendo senha de saque ' + PWD + ' em ' + gs.length + ' grupo(s)');
      await fillGroup(gs[0], 0);
      await sleep(260);
      if (gs[1]) {
        await fillGroup(gs[1], 1);
        await sleep(140);
        // Repasse de segurança no segundo grupo (evita dígito faltando)
        await fillGroup(gs[1], 1);
      }
      await sleep(200);

      // Tenta fechar o teclado numérico (pode estar sobrepondo o Confirmar)
      const closeKeyboard = () => {
        try {
          const cands = Array.from(document.querySelectorAll('.ui-number-keyboard__close, .van-number-keyboard__close, [class*="keyboard"] [class*="close"], [class*="keyboard"] [class*="confirm"]')).filter(visible);
          const d = cands.find(x => /(conclu[íi]r|fechar|ok|confirmar)/i.test((x.innerText||x.textContent||'').trim())) || cands[0];
          if (d) { realClick(d); return true; }
        } catch {}
        return false;
      };

      const findConfirm = () => {
        const txtOf = (b) => {
          const sp = b.querySelector && b.querySelector('.ui-button__text');
          return ((sp && (sp.innerText || sp.textContent)) || b.innerText || b.textContent || '').trim();
        };
        const isDisabled = (b) => b.disabled || b.getAttribute('disabled') !== null
          || /(disabled|is-disabled|ui-button--disabled)/i.test(b.className || '')
          || b.getAttribute('aria-disabled') === 'true';
        const themed = Array.from(document.querySelectorAll('button.ui-button[data-theme-btn], button[data-theme-btn]')).filter(visible);
        let cand = themed.find(b => /^confirmar$/i.test(txtOf(b)) && !isDisabled(b));
        if (cand) return cand;
        cand = themed.find(b => /(confirmar|salvar|cadastrar|definir|enviar|continuar|pr[óo]ximo)/i.test(txtOf(b)) && !isDisabled(b));
        if (cand) return cand;
        const all = Array.from(document.querySelectorAll('button.ui-button, button, [role="button"]')).filter(visible);
        cand = all.find(b => /^confirmar$/i.test(txtOf(b)) && !isDisabled(b));
        if (cand) return cand;
        cand = all.find(b => /(confirmar|salvar|cadastrar|definir|enviar|continuar|pr[óo]ximo)/i.test(txtOf(b)) && !isDisabled(b));
        if (cand) return cand;
        return themed.find(b => /^confirmar$/i.test(txtOf(b))) || all.find(b => /^confirmar$/i.test(txtOf(b)));
      };

      const pointerClick = (el) => {
        try { el.scrollIntoView({ block:'center', inline:'center' }); } catch {}
        const r = el.getBoundingClientRect();
        const x = r.left + r.width/2, y = r.top + r.height/2;
        const opts = { bubbles:true, cancelable:true, composed:true, clientX:x, clientY:y, button:0, pointerType:'mouse' };
        try { el.dispatchEvent(new PointerEvent('pointerover', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerenter', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', opts)); } catch {}
        try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerup', opts)); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseup', opts)); } catch {}
        try { el.dispatchEvent(new MouseEvent('click', opts)); } catch {}
        try { el.click && el.click(); } catch {}
      };

      closeKeyboard();
      await sleep(180);

      const clickEnd = Date.now() + 20000;
      let clicked = false;
      while (Date.now() < clickEnd) {
        const btn = findConfirm();
        if (btn) {
          pointerClick(btn);
          clicked = true;
          log('clicou confirmar senha de saque');
          await sleep(350);
          if (!btn.isConnected || !visible(btn)) break;
        } else {
          closeKeyboard();
        }
        await sleep(120);
      }
      if (!clicked) log('botão confirmar não encontrado');
      if (clicked) { try { window.__pandoraSecPinConfirmed = true; } catch {} log('senha de saque confirmada com sucesso'); }
      } catch (e) {
        try { log('exceção durante preenchimento: ' + (e && e.message ? e.message : String(e))); } catch {}
      } finally {
        window.__pandoraSecPinBusy = false;
      }
    })();

  })();`;
}


function sendSecurityPinNative(wc, pin) {
  try {
    for (const ch of String(pin)) {
      wc.sendInputEvent({ type: "keyDown", keyCode: ch });
      wc.sendInputEvent({ type: "char", keyCode: ch });
      wc.sendInputEvent({ type: "keyUp", keyCode: ch });
    }
  } catch {}
}

async function nativeFillSecurityPin(win, pin) {
  if (!win || win.isDestroyed()) return;
  if (win.__pandoraNativeSecPinRunning) return;
  win.__pandoraNativeSecPinRunning = true;
  const wc = win.webContents;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const nativeClick = (x, y) => {
    try {
      wc.sendInputEvent({ type: "mouseMove", x, y });
      wc.sendInputEvent({ type: "mouseDown", x, y, button: "left", clickCount: 1 });
      wc.sendInputEvent({ type: "mouseUp", x, y, button: "left", clickCount: 1 });
    } catch {}
  };
  const pressDigit = async (ch) => {
    try {
      const rect = await wc.executeJavaScript(`(() => {
        const ch = ${JSON.stringify(String(ch))};
        const visible = (el) => {
          if (!el || !el.isConnected) return false;
          const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
          return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
        };
        const keys = Array.from(document.querySelectorAll('button, [role="button"], .van-key, .ui-number-keyboard__key, [class*="keyboard"] [class*="key"], [class*="Keyboard"] [class*="key"], [data-key]')).filter(visible);
        const el = keys.find(k => String((k.innerText || k.textContent || k.getAttribute('data-key') || k.getAttribute('aria-label') || '')).trim() === ch);
        if (!el) return null;
        const r = el.getBoundingClientRect();
        return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
      })()`, true).catch(() => null);
      if (rect && Number.isFinite(rect.x) && Number.isFinite(rect.y)) {
        nativeClick(rect.x, rect.y);
        await sleep(80);
        return;
      }
    } catch {}
    try {
      wc.sendInputEvent({ type: "keyDown", keyCode: String(ch) });
      wc.sendInputEvent({ type: "char", keyCode: String(ch) });
      wc.sendInputEvent({ type: "keyUp", keyCode: String(ch) });
    } catch {}
    await sleep(80);
  };
  try {
    appendSecDiag("preenchimento nativo iniciado para senha 6+6");
    const deadline = Date.now() + 90000;
    while (Date.now() < deadline) {
      if (!win || win.isDestroyed()) return;
      let cur = "";
      try { cur = wc.getURL(); } catch {}
      if (!/\/home\/security\b/i.test(cur) && !/[?&]active=5\b/i.test(cur)) {
        await sleep(250);
        continue;
      }
      const info = await wc.executeJavaScript(`(() => {
        const visible = (el) => {
          if (!el || !el.isConnected) return false;
          const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
          return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
        };
        const center = (el) => { const r = el.getBoundingClientRect(); return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) }; };
        const rawItems = Array.from(document.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).filter(visible);
        const groups = [];
        const seen = new Set();
        for (const item of rawItems) {
          const p = item.parentElement;
          if (!p || seen.has(p)) continue;
          const kids = Array.from(p.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).filter(visible);
          if (kids.length >= 6) { seen.add(p); groups.push(center(kids[0])); }
        }
        if (groups.length < 2 && rawItems.length >= 12) {
          groups.length = 0; groups.push(center(rawItems[0]), center(rawItems[6]));
        }
        const inputs = Array.from(document.querySelectorAll('input[type="password"], input[inputmode="numeric"], input[maxlength="6"], input[maxlength="12"], [class*="password"] input, [class*="Password"] input')).filter(visible).filter(el => {
          const t = String((el.type||'') + ' ' + (el.id||'') + ' ' + (el.name||'') + ' ' + (el.placeholder||'') + ' ' + (el.className||'')).toLowerCase();
          return !/(search|busca|phone|telefone|cpf|amount|valor|user|login|email)/.test(t);
        }).map(center);
        if (groups.length < 2 && inputs.length) groups.push(...inputs.slice(0, 2));
        const btns = Array.from(document.querySelectorAll('button.ui-button, button[data-theme-btn], button, [role="button"], a')).filter(visible);
        const confirm = btns.map(b => ({ el:b, txt:String((b.querySelector('.ui-button__text, span')?.textContent || b.innerText || b.textContent || '')).trim() }))
          .find(o => /(confirmar|salvar|continuar|pr[óo]ximo|ok|enviar|definir|cadastrar)/i.test(o.txt));
        return { url: location.href, groups, inputCount: inputs.length, itemCount: rawItems.length, confirm: confirm ? center(confirm.el) : null };
      })()`, true).catch(() => null);
      if (!info || !Array.isArray(info.groups) || !info.groups.length) {
        await sleep(180);
        continue;
      }
      appendSecDiag("alvos nativos encontrados grupos=" + info.groups.length + " itens=" + (info.itemCount || 0) + " inputs=" + (info.inputCount || 0));
      const first = info.groups[0];
      nativeClick(first.x, first.y);
      await sleep(160);
      for (const ch of pin) await pressDigit(ch);
      await sleep(280);
      const second = info.groups[1] || info.groups[0];
      nativeClick(second.x, second.y);
      await sleep(160);
      for (const ch of pin) await pressDigit(ch);
      await sleep(500);
      // Tenta clicar Confirmar repetidamente até o site aceitar (URL sair de /home/security)
      const clickDeadline = Date.now() + 20000;
      let anyClick = false;
      while (Date.now() < clickDeadline) {
        if (!win || win.isDestroyed()) return;
        let curUrl = "";
        try { curUrl = wc.getURL(); } catch {}
        if (!/\/home\/security\b/i.test(curUrl)) {
          appendSecDiag("URL saiu de /home/security após clique nativo — confirmação aceita pelo site. url=" + curUrl);
          win.__pandoraSecConfirmedNode = true;
          return;
        }
        const fresh = await wc.executeJavaScript(`(() => {
          const visible = (el) => { if (!el || !el.isConnected) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01; };
          const txtOf = (b) => { const sp = b.querySelector && b.querySelector('.ui-button__text'); return ((sp && (sp.innerText || sp.textContent)) || b.innerText || b.textContent || '').trim(); };
          const isDisabled = (b) => b.disabled || b.getAttribute('disabled') !== null || /(disabled|is-disabled|ui-button--disabled)/i.test(b.className || '') || b.getAttribute('aria-disabled') === 'true';
          const themed = Array.from(document.querySelectorAll('button.ui-button[data-theme-btn], button[data-theme-btn]')).filter(visible);
          let cand = themed.find(b => /^confirmar$/i.test(txtOf(b)) && !isDisabled(b))
                  || themed.find(b => /(confirmar|salvar|cadastrar|definir|enviar|continuar|pr[óo]ximo)/i.test(txtOf(b)) && !isDisabled(b));
          if (!cand) {
            const all = Array.from(document.querySelectorAll('button.ui-button, button, [role="button"], a')).filter(visible);
            cand = all.find(b => /^confirmar$/i.test(txtOf(b)) && !isDisabled(b))
                || all.find(b => /(confirmar|salvar|cadastrar|definir|enviar|continuar|pr[óo]ximo)/i.test(txtOf(b)) && !isDisabled(b));
          }
          if (!cand) return null;
          try { cand.scrollIntoView({ block:'center', inline:'center' }); } catch {}
          const r = cand.getBoundingClientRect();
          return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2), txt: txtOf(cand) };
        })()`, true).catch(() => null);
        if (fresh && Number.isFinite(fresh.x) && Number.isFinite(fresh.y)) {
          nativeClick(fresh.x, fresh.y);
          if (!anyClick) { appendSecDiag("clique nativo no confirmar da senha de saque (txt=" + (fresh.txt || "") + ")"); anyClick = true; }
        }
        await sleep(500);
      }
      if (!anyClick) {
        appendSecDiag("confirmar nativo não encontrado após preencher 6+6");
      } else {
        appendSecDiag("timeout: cliquei confirmar mas URL não saiu de /home/security — site rejeitou o PIN");
      }
      return;
    }
    appendSecDiag("preenchimento nativo timeout sem encontrar os 12 campos");
  } catch (e) {
    appendSecDiag("erro no preenchimento nativo: " + (e?.message || e));
  } finally {
    try { win.__pandoraNativeSecPinRunning = false; } catch {}
  }
}

function appendSecDiag(msg) {
  try {
    getDiagFilePath(); // garante rotação/inicialização do caminho
    const line = `[${new Date().toISOString()}] [SEC-PIN] ${msg}\r\n`;
    queueDiagLine(line); // assíncrono/enfileirado — ver comentário em auto-register.cjs
  } catch {}
}

function scheduleSecurityPinFill(win, pin, flow) {
  flow = flow || "saque";
  if (!win || win.isDestroyed()) return;
  const wc = win.webContents;
  pin = String(pin || getWithdrawPin(win)).replace(/\D/g, "").slice(0, 6);
  if (!/^\d{6}$/.test(pin)) {
    appendSecDiag("senha de saque inválida/ausente antes do preenchimento; abortado");
    return;
  }
  win.__pandoraSecClickedAt = 0;
  // Captura logs do script injetado e grava no diag
  if (!win.__pandoraSecDiagAttached) {
    win.__pandoraSecDiagAttached = true;
    try {
      wc.on("console-message", (_e, _level, message) => {
        if (typeof message === "string" && message.includes("__PANDORA_SEC_FILL__")) {
          const clean = message.replace("__PANDORA_SEC_FILL__", "").trim();
          appendSecDiag(clean);
          if (/clicou confirmar senha de saque/i.test(clean)) {
            // Marca o instante do clique real no botão Confirmar. Usado pelo
            // watcher como uma rede de segurança: se o site aceitar o PIN mas
            // não trocar a URL sozinho (SPA que só mostra um toast/checkmark
            // e não navega), o watcher esperava para sempre a URL sair de
            // /home/security — e como as tentativas seguintes agendadas do
            // run() já não acham mais os campos (preenchidos/mascarados),
            // a janela ficava parada bem no momento de ir pra próxima URL.
            win.__pandoraSecClickedAt = Date.now();
          }
        }
      });
    } catch {}
  }
  const run = () => {
    try { executeInAllFrames(wc, buildSecurityPinScript(pin)); } catch {
      try { wc.executeJavaScript(buildSecurityPinScript(pin), true).catch(() => {}); } catch {}
    }
    // sendSecurityPinNative/nativeFillSecurityPin eram reforços "de graça" no
    // Electron antigo — sendInputEvent(keyDown/char/keyUp) sempre foi um
    // no-op silencioso em Chrome real (o shim não suportava teclado até essa
    // sessão), então nunca digitavam nada ali, e o preenchimento inteiro
    // dependia só do buildSecurityPinScript acima (que já é completo e
    // sozinho dava conta — clica no teclado numérico do próprio site).
    // Agora que o teclado funciona de verdade em Chrome real, esses reforços
    // passaram a digitar os 6 dígitos de NOVO por cima do que o script acima
    // já tinha digitado (às vezes duas vezes, 600ms E 1500ms depois) — uma
    // corrida que sobrescrevia/estourava o campo e explicava só ALGUMAS
    // janelas pegarem certo (dependia de qual reforço vencia a corrida).
    // Restrito ao caminho Electron antigo, onde já era o comportamento
    // testado/aceito.
    if (!win._realChrome) {
      setTimeout(() => sendSecurityPinNative(wc, pin), 600);
      setTimeout(() => sendSecurityPinNative(wc, pin), 1500);
      setTimeout(() => nativeFillSecurityPin(win, pin), 900);
    }
  };
  // Watcher: assim que a senha for confirmada, força uma atualização limpa em /home/withdraw?active=10
  const startWatcher = () => {
    if (win.__pandoraSecWatcher) return;
    win.__pandoraSecWatcher = true;
    win.__pandoraSecConfirmedNode = false;
    appendSecDiag("watcher iniciado, aguardando confirmação da senha de 12 dígitos");
    const t0 = Date.now();
    const iv = setInterval(async () => {
      if (!win || win.isDestroyed()) { clearInterval(iv); return; }
      if (Date.now() - t0 > 120000) {
        appendSecDiag("watcher timeout (120s) sem confirmação — desistindo");
        clearInterval(iv);
        win.__pandoraSecWatcher = false;
        return;
      }
      let confirmed = !!win.__pandoraSecConfirmedNode;
      if (!confirmed) {
        try {
          confirmed = await wc.executeJavaScript("!!window.__pandoraSecPinConfirmed", true);
        } catch {}
      }
      if (!confirmed) return;
      // Normalmente só aceita confirmação se a URL realmente saiu de
      // /home/security. Mas algumas janelas ficam paradas justamente aqui:
      // o site aceita o clique em Confirmar (o toast/checkmark aparece) mas
      // não navega sozinho — e como os campos já foram preenchidos, as
      // tentativas seguintes de run() só acham "campos não encontrados" e
      // não clicam de novo. Sem um limite, o watcher esperava a URL mudar
      // por até 120s e desistia em silêncio, travando a janela ali mesmo.
      // Rede de segurança: se já clicamos Confirmar de verdade (temos o
      // timestamp) e passou tempo suficiente sem a URL sair da tela de
      // segurança, força a navegação mesmo assim.
      let curUrlCheck = "";
      try { curUrlCheck = wc.getURL(); } catch {}
      if (/\/home\/security\b/i.test(curUrlCheck)) {
        const clickedAt = win.__pandoraSecClickedAt || 0;
        const stuckLongEnough = clickedAt > 0 && (Date.now() - clickedAt) > 6000;
        if (!stuckLongEnough) {
          // ainda na tela de segurança — clique não foi aceito pelo site (ou site ainda processando), continua aguardando
          win.__pandoraSecConfirmedNode = false;
          try { await wc.executeJavaScript("window.__pandoraSecPinConfirmed = false; void 0;", true); } catch {}
          return;
        }
        appendSecDiag("[" + flow + "] confirmar clicado há " + (Date.now() - clickedAt) + "ms mas URL não saiu de /home/security sozinha — forçando navegação mesmo assim");
      }
      clearInterval(iv);
      appendSecDiag("confirmação detectada (flow=" + flow + ") — verificando URL atual antes de redirecionar");
      setTimeout(() => {
        try {
          if (!win || win.isDestroyed()) return;
          let curUrl = "";
          try { curUrl = wc.getURL(); } catch {}
          let origin = "";
          try { origin = new URL(curUrl).origin; } catch {}
          if (!origin) { try { origin = new URL(win._targetUrl || "").origin; } catch {} }

          const isWithdrawActive20 = /\/home\/withdraw\b/.test(curUrl) && /[?&]active=20\b/.test(curUrl);
          const isWithdrawActive10 = /\/home\/withdraw\b/.test(curUrl) && /[?&]active=10\b/.test(curUrl);

          // Saque flow: se já está em withdraw (10 ou 20), permanece — qualquer
          // navegação adicional bugaria o site. Para PIX, SEMPRE força active=10
          // após a confirmação da senha (o site auto-redireciona para active=20,
          // mas o cadastro de chave precisa estar em active=10).
          if (flow === "saque") {
            if (isWithdrawActive20) {
              appendSecDiag("[saque] URL já é withdraw?active=20 — permanecendo. url=" + curUrl);
              win.__pandoraSecWatcher = false;
              return;
            }
            if (isWithdrawActive10) {
              appendSecDiag("[saque] URL já é withdraw?active=10 — permanecendo. url=" + curUrl);
              win.__pandoraSecWatcher = false;
              return;
            }
          } else {
            if (isWithdrawActive10) {
              appendSecDiag("[pix] URL já é withdraw?active=10 — permanecendo. url=" + curUrl);
              win.__pandoraSecWatcher = false;
              return;
            }
            appendSecDiag("[pix] senha confirmada, url atual=" + curUrl + " — forçando navegação para /home/withdraw?active=10");
          }

          const next = (origin || "") + "/home/withdraw?active=10";
          if (origin) {
            appendSecDiag("[" + flow + "] destino: " + next + " · url atual: " + curUrl);
            try { wc.stop(); } catch {}
            try { wc.loadURL("about:blank"); } catch {}
            setTimeout(() => {
              try {
                if (!win || win.isDestroyed()) return;
                wc.loadURL(next);
              } catch (e) { appendSecDiag("erro loadURL final: " + (e?.message || e)); }
            }, 80);
          } else {
            appendSecDiag("origin não disponível — não foi possível navegar");
          }
        } catch (e) { appendSecDiag("erro no watcher pós-confirmação: " + (e?.message || e)); }
        win.__pandoraSecWatcher = false;
      }, 300);
    }, 150);
  };
  const kickoff = (origem) => {
    appendSecDiag("kickoff (" + origem + ") em " + (() => { try { return wc.getURL(); } catch { return "?"; } })());
    // Tentativas mais próximas no início (antes o próximo salto depois da
    // 2ª tentativa era só aos 9s, depois 17s/32s/47s/62s — se a primeira
    // falhasse por um motivo passageiro (página ainda renderizando, proxy
    // mais lenta naquela janela específica, etc.), a janela ficava "parada"
    // por até dezenas de segundos até a próxima chance. Mais tentativas,
    // mais cedo, cobrindo a mesma janela total de ~50s.
    setTimeout(run, 200);
    setTimeout(run, 800);
    setTimeout(startWatcher, 800);
    setTimeout(run, 1500);
    setTimeout(run, 2500);
    setTimeout(run, 4000);
    setTimeout(run, 6000);
    setTimeout(run, 9000);
    setTimeout(run, 13000);
    setTimeout(run, 18000);
    setTimeout(run, 25000);
    setTimeout(run, 35000);
    setTimeout(run, 48000);
  };
  // Dispara imediatamente — a página da senha de saque normalmente já está
  // carregada quando o usuário clica "Cadastrar Chaves PIX" na aba Operação.
  // Sem isso, o preenchimento dos 12 dígitos só rodava se houvesse um novo
  // did-finish-load (o que não ocorre numa SPA já montada), deixando os
  // campos em branco.
  try {
    if (!wc.isLoading()) kickoff("imediato");
  } catch { kickoff("imediato-fallback"); }
  wc.once("did-finish-load", () => kickoff("did-finish-load"));
}

module.exports = {
  getWithdrawPin,
  buildSecurityPinScript,
  sendSecurityPinNative,
  nativeFillSecurityPin,
  appendSecDiag,
  scheduleSecurityPinFill,
};
