import { useEffect, useState } from "react";
import { q, log } from "@/lib/api";
import type { Account } from "@/types";
import { Cpu, Wifi, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";

// Janela worker (aberta pelo Play). Cada uma recebe ?idx=N&accId=X no hash.
export function Worker() {
  const params = new URLSearchParams(window.location.hash.split("?")[1] || "");
  const idx = params.get("idx") || "?";
  const accId = params.get("accId");
  const [acc, setAcc] = useState<Account | null>(null);
  const [stage, setStage] = useState<"idle" | "connecting" | "ready" | "running" | "done" | "error">("idle");
  const [steps, setSteps] = useState<string[]>([]);

  useEffect(() => {
    document.title = `Worker #${idx}`;
    (async () => {
      if (accId) {
        const rows = await q<Account>("SELECT * FROM accounts WHERE id=?", [parseInt(accId)]);
        if (rows[0]) setAcc(rows[0]);
      }
      setStage("connecting");
      pushStep("Inicializando sessão isolada...");
      await wait(600); pushStep("Aplicando configuração de proxy...");
      await wait(500); setStage("ready"); pushStep("Pronto para receber tarefas.");
      await log("info", "worker", `Worker #${idx} pronto (acc=${accId || "—"})`);
    })();
  }, []);

  function pushStep(s: string) { setSteps((p) => [...p, `[${new Date().toLocaleTimeString()}] ${s}`]); }
  const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

  return (
    <div className="min-h-screen flex flex-col bg-bg text-slate-100">
      <header className="bg-panel border-b border-border px-5 py-3 flex items-center gap-3">
        <div className="w-9 h-9 rounded-lg bg-amber-500/20 grid place-items-center">
          <Cpu className="w-4 h-4 text-amber-400" />
        </div>
        <div>
          <p className="font-semibold text-sm">Worker #{idx}</p>
          <p className="text-xs text-muted">{acc ? `${acc.label}${acc.holder_name ? " · " + acc.holder_name : ""}` : "Sem conta atribuída"}</p>
        </div>
        <div className="ml-auto flex items-center gap-2 text-xs">
          {stage === "connecting" && <><Loader2 className="w-4 h-4 animate-spin text-amber-400" /> conectando</>}
          {stage === "ready" && <><CheckCircle2 className="w-4 h-4 text-success" /> pronto</>}
          {stage === "running" && <><Loader2 className="w-4 h-4 animate-spin text-accent" /> executando</>}
          {stage === "done" && <><CheckCircle2 className="w-4 h-4 text-success" /> concluído</>}
          {stage === "error" && <><AlertCircle className="w-4 h-4 text-danger" /> erro</>}
        </div>
      </header>

      <div className="flex-1 grid grid-cols-3 gap-4 p-5">
        <div className="card p-4 col-span-1">
          <h3 className="font-semibold text-sm mb-3 flex items-center gap-2"><Wifi className="w-4 h-4 text-accent" /> Sessão</h3>
          <dl className="text-xs space-y-1.5">
            <div className="flex justify-between"><dt className="text-muted">Worker</dt><dd>#{idx}</dd></div>
            <div className="flex justify-between"><dt className="text-muted">Conta</dt><dd>{acc?.label || "—"}</dd></div>
            <div className="flex justify-between"><dt className="text-muted">Titular</dt><dd>{acc?.holder_name || "—"}</dd></div>
            <div className="flex justify-between"><dt className="text-muted">Banco</dt><dd>{acc?.bank || "—"}</dd></div>
            <div className="flex justify-between"><dt className="text-muted">Estado</dt><dd className="capitalize">{stage}</dd></div>
          </dl>
        </div>

        <div className="card p-4 col-span-2">
          <h3 className="font-semibold text-sm mb-3">Console</h3>
          <div className="font-mono text-xs space-y-1 max-h-[400px] overflow-auto">
            {steps.map((s, i) => <div key={i} className="text-muted">{s}</div>)}
          </div>
        </div>
      </div>

      <footer className="px-5 py-3 border-t border-border text-xs text-muted">
        Janela isolada · Esta tela representa uma sessão worker independente lançada pelo Play.
      </footer>
    </div>
  );
}
