import { useEffect, useMemo, useState } from "react";
import { getSetting } from "@/lib/api";
import { useUI } from "@/stores/ui";
import { Trash2, Search, Eye, EyeOff, Copy, FolderArchive, ChevronLeft, ChevronRight, Rocket, X } from "lucide-react";

const PAGE_SIZE = 10;

type ContaLocal = {
  id: string;
  data_hora: string;
  casa_url: string | null;
  login: string | null;
  senha: string | null;
  senha_saque: string | null;
  conta_id: string | null;
  saldo?: number | null;
  saldo_at?: string | null;
  proxy?: string | null;
};

function fmtSaldo(v?: number | null): string {
  if (v == null || !isFinite(v)) return "—";
  return "R$ " + v.toFixed(2).replace(".", ",");
}

function fmtDate(iso?: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" });
}

type ConfirmState =
  | { kind: "all" }
  | { kind: "selected"; count: number }
  | null;

export function Contas() {
  const [list, setList] = useState<ContaLocal[]>([]);
  const [search, setSearch] = useState("");
  const [showPwd, setShowPwd] = useState<Record<string, boolean>>({});
  const [showPin, setShowPin] = useState<Record<string, boolean>>({});
  const [page, setPage] = useState(1);
  const [globalPin, setGlobalPin] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [confirm, setConfirm] = useState<ConfirmState>(null);
  const { showToast, setRunning } = useUI();

  async function load() {
    try {
      const api = (window as any).contasAPI;
      if (!api?.listar) {
        console.warn("[contas-ui] window.contasAPI indisponível (rode dentro do Electron)");
        setList([]);
        return;
      }
      const rows: ContaLocal[] = (await api.listar()) || [];
      setList(rows);
    } catch (e) {
      console.error("[contas-ui] erro ao listar contas", e);
      setList([]);
    }
    try { setGlobalPin(await getSetting("senha_saque", "")); } catch {}
  }

  useEffect(() => { load(); setPage(1); }, []);
  useEffect(() => {
    const id = setInterval(load, 5000);
    return () => clearInterval(id);
  }, []);
  useEffect(() => {
    const off = (window as any).contasAPI?.aoAtualizar?.(() => {
      console.log("[contas-ui] contas:atualizou recebido");
      setPage(1);
      load();
    });
    return () => { try { off && off(); } catch {} };
  }, []);

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    if (!s) return list;
    return list.filter(
      (c) =>
        (c.login || "").toLowerCase().includes(s) ||
        (c.casa_url || "").toLowerCase().includes(s) ||
        (c.conta_id || "").toLowerCase().includes(s),
    );
  }, [list, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageRows = useMemo(
    () => filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE),
    [filtered, currentPage],
  );

  const pageSelectedCount = pageRows.reduce((n, c) => n + (selected.has(c.id) ? 1 : 0), 0);
  const pageAllChecked = pageRows.length > 0 && pageSelectedCount === pageRows.length;
  const pageSomeChecked = pageSelectedCount > 0 && !pageAllChecked;

  function toggleOne(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function togglePage() {
    setSelected((prev) => {
      const next = new Set(prev);
      if (pageAllChecked) {
        for (const c of pageRows) next.delete(c.id);
      } else {
        for (const c of pageRows) next.add(c.id);
      }
      return next;
    });
  }

  async function remove(id: string) {
    if (!confirm) {
      // confirmação inline de remoção individual continua usando confirm nativo
      // (mantém comportamento original)
    }
    if (!window.confirm("Excluir conta?")) return;
    try {
      await (window as any).contasAPI?.remover?.(id);
      setSelected((s) => { const n = new Set(s); n.delete(id); return n; });
      showToast("Conta excluída", "success");
      load();
    } catch (e: any) {
      showToast(`Erro ao excluir: ${e?.message || e}`, "error");
    }
  }

  async function copy(text: string) {
    try { await navigator.clipboard.writeText(text); showToast("Copiado", "success"); } catch {}
  }

  async function doDeleteAll() {
    try {
      const n = await (window as any).contasAPI?.removerTodos?.();
      setSelected(new Set());
      showToast(`${n ?? 0} conta(s) removida(s)`, "success");
      load();
    } catch (e: any) {
      showToast(`Erro: ${e?.message || e}`, "error");
    } finally {
      setConfirm(null);
    }
  }
  async function doDeleteSelected() {
    try {
      const ids = Array.from(selected);
      const n = await (window as any).contasAPI?.removerVarios?.(ids);
      setSelected(new Set());
      showToast(`${n ?? 0} conta(s) removida(s)`, "success");
      load();
    } catch (e: any) {
      showToast(`Erro: ${e?.message || e}`, "error");
    } finally {
      setConfirm(null);
    }
  }
  async function saveProxy(id: string | number, value: string) {
    const proxy = value.trim();
    try {
      await (window as any).contasAPI?.definirProxy?.(id, proxy);
      // Atualiza a lista em memória pra o payload de "Abrir" já levar o novo proxy.
      setList((prev) => prev.map((c) => (c.id === id ? { ...c, proxy } : c)));
    } catch (e: any) {
      showToast(`Erro ao salvar proxy: ${e?.message || e}`, "error");
    }
  }
  async function openSelected() {
    const payload = list
      .filter((c) => selected.has(c.id) && c.casa_url)
      .map((c) => ({ url: c.casa_url!, login: c.login || "", senha: c.senha || "", proxy: c.proxy || "" }));
    if (payload.length === 0) {
      showToast("Nenhuma conta selecionada com URL válida", "warning");
      return;
    }
    try {
      const r = await (window as any).contasAPI?.abrirSelecionadas?.(payload, 0);
      if (r?.ok) {
        setRunning(true);
        showToast(`Abrindo ${r.opened} janela(s) com auto-login`, "success");
      } else showToast(`Falha ao abrir: ${r?.error || "desconhecida"}`, "error");
    } catch (e: any) {
      showToast(`Erro: ${e?.message || e}`, "error");
    }
  }

  return (
    <div className="h-full flex flex-col p-3 max-w-[1280px] mx-auto w-full">
      <header className="flex items-center justify-between mb-2 shrink-0 gap-2 flex-wrap">
        <div className="min-w-0">
          <h1 className="text-lg font-semibold leading-tight">Contas</h1>
          <p className="text-[11px] text-muted">
            {filtered.length} registro(s) · {selected.size} selecionada(s) — armazenamento local criptografado (contas.json)
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button
            className="flex items-center gap-1 px-3 py-1.5 rounded-md bg-warning text-black text-xs font-semibold hover:bg-warning/90"
            onClick={async () => {
              try {
                const r = await (window as any).contasAPI?.abrirBackup?.();
                if (r?.ok) showToast(`Backup TXT atualizado`, "success");
                else showToast(`Falha no backup: ${r?.error || "desconhecida"}`, "error");
              } catch (e: any) { showToast(`Erro no backup: ${e?.message || e}`, "error"); }
            }}
            title="Abre o arquivo TXT de backup (sincronizado automaticamente)"
          >
            <FolderArchive className="w-4 h-4" /> Backup
          </button>
          <button
            className="flex items-center gap-1 px-3 py-1.5 rounded-md bg-success text-black text-xs font-semibold hover:bg-success/90 disabled:opacity-50"
            disabled={selected.size === 0}
            onClick={openSelected}
            title="Abre 1 janela Chromium por conta selecionada e preenche login/senha"
          >
            <Rocket className="w-4 h-4" /> Abrir Selecionadas
          </button>
          <button
            className="flex items-center gap-1 px-3 py-1.5 rounded-md bg-danger text-white text-xs font-semibold hover:bg-danger/90 disabled:opacity-50"
            disabled={selected.size === 0}
            onClick={() => setConfirm({ kind: "selected", count: selected.size })}
          >
            <Trash2 className="w-4 h-4" /> Excluir Selecionadas
          </button>
          <button
            className="flex items-center gap-1 px-3 py-1.5 rounded-md bg-black text-white border border-danger text-xs font-semibold hover:bg-danger/20 disabled:opacity-50"
            disabled={list.length === 0}
            onClick={() => setConfirm({ kind: "all" })}
          >
            <Trash2 className="w-4 h-4" /> Excluir Tudo
          </button>
        </div>
      </header>

      <div className="card mb-2 p-2 flex items-center gap-2 shrink-0">
        <Search className="w-4 h-4 text-muted ml-1" />
        <input
          className="input border-0 bg-transparent !py-1 text-sm"
          placeholder="Buscar por login, casa ou ID..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
        />
      </div>

      <div className="card flex-1 min-h-0 overflow-auto">
        <table className="w-full text-xs">
          <thead className="bg-panel2 text-muted text-[10px] uppercase tracking-wider sticky top-0 z-10">
            <tr>
              <th className="w-8 text-center px-1 py-1.5">
                <input
                  type="checkbox"
                  aria-label="Selecionar página"
                  className="accent-success cursor-pointer"
                  checked={pageAllChecked}
                  ref={(el) => { if (el) el.indeterminate = pageSomeChecked; }}
                  onChange={togglePage}
                  disabled={pageRows.length === 0}
                />
              </th>
              {[
                ["Data/Hora", "140px"],
                ["Casa", "140px"],
                ["Login", "110px"],
                ["Senha", "90px"],
                ["ID da Conta", "100px"],
                ["Saldo", "80px"],
                ["Proxy", "180px"],
              ].map(([label, w]) => (
                <th key={label} className="text-left px-2 py-1.5">
                  {/* Redimensionável arrastando a quininha no canto direito
                      (resize-x nativo do navegador) — pedido do usuário
                      2026-08-08. table-layout continua "auto" (padrão), então
                      o navegador respeita a largura da div ao redimensionar. */}
                  <div className="resize-x overflow-hidden whitespace-nowrap" style={{ minWidth: "40px", width: w }}>
                    {label}
                  </div>
                </th>
              ))}
              <th className="w-10"></th>
            </tr>
          </thead>
          <tbody>
            {pageRows.map((c) => {
              const shown = showPwd[c.id];
              const shownPin = showPin[c.id];
              const pin = String(c.senha_saque || globalPin || "");
              const isSel = selected.has(c.id);
              return (
                <tr key={c.id} className={`border-t border-border hover:bg-panel2/40 ${isSel ? "bg-success/5" : ""}`}>
                  <td className="px-1 py-1 text-center">
                    <input
                      type="checkbox"
                      aria-label={`Selecionar ${c.login || c.id}`}
                      className="accent-success cursor-pointer"
                      checked={isSel}
                      onChange={() => toggleOne(c.id)}
                    />
                  </td>
                  <td className="px-2 py-1 text-muted whitespace-nowrap">{fmtDate(c.data_hora)}</td>
                  <td className="px-2 py-1 font-medium truncate max-w-[200px]">{c.casa_url || "—"}</td>
                  <td className="px-2 py-1">
                    <div className="flex items-center gap-1">
                      <span className="truncate max-w-[140px]">{c.login || "—"}</span>
                      {c.login && <button className="btn-ghost p-0.5" onClick={() => copy(c.login!)}><Copy className="w-3 h-3" /></button>}
                    </div>
                  </td>
                  <td className="px-2 py-1">
                    <div className="flex items-center gap-1">
                      <span className="font-mono">{c.senha ? (shown ? c.senha : "••••••••") : "—"}</span>
                      {c.senha && (
                        <>
                          <button className="btn-ghost p-0.5" onClick={() => setShowPwd((s) => ({ ...s, [c.id]: !s[c.id] }))}>
                            {shown ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          </button>
                          <button className="btn-ghost p-0.5" onClick={() => copy(c.senha!)}><Copy className="w-3 h-3" /></button>
                        </>
                      )}
                    </div>
                  </td>
                  <td className="px-2 py-1">
                    {c.conta_id ? (
                      <div className="flex items-center gap-1">
                        <span className="font-mono">{c.conta_id}</span>
                        <button className="btn-ghost p-0.5" onClick={() => copy(String(c.conta_id))}><Copy className="w-3 h-3" /></button>
                      </div>
                    ) : <span className="text-muted">—</span>}
                  </td>
                  <td className="px-2 py-1 whitespace-nowrap" title={c.saldo_at ? "Atualizado " + fmtDate(c.saldo_at) : ""}>
                    <span className={c.saldo != null ? "text-success font-semibold" : "text-muted"}>{fmtSaldo(c.saldo)}</span>
                  </td>
                  <td className="px-2 py-1">
                    <input
                      defaultValue={c.proxy || ""}
                      placeholder="host:porta:user:senha"
                      title="Proxy só desta conta. Formato host:porta:user:senha (ou host:porta). Enter/sair pra salvar. Vazio = usa o pool global."
                      onBlur={(e) => saveProxy(c.id, e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") (e.target as HTMLInputElement).blur(); }}
                      className="w-full bg-panel border border-border rounded px-1.5 py-0.5 font-mono text-[10px] text-white outline-none focus:border-success"
                    />
                  </td>
                  <td className="px-2 py-1 text-right">
                    <button className="btn-ghost text-danger p-0.5" onClick={() => remove(c.id)}><Trash2 className="w-3.5 h-3.5" /></button>
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={9} className="px-4 py-6 text-center text-muted">
                  Nenhuma conta cadastrada ainda. As contas criadas pelo bot aparecerão aqui automaticamente.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="mt-2 flex items-center justify-between text-xs shrink-0">
        <span className="text-muted">
          Página <strong className="text-white">{currentPage}</strong> de <strong className="text-white">{totalPages}</strong> ·
          {" "}Mostrando {pageRows.length} de {filtered.length}
        </span>
        <div className="flex items-center gap-1">
          <button
            className="flex items-center gap-1 px-3 py-1.5 rounded-md bg-panel2 border border-border text-white disabled:opacity-40"
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={currentPage <= 1}
          >
            <ChevronLeft className="w-3.5 h-3.5" /> Voltar
          </button>
          <button
            className="flex items-center gap-1 px-3 py-1.5 rounded-md bg-panel2 border border-border text-white disabled:opacity-40"
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage >= totalPages}
          >
            Próxima <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Modal de confirmação para exclusão em massa */}
      {confirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60" onClick={() => setConfirm(null)}>
          <div className="bg-panel border border-border rounded-md w-[360px] max-w-[92vw] shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="bg-black text-white text-xs font-semibold py-2 px-3 border-b border-border flex items-center justify-between">
              <span className="flex items-center gap-1.5"><Trash2 className="w-3.5 h-3.5 text-danger" /> Confirmação</span>
              <button onClick={() => setConfirm(null)} className="text-muted hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            <div className="p-4 space-y-3">
              <p className="text-sm text-white">Tem certeza?</p>
              <p className="text-[11px] text-muted">
                {confirm.kind === "all"
                  ? `Esta ação remove TODAS as ${list.length} conta(s) salvas. Não pode ser desfeita.`
                  : `Esta ação remove ${confirm.count} conta(s) selecionada(s). Não pode ser desfeita.`}
              </p>
              <div className="flex justify-end gap-2 pt-1">
                <button
                  onClick={() => setConfirm(null)}
                  className="px-3 py-1.5 rounded-md bg-panel2 border border-border text-white text-xs hover:bg-panel2/70"
                >Não</button>
                <button
                  onClick={confirm.kind === "all" ? doDeleteAll : doDeleteSelected}
                  className="px-3 py-1.5 rounded-md bg-danger text-white text-xs font-semibold hover:bg-danger/90"
                >Sim, excluir</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
