// ============================================================================
// Injeções de script no browser (janelas Chromium controladas)
// ----------------------------------------------------------------------------
// Título sincronizado com a URL, toolbar de navegação (voltar/avançar/
// recarregar/home), overlay "Dados da Conta" e o multiplicador de
// velocidade (__setSpeedInAllFrames) injetados via executeJavaScript em
// todos os frames da página. Extraído do main.cjs original sem alterar a
// lógica — apenas trocando variáveis de módulo soltas por `state.*`.
// ============================================================================
const fs = require("fs");
const state = require("../state.cjs");
const { saveDB } = require("../../db.cjs");
const { getDiagFilePath, saveAutoAccount, persistAutoRegisterLog, queueDiagLine } = require("../../auto-register.cjs");

function attachUrlAsTitle(win) {
  if (!win || win._urlTitleAttached) return;
  win._urlTitleAttached = true;
  const wc = win.webContents;
  const apply = () => {
    try {
      if (!win || win.isDestroyed()) return;
      const u = (wc.getURL && wc.getURL()) || "";
      if (!u || u.startsWith("file://") || u.startsWith("data:") || u.startsWith("about:")) return;
      let display = u;
      try {
        const parsed = new URL(u);
        display = parsed.host || u;
      } catch {}
      if (display.length > 160) display = display.slice(0, 157) + "...";
      win._baseTitleForIp = display;
      try { win.setTitle(display); } catch {}

    } catch {}
  };
  try { wc.on("did-navigate", apply); } catch {}
  try { wc.on("did-navigate-in-page", apply); } catch {}
  try { wc.on("did-finish-load", apply); } catch {}
  try {
    wc.on("page-title-updated", (e) => {
      try { e.preventDefault(); } catch {}
      apply();
    });
  } catch {}
}



function showWindowMessage(win, title, message) {
  if (!win || win.isDestroyed()) return;
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title>
    <style>html,body{margin:0;height:100%;background:#050505;color:#f8fafc;font-family:system-ui,-apple-system,Segoe UI,sans-serif}body{display:grid;place-items:center}.box{max-width:520px;padding:28px;text-align:center}.title{font-size:18px;font-weight:700;margin-bottom:10px}.msg{font-size:14px;line-height:1.5;color:#cbd5e1}</style>
    </head><body><div class="box"><div class="title">${title}</div><div class="msg">${message}</div></div></body></html>`;
  try { win.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(html)}`); } catch {}
}

function executeInAllFrames(wc, script) {
  // Injeta em TODOS os frames/subframes (incluindo cross-origin como os
  // iframes do motor PG SOFT). Usa wc.mainFrame.framesInSubtree para
  // alcançar frames isolados que o frame principal não enxerga via DOM.
  try { wc.executeJavaScript(script, true).catch(() => {}); } catch {}
  const visited = new Set();
  const walk = (frame) => {
    if (!frame || visited.has(frame)) return;
    visited.add(frame);
    try { frame.executeJavaScript(script, true).catch(() => {}); } catch {}
    try {
      const kids = Array.isArray(frame.frames) ? frame.frames : [];
      for (const k of kids) walk(k);
    } catch {}
  };
  try {
    const root = wc.mainFrame;
    if (root) {
      const subtree = Array.isArray(root.framesInSubtree) ? root.framesInSubtree : [root];
      for (const f of subtree) {
        if (!f || f === root) { walk(f); continue; }
        try { f.executeJavaScript(script, true).catch(() => {}); } catch {}
        walk(f);
      }
    }
  } catch {}
}

// Chrome real roda em modo --app (sem abas/barra de endereço — é o que
// permite a janela ter o tamanho exato configurado em TELAS, sem o piso de
// 516px do Chrome normal). Sem nenhuma UI de navegador, não tem como voltar/
// avançar/recarregar/abrir nova guia — injeta uma faixa de botões pequena e
// TRANSPARENTE (só os botões em si têm fundo visível) no canto superior
// esquerdo, pra não cobrir nada importante da página (ex.: botão de
// Depósito, que já foi coberto antes por uma barra cheia — não repete o erro).
function injectBrowserToolbar(win) {
  if (!win || win.isDestroyed()) return;
  // Chrome real em modo "nativo" (janela grande o bastante pra mostrar a
  // UI de verdade do Chrome — abas, voltar/avançar/atualizar, endereço —
  // ver MIN_NATIVE_CHROME_WIDTH em realChromeManager.cjs) já tem tudo isso
  // de fábrica; nossa barra sobreposta só faria sentido (e só é injetada)
  // no modo --app, que não desenha UI nenhuma de navegador.
  if (win._nativeChrome) return;
  try {
    const currentUrl = win.webContents.getURL() || "";
    if (currentUrl.startsWith("file://")) return; // não injeta na splash
    const js = `(() => {
      try {
        const ID = "__pandora_browser_toolbar__";
        if (document.getElementById(ID)) return;
        const bar = document.createElement("div");
        bar.id = ID;
        bar.style.cssText = [
          "all:initial","position:fixed","top:6px","left:6px","z-index:2147483647",
          "display:flex","align-items:center","gap:4px","background:transparent","pointer-events:none"
        ].join(";");
        const mkBtn = (label, title, onClick) => {
          const b = document.createElement("button");
          b.type = "button"; b.title = title; b.innerHTML = label;
          b.style.cssText = [
            "all:unset","pointer-events:auto","display:inline-flex","align-items:center","justify-content:center",
            "width:24px","height:24px","border-radius:5px","cursor:pointer","flex:none",
            "background:rgba(30,30,30,0.85)","color:#e8e8e8","font-size:14px","font-weight:600",
            "line-height:1","user-select:none","font-family:-apple-system,'Segoe UI',system-ui,sans-serif"
          ].join(";");
          b.onmouseenter = () => b.style.background = "rgba(60,60,60,0.95)";
          b.onmouseleave = () => b.style.background = "rgba(30,30,30,0.85)";
          b.onclick = onClick;
          return b;
        };
        const signal = (cmd) => {
          // Canal direto (Chrome real — exposeNavSignal em realChromeManager.cjs):
          // não depende de console.log/document.title, que sites de produção
          // costumam desativar/sobrescrever. Preferido quando disponível.
          if (typeof window.__pandoraNavSignal === "function") {
            try { window.__pandoraNavSignal(cmd); return; } catch(e){}
          }
          // Fallback (janela Electron antiga): console.log + document.title.
          const ts = Date.now();
          try{ console.log("__PANDORA_NAV__:"+cmd+":"+ts); }catch{}
          try{
            const prev = document.title;
            document.title = "__PANDORA_NAV__:"+cmd+":"+ts;
            setTimeout(()=>{ try{ document.title = prev; }catch{} }, 0);
          }catch{}
        };
        bar.appendChild(mkBtn("&#x2190;", "Voltar", () => signal("back")));
        bar.appendChild(mkBtn("&#x2192;", "Avançar", () => signal("fwd")));
        bar.appendChild(mkBtn("&#x21bb;", "Atualizar", () => signal("reload")));
        bar.appendChild(mkBtn("+", "Nova guia", () => signal("newtab")));
        const mount = () => {
          if (!document.body) { setTimeout(mount, 30); return; }
          document.body.appendChild(bar);
        };
        mount();
      } catch(e){}
    })();`;
    win.webContents.executeJavaScript(js, true).catch(() => {});
  } catch {}
}

// ============== Overlay "Dados da Conta" (camada externa nas janelas Chromium) ==============
// Estado global do overlay. Renderizado DIRETAMENTE no DOM da página visitada
// (camada fixed top-right), nunca dentro da UI interna do app. Reinjetado em
// cada navegação por attachBrowserToolbar → apply().
let __accountOverlayState = { enabled: false, login: "", senha: "", senhaSaque: "" };

function applyAccountOverlay(win) {
  if (!win || win.isDestroyed()) return;
  try {
    const wc = win.webContents;
    const currentUrl = wc.getURL() || "";
    if (currentUrl.startsWith("file://")) return; // não injeta na splash
    const st = __accountOverlayState || { enabled: false };
    // Preferência: 1) credenciais REALMENTE usadas no cadastro automático
    // desta janela (win._regCred, atribuído por attachAutoRegister em
    // auto-register.cjs — é a conta de verdade criada ali, e acompanha
    // rotateCredentials se o login for trocado no meio do cadastro);
    // 2) credenciais fixas por janela do fluxo "Contas" (login numa conta já
    // existente, win._contaAutoLogin); 3) fallback pro valor genérico global.
    // Sem isso, toda janela mostrava a MESMA credencial global em vez da
    // conta que de fato foi cadastrada em cada uma.
    const regCred = win._regCred || {};
    const perWin = win._contaAutoLogin || {};
    const login = regCred.login || perWin.login || st.login || "";
    const senha = regCred.senha || perWin.senha || st.senha || "";
    // Senha de saque: usa o MESMO pin que é injetado no cadastro de PIX/saque
    // (getWithdrawPin) — assim o overlay "Exibir Dados" mostra exatamente o
    // valor de 6 dígitos que foi configurado/aplicado para esta janela.
    let senhaSaque = perWin.senhaSaque || st.senhaSaque || "";
    try {
      let pin = "";
      try { pin = require("../security/securityPin.cjs").getWithdrawPin(win); } catch {}
      if (pin && /^\d{6}$/.test(pin)) senhaSaque = pin;
    } catch {}

    const payload = JSON.stringify({
      enabled: !!st.enabled,
      login: String(login),
      senha: String(senha),
      senhaSaque: String(senhaSaque),
    });
    const js = `(() => {
      try {
        var ID = "__pandora_account_overlay__";
        var state = ${payload};
        var el = document.getElementById(ID);
        if (!state.enabled) { if (el && el.parentNode) el.parentNode.removeChild(el); return; }
        if (!document.body) { setTimeout(arguments.callee, 30); return; }
        if (!el) {
          el = document.createElement("div");
          el.id = ID;
          el.style.cssText = [
            "all:initial","position:fixed","top:36px","right:8px","z-index:2147483647",
            "background:#000","color:#fff","border:1px solid #e53935",
            "border-radius:8px","padding:9px 14px","box-shadow:0 2px 8px rgba(0,0,0,0.5)",
            "font-family:ui-monospace,Menlo,Consolas,monospace","font-size:14px",
            "line-height:1.6","user-select:text","pointer-events:none","min-width:220px"
          ].join(";");
          document.documentElement.appendChild(el);
        }
        var esc = function(s){ return String(s||"").replace(/[&<>"']/g, function(c){ return ({"&":"&amp;","<":"&lt;",">":"&gt;","\\"":"&quot;","'":"&#39;"})[c]; }); };
        el.innerHTML =
          '<div style="color:#fff;font-size:11px;font-weight:600;letter-spacing:0.12em;text-transform:uppercase;margin-bottom:5px">Dados da Conta</div>' +
          '<div>Login: <span style="color:#fff">' + (esc(state.login)||"—") + '</span></div>' +
          '<div>Senha: <span style="color:#fff">' + (esc(state.senha)||"—") + '</span></div>' +
          '<div>Senha Saque: <span style="color:#fff">' + (esc(state.senhaSaque)||"—") + '</span></div>';
      } catch(e){}
    })();`;
    wc.executeJavaScript(js, true).catch(() => {});
  } catch {}
}
global.__pandoraApplyOverlay = applyAccountOverlay;

function applyAccountOverlayToTargets() {
  try {
    const st = __accountOverlayState || { enabled: false };
    const all = state.chromeWins.filter((w) => w && !w.isDestroyed());
    // Sem seleção (campo "Janelas Para Controlar" vazio) → todas as janelas.
    // Com seleção → apenas as escolhidas. Se desligando, remove de TODAS para
    // não deixar overlay órfão em janelas que saíram da seleção.
    let targets;
    if (!st.enabled) {
      targets = all;
    } else {
      const sel = require("../window/chromiumWindows.cjs").getSelectedChromeWins();
      targets = sel.length ? sel : all;
      // Remove de janelas não-alvo (garante "individual" quando há seleção).
      const setTargets = new Set(targets);
      for (const w of all) if (!setTargets.has(w)) {
        try {
          w.webContents.executeJavaScript(
            "(()=>{var e=document.getElementById('__pandora_account_overlay__');if(e&&e.parentNode)e.parentNode.removeChild(e);})()",
            true
          ).catch(() => {});
        } catch {}
      }
    }
    for (const w of targets) applyAccountOverlay(w);
  } catch {}
}


// Script injetado em toda página: captura submissões de formulários de cadastro
// (manuais OU automáticas) e emite marker __PANDORA_MANUAL_REG__ com login/senha
// reais lidos do DOM, garantindo que qualquer conta criada vá para a aba Contas.
// Prioriza os seletores específicos data-input-name="account" e
// data-input-name="userpass" (cassino 91-handsetpg.com e similares).

// Anti "página sobe sozinha" — causa raiz achada 2026-08-19 via armadilha
// real no DevTools (sugestão do Gemini, confirmada por log real do
// usuário): o PRÓPRIO SITE chama .scrollIntoView() na barra de abas
// horizontal (ui-tabs__nav, ex.: ao trocar/realçar a aba ativa) — como essa
// barra fica DENTRO do container vertical que rola a lista de jogos,
// scrollIntoView() por padrão mexe em TODOS os ancestrais roláveis
// necessários pra trazer o alvo à vista, jogando o scroll vertical de volta
// pra posição onde a barra de abas fica visível (sempre o mesmo Y, porque é
// sempre o mesmo layout). Não é scrollTo/scrollBy/scrollTop (por isso
// interceptar esses três nunca resolveu) — é scrollIntoView(), chamado
// pelo JS do site, não pelo nosso.
// Fix: intercepta Element.prototype.scrollIntoView GLOBALMENTE. Primeira
// tentativa (forçar block:'nearest', inline:'nearest' sempre) trocou o
// sintoma: em vez do valor fixo antigo, passou a fixar a barra de abas
// colada no topo (escondendo Promoção/Jogo especiais) — 'nearest' AINDA
// arrasta o ancestral vertical quando julga necessário. Fix mais direto:
// quando o alvo é a barra de abas horizontal (ou está dentro dela —
// reconhecida por 'lobby-scroll--x'/'ui-tabs__nav', a rolagem só deveria
// ser HORIZONTAL — ela NUNCA deveria mexer no scroll vertical) — CANCELA a
// chamada por completo, não deixa ela nem tentar.
const __ANTI_SCROLL_SNAP_SCRIPT = `(() => {
  try {
    if (window.__pandoraAntiScrollSnap) return;
    window.__pandoraAntiScrollSnap = true;
    var isInsideHorizontalScroller = function(el) {
      var p = el;
      for (var i = 0; p && i < 6; i++, p = p.parentElement) {
        var cls = (p.className && p.className.baseVal) || p.className || '';
        if (typeof cls === 'string' && (cls.indexOf('lobby-scroll--x') !== -1 || cls.indexOf('ui-tabs__nav') !== -1)) return true;
      }
      return false;
    };
    var origSIV = Element.prototype.scrollIntoView;
    Element.prototype.scrollIntoView = function(arg) {
      try {
        if (isInsideHorizontalScroller(this)) return; // cancela — nunca precisa mexer no vertical
        if (arg && typeof arg === 'object') {
          return origSIV.call(this, Object.assign({}, arg, { block: 'nearest', inline: 'nearest' }));
        }
        return origSIV.call(this, { block: 'nearest', inline: 'nearest' });
      } catch(_e) {
        try { return origSIV.apply(this, arguments); } catch(_e2) {}
      }
    };
  } catch(e){}
})();`;

// Bloqueia chamadas de fullscreen (ex.: jogos/slots da PG SOFT que forçam
// tela cheia ao iniciar o Canvas/WebGL). Mantém o jogo dentro dos limites
// fixos da janela do bot. Injetado em TODOS os frames o mais cedo possível.
const __NO_FULLSCREEN_SCRIPT = `(() => {
  if (window.__pandoraNoFullscreen) return; window.__pandoraNoFullscreen = true;
  const desativarFullscreen = () => {
    const ignorar = () => Promise.resolve();
    if (typeof Element !== 'undefined') {
      try { Element.prototype.requestFullscreen = ignorar; } catch(e){}
      try { Element.prototype.webkitRequestFullscreen = ignorar; } catch(e){}
      try { Element.prototype.mozRequestFullScreen = ignorar; } catch(e){}
      try { Element.prototype.msRequestFullscreen = ignorar; } catch(e){}
    }
    if (typeof document !== 'undefined' && document.documentElement) {
      try { document.documentElement.requestFullscreen = ignorar; } catch(e){}
      try { document.documentElement.webkitRequestFullscreen = ignorar; } catch(e){}
      try { document.documentElement.mozRequestFullScreen = ignorar; } catch(e){}
      try { document.documentElement.msRequestFullscreen = ignorar; } catch(e){}
    }
  };
  desativarFullscreen();
  try { window.addEventListener('DOMContentLoaded', desativarFullscreen); } catch(e){}
  try { window.addEventListener('load', desativarFullscreen); } catch(e){}
})();`;

// SpeedHack para slots PG SOFT: acelera o Delta Time do motor gráfico via
// requestAnimationFrame, sem tocar em setTimeout/setInterval/WebSocket
// (preserva o heartbeat de rede). Enquanto a página não terminar de carregar
// (document.readyState !== 'complete'), força 1x para não travar o boot do
// jogo na barra de loading.
// Baseado na técnica real de extensões tipo "HTML5 Universal Speed Hack"
// (confirmado pelo usuário que funciona no jogo em que o nosso não estava
// funcionando): a peça que faltava não era só acelerar RAF/setTimeout, era
// principalmente acelerar o RELÓGIO que o jogo lê (performance.now/Date.now)
// — motores de jogo calculam o próprio ritmo comparando esses valores, não
// só confiando no delay pedido ao setTimeout. E setInterval precisa ser
// RECRIADO quando a velocidade muda (não dá pra "reagendar" um intervalo já
// rodando, só cancelar e criar de novo com o novo tempo).
const __SPEEDHACK_SCRIPT_FULL = `(() => {
  try {
    if (!window.__pandoraSpeedNative) {
      window.__pandoraSpeedNative = {
        raf: window.requestAnimationFrame.bind(window),
        setTimeout: window.setTimeout.bind(window),
        setInterval: window.setInterval.bind(window),
        clearInterval: window.clearInterval.bind(window),
        perfNow: window.performance.now.bind(window.performance),
        dateNow: Date.now,
      };
    }
    const N = window.__pandoraSpeedNative;
    if (window.__pandoraSpeedMultiplier == null) window.__pandoraSpeedMultiplier = 1.0;
    const getMult = () => parseFloat(window.__pandoraSpeedMultiplier) || 1.0;

    // ---- Relógio virtual: performance.now() e Date.now() acelerados ----
    // Acumula o tempo real decorrido a cada chamada, multiplicado pela
    // velocidade atual (lida na hora, muda em tempo real).
    let perfVirtual = null, perfLastReal = null;
    const patchedPerfNow = function () {
      const real = N.perfNow();
      if (perfVirtual === null) { perfVirtual = real; perfLastReal = real; return perfVirtual; }
      perfVirtual += (real - perfLastReal) * getMult();
      perfLastReal = real;
      return perfVirtual;
    };
    let dateVirtual = null, dateLastReal = null;
    const patchedDateNow = function () {
      const real = N.dateNow();
      if (dateVirtual === null) { dateVirtual = real; dateLastReal = real; return Math.floor(dateVirtual); }
      dateVirtual += (real - dateLastReal) * getMult();
      dateLastReal = real;
      return Math.floor(dateVirtual);
    };

    // ---- requestAnimationFrame: timestamp acelerado (igual antes) ----
    let rafLast = N.perfNow();
    let rafVirtual = N.perfNow();
    const patchedRAF = function (callback) {
      return N.raf(function (now) {
        try {
          const multiplier = getMult();
          if (document.readyState !== 'complete' || multiplier === 1.0) {
            rafLast = now; rafVirtual = now;
            return callback(now);
          }
          const dt = now - rafLast;
          rafVirtual += dt * multiplier;
          rafLast = now;
          return callback(rafVirtual);
        } catch (e) { return callback(now); }
      });
    };

    // ---- setTimeout: divide o delay pedido pela velocidade atual ----
    const patchedSetTimeout = function (fn, delay, ...args) {
      const d = typeof delay === 'number' ? delay : 0;
      const m = getMult();
      return N.setTimeout(fn, m > 1 ? Math.max(0, d / m) : d, ...args);
    };

    // ---- setInterval: rastreia cada intervalo criado, e quando a
    // velocidade MUDA, cancela e recria todos com o novo tempo (senão fica
    // preso na velocidade de quando foi criado pra sempre — isso explicava
    // "funciona na tela de loading, para quando o jogo de verdade começa":
    // os timers do motor real são criados DEPOIS que a gente já tinha
    // ativado a velocidade, então precisam ser re-tempados quando ela muda).
    const activeIntervals = [];
    const patchedSetInterval = function (fn, delay, ...args) {
      const d = typeof delay === 'number' ? delay : 0;
      const m = getMult();
      const realId = N.setInterval(fn, m > 1 ? Math.max(1, d / m) : d, ...args);
      const entry = { realId, fn, delay: d, args, lastMult: m };
      activeIntervals.push(entry);
      return realId;
    };
    const patchedClearInterval = function (id) {
      N.clearInterval(id);
      const idx = activeIntervals.findIndex((e) => e.realId === id);
      if (idx !== -1) activeIntervals.splice(idx, 1);
    };
    let lastKnownMult = getMult();
    const reloadIntervalsIfSpeedChanged = () => {
      const m = getMult();
      if (m === lastKnownMult) return;
      lastKnownMult = m;
      for (const entry of activeIntervals) {
        N.clearInterval(entry.realId);
        entry.realId = N.setInterval(entry.fn, m > 1 ? Math.max(1, entry.delay / m) : entry.delay, ...entry.args);
        entry.lastMult = m;
      }
    };

    patchedRAF.__pandoraPatched = true;
    patchedSetTimeout.__pandoraPatched = true;
    patchedSetInterval.__pandoraPatched = true;
    patchedPerfNow.__pandoraPatched = true;
    patchedDateNow.__pandoraPatched = true;

    const apply = () => {
      if (window.requestAnimationFrame !== patchedRAF) window.requestAnimationFrame = patchedRAF;
      if (window.setTimeout !== patchedSetTimeout) window.setTimeout = patchedSetTimeout;
      if (window.setInterval !== patchedSetInterval) window.setInterval = patchedSetInterval;
      if (window.clearInterval !== patchedClearInterval) window.clearInterval = patchedClearInterval;
      if (window.performance.now !== patchedPerfNow) window.performance.now = patchedPerfNow;
      if (Date.now !== patchedDateNow) Date.now = patchedDateNow;
      reloadIntervalsIfSpeedChanged();
    };
    apply();
    // Vigia contínuo: reaplica se o jogo sobrescrever qualquer um desses
    // depois de carregar, e recria os setInterval quando a velocidade mudar.
    if (!window.__pandoraSpeedWatchdog) {
      window.__pandoraSpeedWatchdog = setInterval(apply, 300);
    }
  } catch (e) {
    try { console.log('Erro no sistema integrado de Speedhack Pandora:', e); } catch(_){}
  }
})();`;

// URGENTE (2026-08-08, achado real do usuário): a versão "completa" acima
// (virtualização de Date.now/performance.now + recriação de setInterval —
// técnica trazida da extensão de referência SpeedHack25x pra consertar a
// WG) QUEBRA os slots da PG — o motor da PG aparentemente depende do
// relógio real de alguma forma que a WG não depende (ex.: valida timestamp
// de sessão/rodada contra o servidor, ou detecta Date.now adulterado).
// Essa versão SIMPLES (só RAF com timestamp acelerado + setTimeout escalado
// — exatamente o que já funcionava confirmado pelo usuário em 2x/4x na PG
// ANTES da investigação da WG) fica reservada pra qualquer alvo que NÃO
// seja explicitamente um domínio da WG (ver WG_HOST_RX/aplicação em
// realChromeManager.cjs — applySpeedhackToTarget escolhe qual das duas
// injetar, por domínio do alvo).
// RAF-só, de propósito — igual era ANTES de qualquer investigação da WG
// (comentário histórico do código original: "acelera o Delta Time do motor
// gráfico via requestAnimationFrame, SEM TOCAR em setTimeout/setInterval/
// WebSocket, preserva o heartbeat de rede"). Bug meu (2026-08-08): a
// primeira versão desse "simples" que escrevi incluía um patch de
// setTimeout que a versão original NUNCA teve — foi isso que quebrou o
// carregamento da PG (ficava preso na tela de loading pra sempre). Voltando
// exatamente ao que era confirmado funcionando.
const __SPEEDHACK_SCRIPT_SIMPLE = `(() => {
  try {
    if (!window.__pandoraSpeedNative) {
      window.__pandoraSpeedNative = {
        raf: window.requestAnimationFrame.bind(window),
      };
    }
    const N = window.__pandoraSpeedNative;
    if (window.__pandoraSpeedMultiplier == null) window.__pandoraSpeedMultiplier = 1.0;
    const getMult = () => parseFloat(window.__pandoraSpeedMultiplier) || 1.0;

    let rafLast = performance.now();
    let rafVirtual = rafLast;
    const patchedRAF = function (callback) {
      return N.raf(function (now) {
        try {
          const multiplier = getMult();
          if (document.readyState !== 'complete' || multiplier === 1.0) {
            rafLast = now; rafVirtual = now;
            return callback(now);
          }
          const dt = now - rafLast;
          rafVirtual += dt * multiplier;
          rafLast = now;
          return callback(rafVirtual);
        } catch (e) { return callback(now); }
      });
    };
    patchedRAF.__pandoraPatched = true;

    const apply = () => {
      if (window.requestAnimationFrame !== patchedRAF) window.requestAnimationFrame = patchedRAF;
    };
    apply();
    if (!window.__pandoraSpeedWatchdog) {
      window.__pandoraSpeedWatchdog = setInterval(apply, 300);
    }
  } catch (e) {
    try { console.log('Erro no sistema integrado de Speedhack Pandora (simples):', e); } catch(_){}
  }
})();`;

// Dispatcher: decide qual das duas versões usar OLHANDO O DOMÍNIO NA HORA,
// dentro do próprio navegador — não dá pra decidir isso com segurança do
// lado do Node no momento em que o target é criado (a URL real muitas vezes
// só existe DEPOIS da primeira navegação, e por-target já reinjeta várias
// vezes seguidas). Exportado como __SPEEDHACK_SCRIPT (nome de sempre) pra
// nenhum outro arquivo precisar mudar — só WG e PP usam a versão completa
// (precisam da virtualização de relógio pra acelerar de verdade, achado
// 2026-08-07/08); PG e qualquer outro domínio usam a simples (a completa
// QUEBRA a PG — achado urgente do usuário 2026-08-08).
const __SPEEDHACK_SCRIPT = `(() => {
  try {
    var __pandoraSpeedFullDomain = /wgnetworking|wgosd|wgkonnect|fvnkonnect|wggos|pwmercjm|140\\.150\\.33\\.110|lwfzaieifo/i.test(location.hostname);
    if (__pandoraSpeedFullDomain) {
      ${__SPEEDHACK_SCRIPT_FULL}
    } else {
      ${__SPEEDHACK_SCRIPT_SIMPLE}
    }
  } catch (e) {}
})();`;

// Atualiza o multiplicador em runtime em todos os frames (instantâneo).
function __setSpeedInAllFrames(wc, mult) {
  const m = Math.max(1, Math.min(25, parseFloat(mult) || 1));
  const script = `(() => { try { window.__pandoraSpeedMultiplier = ${m}; } catch(e){} })();`;
  // 2026-08-09: removido bloco de DEBUG temporário que ficou esquecido aqui
  // (investigação antiga "speedhack não funciona na WG") — fazia uma
  // varredura RECURSIVA de toda a árvore de frames + escrita em disco a
  // CADA chamada, e essa função roda em did-finish-load/did-navigate/
  // dom-ready/did-navigate-in-page de TODA janela, ou seja, o tempo todo.
  // Puro desperdício de CPU/disco sem nenhum uso funcional — a lógica de
  // setar a velocidade de verdade está abaixo, intacta.
  // 1) Caminho nativo (cruza Site Isolation / OOPIF): IPC para o preload de
  //    cada subframe. Funciona mesmo quando o frame está em outro processo.
  try {
    const root = wc && wc.mainFrame;
    if (root) {
      const subtree = Array.isArray(root.framesInSubtree) ? root.framesInSubtree : [root];
      for (const f of subtree) {
        try { f.send("pandora:set-speed", m); } catch (_) {}
      }
    }
  } catch (_) {}
  // 2) Fallback: executeJavaScript in-process (cobre frames do mesmo processo
  //    do main frame, caso o preload ainda não tenha terminado de carregar).
  try { executeInAllFrames(wc, __SPEEDHACK_SCRIPT); } catch {}
  try { executeInAllFrames(wc, script); } catch {}
}
let __speedMultiplier = 1;

// Identifica se a URL atual de um frame principal corresponde a um SLOT
// (página do jogo). Quando o usuário sai do slot, o speedhack volta para 1x.
function __isSlotUrl(url) {
  try {
    const u = String(url || "").toLowerCase();
    if (!u) return false;
    return u.includes("/home/embedded") || u.includes("/home/subgame") || u.includes("/subgame");
  } catch (_) { return false; }
}

// Reseta o multiplicador global para 1x em todas as janelas Chromium e
// avisa a UI principal para sincronizar o estado dos botões.
function __resetSpeedToDefault(reason) {
  const wasMult = __speedMultiplier;
  __speedMultiplier = 1;
  try {
    for (const win of state.chromeWins || []) {
      try {
        if (!win || win.isDestroyed()) continue;
        __setSpeedInAllFrames(win.webContents, 1);
      } catch (_) {}
    }
  } catch (_) {}
  // Sempre avisa a UI principal para sincronizar o estado dos botões,
  // mesmo que o multiplicador já estivesse em 1 (a UI pode estar dessincronizada).
  try {
    const { BrowserWindow } = require("electron");
    const wins = BrowserWindow.getAllWindows() || [];
    for (const w of wins) {
      try {
        if (!w || w.isDestroyed()) continue;
        // Não enviar para janelas Chromium (têm preload diferente)
        if (state.chromeWins && state.chromeWins.includes && state.chromeWins.includes(w)) continue;
        w.webContents.send("chrome:speedReset", { multiplier: 1, reason: reason || "" });
      } catch (_) {}
    }
  } catch (_) {}
  try { console.log(`[speedhack] resetado para 1x (antes=${wasMult}x, motivo: ${reason || "n/a"}).`); } catch (_) {}
}


const __MANUAL_REG_SCRIPT = `(() => {
  try {
    if (window.__pandoraManualReg) return;
    window.__pandoraManualReg = true;
    const log = (m) => { try { console.log('[pandora-cap] ' + m); } catch(e){} };
    const send = (d) => { try { console.log('__PANDORA_MANUAL_REG__:' + JSON.stringify(d)); } catch(e){} };
    let lastCandidate = null;
    let lastActionAt = 0;
    let lastSentKey = '';
    let lastSentAt = 0;
    const readVal = (sel) => {
      try { const el = document.querySelector(sel); return el ? String(el.value||'').trim() : ''; } catch(e){ return ''; }
    };
    const captureBySpecific = () => {
      const login = readVal('input[data-input-name="account"], textarea[data-input-name="account"]');
      const senha = readVal('input[data-input-name="userpass"], textarea[data-input-name="userpass"]');
      if (login && senha) {
        log('captura específica account="' + login + '" userpass=*** url=' + location.href);
        return { login, senha, source: 'specific' };
      }
      return null;
    };
    const isReg = (form) => {
      try {
        const ins = form.querySelectorAll('input');
        let pwd = 0;
        for (const i of ins) { if ((i.type||'').toLowerCase() === 'password') pwd++; }
        return pwd >= 1;
      } catch(e){ return false; }
    };
    const captureGeneric = (form) => {
      try {
        const ins = (form || document).querySelectorAll('input,textarea');
        let login='', senha='', celular='';
        const pwds = [];
        const textCandidates = [];
        for (const i of ins) {
          const t = (i.type||'').toLowerCase();
          const dn = (i.getAttribute && i.getAttribute('data-input-name')) || '';
          const n = ((i.name||'')+' '+(i.id||'')+' '+(i.placeholder||'')+' '+(i.getAttribute('aria-label')||'')+' '+(i.autocomplete||'')+' '+dn).toLowerCase();
          const v = (i.value||'').trim();
          if (!v) continue;
          if (t === 'password' || /userpass|password|senha/.test(n)) { pwds.push(v); continue; }
          if (/phone|celular|tel|mobile/.test(n) && !celular) { celular = v; continue; }
          if (/account|user|login|usuario|conta|email|nick|apelid/.test(n) && !login) { login = v; continue; }
          if ((t === 'text' || t === '' || t === 'email') && v.length >= 3 && v.length <= 64) textCandidates.push(v);
        }
        if (!login && textCandidates.length) login = textCandidates[0];
        if (pwds.length) senha = pwds[0];
        return (login && senha) ? { login, senha, celular, source: 'generic' } : null;
      } catch(e){ return null; }
    };
    const remember = (form, reason) => {
      const spec = captureBySpecific();
      const data = spec || captureGeneric(form || document);
      if (data && data.login && data.senha) {
        lastCandidate = data;
        log('captura ' + (data.source || '?') + ' account="' + data.login + '" userpass=*** reason=' + reason + ' url=' + location.href);
      }
      return data;
    };
    const fire = (form, reason) => {
      const data = remember(form, reason) || lastCandidate;
      if (!data) { log('captura abortada (sem login+senha) reason=' + reason + ' url=' + location.href); return; }
      const now = Date.now();
      const key = String(data.login) + '|' + String(data.senha);
      if (lastSentKey === key && (now - lastSentAt) < 30000) { log('MANUAL_REG duplicado ignorado login=' + data.login + ' reason=' + reason); return; }
      lastSentKey = key; lastSentAt = now;
      log('enviando MANUAL_REG login=' + data.login + ' source=' + (data.source || '?') + ' reason=' + reason);
      send({ login: data.login, senha: data.senha, celular: data.celular || '', status:'manual-submitted', site: location.href, criadoEm: new Date().toISOString(), captureReason: reason || '' });
    };
    document.addEventListener('input', (e) => {
      try { remember((e.target && e.target.closest && e.target.closest('form')) || document, 'input'); } catch(e){}
    }, true);
    document.addEventListener('change', (e) => {
      try { remember((e.target && e.target.closest && e.target.closest('form')) || document, 'change'); } catch(e){}
    }, true);
    document.addEventListener('submit', (e) => {
      try { const f = e.target; if (f && f.tagName === 'FORM' && isReg(f)) { lastActionAt = Date.now(); fire(f, 'submit'); } } catch(e){}
    }, true);
    document.addEventListener('click', (e) => {
      try {
        const form = (e.target && e.target.closest && e.target.closest('form')) || document.querySelector('form');
        remember(form || document, 'click-seen');
        const el = e.target && e.target.closest ? e.target.closest('button,a,[role=button],input[type=button],input[type=submit],div,span') : null;
        if (lastCandidate) lastActionAt = Date.now();
        if (!el) return;
        const txt = ((el.innerText||el.textContent||el.value||'')+' '+(el.id||'')+' '+(el.className||'')+' '+(el.getAttribute('aria-label')||'')+' '+(el.getAttribute('data-testid')||'')).trim().toLowerCase();
        const isSubmitLike = /cadastr|registr|criar.*conta|sign\\s*up|finalizar|enviar|confirmar|continuar|entrar|login|insideregistersubmitclick|submit/.test(txt)
          || (el.tagName === 'BUTTON' && (el.type||'').toLowerCase() === 'submit')
          || ((el.getAttribute && (el.getAttribute('type')||'').toLowerCase()) === 'submit');
        if (!isSubmitLike) return;
        setTimeout(() => fire(form, 'click-submit'), 80);
      } catch(e){}
    }, true);
    document.addEventListener('keydown', (e) => {
      try { if (e.key === 'Enter') { lastActionAt = Date.now(); const f = e.target && e.target.closest ? e.target.closest('form') : null; setTimeout(() => fire(f || document, 'enter'), 80); } } catch(e){}
    }, true);
    setInterval(() => {
      try {
        remember(document, 'interval');
        if (!lastCandidate) return;
        const txt = ((document.body && document.body.innerText) || '').toLowerCase();
        const success = /sucesso|success|bem.?vind|welcome|dep[óo]sito|recarregar|deposit|conta criada|registro conclu/.test(txt);
        const formGone = !document.querySelector('input[data-input-name="account"],input[data-input-name="userpass"]');
        if (success || (lastActionAt && Date.now() - lastActionAt < 20000 && formGone)) fire(document, success ? 'success-detected' : 'post-action');
      } catch(e){}
    }, 1000);
    window.addEventListener('pagehide', () => { try { if (lastCandidate && lastActionAt && Date.now() - lastActionAt < 30000) fire(document, 'pagehide'); } catch(e){} }, true);
  } catch(e){}
})();`;

// Captura o ID numérico da conta em QUALQUER página, sem depender de /home/mine.
// Estratégias (em ordem de confiabilidade):
//  1) Intercepta fetch/XHR e procura campos id/userId/uid/account_id em respostas JSON
//  2) Lê localStorage/sessionStorage por chaves contendo userId/uid/account
//  3) Lê cookies (uid=..., userId=..., account_id=...)
//  4) DOM: atributos data-user-id/data-account-id e fallback de spans numéricos
const __CONTA_ID_SCRIPT = `(() => {
  try {
    if (window.__pandoraContaIdActive) return;
    window.__pandoraContaIdActive = true;
    const log = (m) => { try { console.log('[pandora-cap] ' + m); } catch(e){} };
    const isNumId = (v) => typeof v === 'string' && /^\\d{5,12}$/.test(v);
    const sendOnce = (id, source) => {
      try {
        if (!id || !isNumId(String(id))) return;
        if (window.__pandoraLastContaId === String(id)) return;
        window.__pandoraLastContaId = String(id);
        let login = '';
        try {
          const acc = document.querySelector('input[data-input-name="account"]');
          if (acc) login = String(acc.value || '').trim();
        } catch(e){}
        log('ID da conta detectado=' + id + ' via=' + source + (login ? (' login=' + login) : ''));
        console.log('__PANDORA_CONTA_ID__:' + JSON.stringify({ id: String(id), login: login||'', url: location.href, source: source||'', at: Date.now() }));
      } catch(e){}
    };
    // ----- Estratégia 1: fetch/XHR -----
    const ID_KEYS = ['id','userId','user_id','uid','account_id','accountId','memberId','member_id','playerId','player_id'];
    const scanObj = (obj, depth) => {
      if (!obj || depth > 4) return null;
      if (typeof obj !== 'object') return null;
      for (const k of ID_KEYS) {
        if (obj[k] != null) {
          const v = String(obj[k]);
          if (isNumId(v)) return { id: v, key: k };
        }
      }
      for (const k in obj) {
        try {
          const r = scanObj(obj[k], depth + 1);
          if (r) return r;
        } catch(e){}
      }
      return null;
    };
    const scanText = (txt, where) => {
      if (!txt || typeof txt !== 'string' || txt.length > 200000) return;
      try {
        const j = JSON.parse(txt);
        const r = scanObj(j, 0);
        if (r) sendOnce(r.id, where + ':' + r.key);
      } catch(e){}
    };
    try {
      const _fetch = window.fetch;
      if (_fetch && !window.__pandoraFetchHook) {
        window.__pandoraFetchHook = true;
        window.fetch = function(...args) {
          return _fetch.apply(this, args).then((res) => {
            try {
              const c = res.clone();
              c.text().then((t) => scanText(t, 'fetch')).catch(()=>{});
            } catch(e){}
            return res;
          });
        };
      }
    } catch(e){}
    try {
      const XHR = window.XMLHttpRequest;
      if (XHR && XHR.prototype && !window.__pandoraXhrHook) {
        window.__pandoraXhrHook = true;
        const _send = XHR.prototype.send;
        XHR.prototype.send = function(body) {
          try {
            this.addEventListener('load', () => {
              try {
                const rt = this.responseType;
                if (rt === '' || rt === 'text') {
                  try { scanText(this.responseText, 'xhr'); } catch(e){}
                } else if (rt === 'json') {
                  try {
                    const r = this.response;
                    if (r && typeof r === 'object') {
                      const found = scanObj(r, 0);
                      if (found) sendOnce(found.id, 'xhr:json:' + found.key);
                    }
                  } catch(e){}
                }
              } catch(e){}
            });
          } catch(e){}
          return _send.apply(this, arguments);
        };
      }
    } catch(e){}
    // ----- Estratégia 2: storage -----
    const scanStorage = (storage, where) => {
      try {
        for (let i = 0; i < storage.length; i++) {
          const k = storage.key(i) || '';
          if (!/user|uid|account|member|player|profile/i.test(k)) continue;
          const v = storage.getItem(k);
          if (!v) continue;
          if (isNumId(v)) { sendOnce(v, where + ':' + k); continue; }
          scanText(v, where + ':' + k);
        }
      } catch(e){}
    };
    // ----- Estratégia 3: cookies -----
    const scanCookies = () => {
      try {
        const parts = (document.cookie || '').split(';');
        for (const p of parts) {
          const [rk, rv] = p.split('=');
          if (!rk || !rv) continue;
          const k = rk.trim(), v = decodeURIComponent(rv.trim());
          if (/user|uid|account|member|player/i.test(k) && isNumId(v)) sendOnce(v, 'cookie:' + k);
        }
      } catch(e){}
    };
    // ----- Estratégia 4: DOM -----
    const scanDom = () => {
      try {
        const cand = document.querySelector('[data-account-id],[data-user-id],[data-uid],[data-member-id],[data-player-id]');
        if (cand) {
          const v = (cand.getAttribute('data-account-id') || cand.getAttribute('data-user-id') || cand.getAttribute('data-uid') || cand.getAttribute('data-member-id') || cand.getAttribute('data-player-id') || '').trim();
          if (isNumId(v)) { sendOnce(v, 'dom:data-attr'); return; }
        }
        // Procura "ID: 123456" ou "UID 123456" no texto
        const m = (document.body && document.body.innerText || '').match(/\\b(?:ID|UID|Conta|Account|User)\\s*[:#-]?\\s*(\\d{5,12})\\b/i);
        if (m && isNumId(m[1])) sendOnce(m[1], 'dom:text');
      } catch(e){}
    };
    const runAll = () => { scanStorage(localStorage, 'local'); scanStorage(sessionStorage, 'session'); scanCookies(); scanDom(); };
    runAll();
    let attempts = 0;
    const iv = setInterval(() => { attempts++; runAll(); if (window.__pandoraLastContaId || attempts > 60) { try { clearInterval(iv); } catch(e){} } }, 1000);
    try {
      const mo = new MutationObserver(() => { scanDom(); });
      mo.observe(document.documentElement, { childList: true, subtree: true });
    } catch(e){}
  } catch(e){}
})();`;

// Auto-click no botão "INICIAR" (#__startedButton) assim que o slot termina
// de carregar (barra 100%). Reseta quando o botão some para servir o próximo
// jogo dentro da mesma janela.
const __SLOT_AUTOSTART_SCRIPT = `(() => {
  try {
    if (window.__pandoraAutoStartSlotInstalled) return;
    window.__pandoraAutoStartSlotInstalled = true;
    var jaIniciou = false;
    function tick() {
      try {
        try {
          if (document.getElementById('__startedButton') && !window.__pandoraSlotCanvasSeenAt) {}
          if (document.getElementById('GameCanvas') && !window.__pandoraSlotCanvasSeenAt) {
            window.__pandoraSlotCanvasSeenAt = Date.now();
          }
        } catch(_){}
        var btn = document.getElementById('__startedButton');
        if (btn) {
          var visivel = false;
          try {
            visivel = btn.classList.contains('start-button-show-port') ||
                      (window.getComputedStyle(btn).display !== 'none');
          } catch(_) { visivel = true; }
          if (visivel && !jaIniciou) {
            jaIniciou = true;
            window.__pandoraSlotLoadingButtonSeen = true;
            try { console.log("-> [Pandora BOT] Slot carregado. Detectando botão 'INICIAR'..."); } catch(_){}
            setTimeout(function(){
              try {
                if (typeof btn.click === 'function') {
                  btn.click();
                  window.__pandoraSlotStartClickedAt = Date.now();
                  try { console.log("-> [Pandora BOT] Tela de carregamento pulada."); } catch(_){}
                }
              } catch(_){}
            }, 500);
          }
        } else if (jaIniciou) {
          jaIniciou = false;
          window.__pandoraSlotReadyAt = Date.now();
          try { console.log("-> [Pandora BOT] Monitor de início resetado."); } catch(_){}
        } else if (window.__pandoraSlotCanvasSeenAt && !window.__pandoraSlotLoadingButtonSeen && !window.__pandoraSlotReadyAt && Date.now() - window.__pandoraSlotCanvasSeenAt > 7000) {
          window.__pandoraSlotReadyAt = Date.now();
        }
      } catch(_){}
    }
    setInterval(tick, 400);
  } catch(e){}
})();`;

// Função utilitária global para simular cliques proporcionais (em %) dentro
// do <canvas id="GameCanvas"> usado pelos slots. Disponibiliza
// window.simularCliqueNoCanvas(porcentagemX, porcentagemY) em todos os frames.
const __CANVAS_CLICK_SCRIPT = `(() => {
  try {
    if (window.__pandoraCanvasClickInstalled) return;
    window.__pandoraCanvasClickInstalled = true;
    function simularCliqueNoCanvas(porcentagemX, porcentagemY) {
      try {
        var canvas = document.getElementById('GameCanvas');
        if (!canvas) {
          try { console.log("-> [Pandora BOT] Erro: Elemento #GameCanvas não encontrado na página."); } catch(_){}
          return false;
        }
        var rect = canvas.getBoundingClientRect();
        var clienteX = rect.left + (rect.width * (porcentagemX / 100));
        var clienteY = rect.top + (rect.height * (porcentagemY / 100));
        try { console.log("-> [Pandora BOT] Disparando clique simulado no Canvas em: X=" + porcentagemX + "%, Y=" + porcentagemY + "%"); } catch(_){}
        var alvo = canvas;
        try { alvo = document.elementFromPoint(clienteX, clienteY) || canvas; } catch(_){}
        var opts = { clientX: clienteX, clientY: clienteY, bubbles: true, cancelable: true, composed: true, view: window, button: 0, buttons: 1 };
        try { alvo.dispatchEvent(new PointerEvent('pointerover', Object.assign({}, opts, { pointerType: 'touch', isPrimary: true }))); } catch(_){}
        try { alvo.dispatchEvent(new PointerEvent('pointermove', Object.assign({}, opts, { pointerType: 'touch', isPrimary: true }))); } catch(_){}
        try { alvo.dispatchEvent(new PointerEvent('pointerdown', Object.assign({}, opts, { pointerType: 'touch', isPrimary: true }))); } catch(_){}
        try {
          if (typeof Touch !== 'undefined' && typeof TouchEvent !== 'undefined') {
            var touch = new Touch({ identifier: 1, target: alvo, clientX: clienteX, clientY: clienteY, pageX: clienteX, pageY: clienteY });
            alvo.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, composed: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
            alvo.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, composed: true, touches: [], targetTouches: [], changedTouches: [touch] }));
          }
        } catch(_){}
        try { alvo.dispatchEvent(new PointerEvent('pointerup', Object.assign({}, opts, { pointerType: 'touch', isPrimary: true, buttons: 0 }))); } catch(_){}
        ['mousedown', 'mouseup', 'click'].forEach(function(tipoEvento) {
          try { alvo.dispatchEvent(new MouseEvent(tipoEvento, Object.assign({}, opts, { buttons: tipoEvento === 'mousedown' ? 1 : 0 }))); } catch(_){}
          try { if (alvo !== canvas) canvas.dispatchEvent(new MouseEvent(tipoEvento, Object.assign({}, opts, { buttons: tipoEvento === 'mousedown' ? 1 : 0 }))); } catch(_){}
        });
        return true;
      } catch(_) { return false; }
    }
    try { window.simularCliqueNoCanvas = simularCliqueNoCanvas; } catch(_){}
  } catch(e){}
})();`;

// TEMPORÁRIO (reinvestigação 2026-08-07): mesma ideia do __API_INSPECT_SCRIPT,
// mas pro escopo global de um Web Worker dedicado (self, não window — Worker
// não tem XMLHttpRequest nem document, só fetch/WebSocket/importScripts).
// Injetado direto na sessão CDP do worker (ver applyWorkerInspect em
// realChromeManager.cjs) — motivo: a captura de rede na página/iframe
// sempre parava logo depois do motor Cocos inicializar, sinal de que o
// jogo muda pra um Worker pra fazer rede/lógica a partir daí.
const __WORKER_INSPECT_SCRIPT = `(() => {
  try {
    if (self.__pandoraWorkerInspectInstalled) return;
    self.__pandoraWorkerInspectInstalled = true;
    console.log('[pandora-worker] inspetor instalado em worker, url=', self.location ? self.location.href : '?');
    if (self.fetch && !self.__pandoraWorkerFetchHooked) {
      self.__pandoraWorkerFetchHooked = true;
      var origFetch = self.fetch;
      self.fetch = function (...args) {
        var url = String(args[0] && args[0].url ? args[0].url : args[0]);
        var method = String((args[1] && args[1].method) || (args[0] && args[0].method) || 'GET');
        return origFetch.apply(this, args).then(function (res) {
          try {
            res.clone().text().then(function (t) { console.log('[pandora-worker] fetch ' + method + ' ' + url + ' =>', t.slice(0, 800)); }).catch(function () {});
          } catch (e) {}
          return res;
        });
      };
    }
    if (self.WebSocket && !self.__pandoraWorkerWSHooked) {
      self.__pandoraWorkerWSHooked = true;
      var NativeWS = self.WebSocket;
      self.WebSocket = function (...args) {
        console.log('[pandora-worker] NOVO WebSocket ->', args[0]);
        var ws = new NativeWS(...args);
        ws.addEventListener('open', function () { console.log('[pandora-worker] WS aberto'); });
        ws.addEventListener('close', function (e) { console.log('[pandora-worker] WS fechado', e.code, e.reason); });
        ws.addEventListener('message', function (ev) {
          try {
            var data = ev.data;
            if (data instanceof ArrayBuffer) { console.log('[pandora-worker] WS <= (binario, ' + data.byteLength + ' bytes)'); }
            else if (data instanceof Blob) { console.log('[pandora-worker] WS <= (blob, ' + data.size + ' bytes)'); }
            else { console.log('[pandora-worker] WS <=', String(data).slice(0, 500)); }
          } catch (e) {}
        });
        var origSend = ws.send.bind(ws);
        ws.send = function (data) {
          try {
            if (data instanceof ArrayBuffer) { console.log('[pandora-worker] WS => (binario, ' + data.byteLength + ' bytes)'); }
            else { console.log('[pandora-worker] WS =>', String(data).slice(0, 500)); }
          } catch (e) {}
          return origSend(data);
        };
        return ws;
      };
      self.WebSocket.prototype = NativeWS.prototype;
    }
  } catch (e) {
    try { console.log('[pandora-worker] erro:', e && e.message); } catch (e2) {}
  }
})();`;

// TEMPORÁRIO (investigação 2026-08-07): loga em console.log (com a tag
// [pandora-api], já capturada automaticamente pro arquivo de diagnóstico —
// ver console-message em realChromeManager.cjs) o tráfego de WebSocket/fetch
// e objetos suspeitos de window, tentando achar a função interna de
// aposta/spin de cada motor de jogo (Cocos/PixiJS), pra ver se dá pra
// apostar sem precisar simular clique. Remover depois que a investigação
// terminar (ver __API_INSPECT_SCRIPT nos pontos de injeção).
const __API_INSPECT_SCRIPT = `(() => {
  try {
    if (window.__pandoraApiInspectInstalled) return;
    window.__pandoraApiInspectInstalled = true;
    console.log('[pandora-api] inspetor instalado em', location.href);
    if (!window.__pandoraWSHooked) {
      window.__pandoraWSHooked = true;
      var NativeWS = window.WebSocket;
      window.WebSocket = function (...args) {
        console.log('[pandora-api] NOVO WebSocket ->', args[0]);
        var ws = new NativeWS(...args);
        ws.addEventListener('open', function () { console.log('[pandora-api] WS aberto'); });
        ws.addEventListener('close', function (e) { console.log('[pandora-api] WS fechado', e.code, e.reason); });
        ws.addEventListener('message', function (ev) {
          try {
            var data = ev.data;
            if (data instanceof ArrayBuffer) { console.log('[pandora-api] WS <= (binario, ' + data.byteLength + ' bytes)'); }
            else if (data instanceof Blob) { console.log('[pandora-api] WS <= (blob, ' + data.size + ' bytes)'); }
            else { console.log('[pandora-api] WS <=', String(data).slice(0, 500)); }
          } catch (e) {}
        });
        var origSend = ws.send.bind(ws);
        ws.send = function (data) {
          try {
            if (data instanceof ArrayBuffer) { console.log('[pandora-api] WS => (binario, ' + data.byteLength + ' bytes)'); }
            else { console.log('[pandora-api] WS =>', String(data).slice(0, 500)); }
          } catch (e) {}
          return origSend(data);
        };
        return ws;
      };
      window.WebSocket.prototype = NativeWS.prototype;
      window.WebSocket.CONNECTING = NativeWS.CONNECTING;
      window.WebSocket.OPEN = NativeWS.OPEN;
      window.WebSocket.CLOSING = NativeWS.CLOSING;
      window.WebSocket.CLOSED = NativeWS.CLOSED;
    }
    if (navigator.sendBeacon && !window.__pandoraBeaconHooked) {
      window.__pandoraBeaconHooked = true;
      var origBeacon = navigator.sendBeacon.bind(navigator);
      navigator.sendBeacon = function (url, data) {
        try { console.log('[pandora-api] sendBeacon ' + url + ' body=>', data ? String(data).slice(0, 500) : '(vazio)'); } catch (e) {}
        return origBeacon(url, data);
      };
    }
    // RTCPeerConnection — WebRTC data channel (última reinvestigação
    // 2026-08-07, técnica corrigida por-target). Loga criação de canal e
    // toda mensagem, entrada ou saída.
    if (window.RTCPeerConnection && !window.__pandoraRTCHooked) {
      window.__pandoraRTCHooked = true;
      var NativeRTC = window.RTCPeerConnection;
      var hookChannel = function (ch, label) {
        try {
          console.log('[pandora-api] RTC canal de dados criado/recebido:', label || ch.label);
          ch.addEventListener('open', function () { console.log('[pandora-api] RTC canal aberto:', label || ch.label); });
          ch.addEventListener('close', function () { console.log('[pandora-api] RTC canal fechado:', label || ch.label); });
          ch.addEventListener('message', function (ev) {
            try {
              var data = ev.data;
              if (data instanceof ArrayBuffer) console.log('[pandora-api] RTC <= (binario, ' + data.byteLength + ' bytes) canal=' + (label || ch.label));
              else console.log('[pandora-api] RTC <=', String(data).slice(0, 500), 'canal=' + (label || ch.label));
            } catch (e) {}
          });
          var origChSend = ch.send.bind(ch);
          ch.send = function (data) {
            try {
              if (data instanceof ArrayBuffer) console.log('[pandora-api] RTC => (binario, ' + data.byteLength + ' bytes) canal=' + (label || ch.label));
              else console.log('[pandora-api] RTC =>', String(data).slice(0, 500), 'canal=' + (label || ch.label));
            } catch (e) {}
            return origChSend(data);
          };
        } catch (e) {}
      };
      window.RTCPeerConnection = function (...args) {
        console.log('[pandora-api] NOVA RTCPeerConnection', JSON.stringify(args[0] || {}).slice(0, 300));
        var pc = new NativeRTC(...args);
        var origCreateDC = pc.createDataChannel.bind(pc);
        pc.createDataChannel = function (label, opts) {
          var ch = origCreateDC(label, opts);
          hookChannel(ch, label);
          return ch;
        };
        pc.addEventListener('datachannel', function (ev) { hookChannel(ev.channel); });
        return pc;
      };
      window.RTCPeerConnection.prototype = NativeRTC.prototype;
    }
    // WebTransport — protocolo mais novo, usado por alguns jogos "ao vivo"
    // no lugar de WebSocket. Loga datagrams e streams bidirecionais.
    if (window.WebTransport && !window.__pandoraWTHooked) {
      window.__pandoraWTHooked = true;
      var NativeWT = window.WebTransport;
      window.WebTransport = function (url, opts) {
        console.log('[pandora-api] NOVO WebTransport ->', url);
        var wt = new NativeWT(url, opts);
        wt.ready.then(function () { console.log('[pandora-api] WebTransport pronto ->', url); }).catch(function () {});
        try {
          var reader = wt.datagrams.readable.getReader();
          (function pump() {
            reader.read().then(function (r) {
              if (r.done) return;
              try { console.log('[pandora-api] WT datagram <= (' + r.value.byteLength + ' bytes)'); } catch (e) {}
              pump();
            }).catch(function () {});
          })();
        } catch (e) {}
        try {
          var streamReader = wt.incomingBidirectionalStreams.getReader();
          (function pumpStreams() {
            streamReader.read().then(function (r) {
              if (r.done) return;
              console.log('[pandora-api] WT stream bidirecional recebido');
              try {
                var sr = r.value.readable.getReader();
                (function pumpStreamData() {
                  sr.read().then(function (rr) {
                    if (rr.done) return;
                    try { console.log('[pandora-api] WT stream <= (' + rr.value.byteLength + ' bytes)'); } catch (e) {}
                    pumpStreamData();
                  }).catch(function () {});
                })();
              } catch (e) {}
              pumpStreams();
            }).catch(function () {});
          })();
        } catch (e) {}
        return wt;
      };
      window.WebTransport.prototype = NativeWT.prototype;
    }
    var isStaticAsset = function (url) {
      return /\.(png|jpe?g|webp|gif|bmp|mp3|ogg|wav|m4a|ttf|woff2?|eot|pvr|pkm|astc|atlas|plist|bin|wasm|ico|svg|css)(\\?|#|$)/i.test(url);
    };
    if (!window.__pandoraFetchNative) window.__pandoraFetchNative = window.fetch;
    if (!window.__pandoraFetchHooked2) {
      window.__pandoraFetchHooked2 = true;
      var origFetch = window.__pandoraFetchNative;
      window.__pandoraPatchedFetch = function (...args) {
        var url = String(args[0] && args[0].url ? args[0].url : args[0]);
        var method = String((args[1] && args[1].method) || (args[0] && args[0].method) || 'GET');
        return origFetch.apply(this, args).then(function (res) {
          try {
            if (!isStaticAsset(url)) {
              res.clone().text().then(function (t) { console.log('[pandora-api] fetch ' + method + ' ' + url + ' =>', t.slice(0, 800)); }).catch(function () {});
            }
          } catch (e) {}
          return res;
        });
      };
      window.fetch = window.__pandoraPatchedFetch;
    }
    // XMLHttpRequest — muitos motores mais antigos (Cocos 2.x) usam XHR em
    // vez de fetch. Loga URL/método na abertura e corpo da resposta ao
    // terminar, pra qualquer request que não pareça ser um asset estático.
    if (!window.__pandoraXhrHooked) {
      window.__pandoraXhrHooked = true;
      var OrigXHR = window.XMLHttpRequest;
      var origOpen = OrigXHR.prototype.open;
      var origSend = OrigXHR.prototype.send;
      window.__pandoraPatchedXhrOpen = function (method, url) {
        this.__pandoraMethod = method;
        this.__pandoraUrl = url;
        return origOpen.apply(this, arguments);
      };
      OrigXHR.prototype.open = window.__pandoraPatchedXhrOpen;
      window.__pandoraPatchedXhrSend = function (body) {
        try {
          var url = String(this.__pandoraUrl || '');
          if (!isStaticAsset(url)) {
            if (body) console.log('[pandora-api] XHR ' + this.__pandoraMethod + ' ' + url + ' body=>', String(body).slice(0, 500));
            this.addEventListener('load', function () {
              try {
                var rt = this.responseType;
                console.log('[pandora-api] XHR ' + this.__pandoraMethod + ' ' + url + ' status=' + this.status + ' responseType=' + JSON.stringify(rt));
                if (rt === '' || rt === 'text') {
                  console.log('[pandora-api] XHR ' + this.__pandoraMethod + ' ' + url + ' <=', String(this.responseText).slice(0, 1200));
                } else if (rt === 'json') {
                  console.log('[pandora-api] XHR ' + this.__pandoraMethod + ' ' + url + ' <= (json)', JSON.stringify(this.response).slice(0, 1200));
                  // Motor de giros via API pura (sem clicar em nada) —
                  // 2026-08-07. Mantém window.__pandoraApiState atualizado
                  // sempre que vê um GameInfo/Get (chamada que o próprio
                  // jogo dispara sozinho ao entrar, ANTES de qualquer giro —
                  // a resposta já traz o "sid" do último giro em
                  // dt.ls.si.sid, então não precisa de clique nenhum pra
                  // semear) ou um Spin (real, de clique, ou nosso). Expõe
                  // window.__pandoraApiSpinRun(count, opts) chamável de fora
                  // (via CDP/Puppeteer, ver realChromeManager.cjs) a
                  // qualquer momento depois que o estado estiver pronto.
                  try {
                    var st = window.__pandoraApiState = window.__pandoraApiState || {};
                    if (/\\/GameInfo\\/Get(\\?|$)/i.test(url) && body) {
                      var giParams = new URLSearchParams(String(body));
                      var giResp = this.response;
                      var lastSi = giResp && giResp.dt && giResp.dt.ls && giResp.dt.ls.si;
                      st.atk = giParams.get('atk') || st.atk;
                      st.pf = giParams.get('pf') || st.pf;
                      st.validCs = (giResp && giResp.dt && giResp.dt.cs) || st.validCs;
                      st.validMl = (giResp && giResp.dt && giResp.dt.ml) || st.validMl;
                      st.balance = (giResp && giResp.dt && giResp.dt.bl) || st.balance;
                      if (lastSi) {
                        st.spinUrl = st.spinUrl || url.replace(/\\/GameInfo\\/Get.*$/i, '/Spin');
                        st.sid = lastSi.sid || lastSi.psid || st.sid;
                        st.cs = lastSi.cs != null ? lastSi.cs : st.cs;
                        st.ml = lastSi.ml != null ? lastSi.ml : st.ml;
                        st.wk = lastSi.wk || st.wk;
                        st.btt = st.btt || '1';
                      }
                      console.log('[pandora-api] estado semeado via GameInfo/Get ->', JSON.stringify(st));
                    } else if (/\\/spin(\\?|$)/i.test(url) && body && String(body).indexOf('atk=') !== -1) {
                      var spParams = new URLSearchParams(String(body));
                      var spResp = this.response;
                      var spSi = spResp && spResp.dt && spResp.dt.si;
                      st.spinUrl = url;
                      st.atk = spParams.get('atk') || st.atk;
                      st.pf = spParams.get('pf') || st.pf;
                      st.wk = spParams.get('wk') || st.wk;
                      st.btt = spParams.get('btt') || st.btt;
                      st.cs = spParams.get('cs') || st.cs;
                      st.ml = spParams.get('ml') || st.ml;
                      if (spSi) { st.sid = spSi.sid || spSi.psid || st.sid; st.balance = spSi.bl != null ? spSi.bl : st.balance; }
                    }
                    if (!window.__pandoraApiSpinRun) {
                      // opts: { minBalance, delayMs, cs, ml } — todos opcionais.
                      window.__pandoraApiSpinRun = async function (count, opts) {
                        opts = opts || {};
                        var s = window.__pandoraApiState || {};
                        if (!s.spinUrl || !s.atk || !s.sid) {
                          console.log('[pandora-api-auto] ABORTADO: estado incompleto (ainda não capturou GameInfo/Get nem Spin nenhum) ->', JSON.stringify(s));
                          return { ok: false, reason: 'estado incompleto' };
                        }
                        var cs = opts.cs != null ? opts.cs : s.cs;
                        var ml = opts.ml != null ? opts.ml : s.ml;
                        var minBalance = opts.minBalance != null ? opts.minBalance : 0;
                        var delayMs = opts.delayMs != null ? opts.delayMs : 350;
                        var sid = s.sid;
                        var giros = 0, ganhoTotal = 0;
                        var slotSlug = opts.slotLabel || (function () { var m = /\\/game-api\\/([^\\/]+)\\//i.exec(s.spinUrl || ''); return m ? m[1] : 'slot'; })();
                        console.log('[pandora-api-auto] iniciando ' + count + ' giros encadeados cs=' + cs + ' ml=' + ml + ' minBalance=' + minBalance + ' sid inicial=' + sid);
                        for (var i = 0; i < count; i++) {
                          if (!sid) { console.log('[pandora-api-auto] parado no giro ' + (i + 1) + ': sem sid pra encadear'); break; }
                          try {
                            var p = new URLSearchParams();
                            p.set('cs', String(cs));
                            p.set('ml', String(ml));
                            p.set('pf', s.pf);
                            p.set('id', String(sid));
                            p.set('wk', s.wk);
                            p.set('btt', s.btt);
                            p.set('atk', s.atk);
                            var r = await fetch(s.spinUrl, {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                              body: p.toString(),
                              credentials: 'same-origin',
                            });
                            var t = await r.text();
                            var j = null; try { j = JSON.parse(t); } catch (e2) {}
                            var si = j && j.dt && j.dt.si;
                            var err = j && j.err;
                            var aw = si ? si.aw : 0;
                            var bl = si ? si.bl : null;
                            var zerado = bl != null && bl <= 0;
                            // BUG real 2026-08-10 (mesma classe do bug achado
                            // na PP/Plushie Wins: log mostrava "GIROS
                            // COMPLETOS" mas o Relatório de Apostas confere
                            // menos giros de verdade) — antes giros++ rodava
                            // SEMPRE que o fetch não lançasse exceção, mesmo
                            // sem "si" nenhum na resposta (sem err também,
                            // então nunca entrava no break — resposta vazia/
                            // inesperada contava como giro de verdade do
                            // mesmo jeito). Agora só conta como giro real
                            // quando "si" veio preenchido; sem isso é erro,
                            // não conta, e para o loop.
                            if (!si) { console.log('[pandora-api-auto] parado: resposta sem "si" (giro pode não ter sido registrado) ->', JSON.stringify(j)); break; }
                            giros++; ganhoTotal += (aw || 0);
                            console.log('[pandora-api-auto] giro ' + (i + 1) + '/' + count + ' status=' + r.status + ' aw=' + aw + ' bl=' + bl + ' err=' + JSON.stringify(err));
                            try { if (window.__pandoraApiSpinProgress) window.__pandoraApiSpinProgress({ slot: slotSlug, i: i + 1, count: count, aw: aw, bl: bl, err: err || null, zerado: zerado }); } catch (e3) {}
                            if (err) { console.log('[pandora-api-auto] parado: servidor retornou erro ->', JSON.stringify(j)); break; }
                            if (zerado) { console.log('[pandora-api-auto] parado: SALDO ZERADO (' + bl + ')'); break; }
                            if (bl != null) { st.balance = bl; if (bl < minBalance) { console.log('[pandora-api-auto] parado: saldo ' + bl + ' abaixo do mínimo ' + minBalance); break; } }
                            sid = si && (si.sid || si.psid);
                            if (sid) st.sid = sid;
                          } catch (e) {
                            console.log('[pandora-api-auto] ERRO no giro ' + (i + 1) + ':', e && e.message);
                            break;
                          }
                          if (i < count - 1) await new Promise(function (res) { setTimeout(res, delayMs); });
                        }
                        console.log('[pandora-api-auto] finalizado — giros=' + giros + '/' + count + ' ganhoTotal=' + ganhoTotal);
                        return { ok: true, giros: giros, ganhoTotal: ganhoTotal };
                      };
                    }
                  } catch (e) {}
                } else if (rt === 'arraybuffer' && this.response) {
                  var buf = new Uint8Array(this.response);
                  var hex = '';
                  for (var i = 0; i < Math.min(buf.length, 300); i++) hex += buf[i].toString(16).padStart(2, '0');
                  var asText = '';
                  try { asText = new TextDecoder('utf-8', { fatal: false }).decode(buf.slice(0, 400)); } catch (e2) {}
                  console.log('[pandora-api] XHR ' + this.__pandoraMethod + ' ' + url + ' <= (arraybuffer, ' + buf.length + ' bytes) hex=' + hex);
                  console.log('[pandora-api] XHR ' + this.__pandoraMethod + ' ' + url + ' <= (arraybuffer as text)', asText);
                } else if (rt === 'blob' && this.response) {
                  this.response.arrayBuffer().then(function (ab) {
                    var buf = new Uint8Array(ab);
                    var hex = '';
                    for (var i = 0; i < Math.min(buf.length, 300); i++) hex += buf[i].toString(16).padStart(2, '0');
                    console.log('[pandora-api] XHR ' + this.__pandoraMethod + ' ' + url + ' <= (blob, ' + buf.length + ' bytes) hex=' + hex);
                  }.bind(this)).catch(function () {});
                } else {
                  console.log('[pandora-api] XHR ' + this.__pandoraMethod + ' ' + url + ' <= (tipo desconhecido, sem captura)');
                }
              } catch (e) { try { console.log('[pandora-api] XHR resposta erro:', e && e.message); } catch (e2) {} }
            });
          }
        } catch (e) {}
        return origSend.apply(this, arguments);
      };
      OrigXHR.prototype.send = window.__pandoraPatchedXhrSend;
    }
    // Vigia contínuo: o motor do jogo (Cocos/etc.) pode sobrescrever fetch/
    // XHR com a própria versão depois de carregar (retry/CDN fallback/etc.),
    // derrubando nosso hook em silêncio — mesma causa raiz que quebrava o
    // speedhack. Evidência real: capturamos tráfego normalmente no início
    // (config/assets) e o log parava completamente pouco depois, mesmo com
    // o usuário continuando a jogar/apostar. Reaplica pra sempre, a cada 300ms.
    if (!window.__pandoraApiWatchdog) {
      window.__pandoraApiWatchdog = setInterval(function () {
        try {
          if (window.__pandoraPatchedFetch && window.fetch !== window.__pandoraPatchedFetch) window.fetch = window.__pandoraPatchedFetch;
          if (window.__pandoraPatchedXhrOpen && window.XMLHttpRequest.prototype.open !== window.__pandoraPatchedXhrOpen) window.XMLHttpRequest.prototype.open = window.__pandoraPatchedXhrOpen;
          if (window.__pandoraPatchedXhrSend && window.XMLHttpRequest.prototype.send !== window.__pandoraPatchedXhrSend) window.XMLHttpRequest.prototype.send = window.__pandoraPatchedXhrSend;
        } catch (e) {}
      }, 300);
    }
    // Varredura global RECURSIVA (armadilha #3 do Gemini — pedido explícito
    // do usuário 2026-08-07): a versão anterior só olhava as propriedades
    // DIRETAS de window (1 nível), então um "Game Manager" pendurado em
    // window.cc.director.getScene()... ou window.app.gameCtrl.spin nunca
    // seria achado. Agora desce alguns níveis, evita ciclos/DOM/funções
    // nativas, e roda PERIODICAMENTE (o objeto pode só existir depois do
    // motor terminar de montar a cena, bem depois dos 3s originais).
    var jaLogado = {};
    var scanDeep = function () {
      var candidatos = [];
      var visitados = new WeakSet();
      var RX = /spin(?!e)|bet|aposta|girar|wager|placebet|startgame|autoplay|sendaction|wallet|balance|saldo/i;
      var scan = function (obj, caminho, prof) {
        if (!obj || prof > 3) return;
        if (typeof obj !== 'object' && typeof obj !== 'function') return;
        if (obj === window || obj instanceof Node || obj instanceof Window) return;
        try { if (visitados.has(obj)) return; visitados.add(obj); } catch (e) { return; }
        var proto = null;
        try { proto = Object.getPrototypeOf(obj); } catch (e) {}
        var keys = [];
        try { keys = Object.getOwnPropertyNames(obj); } catch (e) {}
        var protoKeys = [];
        try { protoKeys = proto ? Object.getOwnPropertyNames(proto) : []; } catch (e) {}
        var hit = [].concat(keys, protoKeys).filter(function (m) { return RX.test(m); });
        if (hit.length) candidatos.push(caminho + ' -> [' + hit.join(', ') + ']');
        for (var i = 0; i < keys.length; i++) {
          var k = keys[i];
          if (/^(parent|top|window|self|frames|opener|document|location)$/.test(k)) continue;
          var v;
          try { v = obj[k]; } catch (e) { continue; }
          if (v && (typeof v === 'object' || typeof v === 'function') && !Array.isArray(v)) {
            scan(v, caminho + '.' + k, prof + 1);
          }
        }
      };
      try {
        var props = Object.getOwnPropertyNames(window);
        for (var j = 0; j < props.length; j++) {
          var k2 = props[j];
          try { scan(window[k2], k2, 0); } catch (e) {}
        }
      } catch (e) {}
      var novos = candidatos.filter(function (c) { return !jaLogado[c]; });
      novos.forEach(function (c) { jaLogado[c] = true; });
      if (novos.length) {
        console.log('[pandora-api] objetos candidatos NOVOS (metodos suspeitos):', novos.join(' | '));
      } else if (!window.__pandoraApiScanLoggedEmpty) {
        window.__pandoraApiScanLoggedEmpty = true;
        console.log('[pandora-api] varredura profunda: nenhum candidato ainda (' + candidatos.length + ' no total).');
      }
      try { if (window.cc && !window.__pandoraCcLogged) { window.__pandoraCcLogged = true; console.log('[pandora-api] motor Cocos detectado: cc.ENGINE_VERSION=' + (window.cc.ENGINE_VERSION || window.cc.VERSION || '?')); } } catch (e) {}
    };
    setTimeout(scanDeep, 3000);
    setInterval(scanDeep, 10000);
  } catch (e) { console.log('[pandora-api] erro no inspetor:', e && e.message); }
})();`;

// AUTO SLOT removido. Este script apenas limpa qualquer overlay/flag legado
// que tenha sido injetado por versões anteriores do app.
const __AUTO_SLOT_ENGINE_SCRIPT = `(() => {
  try {
    try { if (typeof window.pandoraPararAutoSlot === 'function') window.pandoraPararAutoSlot(); } catch(_){}
    try { window.pandoraPararAutoSlot = function(){}; } catch(_){}
    try { window.__pandoraAutoSlotEngineInstalled = true; } catch(_){}
    var alvos = [document];
    try { if (window.top && window.top.document && window.top.document !== document) alvos.push(window.top.document); } catch(_){}
    for (var i = 0; i < alvos.length; i++) {
      try {
        var d = alvos[i];
        var ov = d && d.getElementById && d.getElementById('__pandoraAutoSlotOverlay');
        if (ov && ov.parentNode) ov.parentNode.removeChild(ov);
      } catch(_){}
    }
  } catch(_){}
})();`;







// Liga os listeners de navegação para reinjetar/atualizar a barra
// Lógica de fato dos botões da toolbar (voltar/avançar/atualizar/nova guia) —
// extraída pra função nomeada no escopo do módulo pra poder ser chamada por
// DOIS caminhos: 1) o dispatch via console.log/title (janela Electron antiga)
// 2) diretamente via page.exposeFunction (Chrome real — ver realChromeManager.cjs),
// que não depende de console.log da página (sites de produção costumam
// desativá-lo, o que quebrava o único canal que existia antes).
function runToolbarNavCommand(win, cmd) {
  const wc = win.webContents;
  try {
    const url = wc.getURL() || "";
    console.log("[toolbar-nav] cmd=" + cmd + " from=" + url);
    if (cmd === "back") {
      const nh = wc.navigationHistory;
      const canBack = nh && typeof nh.canGoBack === "function" ? nh.canGoBack() : (wc.canGoBack && wc.canGoBack());
      if (canBack) { (nh && nh.goBack ? nh.goBack() : wc.goBack()); }
      else { try { wc.executeJavaScript("history.back()", true).catch(()=>{}); } catch {} }
    } else if (cmd === "fwd") {
      const nh = wc.navigationHistory;
      const canFwd = nh && typeof nh.canGoForward === "function" ? nh.canGoForward() : (wc.canGoForward && wc.canGoForward());
      if (canFwd) { (nh && nh.goForward ? nh.goForward() : wc.goForward()); }
      else { try { wc.executeJavaScript("history.forward()", true).catch(()=>{}); } catch {} }
    } else if (cmd === "reload") {
      try { wc.reload(); } catch { try { wc.executeJavaScript("location.reload()", true).catch(()=>{}); } catch {} }
    } else if (cmd === "home") {
      try {
        const u = new URL(url);
        const target = u.origin + "/";
        console.log("[toolbar-nav] home → " + target);
        wc.loadURL(target);
      } catch (e) {
        console.warn("[toolbar-nav] home falhou:", e && e.message);
      }
    } else if (cmd === "newtab") {
      try {
        // Lazy require (dependência circular). Chrome real "nativo" (janela
        // grande o bastante pra UI de verdade do Chrome) nunca chama isso —
        // não tem barra customizada, o botão "+" é o de verdade do Chrome e
        // já abre aba na mesma janela sozinho. Só sobra pro modo --app (sem
        // abas de verdade — ver openNewTabForWindow) e pro caminho Electron.
        if (win._realChrome) {
          const { openNewTabForWindow } = require("../window/realchrome/realChromeManager.cjs");
          openNewTabForWindow(win);
        } else {
          const { openNewTabForWindow } = require("../window/chromiumWindows.cjs");
          openNewTabForWindow(win);
        }
      } catch (e) {
        console.warn("[toolbar-nav] newtab falhou:", e && e.message);
      }
    }
  } catch (e) {
    console.warn("[toolbar-nav] erro:", e && e.message);
  }
}

// Pedido do usuário 2026-08-09 (5 telas abertas em "Relatório de Apostas":
// só a 1ª ficou parada, as outras 4 ficaram "bugando querendo mudar" e
// acabaram recarregando sozinhas) — "certifique-se de quando ir [pro
// relatório] é pra não clicar em absolutamente NADA". Os scripts de
// clique automático abaixo (__MANUAL_REG_SCRIPT, __SLOT_AUTOSTART_SCRIPT,
// __CANVAS_CLICK_SCRIPT, __AUTO_SLOT_ENGINE_SCRIPT) rodavam SEM NENHUMA
// checagem de URL, em QUALQUER página — inclusive na tela de Relatório,
// que tem suas próprias abas internas (reportCurrent=1/2...) com botões
// que podem coincidir com os seletores genéricos desses scripts,
// clicando/trocando de aba sozinho e deixando a tela instável. A tela de
// Relatório é só consulta — nunca precisa de nenhuma automação de
// clique, então é a mais segura pra excluir por completo.
const __isReportUrl = (url) => /\/home\/report\b/i.test(String(url || ""));

function attachBrowserToolbar(win) {
  if (!win || win.isDestroyed()) return;
  const wc = win.webContents;
  const apply = () => {
    injectBrowserToolbar(win);
    executeInAllFrames(wc, __ANTI_SCROLL_SNAP_SCRIPT);
    executeInAllFrames(wc, __NO_FULLSCREEN_SCRIPT);
    executeInAllFrames(wc, __SPEEDHACK_SCRIPT);
    __setSpeedInAllFrames(wc, __speedMultiplier);
    // Speedhack fica de fora do guard __isReportUrl abaixo de propósito —
    // já reseta pra 1x sozinho ao sair do slot (resetIfNotSlot, mais abaixo
    // neste arquivo), então pausar de novo aqui seria redundante (confirmado
    // pelo usuário 2026-08-09).
    let curUrl = "";
    try { curUrl = wc.getURL(); } catch {}
    if (!__isReportUrl(curUrl)) {
      executeInAllFrames(wc, __MANUAL_REG_SCRIPT);
      executeInAllFrames(wc, __CONTA_ID_SCRIPT);
      executeInAllFrames(wc, __SLOT_AUTOSTART_SCRIPT);
      executeInAllFrames(wc, __CANVAS_CLICK_SCRIPT);
      executeInAllFrames(wc, __AUTO_SLOT_ENGINE_SCRIPT);
    }
    try { applyAccountOverlay(win); } catch {}

  };
  const applyNoFs = () => {
    try { executeInAllFrames(wc, __ANTI_SCROLL_SNAP_SCRIPT); } catch {}
    try { executeInAllFrames(wc, __NO_FULLSCREEN_SCRIPT); } catch {}
    try { executeInAllFrames(wc, __SPEEDHACK_SCRIPT); } catch {}
    try { __setSpeedInAllFrames(wc, __speedMultiplier); } catch {}
  };
  wc.on("did-start-navigation", applyNoFs);
  wc.on("dom-ready", applyNoFs);
  wc.on("did-frame-finish-load", applyNoFs);
  wc.on("did-finish-load", apply);
  wc.on("did-frame-finish-load", apply);
  wc.on("did-navigate", apply);
  wc.on("did-navigate-in-page", apply);
  wc.on("dom-ready", apply);

  // Quando o usuário sai da página do slot (volta para o lobby ou navega
  // para outra rota), reseta o speedhack para 1x automaticamente.
  // BUG real 2026-08-23 (reportado: "speedhack desativa sozinho na PG"): os
  // slots PG Soft rodam num IFRAME que faz navegação interna (history/hash)
  // durante o jogo. did-navigate-in-page dispara TAMBÉM pra subframes, com a
  // URL do iframe (CDN da PG, sem "/home/embedded") — o que fazia o reset
  // achar que o usuário "saiu do slot" e voltar pra 1x no meio da jogada.
  // Agora só reseta em navegação do FRAME PRINCIPAL (isMainFrame). did-navigate
  // é sempre top-level (3º arg é o status HTTP, não isMainFrame), então segue;
  // did-navigate-in-page passa isMainFrame e é filtrado quando for subframe.
  const resetIfNotSlot = (_e, url, isMainFrame) => {
    try {
      if (isMainFrame === false) return;
      if (!__isSlotUrl(url)) __resetSpeedToDefault("saiu-do-slot");
    } catch (_) {}
  };
  wc.on("did-navigate", resetIfNotSlot);
  wc.on("did-navigate-in-page", resetIfNotSlot);

  // Pedido do usuário 2026-08-10 (reportado: giro 1394/1501 no Plushie Wins
  // deu "Runtime.evaluate timed out" no meio de uma sequência longa de Auto
  // Slot) — suspeita do usuário: a proxy (mais lenta/instável que conexão
  // direta sob volume alto e sustentado de requisições) cai no meio de
  // rodadas longas. Desliga a proxy automaticamente depois que a página do
  // slot termina de carregar — não na hora que entra (dá tempo dos assets
  // do jogo, que podem depender da proxy pra geo-liberação regional,
  // carregarem primeiro) — os giros do Auto Slot (fetch feito DENTRO da
  // própria página do jogo, não passa pelos launch args do Chrome) passam a
  // usar conexão direta a partir daí, mais estável sob volume alto. Só
  // afeta janelas de Chrome real com proxy toggleável (win._proxyToggle —
  // ver createToggleableProxyBridge em realChromeManager.cjs); Electron
  // legado não tem esse mecanismo, o if abaixo já filtra isso sozinho.
  let __pandoraSlotProxyTimer = null;
  const desligarProxyAoCarregarSlot = () => {
    try {
      if (!win._proxyToggle || typeof win._proxyToggle.setEnabled !== "function") return;
      const url = wc.getURL();
      if (!__isSlotUrl(url)) return;
      if (__pandoraSlotProxyTimer) return;
      __pandoraSlotProxyTimer = setTimeout(() => {
        __pandoraSlotProxyTimer = null;
        try {
          if (win._proxyToggle.isEnabled && win._proxyToggle.isEnabled()) {
            win._proxyToggle.setEnabled(false);
            console.log(`[proxy] desligada automaticamente após o slot carregar (tela ${win._pandoraOrder || "?"})`);
          }
        } catch {}
      }, 3000);
    } catch {}
  };
  wc.on("did-finish-load", desligarProxyAoCarregarSlot);
  // Restaura a proxy ao sair do slot (volta pro lobby/outra rota) — mantém
  // o comportamento configurado pra qualquer outra tela que não seja slot.
  const restaurarProxyAoSairDoSlot = (_e, url, isMainFrame) => {
    try {
      // Mesmo motivo do resetIfNotSlot: ignora navegação de subframe (iframe da
      // PG faz history interno) pra não religar a proxy no meio da jogada.
      if (isMainFrame === false) return;
      if (!win._proxyToggle || typeof win._proxyToggle.setEnabled !== "function") return;
      if (__isSlotUrl(url)) return;
      if (__pandoraSlotProxyTimer) { clearTimeout(__pandoraSlotProxyTimer); __pandoraSlotProxyTimer = null; }
      if (win._proxyToggle.isEnabled && !win._proxyToggle.isEnabled()) win._proxyToggle.setEnabled(true);
    } catch {}
  };
  wc.on("did-navigate", restaurarProxyAoSairDoSlot);
  wc.on("did-navigate-in-page", restaurarProxyAoSairDoSlot);


  // Injeta o NoFullscreen + SpeedHack assim que QUALQUER subframe (incluindo
  // iframes cross-origin do motor PG SOFT) é criado, antes do JS do jogo rodar.
  try {
    wc.on("frame-created", (_e, details) => {
      const frame = details && details.frame;
      if (!frame) return;
      const inject = () => {
        try { frame.executeJavaScript(__NO_FULLSCREEN_SCRIPT, true).catch(() => {}); } catch {}
        try { frame.executeJavaScript(__SPEEDHACK_SCRIPT, true).catch(() => {}); } catch {}
        try {
          const m = Math.max(1, Math.min(25, parseFloat(__speedMultiplier) || 1));
          frame.executeJavaScript(`(() => { try { window.__pandoraSpeedMultiplier = ${m}; } catch(e){} })();`, true).catch(() => {});
        } catch {}
        try { frame.executeJavaScript(__SLOT_AUTOSTART_SCRIPT, true).catch(() => {}); } catch {}
        try { frame.executeJavaScript(__CANVAS_CLICK_SCRIPT, true).catch(() => {}); } catch {}
        try { frame.executeJavaScript(__AUTO_SLOT_ENGINE_SCRIPT, true).catch(() => {}); } catch {}
      };
      inject();
      try { frame.once("dom-ready", inject); } catch {}
    });
  } catch {}

  // Bloqueia o pedido HTML5 de fullscreen em nível de Electron — o jogo PG SOFT
  // dispara isso assim que o canvas inicializa, o que expandiria a janela.
  try {
    wc.on("enter-html-full-screen", (e) => { try { e.preventDefault?.(); } catch {} try { win.setFullScreen(false); } catch {} });
    if (typeof win.setFullScreenable === "function") win.setFullScreenable(false);
  } catch {}

  // Comandos de navegação enviados pelos botões da toolbar.
  // Usamos DOIS canais para máxima confiabilidade:
  //   1) document.title = "__PANDORA_NAV__:<cmd>:<ts>"  → page-title-updated
  //   2) console.log("__PANDORA_NAV__:<cmd>")           → console-message
  // (Chrome real usa um TERCEIRO canal, mais robusto — ver runToolbarNavCommand:
  // page.exposeFunction, imune a sites que desativam console.log em produção.)
  if (!wc.__pandoraNavListener) {
    const handler = (cmd) => runToolbarNavCommand(win, cmd);
    const dispatch = (raw) => {
      if (typeof raw !== "string") return false;
      const i = raw.indexOf("__PANDORA_NAV__:");
      if (i < 0) return false;
      const rest = raw.slice(i + "__PANDORA_NAV__:".length).trim();
      const parts = rest.split(":");
      const cmd = parts[0];
      const ts = parseInt(parts[1] || "0", 10) || 0;
      const now = Date.now();
      // Descarta marcadores antigos (>2s) — protege contra títulos restaurados
      // pelo BFCache ao voltar/avançar, que poderiam re-disparar a navegação.
      if (ts && (now - ts) > 2000) {
        console.log("[toolbar-nav] descartado (stale) cmd=" + cmd + " age=" + (now - ts) + "ms");
        return true;
      }
      // Dedup: mesma janela + mesmo cmd + mesmo ts (canais title+console)
      const key = cmd + "|" + ts + "|" + (wc.id || 0);
      if (wc.__pandoraLastNavKey === key && (now - (wc.__pandoraLastNavAt || 0)) < 1500) return true;
      wc.__pandoraLastNavKey = key; wc.__pandoraLastNavAt = now;
      console.log("[toolbar-nav] dispatch cmd=" + cmd + " ts=" + ts);
      handler(cmd);
      return true;
    };
    const onTitle = (_event, title) => { try { dispatch(title); } catch {} };
    const onMsg = (event, levelOrMsg, maybeMsg) => {
      const message = (event && typeof event === "object" && "message" in event)
        ? event.message
        : (typeof maybeMsg === "string" ? maybeMsg : levelOrMsg);
      if (typeof message !== "string") return;
      // Captura logs do motor AUTO SLOT e grava no DIAG
      try {
        if (message.indexOf("[Pandora BOT]") >= 0 || message.indexOf("[AUTO SLOT]") >= 0) {
          const clean = message.replace(/^->\s*/, "").trim();
          fs.appendFileSync(getDiagFilePath(), `[${new Date().toISOString()}] [AUTO SLOT] ${clean}\r\n`, "utf8");
        }
      } catch {}
      if (dispatch(message)) return;
      if (message.startsWith("__PANDORA_MANUAL_REG__:")) {

        try {
          const payload = JSON.parse(message.slice("__PANDORA_MANUAL_REG__:".length));
          if (!payload || !payload.login || !payload.senha) return;
          const key = String(payload.login || "") + "|" + String(payload.senha || "");
          const now = Date.now();
          if (wc.__pandoraLastManualKey === key && (now - (wc.__pandoraLastManualAt || 0)) < 5000) return;
          wc.__pandoraLastManualKey = key;
          wc.__pandoraLastManualAt = now;
          let url = "";
          try { url = wc.getURL() || ""; } catch {}
          try {
            if (typeof saveAutoAccount === "function" && state.db) {
              const saved = saveAutoAccount(state.db, saveDB, state.dbPath, payload, url);
              console.log("[manual-reg] capturado login=" + payload.login + " saved=" + !!saved + " url=" + url);
              if (typeof persistAutoRegisterLog === "function") {
                persistAutoRegisterLog(state.db, saveDB, state.dbPath, "MANUAL_REG capturado", { login: payload.login, saved: !!saved, url });
              }
            }
          } catch (e) {
            console.warn("[manual-reg] falha salvando:", e && e.message);
          }
        } catch (e) {
          console.warn("[manual-reg] parse falhou:", e && e.message);
        }
        return;
      }
      if (message.startsWith("__PANDORA_CONTA_ID__:")) {
        try {
          const payload = JSON.parse(message.slice("__PANDORA_CONTA_ID__:".length));
          const contaId = payload && String(payload.id || "").trim();
          if (!contaId) return;
          // Dedup: mesmo ID na mesma janela em 10s
          const dkey = "cid|" + contaId + "|" + (wc.id || 0);
          const now = Date.now();
          if (wc.__pandoraLastContaKey === dkey && (now - (wc.__pandoraLastContaAt || 0)) < 10000) return;
          wc.__pandoraLastContaKey = dkey; wc.__pandoraLastContaAt = now;
          try {
            if (state.db) {
              const loginHint = payload.login ? String(payload.login).trim() : "";
              let target = null;
              if (loginHint) {
                const s = state.db.prepare("SELECT id, notes FROM accounts WHERE username=? ORDER BY id DESC LIMIT 1");
                s.bind([loginHint]); if (s.step()) target = s.getAsObject(); s.free();
              }
              if (!target) {
                // Última conta criada nos últimos 30 minutos
                const s2 = state.db.prepare("SELECT id, notes FROM accounts WHERE datetime(created_at) >= datetime('now','-30 minutes') ORDER BY id DESC LIMIT 1");
                if (s2.step()) target = s2.getAsObject(); s2.free();
              }
              if (!target) {
                console.log("[conta-id] ID=" + contaId + " — nenhuma conta recente para associar");
                return;
              }
              let notes = {};
              try { notes = JSON.parse(target.notes || "{}"); } catch {}
              if (notes.conta_id === contaId) {
                console.log("[conta-id] ID=" + contaId + " já vinculado à conta #" + target.id);
                return;
              }
              notes.conta_id = contaId;
              notes.conta_id_url = payload.url || "";
              const up = state.db.prepare("UPDATE accounts SET notes=?, updated_at=datetime('now') WHERE id=?");
              up.run([JSON.stringify(notes), target.id]); up.free();
              saveDB(state.db, state.dbPath).catch((e) => console.warn("[conta-id] saveDB falhou:", e?.message || e));
              console.log("[conta-id] vinculado ID=" + contaId + " → conta #" + target.id + " (login=" + (loginHint || "?") + ")");
              try {
                if (state.mainWin && !state.mainWin.isDestroyed()) {
                  state.mainWin.webContents.send("accounts:changed", { action: "conta-id", id: target.id, conta_id: contaId, via: "conta-id" });
                }
              } catch {}
            }
          } catch (e) { console.warn("[conta-id] falha vinculando:", e?.message || e); }
        } catch (e) { console.warn("[conta-id] parse falhou:", e && e.message); }
        return;
      }
    };
    wc.on("console-message", onMsg);
    wc.on("page-title-updated", onTitle);
    wc.__pandoraNavListener = onMsg;
  }
}







// ============ Modal PIX: maximizar QR Code ============
// Injeta CSS+JS em cada bot window para reorganizar o modal de depósito PIX:
// • QR Code passa a ocupar ~65% da altura do modal
// • Valor (R$ XX,XX) é movido para BAIXO do QR
// • Título/instrução fica ACIMA do QR

// Setters usados pelos handlers IPC (chrome:setAccountOverlay / chrome:setSpeedMultiplier)
// para alterar o estado interno deste módulo sem expor as variáveis diretamente.
function setAccountOverlayState(s) {
  __accountOverlayState = {
    enabled: !!s.enabled,
    login: String(s.login || ""),
    senha: String(s.senha || ""),
    senhaSaque: String(s.senhaSaque || ""),
  };
  return __accountOverlayState;
}
function getAccountOverlayState() { return __accountOverlayState; }
function setSpeedMultiplier(m) { __speedMultiplier = m; return __speedMultiplier; }
function getSpeedMultiplier() { return __speedMultiplier; }

// Ponto 3 do Gemini (2026-08-07), mas já com o alvo CERTO em vez de um
// palpite genérico: o dump do motor da WG (wg-dump/clientv3_assets_wcg_index.js)
// revelou o código-fonte real do botão de aposta:
//   a.requestBet = function () {
//     if (R.network.isConnect) {
//       var t = { betIdx: this.model.betIndex, betTimesIdx: this.model.betMultiple,
//                  autoInfo: this.model.autoInfo, clientBetValue: Math.abs(this.model.allArry) };
//       R.network.send(Y, t); // Y = {cmd:12101, route:"com_protocol.CommonElecBetReq"}
//     }
//   }
// PRIMEIRA tentativa (2026-08-07) chamava requestBet() direto — RESULTADO:
// servidor recusou (result:3055) porque model.allArry ainda era 0. Motivo
// achado no mesmo dump: quem de fato PREENCHE model.allArry/betIndex/
// betMultiple é o clique real no botão "Girar", num componente DIFERENTE
// (o controlador do próprio botão, não o WcgController):
//   l.onSpin = function () {
//     ...
//     var t = this._betInformations.get(this._betAmount);
//     k.model.allArry = this._betAmount;
//     k.model.betIndex = t.lineAamount;
//     k.model.betMultiple = t.multiple;
//     ...
//     p.emit(g.START_BET); // WcgController escuta esse evento -> requestBet()
//   }
// Ou seja: onSpin() é o alvo certo — ele preenche o model com o valor de
// aposta REALMENTE selecionado na tela (this._betAmount) e SÓ DEPOIS aciona
// o requestBet (via evento), exatamente como um clique de verdade faria.
// Procura esse método pelo nome exato na árvore de nós Cocos (mesma técnica
// de antes — componentes ficam em arrays node._components/node.children,
// que a varredura genérica de window pula de propósito). Só EXPÕE
// window.__pandoraWgBet() — não chama sozinho, dinheiro real está em jogo.
const __WG_SCENE_BET_FINDER_SCRIPT = `(() => {
  try {
    var log = function(m){ try { console.log('[pandora-wg] ' + m); } catch(e){} };
    // Varredura pura (sem guardar em closure) — extraída à parte pra poder
    // rodar TODA VEZ que __pandoraWgBet for chamado, não só uma vez no
    // início. BUG real (2026-08-08, achado pelo usuário): trocar de jogo
    // (ex.: PG -> WG, ou WG -> outro WG) SEM recarregar a página inteira
    // deixava a referência de componente antiga (found) presa num objeto
    // "morto" da cena anterior — _betInformations dele reflete o jogo
    // ERRADO (ou fica vazio), rejeitando um valor que na verdade é válido
    // no jogo atual. Buscar de novo a cada chamada garante que sempre
    // reflete o componente de VERDADE do jogo que está na tela agora.
    var findSpinComponent = function () {
      try {
        if (!window.cc || !window.cc.director || typeof window.cc.director.getScene !== 'function') return null;
        var scene = window.cc.director.getScene();
        if (!scene) return null;
        var found = null;
        var visited = new WeakSet();
        var walk = function (node, depth) {
          if (!node || found || depth > 60) return;
          try { if (visited.has(node)) return; visited.add(node); } catch(e){ return; }
          try {
            var comps = node._components || node.components || [];
            for (var i = 0; i < comps.length; i++) {
              var c = comps[i];
              // onSpin() é quem preenche o valor de aposta certo antes de
              // pedir o giro (ver comentário grande acima) — é o alvo
              // certo, não requestBet() (que só reenvia o que já estiver
              // no model, e pode estar zerado se nunca setado nessa sessão).
              if (c && typeof c.onSpin === 'function' && c._betInformations) { found = c; return; }
            }
          } catch (e) {}
          try {
            var kids = node.children || [];
            for (var j = 0; j < kids.length; j++) { walk(kids[j], depth + 1); if (found) return; }
          } catch (e) {}
        };
        walk(scene, 0);
        return found;
      } catch (e) { log('erro na varredura: ' + (e && e.message)); return null; }
    };
    if (!window.__pandoraWgBet) {
      // window.__pandoraWgBet(valor opcional): sem argumento, gira com o
      // valor já selecionado na tela (comportamento original). Com
      // argumento, força esse valor ANTES de girar — _betInformations é um
      // Map já populado (na hora que o jogo carrega) com TODA combinação
      // de aposta válida DAQUELE jogo (chave = valor em R$, valor =
      // {lineAamount, multiple}); trocar _betAmount pra uma chave que já
      // existe nesse Map é exatamente o que o onAddClick/onSubClick (+/-
      // da tela) fazem por baixo dos panos, então é seguro — só rejeita se
      // o valor pedido não for uma aposta que esse jogo realmente oferece.
      // Busca best-effort o saldo atual no MESMO componente que controla a
      // aposta (found) — jogos desse motor Cocos costumam guardar o saldo
      // do jogador ali perto, pra validar se a aposta cabe no saldo antes de
      // girar. Sem acesso ao código-fonte do jogo pra confirmar o nome exato
      // da propriedade, varre por padrão de NOME (coin/gold/balance/saldo/
      // money/wallet/score) com valor NUMÉRICO — loga os candidatos achados
      // (via [pandora-wg], que já cai no diag-auto-register.txt) pra dar pra
      // conferir/ajustar se pegar a propriedade errada (pedido do usuário
      // 2026-08-09: "Auto Slot rodando mas não mostra o saldo" no Lucky Dog).
      var findBalance = function (comp) {
        try {
          if (!comp) return null;
          var RX = /coin|gold|balance|saldo|money|wallet|score/i;
          var candidatos = [];
          for (var k in comp) {
            try {
              if (!RX.test(k)) continue;
              var v = comp[k];
              if (typeof v === 'number' && isFinite(v)) candidatos.push({ key: k, value: v });
            } catch (e) {}
          }
          if (!candidatos.length) return null;
          log('candidatos de saldo achados: ' + JSON.stringify(candidatos));
          return candidatos[0].value;
        } catch (e) { return null; }
      };
      window.__pandoraWgBet = function (valor) {
        try {
          var found = findSpinComponent();
          if (!found) return { ok: false, reason: 'botão de girar não encontrado na cena atual (jogo ainda carregando ou trocou de tela?)' };
          window.__pandoraWgBetCtrl = found;
          if (valor != null) {
            var alvo = Math.round(Number(valor) * 100) / 100;
            var bi = found._betInformations;
            if (!bi || typeof bi.has !== 'function' || !bi.has(alvo)) {
              var validos = bi && typeof bi.keys === 'function' ? Array.from(bi.keys()) : [];
              return { ok: false, reason: 'valor de aposta R$' + alvo.toFixed(2) + ' não existe nesse jogo', valoresValidos: validos };
            }
            found._betAmount = alvo;
          }
          found.onSpin();
          return { ok: true, betAmount: found._betAmount, balance: findBalance(found) };
        } catch (e) { return { ok: false, error: e && e.message }; }
      };
    }
    if (!window.__pandoraWgFinderHeartbeat) {
      window.__pandoraWgFinderHeartbeat = true;
      var tries = 0;
      var iv = setInterval(function () {
        tries++;
        var found = findSpinComponent();
        if (found) {
          // Sinal pro lado Node saber que já dá pra chamar __pandoraWgBet
          // (ver wg-check em realChromeManager.cjs) — não usa mais
          // __pandoraWgBetCtrl pra isso (esse só é setado DENTRO de uma
          // chamada de verdade agora, já que a busca virou sempre-fresca em
          // vez de cacheada — ver comentário grande acima).
          window.__pandoraWgFinderReady = true;
          var valoresDisponiveis = [];
          try { if (found._betInformations && typeof found._betInformations.keys === 'function') valoresDisponiveis = Array.from(found._betInformations.keys()); } catch (e) {}
          log('Botao de Girar achado na arvore da cena! window.__pandoraWgBet(valor?) disponivel. _betAmount atual=' + JSON.stringify(found._betAmount) + ' valores validos=' + JSON.stringify(valoresDisponiveis));
          try { clearInterval(iv); } catch (e) {}
        } else if (tries > 90) {
          try { clearInterval(iv); } catch (e) {}
        }
      }, 1000);
    }
  } catch (e) { try { console.log('[pandora-wg] erro fatal: ' + (e && e.message)); } catch (e2) {} }
})();`;

module.exports = {
  attachUrlAsTitle,
  showWindowMessage,
  executeInAllFrames,
  injectBrowserToolbar,
  applyAccountOverlay,
  applyAccountOverlayToTargets,
  attachBrowserToolbar,
  runToolbarNavCommand,
  __setSpeedInAllFrames,
  __isSlotUrl,
  __resetSpeedToDefault,
  setAccountOverlayState,
  getAccountOverlayState,
  setSpeedMultiplier,
  getSpeedMultiplier,
  // Exportados pra realChromeManager.cjs poder registrá-los via
  // page.evaluateOnNewDocument — ver comentário grande em wireNewPage.
  __SPEEDHACK_SCRIPT,
  __CANVAS_CLICK_SCRIPT,
  __API_INSPECT_SCRIPT, // TEMPORÁRIO — ver comentário na definição
  __WORKER_INSPECT_SCRIPT, // TEMPORÁRIO — ver comentário na definição
  __WG_SCENE_BET_FINDER_SCRIPT, // TEMPORÁRIO — ver comentário na definição
};
