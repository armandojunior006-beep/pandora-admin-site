import { useState } from "react";
import { Minus, Square, X, Minimize2, Maximize2, Pin } from "lucide-react";

// Barra de título custom — a janela é frameless (ver windowManager.cjs
// frame:false). Desenha minimizar / expandir(compacto) / maximizar / fechar,
// e um toggle "Fixar sempre a frente". A barra inteira é região de arrasto
// (-webkit-app-region: drag); os controles são no-drag.
const drag = { WebkitAppRegion: "drag" } as any;
const noDrag = { WebkitAppRegion: "no-drag" } as any;

export function TitleBar({
  compact,
  onToggleCompact,
  title,
  showCompact = true,
}: {
  compact: boolean;
  onToggleCompact: () => void;
  title: string;
  showCompact?: boolean;
}) {
  const [pinned, setPinned] = useState(false);
  const api = () => (window as any).api;

  async function togglePin() {
    const next = !pinned;
    setPinned(next);
    try { await api()?.winSetAlwaysOnTop?.(next); } catch {}
  }

  return (
    <div
      style={drag}
      className="relative flex items-center justify-between h-8 px-2 bg-black border-b border-border select-none shrink-0"
    >
      {/* Esquerda: fixar sempre a frente */}
      <button
        style={noDrag}
        onClick={togglePin}
        title="Fixar janela sempre a frente"
        className={`flex items-center gap-1 text-[11px] px-1.5 py-0.5 rounded ${
          pinned ? "text-warning" : "text-muted hover:text-white"
        }`}
      >
        <Pin className={`w-3.5 h-3.5 ${pinned ? "fill-warning" : ""}`} />
        <span className="hidden sm:inline">Fixar sempre a frente</span>
      </button>

      {/* Centro: título */}
      <div className="absolute left-1/2 -translate-x-1/2 text-[12px] font-semibold text-white/90 pointer-events-none">
        {title}
      </div>

      {/* Direita: controles de janela */}
      <div style={noDrag} className="flex items-center gap-0.5">
        <button onClick={() => api()?.winMinimize?.()} title="Minimizar"
          className="w-8 h-6 grid place-items-center text-muted hover:text-white hover:bg-white/10 rounded">
          <Minus className="w-4 h-4" />
        </button>
        {showCompact && (
          <button onClick={onToggleCompact} title={compact ? "Voltar ao tamanho normal" : "Modo compacto"}
            className="w-8 h-6 grid place-items-center text-muted hover:text-white hover:bg-white/10 rounded">
            {compact ? <Maximize2 className="w-3.5 h-3.5" /> : <Minimize2 className="w-3.5 h-3.5" />}
          </button>
        )}
        <button onClick={() => api()?.winToggleMaximize?.()} title="Maximizar"
          className="w-8 h-6 grid place-items-center text-muted hover:text-white hover:bg-white/10 rounded">
          <Square className="w-3.5 h-3.5" />
        </button>
        <button onClick={() => api()?.winClose?.()} title="Fechar"
          className="w-8 h-6 grid place-items-center text-muted hover:text-white hover:bg-danger rounded">
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
