// ============================================================================
// Atualização automática do app: baixa manifesto/pacote, verifica hash,
// extrai, aplica update de renderer/main/full e exibe as telas de splash de
// reinício. Extraído do main.cjs original sem alterar a lógica.
// ============================================================================
const { app, BrowserWindow } = require("electron");
const path = require("path");
const fs = require("fs");
const http = require("http");
const https = require("https");
const crypto = require("crypto");
const { spawn } = require("child_process");
const extractZip = require("extract-zip");
const { ROOT_DIR } = require("../paths.cjs");
const state = require("../state.cjs");
const { getSettingSync, setSettingSync } = require("../settings/settingsStore.cjs");

// app.exit() mata o processo NA HORA — ao contrário de app.quit(), ele NÃO
// dispara "before-quit"/"will-quit", que é onde flushSaveDB() roda hoje (ver
// main.cjs). Como saveDB() agora é debounced (~1.5s, ver db.cjs — mudança
// desta mesma sessão pra não travar a UI a cada log), um app.exit() logo
// depois de setSettingSync(...) podia matar o processo ANTES da gravação
// pendente ir pro disco — foi exatamente isso que fez "renderer_update_path"
// (limpo aqui embaixo, em relaunchMainUpdate, pra forçar o dist/ novo a ser
// usado) às vezes nunca chegar a ser salvo, deixando o app preso numa tela
// antiga em cache indefinidamente. Sempre usar isso no lugar de app.exit()
// direto depois de qualquer setSettingSync nesse fluxo de atualização.
function safeExit(code) {
  try { require("../../db.cjs").flushSaveDB(); } catch {}
  try { require("../../auto-register.cjs").flushDiagQueueSync(); } catch {}
  app.exit(code);
}

// URL padrão do manifesto de atualização (pode ser sobrescrita em settings ou via env).
// Migrado do domínio antigo (pandora-wonder-box.lovable.app, Lovable Cloud) para
// o nosso próprio painel — ver pandora-admin-site/public/updates/.
const DEFAULT_UPDATE_MANIFEST_URL = process.env.UPDATE_MANIFEST_URL || "https://pandora-admin-site.vercel.app/updates/latest.json";

function emitUpdateProgress(percent, message) {
  if (state.mainWin && !state.mainWin.isDestroyed()) state.mainWin.webContents.send("app:updateProgress", { percent, message });
}

function requestBuffer(url, onProgress) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith("http://") ? http : https;
    const req = client.get(url, { headers: { "User-Agent": `PandoraUpdater/${app.getVersion()}`, "Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache" } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode || 0) && res.headers.location) {
        res.resume();
        requestBuffer(new URL(res.headers.location, url).toString(), onProgress).then(resolve, reject);
        return;
      }
      if ((res.statusCode || 0) >= 400) {
        res.resume();
        reject(new Error(`Download falhou (${res.statusCode})`));
        return;
      }
      const total = parseInt(res.headers["content-length"] || "0", 10);
      const chunks = [];
      let received = 0;
      res.on("data", (chunk) => {
        chunks.push(chunk);
        received += chunk.length;
        if (total && onProgress) onProgress(received / total);
      });
      res.on("end", () => resolve(Buffer.concat(chunks)));
    });
    req.on("error", reject);
    req.setTimeout(60000, () => req.destroy(new Error("Tempo esgotado ao baixar atualização")));
  });
}

function compareBaseVersion(a, b) {
  const pa = String(a || "").split("+")[0].split(".").map((n) => parseInt(n, 10) || 0);
  const pb = String(b || "").split("+")[0].split(".").map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length, 3); i++) {
    const da = pa[i] || 0;
    const db = pb[i] || 0;
    if (da !== db) return da > db ? 1 : -1;
  }
  return 0;
}

function requestFile(url, destPath, onProgress, attempt = 1) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith("http://") ? http : https;
    const req = client.get(url, { headers: { "User-Agent": `PandoraUpdater/${app.getVersion()}`, "Cache-Control": "no-cache, no-store, must-revalidate", "Pragma": "no-cache" } }, (res) => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode || 0) && res.headers.location) {
        res.resume();
        requestFile(new URL(res.headers.location, url).toString(), destPath, onProgress, attempt).then(resolve, reject);
        return;
      }
      if ((res.statusCode || 0) >= 400) {
        res.resume();
        reject(new Error(`Download falhou (${res.statusCode})`));
        return;
      }
      const total = parseInt(res.headers["content-length"] || "0", 10);
      let received = 0;
      const out = fs.createWriteStream(destPath, { flags: "w" });
      res.on("data", (chunk) => {
        received += chunk.length;
        if (total && onProgress) onProgress(received / total, received, total);
      });
      res.pipe(out);
      out.on("finish", () => out.close(() => resolve({ received, total })));
      out.on("error", reject);
      res.on("error", reject);
    });
    req.on("error", reject);
    req.setTimeout(180000, () => req.destroy(new Error(`Tempo esgotado ao baixar atualização (tentativa ${attempt})`)));
  });
}

async function downloadUpdatePackage(url, zipPath, onProgress) {
  let lastError;
  for (let attempt = 1; attempt <= 5; attempt++) {
    try {
      try { fs.rmSync(zipPath, { force: true }); } catch {}
      if (attempt > 1) emitUpdateProgress(Math.max(15, Math.min(70, 15 + (attempt - 1) * 3)), `Retomando download (${attempt}/5)...`);
      await requestFile(url, zipPath, onProgress, attempt);
      const size = fs.statSync(zipPath).size;
      if (size < 1024) throw new Error("Arquivo de atualização incompleto");
      return;
    } catch (e) {
      lastError = e;
      try { fs.rmSync(zipPath, { force: true }); } catch {}
      if (attempt < 5) await new Promise((r) => setTimeout(r, 1500 * attempt));
    }
  }
  throw lastError || new Error("Não foi possível baixar a atualização");
}

async function requestJson(url) {
  const sep = url.includes("?") ? "&" : "?";
  const busted = url + sep + "_cb=" + Date.now();
  const buf = await requestBuffer(busted);
  return JSON.parse(buf.toString("utf8"));
}

function getManifestUrl() {
  return getSettingSync("update_manifest_url", DEFAULT_UPDATE_MANIFEST_URL);
}

function getUpdateId(manifest) {
  return String(manifest.buildId || manifest.version || manifest.url || "");
}

function findFirstExe(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isFile() && entry.name.toLowerCase().endsWith(".exe")) return p;
  }
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.isDirectory()) {
      const found = findFirstExe(path.join(dir, entry.name));
      if (found) return found;
    }
  }
  return null;
}

function resolveExtractRoot(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true }).filter((e) => !e.name.startsWith("."));
  if (entries.length === 1 && entries[0].isDirectory()) return path.join(dir, entries[0].name);
  return dir;
}

async function applyRendererUpdate(extractedRoot, updateId) {
  const rendererRoot = fs.existsSync(path.join(extractedRoot, "index.html")) ? extractedRoot : path.join(extractedRoot, "dist");
  if (!fs.existsSync(path.join(rendererRoot, "index.html"))) throw new Error("Pacote inválido: index.html não encontrado");
  const safeId = String(updateId || Date.now()).replace(/[^a-zA-Z0-9._-]/g, "_");
  const updatesDir = path.join(app.getPath("userData"), "renderer-updates", safeId);
  fs.rmSync(updatesDir, { recursive: true, force: true });
  fs.cpSync(rendererRoot, updatesDir, { recursive: true });
  await setSettingSync("renderer_update_path", updatesDir);
  await setSettingSync("renderer_update_id", String(updateId || safeId));
  await setSettingSync("renderer_update_app_version", app.getVersion());
}

function buildSplashHtml() {
  let logoDataUrl = "";
  try {
    const logoPath = path.join(ROOT_DIR, "assets", "logo.png");
    if (fs.existsSync(logoPath)) {
      logoDataUrl = "data:image/png;base64," + fs.readFileSync(logoPath).toString("base64");
    }
  } catch {}
  const logoTag = logoDataUrl
    ? `<img src="${logoDataUrl}" alt="Spider BOT" class="logo"/>`
    : "";
  return `<!doctype html><html><head><meta charset="utf-8"/><title>Spider BOT</title>
<style>
html,body{margin:0;padding:0;height:100%;width:100%;font-family:'Segoe UI',Arial,sans-serif;background:#000;color:#fff;display:flex;align-items:center;justify-content:center;overflow:hidden;-webkit-user-select:none;user-select:none;}
.box{text-align:center;padding:32px 56px;}
.logo{display:block;margin:0 auto 26px;max-width:320px;max-height:220px;width:auto;height:auto;object-fit:contain;}
.spinner{width:64px;height:64px;border:5px solid #1f1f1f;border-top-color:#3b82f6;border-radius:50%;margin:0 auto 22px;animation:spin 1s linear infinite;}
@keyframes spin{to{transform:rotate(360deg);}}
h1{margin:0 0 8px;font-size:20px;font-weight:600;letter-spacing:.2px;}
p{margin:0;color:#9ca3af;font-size:13px;}
</style></head><body><div class="box">${logoTag}<div class="spinner"></div><h1>Aguarde, o BOT está reiniciando</h1><p>Aplicando atualização...</p></div></body></html>`;
}

function showRestartSplash() {
  try {
    try {
      for (const w of BrowserWindow.getAllWindows()) {
        try { w.hide(); } catch {}
      }
    } catch {}
    const dataUrl = "data:text/html;charset=utf-8," + encodeURIComponent(buildSplashHtml());
    state.restartSplashWin = new BrowserWindow({
      width: 560,
      height: 420,
      frame: false,
      resizable: false,
      movable: false,
      minimizable: false,
      maximizable: false,
      closable: false,
      alwaysOnTop: true,
      skipTaskbar: false,
      show: false,
      transparent: false,
      backgroundColor: "#000000",
      title: "Spider BOT",
      webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
    });
    state.restartSplashWin.setMenuBarVisibility(false);
    state.restartSplashWin.once("ready-to-show", () => {
      try { state.restartSplashWin.show(); state.restartSplashWin.focus(); } catch {}
    });
    state.restartSplashWin.loadURL(dataUrl);
  } catch (e) {
    try { console.error("[restart-splash]", e); } catch {}
  }
}

const STARTUP_SPLASH_MIN_MS = 0;
function showStartupSplash() {
  try {
    state.startupSplashShownAt = Date.now();
    const dataUrl = "data:text/html;charset=utf-8," + encodeURIComponent(buildSplashHtml());
    state.startupSplashWin = new BrowserWindow({
      width: 560,
      height: 420,
      frame: false,
      resizable: false,
      movable: false,
      minimizable: false,
      maximizable: false,
      closable: false,
      alwaysOnTop: true,
      skipTaskbar: false,
      show: false,
      transparent: false,
      backgroundColor: "#000000",
      title: "Spider BOT",
      webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
    });
    state.startupSplashWin.setMenuBarVisibility(false);
    state.startupSplashWin.once("ready-to-show", () => {
      try { state.startupSplashWin.show(); state.startupSplashWin.focus(); } catch {}
    });
    state.startupSplashWin.loadURL(dataUrl);
  } catch (e) {
    try { console.error("[startup-splash]", e); } catch {}
  }
}
function closeStartupSplash() {
  // Respeita tempo mínimo de exibição (mesmo que o renderer carregue rápido)
  if (!state.startupSplashWin || state.startupSplashWin.isDestroyed?.()) {
    state.startupSplashWin = null;
    return;
  }
  const elapsed = Date.now() - state.startupSplashShownAt;
  const remaining = Math.max(0, STARTUP_SPLASH_MIN_MS - elapsed);
  setTimeout(() => {
    try {
      if (state.startupSplashWin && !state.startupSplashWin.isDestroyed()) {
        state.startupSplashWin.destroy();
      }
    } catch {}
    state.startupSplashWin = null;
  }, remaining);
}


// jobs: [{ srcDir, dstDir }, ...] — um ou mais pares copiados em sequência
// antes do relaunch (ex.: electron/ + dist/ juntos num update "main", pra UI
// e backend nunca ficarem dessincronizados entre um update e outro).
// Aceita também a forma antiga { srcDir, dstDir } (um único par) por compat.
// job.verify (opcional): lista de nomes de arquivo (relativos a dstDir) que
// PRECISAM existir e não estar vazios depois da cópia pra considerar essa
// etapa bem-sucedida — normalmente os CRITICAL_FILES (main.cjs, preload.cjs,
// security.cjs, auto-register.cjs) + integrity.json. Sem isso: se a cópia
// falhar NO MEIO (arquivo travado por antivírus/OneDrive sincronizando/
// processo antigo ainda de pé), o app relança mesmo assim com um mix de
// arquivo novo+velho — na melhor das hipóteses a checagem de integridade
// recusa abrir (main.cjs.orig comentava "o app se recusa a abrir" nesse
// caso), na pior o próprio resources/app fica inconsistente o bastante pro
// Electron nem achar o que carregar (tela padrão do Electron, sem nosso
// app — foi exatamente isso que aconteceu numa atualização real). Com
// verify: faz backup do destino ANTES de copiar; se a verificação falhar
// depois, restaura o backup por cima (volta pra versão antiga que já
// funcionava) antes de relançar — nunca deixa o usuário preso numa
// instalação quebrada.
function buildVbsRelauncher(opts) {
  const jobs = Array.isArray(opts.jobs) ? opts.jobs : [{ srcDir: opts.srcDir, dstDir: opts.dstDir, verify: opts.verify }];
  const { tmpRoot } = opts;
  const vbs = (value) => String(value || "").replace(/"/g, '""');
  const stamp = Date.now();
  const scriptPath = path.join(app.getPath("temp"), `pandora-update-${stamp}.vbs`);
  const jobLines = jobs
    .filter((j) => j && j.srcDir && j.dstDir)
    .map((j, i) => {
      const lines = [
        `src${i} = "${vbs(j.srcDir)}"`,
        `dst${i} = "${vbs(j.dstDir)}"`,
        `bak${i} = dst${i} & ".pandora-bak"`,
        `If fso.FolderExists(bak${i}) Then fso.DeleteFolder bak${i}, True`,
        `If fso.FolderExists(dst${i}) Then CopyTree dst${i}, bak${i}`,
        `CopyTree src${i}, dst${i}`,
      ];
      const verifyList = Array.isArray(j.verify) ? j.verify : null;
      if (verifyList && verifyList.length) {
        lines.push(`ok${i} = True`);
        for (const name of verifyList) {
          lines.push(`chk = fso.BuildPath(dst${i}, "${vbs(name)}")`);
          lines.push(`If (Not fso.FileExists(chk)) Then ok${i} = False Else If fso.GetFile(chk).Size = 0 Then ok${i} = False`);
        }
        lines.push(`If Not ok${i} Then`);
        lines.push(`  LogLine "verificacao falhou apos copiar dst${i} - restaurando backup"`);
        lines.push(`  If fso.FolderExists(bak${i}) Then CopyTree bak${i}, dst${i}`);
        lines.push(`End If`);
      }
      lines.push(`If fso.FolderExists(bak${i}) Then fso.DeleteFolder bak${i}, True`);
      return lines.join("\r\n");
    });
  const logPath = vbs(path.join(app.getPath("temp"), "pandora-update-log.txt"));
  const script = [
    "On Error Resume Next",
    "Set sh = CreateObject(\"WScript.Shell\")",
    "Set fso = CreateObject(\"Scripting.FileSystemObject\")",
    `exe = "${vbs(process.execPath)}"`,
    // Em modo dev (npm start, não empacotado), process.execPath é o
    // electron.exe genérico de node_modules — sem apontar pra pasta do
    // app ele abre a telinha padrão do Electron ("path-to-app") em vez de
    // relançar nosso app. No app empacotado de verdade isso não é
    // necessário (o .exe já sabe onde estão os recursos dele).
    `appArg = "${app.isPackaged ? "" : vbs(app.getAppPath())}"`,
    `pid = "${vbs(process.pid)}"`,
    `tmp = "${vbs(tmpRoot)}"`,
    `Sub LogLine(msg)`,
    `  Dim lf : Set lf = fso.OpenTextFile("${logPath}", 8, True)`,
    `  lf.WriteLine "[" & Now & "] " & msg`,
    `  lf.Close`,
    `End Sub`,
    "Set svc = GetObject(\"winmgmts:\\\\.\\root\\cimv2\")",
    "If Err.Number <> 0 Then",
    "  Err.Clear",
    "  WScript.Sleep 5000",
    "Else",
    "  For i = 1 To 120",
    "    Set procs = svc.ExecQuery(\"Select ProcessId From Win32_Process Where ProcessId=\" & pid)",
    "    If Err.Number <> 0 Then Err.Clear: Exit For",
    "    If procs.Count = 0 Then Exit For",
    "    WScript.Sleep 1000",
    "  Next",
    "End If",
    "Sub CopyTree(a, b)",
    "  If Not fso.FolderExists(b) Then fso.CreateFolder(b)",
    "  For Each fil In fso.GetFolder(a).Files",
    "    fso.CopyFile fil.Path, fso.BuildPath(b, fil.Name), True",
    "  Next",
    "  For Each fol In fso.GetFolder(a).SubFolders",
    "    CopyTree fol.Path, fso.BuildPath(b, fol.Name)",
    "  Next",
    "End Sub",
    "LogLine \"iniciando atualizacao\"",
    ...jobLines,
    "LogLine \"copia/verificacao concluida\"",
    `Set f = fso.CreateTextFile("${vbs(path.join(app.getPath("temp"), "pandora-post-update.flag"))}", True)`,
    "f.WriteLine \"1\"",
    "f.Close",
    "qt = Chr(34)",
    "cmd = qt & exe & qt",
    "If appArg <> \"\" Then cmd = cmd & \" \" & qt & appArg & qt",
    "sh.Run cmd, 1, False",
    "LogLine \"relancado \" & exe",
    "If tmp <> \"\" And fso.FolderExists(tmp) Then fso.DeleteFolder tmp, True",
    "WScript.Quit 0",
  ].join("\r\n");
  fs.writeFileSync(scriptPath, script, "utf8");
  const wscript = path.join(process.env.SystemRoot || "C:\\Windows", "System32", "wscript.exe");
  spawn(fs.existsSync(wscript) ? wscript : "wscript.exe", ["//B", "//Nologo", scriptPath], { detached: true, stdio: "ignore", windowsHide: true }).unref();
}

function relaunchFullUpdate(extractedRoot, newVersion) {
  const sourceRoot = resolveExtractRoot(extractedRoot);
  if (!findFirstExe(sourceRoot)) throw new Error("Pacote inválido: executável não encontrado");
  buildVbsRelauncher({
    srcDir: sourceRoot,
    dstDir: path.dirname(process.execPath),
    tmpRoot: path.dirname(extractedRoot),
  });
}

// Main-update: copia apenas os .cjs + integrity.json para o diretório
// <install>/resources/app/electron/ (= __dirname). Zip pequeno (~50KB),
// download rápido. Não troca .exe nem renderer.
function relaunchMainUpdate(extractedRoot) {
  const sourceRoot = resolveExtractRoot(extractedRoot);
  // Aceita zip com arquivos soltos OU dentro de uma pasta "electron/"
  const inner = fs.existsSync(path.join(sourceRoot, "electron")) && fs.statSync(path.join(sourceRoot, "electron")).isDirectory()
    ? path.join(sourceRoot, "electron")
    : sourceRoot;
  if (!fs.existsSync(path.join(inner, "integrity.json"))) {
    throw new Error("Pacote main-update inválido: integrity.json ausente");
  }
  // Confere ANTES de disparar qualquer cópia que o pacote baixado realmente
  // contém os arquivos críticos — pega um publish malformado (esqueceu de
  // incluir algum arquivo) sem nunca chegar a mexer na instalação atual.
  const MAIN_UPDATE_CRITICAL = ["main.cjs", "preload.cjs", "security.cjs", "auto-register.cjs", "integrity.json"];
  for (const name of MAIN_UPDATE_CRITICAL) {
    if (!fs.existsSync(path.join(inner, name))) {
      throw new Error(`Pacote main-update inválido: ${name} ausente`);
    }
  }
  // verify: se a cópia falhar no meio (arquivo travado, disco cheio, etc.),
  // restaura o backup automático ANTES de relançar — nunca deixa o usuário
  // preso numa instalação quebrada (ver comentário grande em buildVbsRelauncher).
  const jobs = [{ srcDir: inner, dstDir: ROOT_DIR, verify: MAIN_UPDATE_CRITICAL }]; // <install>/resources/app/electron/
  // Pacote pode incluir opcionalmente um "dist/" (renderer) irmão do "electron/"
  // — copia junto pro <install>/resources/app/dist/ pra UI e backend nunca
  // ficarem em versões diferentes entre si num mesmo update.
  const distSrc = path.join(sourceRoot, "dist");
  if (fs.existsSync(path.join(distSrc, "index.html"))) {
    jobs.push({ srcDir: distSrc, dstDir: path.join(path.dirname(ROOT_DIR), "dist"), verify: ["index.html"] });
    // Uma atualização de renderer aplicada ANTES desta (renderer_update_path,
    // salva em userData) tem prioridade em loadMain() sobre o dist/ recém-
    // copiado quando a versão do app não mudou — limpa pra garantir que o
    // dist/ novo (que acabamos de copiar) realmente entre em uso.
    try {
      setSettingSync("renderer_update_path", "");
      setSettingSync("renderer_update_id", "");
      setSettingSync("renderer_update_app_version", "");
    } catch {}
  }
  // Pacote pode incluir opcionalmente um "node_modules/" irmão de "electron/"
  // — dependências NPM novas que o app instalado ainda não tem (ex.: quando
  // um update adiciona uma lib nova). Copia por cima de resources/app/node_modules/
  // sem apagar o que já existe lá (CopyTree só adiciona/sobrescreve).
  const nmSrc = path.join(sourceRoot, "node_modules");
  if (fs.existsSync(nmSrc)) {
    jobs.push({ srcDir: nmSrc, dstDir: path.join(path.dirname(ROOT_DIR), "node_modules") });
  }
  // 2026-08-20: corrige o ícone dos atalhos (branco/quebrado em instalações
  // antigas — ver histórico do icon.ico) sobrescrevendo <install>/app.ico,
  // que é exatamente o arquivo que os .lnk já apontam via IconLocation. Não
  // precisa passar pelo relauncher VBS (não é arquivo em uso pelo processo,
  // nem exige o app fechado) — copyFileSync direto já é visível pro Explorer.
  try {
    const newIcon = path.join(inner, "assets", "icon.ico");
    const installRoot = path.dirname(path.dirname(path.dirname(ROOT_DIR))); // <install>
    if (fs.existsSync(newIcon)) fs.copyFileSync(newIcon, path.join(installRoot, "app.ico"));
  } catch {}
  buildVbsRelauncher({ jobs, tmpRoot: path.dirname(extractedRoot) });
}

async function installLatestUpdate() {
  if (state.updateInProgress) return { ok: false, error: "Atualização já está em andamento" };
  state.updateInProgress = true;
  let tempRoot = "";
  try {
    emitUpdateProgress(5, "Verificando versão...");
    const manifestUrl = getManifestUrl();
    const manifest = await requestJson(manifestUrl);
    const packageUrl = manifest.url || manifest.packageUrl || manifest.rendererUrl;
    const updateId = getUpdateId(manifest);
    const currentId = getSettingSync("renderer_update_id", app.getVersion());
    if (!packageUrl) return { ok: false, error: "Manifesto sem URL do pacote" };
    const manifestBase = String(manifest.version || "").split("+")[0];
    const currentBase = String(app.getVersion() || "").split("+")[0];
    const baseIsNewer = manifestBase && compareBaseVersion(manifestBase, currentBase) > 0;
    const sameUpdate = Boolean(updateId && updateId === currentId);
    if (!baseIsNewer && sameUpdate) {
      return { ok: true, hasUpdate: false, version: manifest.version || app.getVersion(), note: "Você já está na última versão" };
    }
    if (!baseIsNewer && manifest.version && compareBaseVersion(manifestBase, currentBase) < 0) {
      return { ok: true, hasUpdate: false, version: app.getVersion(), note: "Você já está na última versão" };
    }

    emitUpdateProgress(15, "Baixando atualização...");
    tempRoot = fs.mkdtempSync(path.join(app.getPath("temp"), "pandora-update-"));
    const zipPath = path.join(tempRoot, "update.zip");
    const rawPackageUrl = new URL(packageUrl, manifestUrl).toString();
    const cbSep = rawPackageUrl.includes("?") ? "&" : "?";
    const packageDownloadUrl = rawPackageUrl + cbSep + "_cb=" + Date.now();
    await downloadUpdatePackage(packageDownloadUrl, zipPath, (progress) => {
      emitUpdateProgress(15 + Math.round(progress * 55), "Baixando atualização...");
    });
    if (manifest.sha256) {
      emitUpdateProgress(72, "Verificando arquivo...");
      const hash = crypto.createHash("sha256").update(fs.readFileSync(zipPath)).digest("hex");
      if (hash.toLowerCase() !== String(manifest.sha256).toLowerCase()) throw new Error("Arquivo de atualização corrompido");
    }

    const extractDir = path.join(tempRoot, "package");
    emitUpdateProgress(75, "Extraindo arquivos...");
    await extractZip(zipPath, { dir: extractDir });

    const extractedRoot = resolveExtractRoot(extractDir);
    const isMainUpdate = manifest.type === "main";
    const isFullUpdate = !isMainUpdate && (manifest.type === "full" || manifest.type === "portable" || (findFirstExe(extractedRoot) && manifest.type !== "renderer"));
    emitUpdateProgress(88, "Aplicando atualização...");
    if (isMainUpdate) {
      showRestartSplash();
      relaunchMainUpdate(extractDir);
      emitUpdateProgress(100, "Reiniciando aplicativo...");
      setTimeout(() => safeExit(0), 2000);
      return { ok: true, hasUpdate: true, version: manifest.version, restarting: true };
    }
    if (isFullUpdate) {
      // Mostra splash "Aguarde, o BOT está reiniciando" no processo atual,
      // antes de disparar o relauncher externo.
      showRestartSplash();
      relaunchFullUpdate(extractDir, manifest.version);
      emitUpdateProgress(100, "Reiniciando aplicativo...");
      // Dá tempo da splash renderizar antes de matar o processo
      setTimeout(() => safeExit(0), 2000);
      return { ok: true, hasUpdate: true, version: manifest.version, restarting: true };
    }

    await applyRendererUpdate(extractedRoot, updateId || Date.now());
    try { fs.rmSync(tempRoot, { recursive: true, force: true }); } catch {}

    emitUpdateProgress(100, "Aplicando nova versão...");
    // Recarrega a janela com o novo renderer (sem precisar reiniciar o processo)
    setTimeout(() => {
      try {
        const newPath = getSettingSync("renderer_update_path", "");
        if (state.mainWin && !state.mainWin.isDestroyed() && newPath && fs.existsSync(path.join(newPath, "index.html"))) {
          // Preserva o estado/tamanho da janela ao recarregar a UI nova
          const wasMaximized = state.mainWin.isMaximized();
          const wasFullScreen = state.mainWin.isFullScreen();
          const prevBounds = state.mainWin.getBounds();
          state.mainWin.loadFile(path.join(newPath, "index.html"));
          state.mainWin.webContents.once("did-finish-load", () => {
            try {
              if (wasFullScreen) state.mainWin.setFullScreen(true);
              else if (wasMaximized) state.mainWin.maximize();
              else state.mainWin.setBounds(prevBounds);
            } catch {}
          });
        } else {
          app.relaunch();
          safeExit(0);
        }
      } catch {
        try { app.relaunch(); safeExit(0); } catch {}
      }
    }, 700);
    return { ok: true, hasUpdate: true, version: manifest.version, restarting: true };
  } catch (e) {
    try { if (tempRoot) fs.rmSync(tempRoot, { recursive: true, force: true }); } catch {}
    emitUpdateProgress(0, "Falha na atualização");
    return { ok: false, error: e?.message || String(e) };
  } finally {
    state.updateInProgress = false;
  }
}


module.exports = {
  emitUpdateProgress,
  requestBuffer,
  requestFile,
  compareBaseVersion,
  downloadUpdatePackage,
  requestJson,
  getManifestUrl,
  getUpdateId,
  findFirstExe,
  resolveExtractRoot,
  applyRendererUpdate,
  buildSplashHtml,
  showRestartSplash,
  showStartupSplash,
  closeStartupSplash,
  buildVbsRelauncher,
  relaunchFullUpdate,
  relaunchMainUpdate,
  installLatestUpdate,
  DEFAULT_UPDATE_MANIFEST_URL,
};
