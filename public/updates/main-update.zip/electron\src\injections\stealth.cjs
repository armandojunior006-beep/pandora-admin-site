// ============================================================================
// Anti-detecção (stealth): spoof de navigator/screen/WebGL/etc + device metrics
// + carregamento da extensão local de captcha (pasta extensions/).
// ============================================================================
const path = require("path");
const fs = require("fs");
const { ROOT_DIR } = require("../paths.cjs");
const { STEALTH_UA } = require("./mobileProfiles.cjs");

function getDeviceMetrics(profile) {
  if (!profile) return { w: 1920, h: 1080, dpr: 1 };
  const n = String(profile.name || "");
  // iOS — CSS pixels (point) + DPR comum
  if (profile.os === "ios") {
    if (/15 Pro Max|14 Pro Max/.test(n)) return { w: 430, h: 932, dpr: 3 };
    if (/15 Pro|15\b|14 Pro|14\b/.test(n)) return { w: 393, h: 852, dpr: 3 };
    if (/13 Pro Max/.test(n)) return { w: 428, h: 926, dpr: 3 };
    if (/13|12 Pro|12\b/.test(n)) return { w: 390, h: 844, dpr: 3 };
    if (/11 Pro|XR|11\b/.test(n)) return { w: 414, h: 896, dpr: 2 };
    if (/SE/.test(n)) return { w: 375, h: 667, dpr: 2 };
    return { w: 390, h: 844, dpr: 3 };
  }
  // Android
  if (/S24 Ultra|S23 Ultra|Note 20|ROG/.test(n)) return { w: 412, h: 915, dpr: 3.5 };
  if (/Pixel 8 Pro|Pixel 7 Pro/.test(n)) return { w: 412, h: 892, dpr: 3 };
  if (/Pixel 8|Pixel 7|Pixel 6a/.test(n)) return { w: 412, h: 915, dpr: 2.625 };
  if (/S24|S23|OnePlus 11|Xiaomi 13|Edge 40/.test(n)) return { w: 384, h: 854, dpr: 3 };
  if (/A54|A34|Moto G84|Nord 3|GT Neo|Redmi|Poco/.test(n)) return { w: 393, h: 873, dpr: 2.75 };
  return { w: 412, h: 915, dpr: 2.625 };
}

// Monta o script de stealth (spoof de navigator/screen/WebGL/etc) como texto
// puro, sem depender de nenhuma BrowserWindow do Electron — reaproveitado
// tanto por applyStealth (janela Electron, via win.webContents.executeJavaScript)
// quanto pelo Chrome real via CDP (realchrome/realChromeManager.cjs, via
// page.evaluateOnNewDocument), que precisam do MESMO texto de script, só
// injetado por mecanismos diferentes.
function buildStealthScript(profile, uaOverride) {
  const ua = profile ? profile.ua : (uaOverride || STEALTH_UA);
  const isMobile = !!profile;
  // ATENÇÃO: NÃO emulamos touch via CDP, NÃO mexemos em viewport/dimensão da janela,
  // NÃO alteramos lógica de cliques. Apenas spoofamos identidade do navegador.
  const platform = profile ? profile.platform : "Win32";
  const vendor = profile ? profile.vendor : "Google Inc.";
  const chromeVer = (ua.match(/Chrome\/(\d+)/) || [, "126"])[1];
  const metrics = getDeviceMetrics(profile);
  // Hardware coerente por SO
  const hwConc = profile && profile.os === "ios" ? 6 : 8;
  const devMem = profile && profile.os === "ios" ? 6 : 8;
  // Connection (4G por padrão)
  const conn = { effectiveType: "4g", type: "cellular", downlink: 8 + Math.random() * 4, rtt: 50 + Math.floor(Math.random() * 80), saveData: false };
  const payload = JSON.stringify({
    isMobile,
    platform,
    vendor,
    deviceName: profile ? profile.name : "",
    os: profile ? profile.os : "win",
    chromeVer,
    sw: metrics.w, sh: metrics.h, dpr: metrics.dpr,
    hwConc, devMem, conn,
  });
  const stealthJs = `
    (function(){ try {
      var __p = ${payload};
      // 1) navigator.webdriver — sempre undefined (anti-bot)
      try { Object.defineProperty(Navigator.prototype, 'webdriver', { get: () => undefined, configurable: true }); } catch(e){}
      try { delete Object.getPrototypeOf(navigator).webdriver; } catch(e){}
      // 2) idiomas naturais
      try { Object.defineProperty(navigator, 'languages', { get: () => ['pt-BR','pt','en-US','en'] }); } catch(e){}
      try { Object.defineProperty(navigator, 'language',  { get: () => 'pt-BR' }); } catch(e){}
      // 3) plataforma e vendor coerentes com o SO simulado
      try { Object.defineProperty(navigator, 'platform', { get: () => __p.platform }); } catch(e){}
      try { Object.defineProperty(navigator, 'vendor',   { get: () => __p.vendor   }); } catch(e){}
      // 4) plugins/mimeTypes não-vazios (Headless deixa vazio)
      try { Object.defineProperty(navigator, 'plugins',   { get: () => [1,2,3,4,5] }); } catch(e){}
      // 5) chrome runtime presente (fingerprint padrão)
      window.chrome = window.chrome || {};
      window.chrome.runtime = window.chrome.runtime || {};
      // 6) Permissions API: notifications coerente
      var origQuery = window.navigator.permissions && window.navigator.permissions.query;
      if (origQuery) {
        window.navigator.permissions.query = (p) => p && p.name === 'notifications'
          ? Promise.resolve({ state: Notification.permission })
          : origQuery(p);
      }
      // 7) WebGL vendor/renderer plausíveis (anti-fingerprint) — cobre WebGL1 e WebGL2,
      //    e também a extensão WEBGL_debug_renderer_info (UNMASKED_VENDOR/RENDERER).
      try {
        var iosVendor = 'Apple Inc.', iosRender = 'Apple GPU';
        var andVendor = 'Qualcomm',   andRender = 'Adreno (TM) 740';
        function fakeGet(p, orig){
          // 37445=UNMASKED_VENDOR_WEBGL, 37446=UNMASKED_RENDERER_WEBGL
          if (p === 37445 || p === 0x9245) return __p.os === 'ios' ? iosVendor : andVendor;
          if (p === 37446 || p === 0x9246) return __p.os === 'ios' ? iosRender : andRender;
          // VENDOR (7936) / RENDERER (7937) base
          if (p === 7936) return 'WebKit';
          if (p === 7937) return __p.os === 'ios' ? 'WebKit WebGL' : 'WebKit WebGL';
          return orig.apply(this, arguments);
        }
        if (window.WebGLRenderingContext) {
          var g1 = WebGLRenderingContext.prototype.getParameter;
          WebGLRenderingContext.prototype.getParameter = function(p){ return fakeGet.call(this, p, g1); };
        }
        if (window.WebGL2RenderingContext) {
          var g2 = WebGL2RenderingContext.prototype.getParameter;
          WebGL2RenderingContext.prototype.getParameter = function(p){ return fakeGet.call(this, p, g2); };
        }
      } catch(e){}
      // 8) userAgentData (somente Android Chrome expõe; iOS Safari não tem)
      if (__p.isMobile && __p.os !== 'ios') {
        try {
          Object.defineProperty(navigator, 'userAgentData', { get: () => ({
            mobile: true, platform: 'Android',
            brands: [
              { brand: 'Chromium',     version: __p.chromeVer },
              { brand: 'Not.A/Brand',  version: '24' },
              { brand: 'Google Chrome',version: __p.chromeVer },
            ],
            getHighEntropyValues: () => Promise.resolve({
              mobile: true, platform: 'Android', architecture: 'arm', model: __p.deviceName
            }),
          })});
        } catch(e){}
      } else if (__p.isMobile && __p.os === 'ios') {
        try { Object.defineProperty(navigator, 'userAgentData', { get: () => undefined }); } catch(e){}
      }
      // 9) Suprime diálogos nativos do site (alert/confirm/prompt).
      try {
        window.alert = function(msg){ try { console.log('[pandora][alert-suprimido]', msg); } catch(e){} };
        window.confirm = function(msg){ try { console.log('[pandora][confirm-suprimido]', msg); } catch(e){} return true; };
        window.prompt = function(msg){ try { console.log('[pandora][prompt-suprimido]', msg); } catch(e){} return null; };
      } catch(e){}
      // ===== Spoofs adicionais MOBILE (não afetam layout/cliques) =====
      if (__p.isMobile) {
        // 10) screen.* coerente com o aparelho
        try {
          var sDef = function(k, v){ try { Object.defineProperty(screen, k, { get: () => v, configurable: true }); } catch(e){} };
          sDef('width',       __p.sw);
          sDef('height',      __p.sh);
          sDef('availWidth',  __p.sw);
          sDef('availHeight', __p.sh);
          sDef('colorDepth',  24);
          sDef('pixelDepth',  24);
          if (screen.orientation) {
            try { Object.defineProperty(screen.orientation, 'type', { get: () => 'portrait-primary', configurable: true }); } catch(e){}
            try { Object.defineProperty(screen.orientation, 'angle', { get: () => 0, configurable: true }); } catch(e){}
          }
        } catch(e){}
        // 11) devicePixelRatio plausível (NÃO mexe em innerWidth/innerHeight para não quebrar layout)
        try { Object.defineProperty(window, 'devicePixelRatio', { get: () => __p.dpr, configurable: true }); } catch(e){}
        // 12) Touch — maxTouchPoints + ontouchstart presente
        try { Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 5, configurable: true }); } catch(e){}
        try { if (!('ontouchstart' in window)) { window.ontouchstart = null; } } catch(e){}
        try {
          if (typeof TouchEvent === 'undefined') {
            window.TouchEvent = function TouchEvent(){};
          }
        } catch(e){}
        // 13) matchMedia — hover/pointer/coarse coerentes com mobile
        try {
          var origMM = window.matchMedia.bind(window);
          window.matchMedia = function(q){
            var s = String(q || '');
            var m = function(v){ return { matches: v, media: s, onchange: null, addListener:function(){}, removeListener:function(){}, addEventListener:function(){}, removeEventListener:function(){}, dispatchEvent:function(){return false;} }; };
            if (/\\(hover:\\s*none\\)/.test(s))       return m(true);
            if (/\\(hover:\\s*hover\\)/.test(s))      return m(false);
            if (/\\(pointer:\\s*coarse\\)/.test(s))   return m(true);
            if (/\\(pointer:\\s*fine\\)/.test(s))     return m(false);
            if (/\\(any-pointer:\\s*coarse\\)/.test(s)) return m(true);
            return origMM(q);
          };
        } catch(e){}
        // 14) Hardware coerente
        try { Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => __p.hwConc, configurable: true }); } catch(e){}
        try { Object.defineProperty(navigator, 'deviceMemory',        { get: () => __p.devMem, configurable: true }); } catch(e){}
        // 15) Network Information API (Android expõe, iOS não)
        if (__p.os !== 'ios') {
          try {
            var connObj = { effectiveType: __p.conn.effectiveType, type: __p.conn.type, downlink: __p.conn.downlink, rtt: __p.conn.rtt, saveData: __p.conn.saveData, addEventListener:function(){}, removeEventListener:function(){}, dispatchEvent:function(){return false;} };
            Object.defineProperty(navigator, 'connection', { get: () => connObj, configurable: true });
          } catch(e){}
        }
        // 16) DeviceMotion / DeviceOrientation — apenas presença dos construtores
        try {
          if (typeof DeviceMotionEvent === 'undefined')      window.DeviceMotionEvent      = function DeviceMotionEvent(){};
          if (typeof DeviceOrientationEvent === 'undefined') window.DeviceOrientationEvent = function DeviceOrientationEvent(){};
          // iOS expõe requestPermission estático
          if (__p.os === 'ios') {
            try { window.DeviceMotionEvent.requestPermission      = function(){ return Promise.resolve('granted'); }; } catch(e){}
            try { window.DeviceOrientationEvent.requestPermission = function(){ return Promise.resolve('granted'); }; } catch(e){}
          }
        } catch(e){}
        // 17) Battery API — valores plausíveis (alguns sites checam presença)
        try {
          if (navigator.getBattery) {
            var fakeBat = { charging: false, chargingTime: Infinity, dischargingTime: 12000, level: 0.78, addEventListener:function(){}, removeEventListener:function(){}, dispatchEvent:function(){return false;} };
            navigator.getBattery = function(){ return Promise.resolve(fakeBat); };
          }
        } catch(e){}
        // 18) navigator.standalone (iOS Safari property)
        if (__p.os === 'ios') {
          try { Object.defineProperty(navigator, 'standalone', { get: () => false, configurable: true }); } catch(e){}
        }
      }
    } catch(e){} })();
  `;
  return { ua, js: stealthJs };
}

function applyStealth(win, opts) {
  // Se a janela tiver um perfil mobile já anexado (window._pandoraMobileProfile),
  // ele tem prioridade. Caso contrário, usa o passado em opts ou STEALTH_UA.
  const profile = (win && win._pandoraMobileProfile) || (opts && opts.profile) || null;
  const { ua, js: stealthJs } = buildStealthScript(profile, opts && opts.ua);
  const ses = win.webContents.session;
  try { ses.setUserAgent(ua); } catch {}
  try { win.webContents.setUserAgent(ua); } catch {}
  // Injeta cedo (antes de scripts da página) e re-injeta a cada navegação.
  const inject = () => {
    try { win.webContents.executeJavaScript(stealthJs, true).catch(() => {}); } catch {}
  };
  win.webContents.on("did-start-navigation", inject);
  win.webContents.on("dom-ready", inject);
  win.webContents.on("did-frame-finish-load", inject);
}

async function loadCaptchaExtension(ses) {
  const extDir = path.join(ROOT_DIR, "extensions");
  if (!fs.existsSync(extDir)) return;
  let entries = [];
  try { entries = fs.readdirSync(extDir, { withFileTypes: true }); } catch { return; }
  for (const ent of entries) {
    if (!ent.isDirectory()) continue;
    const p = path.join(extDir, ent.name);
    if (!fs.existsSync(path.join(p, "manifest.json"))) continue;
    try {
      await ses.loadExtension(p, { allowFileAccess: true });
      console.log("[ext] carregada:", ent.name);
    } catch (e) {
      console.warn("[ext] falha em", ent.name, ":", e?.message || e);
    }
  }
}

module.exports = { getDeviceMetrics, buildStealthScript, applyStealth, loadCaptchaExtension };
