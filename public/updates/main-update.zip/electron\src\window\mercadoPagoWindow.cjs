// ============================================================================
// MERCADO PAGO — pedido do usuário 2026-08-10, depois de ver como o bot do
// amigo dele faz isso (pasta "Mercado_Pago" do outro bot, inspecionada com
// autorização do usuário): lá, cada "conta" é um login de verdade no site do
// Mercado Pago (com sessão salva) usado como FONTE das chaves PIX — "Copiar
// Chaves" importa as chaves PIX cadastradas naquela conta MP pro banco de
// dados do bot (mesma tabela pix_keys que "Nova chave"/"Importar arquivo" já
// usam em ChavesPix.tsx), e "Deletar Chaves" exclui as chaves da conta MP no
// site de verdade (ex.: pra liberar de novo depois de usadas).
//
// Diferença de arquitetura em relação ao bot do amigo (mais simples e mais
// robusto): o outro bot usa Playwright com perfil EFêMERO por execução,
// então precisa exportar/reimportar cookies manualmente a cada abertura.
// Aqui, cada conta MP tem seu próprio --user-data-dir PERSISTENTE (igual um
// perfil normal do Chrome) — loga uma vez manualmente (e-mail/senha/2FA) e o
// próprio Chrome mantém a sessão nas próximas aberturas, sem precisar
// exportar/injetar cookie nenhum.
//
// IMPORTANTE — escopo desta primeira versão: a navegação até a página de
// chaves PIX e a extração/exclusão usam seletores baseados em TEXTO
// (resistentes a pequenas mudanças de classe CSS, mesmo padrão usado em
// pixFlowV2.cjs/autoLogin.cjs), mas foram escritos SEM acesso ao site real
// do Mercado Pago nesta sessão — é esperado precisar de 1-2 rodadas de
// ajuste depois do primeiro teste real do usuário (mesmo processo iterativo
// já usado pra login/PIX/saque no site de apostas). Todo passo loga no
// diagnóstico pra isso ser rápido de corrigir.
// ============================================================================
const fs = require("fs");
const path = require("path");
const { ensureChromeBinary } = require("./realchrome/chromeBinary.cjs");
const { createToggleableProxyBridge } = require("../proxy/toggleableBridge.cjs");
const { getTargetDisplay } = require("./windowManager.cjs");
const state = require("../state.cjs");
const smsApi = require("./smsProviderApi.cjs");

function log(msg) {
  try {
    const { queueDiagLine } = require("../../auto-register.cjs");
    queueDiagLine(`[${new Date().toISOString()}] [MP] ${msg}\r\n`);
  } catch {}
  try { console.log(`[MP] ${msg}`); } catch {}
}

// id (numérico ou string escolhido pelo front) -> { browser, page, proxyBridge }
const janelasAbertas = new Map();

function profileDirFor(id) {
  const { app } = require("electron");
  const dir = path.join(app.getPath("userData"), "mp-profiles", String(id));
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}

// BUG real 2026-08-10 (reportado pelo usuário: "The browser is already
// running for ...mp-profiles\<id>. Use a different userDataDir or stop the
// running browser first") — durante o desenvolvimento o app inteiro é
// reiniciado com frequência (redeploy), mas isso só mata o processo
// PandoraBot.exe — o Chrome dessa conta (processo separado, aberto pelo
// puppeteer) continuava rodando de verdade, com a janela ainda na tela.
// O app reiniciado perdia a referência em memória (janelasAbertas, um Map
// que não sobrevive a reiniciar o processo) e, ao clicar em qualquer ação,
// tentava LANÇAR um Chrome novo apontando pro MESMO --user-data-dir — que o
// Chrome já aberto tinha travado (SingletonLock), gerando esse erro exato.
// Fix: salva o wsEndpoint (URL de WebSocket do CDP) num arquivo dentro do
// próprio perfil da conta sempre que abre com sucesso; antes de tentar
// lançar um Chrome novo, tenta RECONECTAR nesse endpoint salvo primeiro —
// se o Chrome ainda estiver de pé (era exatamente esse o caso), reconecta
// nele em vez de tentar abrir outro (que sempre falharia com esse erro).
function wsEndpointFileFor(userDataDir) {
  return path.join(userDataDir, ".pandora-mp-ws-endpoint");
}

function notificarJanelaFechada(id) {
  try {
    if (state.mainWin && !state.mainWin.isDestroyed()) {
      state.mainWin.webContents.send("mp:janelaFechada", { id: String(id) });
    }
  } catch {}
}

// Pedido do usuário 2026-08-11: "proibida ir para essa URL
// .../acessibilidade/feedback, ele estava excluindo chave e foi pra essa
// URL, corrija!" — antes só detectávamos DEPOIS que já tinha navegado pra
// lá (só no meio do loop de deletarChaves, num ponto específico); o Mercado
// Pago pode mandar pra essa página de feedback em outros momentos também
// (não só depois de excluir chave). Agora um listener fica de olho em
// QUALQUER navegação do frame principal da janela — se cair nessa URL,
// volta pro hub de Pix na hora, antes mesmo de qualquer outro código
// perceber. Anexado uma única vez por página (guardado em __pandoraBlindado
// pra não empilhar listener a cada getOuAbrirJanela).
function blindarContraPaginaFeedback(page, id) {
  if (page.__pandoraBlindadoFeedback) return;
  page.__pandoraBlindadoFeedback = true;
  page.on("framenavigated", (frame) => {
    if (frame !== page.mainFrame()) return;
    if (!/\/acessibilidade\/feedback/i.test(frame.url())) return;
    log(`conta ${id}: bloqueado — site tentou ir pra página de feedback (${frame.url()}), voltando pro hub de Pix`);
    page.goto("https://www.mercadopago.com.br/pix/home/hub", { waitUntil: "domcontentloaded", timeout: 15000 }).catch(() => {});
  });
}

async function getOuAbrirJanela({ id, proxy }) {
  const existente = janelasAbertas.get(String(id));
  if (existente && existente.browser && existente.browser.isConnected && existente.browser.isConnected()) {
    try { await existente.page.bringToFront(); } catch {}
    return existente;
  }
  if (existente) janelasAbertas.delete(String(id));

  const { default: puppeteer } = await import("puppeteer-core");
  const execPath = await ensureChromeBinary();
  const userDataDir = profileDirFor(id);
  const wsFile = wsEndpointFileFor(userDataDir);

  // Tenta reconectar num Chrome que já esteja de pé pra essa conta (ver
  // comentário grande acima) antes de tentar lançar um novo.
  if (fs.existsSync(wsFile)) {
    const wsSalvo = (() => { try { return fs.readFileSync(wsFile, "utf8").trim(); } catch { return ""; } })();
    if (wsSalvo) {
      try {
        const browser = await puppeteer.connect({ browserWSEndpoint: wsSalvo, defaultViewport: null });
        const pages = await browser.pages();
        const page = pages[0] || (await browser.newPage());
        const entry = { browser, page, proxyBridge: null };
        janelasAbertas.set(String(id), entry);
        blindarContraPaginaFeedback(page, id);
        browser.on("disconnected", () => {
          janelasAbertas.delete(String(id));
          try { fs.rmSync(wsFile, { force: true }); } catch {}
          log(`conta ${id}: janela fechada`);
          notificarJanelaFechada(id);
        });
        try { await page.bringToFront(); } catch {}
        log(`conta ${id}: reconectado num Chrome que já estava aberto (endpoint salvo)`);
        return entry;
      } catch (e) {
        log(`conta ${id}: endpoint salvo não respondeu (${e?.message || e}) — era um Chrome já fechado, abrindo um novo`);
        try { fs.rmSync(wsFile, { force: true }); } catch {}
      }
    }
  }

  const target = getTargetDisplay();
  const area = target.workArea || { x: 0, y: 0, width: 1280, height: 800 };
  // Janela estreita tipo "celular" (mesma proporção usada no bot do amigo,
  // ~339x628) — o site do Mercado Pago é responsivo e mostra a versão mobile
  // nesse tamanho, mais simples de automatizar que a versão desktop.
  const w = 360, h = 720;
  // Pedido do usuário 2026-08-11: "quando o MP abre, a janela abre na
  // direita, faça abrir no meio da tela" — antes calculava encostado na
  // borda direita (area.width - w - 40); agora centraliza nos dois eixos
  // dentro da área útil do monitor de destino.
  const x = Math.round(area.x + (area.width - w) / 2);
  const y = Math.round(area.y + (area.height - h) / 2);

  // BUG real 2026-08-10 (reportado pelo usuário: abria com 2 abas, e cada
  // ciclo de Pause+Play abria MAIS uma) — a URL era passada como argumento
  // de linha de comando do Chrome: isso faz o PRÓPRIO Chrome abrir uma aba
  // pra ela, AO MESMO TEMPO que o profile (perfil persistente por conta,
  // ver profileDirFor) pode restaurar aba(s) da sessão anterior se o
  // fechamento não tiver sido 100% "limpo" — acumulando aba a cada ciclo.
  // "page" acabava rastreando a aba ERRADA (a primeira, geralmente em
  // branco/restaurada), não a que o Chrome abriu pra mercadopago.com.br —
  // por isso "Salvar Login" checava uma aba diferente da que o usuário via
  // logada na tela. Fix: nunca passa URL no launch — sempre abre uma página
  // NOVA explicitamente (via newPage()) e fecha qualquer aba que tenha
  // vindo sozinha (em branco ou restaurada), garantindo sempre exatamente
  // UMA aba, sempre a certa.
  const args = [
    `--window-size=${w},${h}`,
    `--window-position=${x},${y}`,
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-blink-features=AutomationControlled",
    "--disable-session-crashed-bubble",
    "--hide-crash-restore-bubble",
  ];

  let proxyBridge = null;
  if (proxy && proxy.host && proxy.port) {
    try {
      proxyBridge = await createToggleableProxyBridge(proxy);
      args.push(`--proxy-server=${proxyBridge.localUrl}`);
    } catch (e) {
      log(`conta ${id}: falha ao preparar proxy — abrindo sem proxy (${e?.message || e})`);
    }
  }

  log(`conta ${id}: abrindo Chrome (perfil ${userDataDir})`);
  const browser = await puppeteer.launch({
    executablePath: execPath,
    headless: false,
    defaultViewport: null,
    userDataDir,
    args,
    pipe: false,
    protocolTimeout: 20000,
  });
  // Sempre cria a página NOVA primeiro (nunca deixa o browser com 0 páginas
  // — alguns builds do Chrome encerram o processo inteiro quando a última
  // janela fecha) e SÓ DEPOIS fecha qualquer aba que já tenha vindo aberta
  // sozinha (em branco ou restaurada de uma sessão anterior).
  const paginasAntigas = await browser.pages();
  const page = await browser.newPage();
  for (const p of paginasAntigas) { try { await p.close(); } catch {} }
  try { await page.goto("https://www.mercadopago.com.br/", { waitUntil: "domcontentloaded", timeout: 20000 }); } catch (e) {
    log(`conta ${id}: falha ao navegar pra mercadopago.com.br no launch — ${e?.message || e}`);
  }
  // Pedido do usuário 2026-08-11: "quando eu coloco a proxy e abro o MP,
  // ela está aplicando? rotativa? verifique." — confirma de verdade
  // buscando o IP de SAÍDA real da própria janela (a requisição sai pelo
  // mesmo proxy configurado no launch, se houver) — compara com o IP
  // esperado da proxy quando dá pra saber, e sempre loga pra dar pra
  // conferir se mudou entre uma abertura e outra (rotativa de verdade
  // muda a cada nova conexão/sessão; fixa fica sempre igual).
  if (proxy && proxy.host && proxy.port) {
    try {
      const ip = await page.evaluate(async () => {
        try { const r = await fetch("https://api.ipify.org?format=json", { cache: "no-store" }); const j = await r.json(); return j?.ip || ""; } catch { return ""; }
      });
      log(`conta ${id}: proxy configurada (${proxy.host}:${proxy.port}) — IP de saída real da janela: ${ip || "falhou ao checar"}`);
    } catch (e) {
      log(`conta ${id}: falha ao checar IP de saída com proxy — ${e?.message || e}`);
    }
  } else {
    log(`conta ${id}: sem proxy configurada — abrindo com o IP normal da máquina`);
  }
  try { fs.writeFileSync(wsFile, browser.wsEndpoint(), "utf8"); } catch (e) {
    log(`conta ${id}: falha ao salvar endpoint de reconexão — ${e?.message || e}`);
  }
  const entry = { browser, page, proxyBridge };
  janelasAbertas.set(String(id), entry);
  blindarContraPaginaFeedback(page, id);
  browser.on("disconnected", () => {
    janelasAbertas.delete(String(id));
    try { proxyBridge && proxyBridge.close(); } catch {}
    try { fs.rmSync(wsFile, { force: true }); } catch {}
    // Diagnóstico 2026-08-11 (reportado pelo usuário: "botão STOP não está
    // aparecendo, sumiu quando cliquei em importar" — a janela real fechou
    // sozinha sem o usuário clicar em Parar): loga o código de saída do
    // processo do Chrome, se disponível, pra distinguir fechamento normal
    // de crash na próxima vez que isso acontecer.
    let codigoSaida = null;
    try { codigoSaida = browser.process()?.exitCode ?? null; } catch {}
    log(`conta ${id}: janela fechada (código de saída do Chrome: ${codigoSaida})`);
    // Pedido do usuário 2026-08-10: o botão Play vira Stop (vermelho) quando
    // a janela está aberta, pra clicar de novo fechar — mas se o usuário
    // fechar pelo X do Chrome em vez do botão, o estado "aberta" na UI
    // ficava desatualizado. Avisa a janela principal sempre que a janela MP
    // realmente fechar, não importa como, pra UI se corrigir sozinha.
    notificarJanelaFechada(id);
  });
  return entry;
}

async function abrirConta({ id, nome, proxy }) {
  if (!id) return { ok: false, error: "id da conta não informado" };
  try {
    await getOuAbrirJanela({ id, proxy });
    log(`conta ${id} (${nome || "?"}): janela aberta/focada`);
    return { ok: true };
  } catch (e) {
    log(`conta ${id}: falha ao abrir — ${e?.message || e}`);
    return { ok: false, error: e?.message || String(e) };
  }
}

function contaEstaAberta({ id }) {
  const entry = janelasAbertas.get(String(id));
  return { ok: true, aberta: !!(entry && entry.browser && entry.browser.isConnected && entry.browser.isConnected()) };
}

// Pedido do usuário 2026-08-10: botão "disquete" — confirma que a conta está
// logada (perfil já fica salvo automaticamente em disco por conta, ver
// profileDirFor, mas o usuário quer uma confirmação explícita, igual o
// "Salvar Login" do bot do amigo). Não precisa fazer nada além de marcar —
// a sessão já persiste sozinha no --user-data-dir dessa conta — mas avisa
// se a página ainda parecer estar na tela de login (campo de senha visível),
// pra não marcar como salva por engano antes do login de verdade acontecer.
async function salvarLogin({ id }) {
  if (!id) return { ok: false, error: "id da conta não informado" };
  const entry = janelasAbertas.get(String(id));
  if (!entry || !entry.browser || !entry.browser.isConnected || !entry.browser.isConnected()) {
    return { ok: false, error: "Abra a conta primeiro (a janela precisa estar aberta pra confirmar o login)." };
  }
  try {
    const aindaNaTelaDeLogin = await entry.page.evaluate(() => {
      return !!document.querySelector('input[type="password"]');
    });
    log(`conta ${id}: salvar login — aindaNaTelaDeLogin=${aindaNaTelaDeLogin}`);
    return { ok: true, provavelLogado: !aindaNaTelaDeLogin };
  } catch (e) {
    log(`conta ${id}: falha ao checar login — ${e?.message || e}`);
    return { ok: true, provavelLogado: null };
  }
}

function fecharConta({ id }) {
  const entry = janelasAbertas.get(String(id));
  if (!entry) return { ok: true, jaFechada: true };
  try { entry.browser.close(); } catch {}
  janelasAbertas.delete(String(id));
  return { ok: true };
}

// URL real confirmada pelo usuário 2026-08-10 (testou no site de verdade) —
// primeira da lista, com os candidatos antigos como fallback caso o site
// mude de layout no futuro.
const PIX_KEYS_URL_CANDIDATES = [
  "https://www.mercadopago.com.br/pix/home/hub",
  "https://www.mercadopago.com.br/pix",
  "https://www.mercadopago.com.br/money-in/pix/keys/list",
  "https://www.mercadopago.com.br/settings/pix",
];

async function irParaPaginaDeChaves(page) {
  for (const url of PIX_KEYS_URL_CANDIDATES) {
    try {
      log(`navegando pra ${url}`);
      await page.goto(url, { waitUntil: "domcontentloaded", timeout: 20000 });
      await new Promise((r) => setTimeout(r, 1500));
      const achou = await page.evaluate(() => {
        const t = (document.body.innerText || "").toLowerCase();
        return t.includes("chave") && t.includes("pix");
      });
      if (achou) { log(`página de chaves PIX encontrada em ${url}`); return true; }
    } catch (e) {
      log(`falha navegando pra ${url}: ${e?.message || e}`);
    }
  }
  // Fallback: clica em qualquer link/botão da home cujo texto contenha "pix".
  try {
    await page.goto("https://www.mercadopago.com.br/", { waitUntil: "domcontentloaded", timeout: 20000 });
    const clicou = await page.evaluate(() => {
      const els = Array.from(document.querySelectorAll("a,button"));
      const el = els.find((e) => /pix/i.test((e.innerText || e.textContent || "").trim()) && (e.innerText || "").trim().length < 30);
      if (el) { el.scrollIntoView({ block: "center" }); el.click(); return true; }
      return false;
    });
    if (clicou) {
      await new Promise((r) => setTimeout(r, 2000));
      log("fallback: clicou em link/botão contendo \"pix\" na home");
      return true;
    }
  } catch (e) {
    log(`fallback de navegação pra Pix falhou: ${e?.message || e}`);
  }
  return false;
}

// Expande a lista completa se houver um "Ver mais"/"Ver todos" (visto no log
// do bot do amigo: "erro ao clicar 'Ver todos/mais'").
async function expandirListaCompleta(page) {
  try {
    await page.evaluate(() => {
      const els = Array.from(document.querySelectorAll("a,button,span"));
      const el = els.find((e) => /ver (todos|mais)/i.test((e.innerText || e.textContent || "").trim()));
      if (el) { el.scrollIntoView({ block: "center" }); el.click(); return true; }
      return false;
    });
    await new Promise((r) => setTimeout(r, 800));
  } catch {}
}

// Pedido do usuário 2026-08-11: "quando a chave for enviada pra Chaves PIX
// com +55 remova. Não pode ter o +55" — o botão de copiar do Mercado Pago
// devolve o número de celular no formato internacional (+55DDXXXXXXXXX);
// tira o "+55"/"55" da frente antes de gravar na tabela de Chaves PIX.
function removerCodigoPaisCelular(valor) {
  let v = String(valor || "").trim();
  v = v.replace(/^\+?55/, (m, offset, str) => {
    // Só remove se o que resta depois ainda parece DDD+número (10 ou 11
    // dígitos) — evita cortar de menos/mais em valores que só por
    // coincidência começam com "55" (ex.: um CPF/CNPJ, que cai noutro tipo
    // de qualquer forma, mas por segurança).
    const resto = str.slice(m.length).replace(/\D/g, "");
    return resto.length === 10 || resto.length === 11 ? "" : m;
  });
  return v;
}

function classificarTipo(labelTexto, valor) {
  const l = (labelTexto || "").toLowerCase();
  if (l.includes("e-mail") || l.includes("email") || /@/.test(valor || "")) return "email";
  if (l.includes("celular") || l.includes("telefone") || l.includes("phone")) return "phone";
  if (l.includes("cnpj")) return "cnpj";
  if (l.includes("cpf")) return "cpf";
  if (l.includes("aleat") || l.includes("evp")) return "evp";
  const digits = String(valor || "").replace(/\D/g, "");
  if (digits.length === 14) return "cnpj";
  if (digits.length === 11) return "cpf";
  return "evp";
}

// Injeta (ou reinjeta, depois de uma navegação que destrói o contexto
// anterior) o interceptador de navigator.clipboard.writeText — usado pra
// capturar o valor REAL que o botão de copiar de cada chave manda pro
// clipboard, sem depender de permissão de clipboard do Chrome/SO.
async function injetarInterceptadorClipboard(page) {
  try {
    await page.evaluate(() => {
      if (window.__pandoraCopias) return;
      window.__pandoraCopias = [];
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          const orig = navigator.clipboard.writeText.bind(navigator.clipboard);
          navigator.clipboard.writeText = (texto) => { window.__pandoraCopias.push(texto); return orig(texto).catch(() => {}); };
        }
      } catch {}
    });
  } catch {}
}

async function copiarChaves({ id, proxy }) {
  if (!id) return { ok: false, error: "id da conta não informado" };
  try {
    const { page } = await getOuAbrirJanela({ id, proxy });
    const achouPagina = await irParaPaginaDeChaves(page);
    if (!achouPagina) {
      log(`conta ${id}: não achei a página de chaves PIX (login pendente ou site mudou de layout)`);
      return { ok: false, error: "Não encontrei a página de chaves PIX — confira se a conta está logada (abra a conta primeiro) ou avise pra eu ajustar a navegação." };
    }
    await expandirListaCompleta(page);
    await injetarInterceptadorClipboard(page);
    // BUG real 2026-08-11 (reportado pelo usuário: "falha: Execution context
    // was destroyed, most likely because of a navigation" — e o botão de
    // Parar chegou a desaparecer da tela depois disso) — a versão anterior
    // fazia TUDO (clicar no botão de copiar de cada chave, esperar,
    // reconferir) dentro de um ÚNICO page.evaluate longo com vários awaits
    // no meio; se o site navegasse/re-renderizasse no meio desse processo
    // (destruindo o contexto de JS), a chamada inteira falhava e nenhuma
    // chave era importada. Agora processa UMA chave por vez, reconsultando
    // a lista do zero a cada volta (mesmo padrão já usado em deletarChaves)
    // — se o contexto morrer no meio de uma chave, só ESSA chave é perdida;
    // o loop volta pro hub e continua com as próximas em vez de abortar tudo.
    const jaColetadas = [];
    const chaves = [];
    const dbg = [];
    for (let tentativa = 0; tentativa < 20 && chaves.length < 20; tentativa++) {
      let alvo = null;
      try {
        alvo = await page.evaluate((jaVistos) => {
          const TIPOS = /(cpf|cnpj|e-?mail|celular|telefone|aleat[óo]ria|evp)/i;
          const candidatos = Array.from(document.querySelectorAll("li, div, tr")).filter((el) => {
            const t = (el.innerText || "").trim();
            if (!t || t.length > 200) return false;
            return TIPOS.test(t) && (/@/.test(t) || /\d{3,}/.test(t));
          });
          const folhas = candidatos.filter((el) => !candidatos.some((outro) => outro !== el && el.contains(outro)));
          // Ícone de copiar confirmado pelo usuário: <svg> com um único
          // <path> cujo "d" começa com "M19.0041 5.99614H17.7521..." (duas
          // folhas sobrepostas, ícone padrão Andes de "copiar").
          const acharBotaoCopiar = (root) => {
            const svgs = Array.from(root.querySelectorAll("svg"));
            const svg = svgs.find((s) => {
              const paths = s.querySelectorAll("path");
              return paths.length === 1 && (paths[0].getAttribute("d") || "").startsWith("M19.0041 5.99614H17.7521");
            });
            return svg ? svg.closest("button,[role=button],a") : null;
          };
          for (const el of folhas) {
            const texto = (el.innerText || "").replace(/\s+/g, " ").trim();
            if (jaVistos.includes(texto)) continue;
            // Sobe até 6 níveis de ancestral procurando o botão de copiar
            // dessa chave (mesmo padrão já usado pros "3 pontinhos" — o
            // botão pode não estar dentro do elemento que tem o texto, e
            // sim num container pai/irmão mais largo).
            let botao = null, container = el;
            for (let i = 0; i < 6 && container && !botao; i++) { botao = acharBotaoCopiar(container); if (!botao) container = container.parentElement; }
            if (botao) { botao.scrollIntoView({ block: "center" }); botao.click(); return { texto, clicou: true }; }
            const mEmail = texto.match(/[\w.+-]+@[\w-]+\.[\w.-]+/);
            const mDigits = texto.match(/\d[\d .()-]{7,}\d/);
            const valorTexto = mEmail ? mEmail[0] : (mDigits ? mDigits[0].replace(/[ .()-]/g, "") : "");
            return { texto, clicou: false, valorTexto };
          }
          return null;
        }, jaColetadas);
      } catch (e) {
        if (/execution context was destroyed/i.test(e?.message || "")) {
          log(`conta ${id}: navegação inesperada no meio da importação — voltando pro hub e continuando (${chaves.length} chave(s) já coletada(s))`);
          try { await irParaPaginaDeChaves(page); await expandirListaCompleta(page); await injetarInterceptadorClipboard(page); } catch {}
          continue;
        }
        throw e;
      }
      if (!alvo) { log(`conta ${id}: nenhuma chave nova pra importar (${chaves.length} coletada(s) no total)`); break; }
      jaColetadas.push(alvo.texto);
      dbg.push(alvo.texto.slice(0, 80));
      let valor = "";
      let via = "";
      if (alvo.clicou) {
        await new Promise((r) => setTimeout(r, 250));
        try {
          const copiado = await page.evaluate(() => (window.__pandoraCopias || []).pop() || "");
          if (copiado) { valor = copiado; via = "botao-copiar"; }
        } catch {
          // Contexto pode ter morrido bem nessa espera — reinjeta pra
          // próxima volta e segue sem valor por essa chave (cai no fallback
          // de texto visível abaixo, se tiver).
          try { await irParaPaginaDeChaves(page); await expandirListaCompleta(page); await injetarInterceptadorClipboard(page); } catch {}
        }
      }
      if (!valor && alvo.valorTexto) { valor = alvo.valorTexto; via = "texto-visivel"; }
      if (!valor) { log(`conta ${id}: não consegui o valor de "${alvo.texto.slice(0, 60)}" — pulando`); continue; }
      chaves.push({ label: alvo.texto, valor, via });
    }
    log(`conta ${id}: ${chaves.length} chave(s) importada(s) — vias: ${JSON.stringify(chaves.map((c) => c.via))} — bruto: ${JSON.stringify(dbg).slice(0, 500)}`);
    const chavesFinal = chaves.map((c) => {
      const tipo = classificarTipo(c.label, c.valor);
      const valor = tipo === "phone" ? removerCodigoPaisCelular(c.valor) : c.valor;
      return { tipo, valor };
    });
    if (!chavesFinal.length) {
      return { ok: false, error: "Nenhuma chave encontrada na página — pode ser que essa conta não tenha chaves cadastradas, ou o layout do site não bateu com o esperado (me avisa pra eu ajustar)." };
    }
    return { ok: true, chaves: chavesFinal };
  } catch (e) {
    log(`conta ${id}: falha ao copiar chaves — ${e?.message || e}`);
    return { ok: false, error: e?.message || String(e) };
  }
}

async function deletarChaves({ id, proxy }) {
  if (!id) return { ok: false, error: "id da conta não informado" };
  try {
    const { page } = await getOuAbrirJanela({ id, proxy });
    const achouPagina = await irParaPaginaDeChaves(page);
    if (!achouPagina) {
      return { ok: false, error: "Não encontrei a página de chaves PIX — confira se a conta está logada." };
    }
    await expandirListaCompleta(page);
    let deletadas = 0;
    let falhas = 0;
    let precisaCaptcha = 0;
    // Pedido do usuário 2026-08-10 ("os botões estão apagados" — ficavam
    // desabilitados o tempo todo porque o loop de 30 tentativas martelava a
    // MESMA chave sem nunca progredir, quando algum passo não achava
    // botão/opção certa, gastando ~45s+ até desistir de verdade): detecta
    // quando a MESMA chave falha 3x seguidas (não é uma chave diferente
    // avançando) e aborta o loop inteiro nesse ponto, em vez de gastar as
    // 30 tentativas inteiras numa causa que já não vai mudar de resultado.
    let ultimoFalhouTexto = null;
    let falhasConsecutivasMesmoItem = 0;
    const marcarFalhaRepetida = (textoItem) => {
      if (textoItem === ultimoFalhouTexto) falhasConsecutivasMesmoItem++;
      else { falhasConsecutivasMesmoItem = 1; ultimoFalhouTexto = textoItem; }
      return falhasConsecutivasMesmoItem >= 3;
    };
    // Loop: sempre re-lê a lista do zero a cada volta (a página muda de DOM
    // depois de cada exclusão) — mesmo padrão de "reconsulta sempre" já usado
    // no resto do app pra evitar referência a elemento morto.
    for (let tentativa = 0; tentativa < 30; tentativa++) {
      const alvo = await page.evaluate(() => {
        // Confirmado pelo usuário 2026-08-10 com o SVG exato do ícone (print
        // do site de verdade): os "3 pontinhos" são um <svg> com EXATAMENTE
        // 3 <path> (cada um desenhando um círculo/ponto), SEM aria-label
        // nenhum.
        const acharSvg3Pontos = (root) => Array.from(root.querySelectorAll("svg")).find((svg) => svg.querySelectorAll("path").length === 3);

        const TIPOS = /(cpf|cnpj|e-?mail|celular|telefone|aleat[óo]ria|evp)/i;
        let candidatos = Array.from(document.querySelectorAll("li, div, tr")).filter((el) => {
          const t = (el.innerText || "").trim();
          if (!t || t.length > 200) return false;
          return TIPOS.test(t) && (/@/.test(t) || /\d{3,}/.test(t));
        });
        let via = "tipo+valor";
        // Fallback (2026-08-10, reportado pelo usuário: chegou na página mas
        // não clicou nos 3 pontinhos — a heurística acima não achou NENHUM
        // candidato, provavelmente porque o tipo da chave é mostrado como
        // ÍCONE em vez de texto "CPF"/"Celular" etc): procura qualquer
        // linha que já tenha o próprio SVG dos 3 pontinhos dentro, sem
        // exigir a palavra do tipo — muito mais amplo, mas o SVG específico
        // (3 paths exatos) evita pegar lixo.
        if (!candidatos.length) {
          via = "svg-3-pontos";
          // BUG real 2026-08-10 (reportado pelo usuário: "se não tem chaves
          // pra excluir e não existe os 3 pontinhos, não deve clicar em
          // NADA") — esse fallback exigia SÓ o ícone dos 3 pontinhos, sem
          // checar se a linha realmente parece uma chave PIX (valor
          // mascarado/dígitos/@) — podia bater em QUALQUER outro menu de
          // "..." da página (configurações, perfil, etc.) quando a conta
          // não tem nenhuma chave de verdade, clicando em algo sem relação
          // nenhuma. Agora exige o mesmo sinal de valor (dígitos ou @) que
          // a heurística principal já exigia — só dispensa a PALAVRA do
          // tipo (CPF/Celular/etc), que é o problema real que esse fallback
          // resolve (tipo mostrado como ícone em vez de texto).
          candidatos = Array.from(document.querySelectorAll("li, div, tr")).filter((el) => {
            const t = (el.innerText || "").trim();
            if (!t || t.length > 200) return false;
            return !!acharSvg3Pontos(el) && (/@/.test(t) || /\d{3,}/.test(t));
          });
        }
        const folhas = candidatos.filter((el) => !candidatos.some((outro) => outro !== el && el.contains(outro)));
        if (!folhas.length) {
          // Diagnóstico: nenhuma das duas heurísticas achou nada — loga uma
          // amostra da página pra ajustar sem precisar adivinhar de novo.
          const totalSvg3 = Array.from(document.querySelectorAll("svg")).filter((s) => s.querySelectorAll("path").length === 3).length;
          return { nadaEncontrado: true, totalSvg3, amostraTexto: (document.body.innerText || "").slice(0, 300) };
        }
        const el = folhas[0];
        // BUG real 2026-08-10 — dados reais confirmados pelo usuário (HTML
        // exato copiado do site): o botão é
        // <button aria-label="Mais opções" aria-haspopup="dialog" class="andes-ui-icon-button ...">
        // com o SVG de 3 pontinhos dentro — MAS não fica dentro do bloco de
        // texto da chave que "el" captura, é um elemento irmão/de um
        // container pai mais largo. Sobe até 6 níveis de ancestral checando
        // os DOIS sinais confirmados (aria-label="Mais opções" E o SVG de 3
        // pontinhos) em cada nível, até achar.
        let menu = null;
        let container = el;
        for (let i = 0; i < 6 && container && !menu; i++) {
          menu = container.querySelector('button[aria-label*="mais opç" i]');
          if (!menu) { const svg3 = acharSvg3Pontos(container); if (svg3) menu = svg3.closest("button,[role=button],a"); }
          if (!menu) container = container.parentElement;
        }
        if (menu) {
          // Pedido do usuário 2026-08-10 (confirmou funcionando, mas "clicando
          // toda hora" — o menu abria de novo repetidamente em vez de avançar
          // pra "Excluir chave"): usa aria-controls do próprio botão (id exato
          // do painel de opções que ELE controla, presente no HTML real
          // confirmado: aria-controls="_R_1kl6aataH1_") pra escopar a busca
          // da opção certa, em vez de procurar "excluir" no documento inteiro
          // (que podia continuar sem achar, fazendo o loop de fora voltar e
          // reabrir/clicar o mesmo botão de novo). Também guarda se o menu
          // JÁ estava aberto (aria-expanded=true) — nesse caso NÃO clica de
          // novo (clicar de novo fecharia o menu que já estava aberto).
          const jaAberto = menu.getAttribute("aria-expanded") === "true";
          const controlsId = menu.getAttribute("aria-controls") || "";
          if (!jaAberto) { menu.scrollIntoView({ block: "center" }); menu.click(); }
          return { abriuMenu: true, controlsId, via, textoItem: (el.innerText || "").slice(0, 60) };
        }
        // Fallback (layout diferente do esperado): botão de excluir já visível direto no item, sem precisar abrir menu.
        const del = Array.from(el.querySelectorAll("button,a,[role=button]")).find((b) => /excluir|remover|delet/i.test((b.innerText || b.getAttribute("aria-label") || "").trim()));
        if (del) { del.scrollIntoView({ block: "center" }); del.click(); return { clicouExcluir: true, via, textoItem: (el.innerText || "").slice(0, 60) }; }
        // Diagnóstico: ainda não achou nada mesmo subindo — pega o HTML real
        // do item (e de 2 níveis acima) pra eu ver a estrutura de verdade em
        // vez de adivinhar (pedido do usuário: "não quer tentar por HTML?").
        const pai1 = el.parentElement, pai2 = pai1 && pai1.parentElement;
        return {
          semBotao: true,
          via,
          textoItem: (el.innerText || "").slice(0, 60),
          htmlItem: (el.outerHTML || "").slice(0, 1500),
          htmlPai1: (pai1 && pai1.outerHTML || "").slice(0, 1500),
          htmlPai2: (pai2 && pai2.outerHTML || "").slice(0, 1500),
        };
      });
      if (alvo && alvo.nadaEncontrado) {
        log(`conta ${id}: nenhuma linha de chave encontrada (svgs de 3 pontos na página inteira: ${alvo.totalSvg3}) — amostra do texto da página: ${JSON.stringify(alvo.amostraTexto)}`);
        break;
      }
      if (!alvo) { log(`conta ${id}: nenhuma chave restante na lista`); break; }
      log(`conta ${id}: chave encontrada via "${alvo.via}" — "${alvo.textoItem}"`);
      // Pedido do usuário 2026-08-10: "acelere a exclusão, está devagar" —
      // reduzidos os tempos de espera fixos entre cada passo (menu → opção
      // → confirmação), que eram mais conservadores do que o site precisa
      // de verdade.
      await new Promise((r) => setTimeout(r, 350));
      if (alvo.abriuMenu) {
        // Pedido do usuário 2026-08-10: "deve clicar a Excluir chave que é a
        // SEGUNDA opção que aparecer" — em vez de procurar o texto "excluir"
        // no documento inteiro (o que podia falhar e fazer o loop de fora
        // reabrir o mesmo menu várias vezes, "clicando toda hora"), escopa a
        // busca pro painel EXATO que esse botão controla (aria-controls,
        // confirmado no HTML real) e clica na 2ª opção da lista por posição.
        const clicouNoMenu = await page.evaluate((controlsId) => {
          // BUG real 2026-08-10 — HTML exato confirmado pelo usuário: cada
          // opção do menu é um <button class="andes-ui-list__item-actionable">
          // VAZIO (sem texto nenhum dentro) — o texto de verdade ("Excluir
          // chave") mora num <div id="..."> separado, ligado só via
          // aria-labelledby. b.innerText nesse botão é "" — por isso nunca
          // batia com nada (nem por texto, nem entrava na lista de opções
          // pra sequer contar como "2ª posição").
          const textoAcessivel = (el) => {
            const labelledBy = el.getAttribute("aria-labelledby");
            if (labelledBy) {
              const labelEl = document.getElementById(labelledBy.split(/\s+/)[0]);
              if (labelEl) return (labelEl.innerText || labelEl.textContent || "").trim();
            }
            return (el.innerText || el.textContent || "").trim();
          };
          const popup = controlsId ? document.getElementById(controlsId) : null;
          const escopo = popup || document;
          const opcoes = Array.from(escopo.querySelectorAll('button,a,[role="menuitem"],li'))
            .map((el) => ({ el, texto: textoAcessivel(el) }))
            .filter((o) => o.texto);
          // Prioriza achar por texto ("Excluir chave") mesmo dentro do
          // escopo certo; só cai pra "2ª opção por posição" se o texto não
          // bater com nada (layout pode variar a ordem das opções).
          const porTexto = opcoes.find((o) => /excluir\s*chave|^excluir$/i.test(o.texto));
          const alvo = porTexto || opcoes[1];
          if (alvo) { alvo.el.click(); return { ok: true, texto: alvo.texto, totalOpcoes: opcoes.length }; }
          return { ok: false, totalOpcoes: opcoes.length };
        }, alvo.controlsId || "");
        if (!clicouNoMenu.ok) {
          log(`conta ${id}: abriu menu mas não achei opção pra clicar pra "${alvo.textoItem}" (opções visíveis: ${clicouNoMenu.totalOpcoes})`);
          falhas++;
          if (marcarFalhaRepetida(alvo.textoItem)) { log(`conta ${id}: mesma chave falhou 3x seguidas — abortando pra não travar tentando à toa`); break; }
          continue;
        }
        log(`conta ${id}: clicou em "${clicouNoMenu.texto}" no menu de "${alvo.textoItem}"`);
        await new Promise((r) => setTimeout(r, 350));
      } else if (alvo.semBotao) {
        log(`conta ${id}: não achei botão de excluir pra "${alvo.textoItem}" — pulando`);
        falhas++;
        if (marcarFalhaRepetida(alvo.textoItem)) { log(`conta ${id}: mesma chave falhou 3x seguidas — abortando pra não travar tentando à toa`); break; }
        continue;
      }
      // Modal de confirmação — clica em "Excluir"/"Confirmar" dentro dele.
      // Mesmo padrão de bug já corrigido no menu (2026-08-10): botões do
      // Design System Andes costumam vir VAZIOS, com o texto de verdade num
      // elemento separado ligado via aria-labelledby — usa a mesma função
      // de "texto acessível" aqui também, em vez de innerText direto.
      const modalRes = await page.evaluate(() => {
        const textoAcessivel = (el) => {
          const labelledBy = el.getAttribute("aria-labelledby");
          if (labelledBy) {
            const labelEl = document.getElementById(labelledBy.split(/\s+/)[0]);
            if (labelEl) return (labelEl.innerText || labelEl.textContent || "").trim();
          }
          return (el.innerText || el.textContent || "").trim();
        };
        // BUG real 2026-08-10 — HTML confirmado pelo diagnóstico: o primeiro
        // "[role=dialog]" do DOM era um modal promocional ESCONDIDO
        // (id="id-widget-main-ftu", aria-hidden="true", data-show-modal=
        // "false"), completamente sem relação com a exclusão — o
        // querySelector (só pega o 1º match, sem checar se está visível)
        // sempre caía nele. Agora filtra só diálogos DE VERDADE visíveis na
        // tela (aria-hidden != true, com tamanho real).
        const visivel = (el) => {
          if (!el || el.getAttribute("aria-hidden") === "true") return false;
          const r = el.getBoundingClientRect();
          if (r.width < 10 || r.height < 10) return false;
          const s = getComputedStyle(el);
          return s.display !== "none" && s.visibility !== "hidden";
        };
        const dialogos = Array.from(document.querySelectorAll('[role="dialog"], [role="alertdialog"], .andes-modal, [class*="modal" i]'));
        const dialogo = dialogos.find(visivel);
        const scope = dialogo || document;
        const botoes = Array.from(scope.querySelectorAll("button")).map((el) => ({ el, texto: textoAcessivel(el) }));
        const btn = botoes.find((b) => /^(excluir|remover|confirmar)(\s*chave)?$/i.test(b.texto));
        if (btn) { btn.el.click(); return { clicou: true, texto: btn.texto }; }
        // Diagnóstico: dump do HTML real do diálogo (agora o visível, não o
        // escondido) pra ver a estrutura de verdade se ainda não achar.
        return {
          clicou: false,
          achouDialogo: !!dialogo,
          totalDialogosNaPagina: dialogos.length,
          totalBotoes: botoes.length,
          botoesVistos: botoes.map((b) => b.texto).filter(Boolean),
          htmlDialogo: (dialogo && dialogo.outerHTML || "").slice(0, 2500),
        };
      });
      if (!modalRes.clicou) {
        log(`conta ${id}: modal de confirmação não encontrado/sem botão — pulando "${alvo.textoItem}" (dialogo achado=${modalRes.achouDialogo}, total de botões=${modalRes.totalBotoes}, botões com texto: ${JSON.stringify(modalRes.botoesVistos)})`);
        if (modalRes.htmlDialogo) log(`conta ${id}: HTML do diálogo (diagnóstico): ${modalRes.htmlDialogo}`);
        falhas++;
        if (marcarFalhaRepetida(alvo.textoItem)) { log(`conta ${id}: mesma chave falhou 3x seguidas — abortando pra não travar tentando à toa`); break; }
        continue;
      }
      await new Promise((r) => setTimeout(r, 600));
      // Verifica se apareceu desafio de captcha (reCAPTCHA/iframe) em vez do
      // snackbar de sucesso — nesse caso não tentamos resolver (fora do
      // escopo dessa 1ª versão), só registra e segue pra próxima chave.
      // Também checa se o site já REDIRECIONOU pra outra página (ex.:
      // pedido do usuário 2026-08-10: depois de excluir a última chave, o
      // Mercado Pago manda sozinho pra .../acessibilidade/feedback — nesse
      // caso já terminou de verdade, não tem mais chave pra excluir, então
      // para direto em vez de tentar de novo numa página que não é mais a
      // de chaves PIX).
      const pos = await page.evaluate(() => {
        const temCaptcha = !!document.querySelector('iframe[src*="recaptcha" i], iframe[title*="recaptcha" i], [class*="captcha" i]');
        const temSnackbar = /exclu[ií]da|removida com sucesso/i.test(document.body.innerText || "");
        const saiuDaPaginaDeChaves = !location.pathname.includes("/pix");
        return { temCaptcha, temSnackbar, saiuDaPaginaDeChaves, urlAtual: location.href };
      });
      if (pos.temCaptcha) {
        log(`conta ${id}: captcha apareceu ao excluir "${alvo.textoItem}" — pulando (resolver captcha manual não está automatizado ainda)`);
        precisaCaptcha++;
        break; // capctha geralmente bloqueia as próximas tentativas também
      }
      deletadas++;
      if (pos.saiuDaPaginaDeChaves) {
        // BUG real 2026-08-11 (reportado pelo usuário: excluiu só 1 chave e
        // parou na página de feedback, mas ainda tinha chave sobrando) — a
        // suposição anterior ("só redireciona pra
        // .../acessibilidade/feedback quando não sobra mais nenhuma chave")
        // estava ERRADA: o Mercado Pago pode mandar pra lá depois de excluir
        // QUALQUER chave, não só a última. Antes isso parava o loop de vez
        // (break) — agora só volta pro hub de Pix e CONTINUA tentando
        // excluir as próximas; o loop só termina de verdade quando a
        // checagem do topo (nadaEncontrado / nenhuma chave restante) não
        // achar mais nenhuma linha de chave na lista.
        log(`conta ${id}: site redirecionou pra ${pos.urlAtual} depois de excluir "${alvo.textoItem}" — voltando pro hub de Pix e continuando`);
        try { await page.goto("https://www.mercadopago.com.br/pix/home/hub", { waitUntil: "domcontentloaded", timeout: 15000 }); } catch {}
        await expandirListaCompleta(page);
        continue;
      }
      log(`conta ${id}: chave "${alvo.textoItem}" excluída (snackbar=${pos.temSnackbar})`);
    }
    return { ok: true, deletadas, falhas, precisaCaptcha };
  } catch (e) {
    log(`conta ${id}: falha ao deletar chaves — ${e?.message || e}`);
    return { ok: false, error: e?.message || String(e) };
  }
}

// ============================================================================
// CRIAR CHAVES PIX — pedido do usuário 2026-08-11, passo a passo ditado por
// ele com o HTML real de cada tela (mesmo processo que corrigiu Deletar
// Chaves): compra um número de celular via API do provedor selecionado
// (SMS 24HR, ver smsProviderApi.cjs), cadastra ele como chave PIX tipo
// Celular, escolhe receber o código por SMS, espera o código chegar via
// polling na API do provedor (é o Mercado Pago que manda o SMS de verdade
// pro número comprado) e confirma.
// ============================================================================
function textoAcessivelJs() {
  // Mesma função usada em deletarChaves — repetida aqui (cada
  // page.evaluate roda isolado no navegador, não dá pra importar).
  return `
    const textoAcessivel = (el) => {
      const labelledBy = el.getAttribute("aria-labelledby");
      if (labelledBy) {
        const labelEl = document.getElementById(labelledBy.split(/\\s+/)[0]);
        if (labelEl) return (labelEl.innerText || labelEl.textContent || "").trim();
      }
      return (el.innerText || el.textContent || "").trim();
    };
  `;
}

// Pedido do usuário 2026-08-11: "quero parar a hora que eu quiser" — a
// compra de número + espera do código SMS pode levar até 90s+ sozinha, sem
// nenhum jeito de interromper antes disso. id -> { cancelado: bool }.
const cancelamentosChavePix = new Map();

function cancelarCriarChavePix({ id }) {
  const ctrl = cancelamentosChavePix.get(String(id));
  if (ctrl) ctrl.cancelado = true;
  return { ok: true };
}

// Uma ÚNICA tentativa de cadastro (compra número → preenche → confirma
// código). Pedido do usuário 2026-08-11: "quando aparecer [tela de número já
// tem dono] deve clicar em Cadastrar outra chave... faz todo o processo
// novamente até ter 5 chaves (TOTAL) cadastradas" — por isso essa função
// devolve `chaveJaTemDono` separado de erro real, pra quem chama decidir se
// tenta de novo com outro número ou desiste de vez.
async function tentarUmaChavePix({ page, id, provedorNome, apiKey, checarCancelado, deveCancelar }) {
  let compra = null;
  try {
    log(`conta ${id}: comprando número via ${provedorNome || "SMS24H"}...`);
    compra = await smsApi.comprarNumero({ apiKey });
    if (!compra.ok) return { ok: false, error: compra.error };
    checarCancelado();
    log(`conta ${id}: número comprado — ${compra.numeroFormatado} (ativação #${compra.id})`);

    await page.goto("https://www.mercadopago.com.br/pix/home/hub", { waitUntil: "domcontentloaded", timeout: 20000 });
    await new Promise((r) => setTimeout(r, 1200));
    // Pedido do usuário 2026-08-11: "as vezes tem que clicar duas vezes no
    // STOP" — esse era o maior intervalo sem checagem de cancelamento
    // (navegação até 20s + 1.2s de espera fixa, sem nenhum checarCancelado
    // no meio) — adicionado aqui pra reduzir o atraso entre clicar em Parar
    // e o processo realmente parar.
    checarCancelado();

    // PASSO 1: clica em "Cadastrar" (texto direto, sem aria-labelledby).
    const r1 = await page.evaluate(() => {
      const els = Array.from(document.querySelectorAll("span,a,button")).filter((e) => (e.innerText || "").trim() === "Cadastrar");
      if (!els.length) return { ok: false };
      els[0].click();
      return { ok: true };
    });
    if (!r1.ok) { await cancelarECair(compra, apiKey); return { ok: false, tentarOutro: true, error: "Não achei o botão \"Cadastrar\" na página de chaves PIX." }; }
    log(`conta ${id}: clicou em "Cadastrar"`);
    await new Promise((r) => setTimeout(r, 900));
    checarCancelado();

    // PASSO 2: clica no item de tipo "Celular" (li com description "Celular";
    // botão interno é vazio, texto via aria-labelledby, mesmo padrão do menu
    // de 3 pontinhos — HTML real confirmado pelo usuário).
    const r2 = await page.evaluate((jsHelper) => {
      eval(jsHelper);
      const desc = Array.from(document.querySelectorAll("span")).find((s) => (s.innerText || "").trim() === "Celular");
      if (!desc) return { ok: false, motivo: "descrição-nao-achada" };
      const li = desc.closest('li[data-andes-list-item], li.andes-ui-list__item, li');
      if (!li) return { ok: false, motivo: "li-nao-achado" };
      const botao = li.querySelector("button");
      (botao || li).click();
      return { ok: true };
    }, textoAcessivelJs());
    if (!r2.ok) { await cancelarECair(compra, apiKey); return { ok: false, tentarOutro: true, error: `Não achei a opção "Celular" (${r2.motivo || "?"}).` }; }
    log(`conta ${id}: clicou em "Celular"`);
    await new Promise((r) => setTimeout(r, 900));
    checarCancelado();

    // PASSO 3: preenche o campo de celular (aria-label confirmado: "Campo de
    // celular", name="key") com o número comprado, via digitação real
    // (page.type dispara os eventos de teclado que um input controlado por
    // React precisa pra atualizar o estado — setar .value direto não basta).
    // BUG real 2026-08-11 (reportado pelo usuário: "não está apagando o
    // número atual... trocou só o último dígito") — o campo já vem
    // PREENCHIDO com o número da própria conta MP por padrão (confirmado no
    // HTML real: value="(11) 93071-9339"), e é um input MASCARADO (formata
    // dígito por dígito conforme digita) — clickCount:3 (triplo-clique) +
    // 1 Backspace só apagava 1 caractere da máscara, não o valor inteiro.
    // Fix: seleciona tudo via Ctrl+A (mais confiável que triplo-clique em
    // inputs mascarados) e aperta Backspace várias vezes de propósito (o
    // suficiente pra qualquer tamanho de número BR), garantindo campo
    // realmente vazio antes de digitar o número novo.
    const campoSel = 'input[aria-label="Campo de celular"], input[name="key"]';
    const campo = await page.$(campoSel);
    if (!campo) {
      // Pedido do usuário 2026-08-11: "as vezes ele notifica dizendo que
      // não encontrou esse campo... e fica parado, corrija" — trata igual
      // as outras falhas de navegação (tenta de novo com outro número em
      // vez de travar de vez).
      await cancelarECair(compra, apiKey);
      return { ok: false, tentarOutro: true, error: "Não achei o campo de celular." };
    }
    await campo.click();
    await page.keyboard.down("Control");
    await page.keyboard.press("A");
    await page.keyboard.up("Control");
    for (let i = 0; i < 20; i++) { await page.keyboard.press("Backspace").catch(() => {}); }
    const aindaTemValor = await page.evaluate((sel) => { const el = document.querySelector(sel); return !!(el && el.value && el.value.trim()); }, campoSel);
    if (aindaTemValor) log(`conta ${id}: campo de celular ainda não ficou vazio depois de limpar — vai digitar em cima mesmo assim`);
    await campo.type(compra.numeroFormatado, { delay: 20 });
    log(`conta ${id}: preencheu o número ${compra.numeroFormatado} no campo de celular`);
    await new Promise((r) => setTimeout(r, 500));
    checarCancelado();

    // PASSO 4: clica em "Cadastrar chave" (texto direto no botão de submit).
    const r4 = await page.evaluate(() => {
      const btn = Array.from(document.querySelectorAll('button[type="submit"], button')).find((b) => /^cadastrar\s*chave$/i.test((b.innerText || "").trim()));
      if (!btn) return { ok: false };
      btn.click();
      return { ok: true };
    });
    if (!r4.ok) { await cancelarECair(compra, apiKey); return { ok: false, tentarOutro: true, error: "Não achei o botão \"Cadastrar chave\"." }; }
    log(`conta ${id}: clicou em "Cadastrar chave"`);
    await new Promise((r) => setTimeout(r, 1500));
    checarCancelado();

    // PASSO 5: escolhe o canal "SMS" pra receber o código.
    // BUG real 2026-08-11 (reportado pelo usuário: chegou até aqui mas não
    // clicou em SMS) — o HTML que ele mandou pra essa tela mostra
    // id="channel-sms-content" no DIV de conteúdo (texto "SMS" +
    // "No celular terminado em ...") — mesmíssimo padrão já confirmado e
    // corrigido antes (botão VAZIO como IRMÃO, ligado via
    // aria-labelledby="channel-sms-content"). Busca esse botão DIRETO pelo
    // id conhecido antes de qualquer heurística por texto.
    const r5 = await page.evaluate((jsHelper) => {
      eval(jsHelper);
      const direto = document.querySelector('button[aria-labelledby="channel-sms-content"], button[aria-labelledby*="sms" i]');
      if (direto) { direto.click(); return { ok: true, via: "aria-labelledby-direto" }; }
      // Fallback: acha o texto "SMS" e sobe procurando um botão vazio
      // ligado por aria-labelledby (mesma técnica usada no menu de excluir).
      const primario = Array.from(document.querySelectorAll("span")).find((s) => (s.innerText || "").trim() === "SMS" && s.className.includes("primary"));
      const alvo = primario || Array.from(document.querySelectorAll("span,div")).find((s) => (s.innerText || "").trim() === "SMS");
      if (!alvo) return { ok: false, motivo: "texto-SMS-nao-achado" };
      let container = alvo;
      for (let i = 0; i < 6 && container; i++) {
        const idContainer = container.id;
        if (idContainer) {
          const botao = document.querySelector(`button[aria-labelledby="${idContainer}"]`);
          if (botao) { botao.click(); return { ok: true, via: "aria-labelledby-subindo" }; }
        }
        container = container.parentElement;
      }
      const clicavel = alvo.closest('li,button,[role="button"]') || alvo;
      clicavel.click();
      return { ok: true, via: "fallback-click-direto" };
    }, textoAcessivelJs());
    if (!r5.ok) { await cancelarECair(compra, apiKey); return { ok: false, tentarOutro: true, error: `Não achei a opção "SMS" pra receber o código (${r5.motivo || "?"}).` }; }
    log(`conta ${id}: escolheu receber código por SMS (via "${r5.via}")`);
    await new Promise((r) => setTimeout(r, 1500));
    checarCancelado();

    // Espera o código chegar via polling na API do provedor — é o Mercado
    // Pago que manda o SMS de verdade pro número comprado. deveCancelar
    // checa a cada volta do polling. BUG real 2026-08-11 (reportado pelo
    // usuário: "está pulando os códigos... voltando muito rápido e indo
    // cadastrar outro número") — 10s era MUITO curto pra um SMS de verdade
    // chegar e ser repassado pela API do provedor; a maioria das tentativas
    // desistia antes do código sequer existir. Voltado pra 30s (compromisso
    // entre não travar pra sempre e dar tempo real do SMS chegar).
    log(`conta ${id}: esperando código SMS chegar (até 30s)...`);
    const codigoRes = await smsApi.esperarCodigo({ apiKey, id: compra.id, deveCancelar, timeoutMs: 30000, intervaloMs: 3000 });
    if (codigoRes.cancelado) throw new Error("CANCELADO_PELO_USUARIO");
    if (!codigoRes.ok || !codigoRes.pronto) {
      log(`conta ${id}: código não chegou em 30s pro número ${compra.numeroFormatado} — cancelando e tentando outro`);
      await cancelarECair(compra, apiKey);
      return { ok: false, tentarOutro: true, error: codigoRes.error || "Código SMS não chegou em 10s." };
    }
    log(`conta ${id}: código recebido — ${codigoRes.codigo}`);

    // PASSO 6: preenche o código (6 dígitos).
    // BUG real 2026-08-11 (reportado pelo usuário: "às vezes não está
    // clicando dentro humanizado aí dá erro e diz que precisa colocar o
    // código") — elementHandle.click() do Puppeteer às vezes não garante
    // foco de verdade no campo (a tela ainda pode estar em transição/
    // animação quando clicamos), e o .type() seguinte então digita no
    // vazio. Fix: clicarComFoco() clica de verdade (via mouse, coordenada
    // real do elemento) e CONFIRMA que o campo ficou focado (document.
    // activeElement) antes de digitar — tenta de novo (até 3x, com um
    // pequeno scroll+espera) se não focar de primeira.
    // BUG real 2026-08-11 (reportado pelo usuário: "parece que clica fora,
    // por isso pede insira o código") — clique por coordenada
    // (elementHandle.click(), que calcula o centro do elemento e clica lá
    // via CDP) pode errar em campos de código estilo OTP: às vezes o
    // <input> de verdade é bem pequeno/quase invisível, com uma caixa
    // decorativa por cima — o clique na coordenada pode acabar focando
    // outra coisa. Depois de tentar clicar normal, força foco DIRETO via
    // JS (el.focus() — sempre funciona pra elemento de formulário, não
    // depende de acertar coordenada nenhuma) como último recurso antes de
    // desistir.
    const clicarComFoco = async (handle) => {
      for (let tentativa = 0; tentativa < 3; tentativa++) {
        try {
          await handle.evaluate((el) => el.scrollIntoView({ block: "center" }));
          await handle.click();
          const focou = await handle.evaluate((el) => document.activeElement === el);
          if (focou) return true;
        } catch {}
        await new Promise((r) => setTimeout(r, 300));
      }
      try {
        await handle.evaluate((el) => el.focus());
        const focouDeVerdade = await handle.evaluate((el) => document.activeElement === el);
        if (focouDeVerdade) return true;
      } catch {}
      return false;
    };
    // HTML real confirmado pelo usuário 2026-08-11: são 6 campos SEPARADOS,
    // sem maxlength (por isso os seletores antigos nunca achavam nada) —
    // <input class="andes-form-control__field" aria-label="Dígito 1"
    // type="tel" pattern="[0-9]*" id="..._digit-0"
    // data-andes-codeinput-input="true">. Seletor certo, direto pelo
    // atributo específico desse componente (Andes CodeInput).
    // BUG real 2026-08-11 (reportado pelo usuário: "as vezes não coloca o
    // código... parece que clica fora") — campos de código costumam
    // avançar o foco pro PRÓXIMO campo automaticamente conforme digita
    // (padrão comum desse tipo de componente). Clicar manualmente em cada
    // campo, um por um, ANTES de digitar cada dígito conflitava com esse
    // avanço automático — o clique manual no campo N podia acontecer bem
    // na hora que o próprio site já tinha avançado pra lá sozinho (ou
    // ainda não), fazendo o clique "errar" o alvo. Fix: foca só o
    // PRIMEIRO campo e digita os 6 dígitos em sequência sem interromper —
    // deixa o próprio avanço automático do site cuidar do resto, sem
    // nenhum clique nosso no meio pra brigar com ele.
    // BUG real 2026-08-11 — usuário confirmou por HTML real que o seletor
    // (input[data-andes-codeinput-input="true"]) está EXATAMENTE certo nos
    // 6 campos, mas mesmo assim page.$$() nunca achava nada. Causa provável:
    // esse passo de validação de telefone é feito num domínio DIFERENTE
    // (mercadolivre.com, confirmado antes pela URL real que o usuário
    // mandou — .../jms/mlb/lgz/phone-validation/...), possivelmente
    // carregado dentro de um IFRAME embutido na página do Mercado Pago —
    // page.$$()/page.evaluate() só olham o frame PRINCIPAL, nunca o
    // conteúdo de um iframe. Fix: procura o seletor em TODOS os frames da
    // página (page.frames()), não só no principal, e usa o frame que
    // achar os 6 campos pra digitar.
    const acharFrameComCampos = async (sel, tamanhoEsperado) => {
      for (const frame of page.frames()) {
        try {
          const els = await frame.$$(sel);
          if (els.length === tamanhoEsperado) return { frame, els };
        } catch {}
      }
      return null;
    };
    const valorBate = async (frame, sel, cod) => frame.evaluate((s, c) => {
      const els = Array.from(document.querySelectorAll(s));
      return els.map((e) => e.value || "").join("") === c;
    }, sel, cod);
    let via6 = null;
    try {
      const sel = 'input[data-andes-codeinput-input="true"]';
      // Espera até 5s por pelo menos o frame principal renderizar ALGO —
      // não garante achar no frame certo, mas dá tempo de qualquer
      // transição de tela/iframe carregar antes de procurar em todo mundo.
      try { await page.waitForSelector(sel, { timeout: 5000 }).catch(() => null); } catch {}
      const achado = await acharFrameComCampos(sel, codigoRes.codigo.length);
      const inputs = achado ? achado.els : [];
      const frameAlvo = achado ? achado.frame : page.mainFrame();
      if (achado) log(`conta ${id}: campos do código achados em ${frameAlvo === page.mainFrame() ? "frame principal" : `iframe (${frameAlvo.url()})`}`);
      if (inputs.length === codigoRes.codigo.length) {
        const focou = await clicarComFoco(inputs[0]);
        if (!focou) log(`conta ${id}: 1º dígito não ganhou foco depois de 3 tentativas — digitando mesmo assim`);
        // page.keyboard funciona cross-frame (eventos de teclado vão pro
        // que estiver focado de verdade, seja no frame principal ou num
        // iframe — não é escopado por frame como page.evaluate/$$ é).
        await page.keyboard.type(codigoRes.codigo, { delay: 80 });
        if (!(await valorBate(frameAlvo, sel, codigoRes.codigo))) {
          // Não bateu digitando tudo seguido — tenta campo a campo como
          // fallback (pode ser um layout que não tem avanço automático).
          log(`conta ${id}: código não "pegou" digitando em sequência — tentando campo a campo`);
          const inputsDeNovo = await frameAlvo.$$(sel);
          for (let i = 0; i < inputsDeNovo.length; i++) {
            await clicarComFoco(inputsDeNovo[i]);
            await inputsDeNovo[i].type(codigoRes.codigo[i], { delay: 60 });
          }
        }
        via6 = "6-digitos-andes";
      } else if (inputs.length) {
        log(`conta ${id}: achei ${inputs.length} dígito(s) do código, mas o código tem ${codigoRes.codigo.length} — não bate, não vou preencher errado`);
      } else {
        // Diagnóstico: zero elementos batem com o seletor confirmado em
        // NENHUM frame — dump de todos os inputs visíveis em CADA frame da
        // página (tag+atributos-chave) pra ver a estrutura real dessa vez.
        const dumpPorFrame = [];
        for (const frame of page.frames()) {
          try {
            const vistos = await frame.evaluate(() => Array.from(document.querySelectorAll("input")).slice(0, 20).map((el) => ({
              id: el.id, name: el.name, type: el.type, maxLength: el.maxLength,
              ariaLabel: el.getAttribute("aria-label"), dataAttrs: Object.keys(el.dataset || {}),
              classe: (el.className || "").slice(0, 80),
            })));
            dumpPorFrame.push({ url: frame.url(), inputs: vistos });
          } catch {}
        }
        log(`conta ${id}: 0 elementos bateram com "${sel}" em nenhum frame (${page.frames().length} frame(s) na página) — inputs por frame: ${JSON.stringify(dumpPorFrame)}`);
      }
    } catch (e) {
      log(`conta ${id}: erro procurando campo do código — ${e?.message || e}`);
    }
    if (!via6) {
      log(`conta ${id}: não achei onde digitar o código — tentando digitar via teclado no campo focado`);
      await page.keyboard.type(codigoRes.codigo, { delay: 60 }).catch(() => {});
    } else {
      log(`conta ${id}: código preenchido (via "${via6}")`);
    }
    await new Promise((r) => setTimeout(r, 500));

    // PASSO 7: clica em "Continuar" (id confirmado: enter-code-submit).
    const continuarClicou = await page.evaluate(() => {
      const btn = document.getElementById("enter-code-submit") || Array.from(document.querySelectorAll("button")).find((b) => /^continuar$/i.test((b.innerText || "").trim()));
      if (btn) { btn.click(); return true; }
      return false;
    });
    if (!continuarClicou) { await cancelarECair(compra, apiKey); return { ok: false, tentarOutro: true, error: "Não achei o botão \"Continuar\" pra confirmar o código." }; }
    log(`conta ${id}: clicou em "Continuar"`);
    await new Promise((r) => setTimeout(r, 2000));

    // Pedido do usuário 2026-08-11: depois de confirmar o código, o
    // Mercado Pago pode dizer que o número JÁ TEM DONO (número reciclado,
    // já usado como chave por outra conta antes) — nesse caso aparece um
    // botão "Cadastrar outra chave". Detecta esse texto ANTES de assumir
    // sucesso — devolve chaveJaTemDono=true pra quem chama tentar de novo
    // com outro número, em vez de contar como cadastrada.
    const jaTemDono = await page.evaluate(() => {
      const btn = Array.from(document.querySelectorAll("button,a,span")).find((b) => /cadastrar\s*outra\s*chave/i.test((b.innerText || "").trim()));
      if (btn) { const el = btn.closest("button,a") || btn; el.click(); return true; }
      return false;
    });
    if (jaTemDono) {
      log(`conta ${id}: número ${compra.numeroFormatado} já tem dono (chave reciclada) — cliquei em "Cadastrar outra chave" pra tentar com outro`);
      await cancelarECair(compra, apiKey);
      await new Promise((r) => setTimeout(r, 1000));
      return { ok: false, chaveJaTemDono: true };
    }

    await smsApi.marcarConcluido({ apiKey, id: compra.id }).catch(() => {});
    log(`conta ${id}: chave PIX (Celular ${compra.numeroFormatado}) cadastrada com sucesso`);
    return { ok: true, numero: compra.numeroFormatado };
  } catch (e) {
    if (e?.message === "CANCELADO_PELO_USUARIO") throw e;
    // BUG real 2026-08-11 (reportado pelo usuário: "falha ao criar chave:
    // Execution context was destroyed, most likely because of a
    // navigation") — o site (SPA) troca de tela sozinho no meio de algum
    // passo, destruindo o contexto de JS bem na hora que um page.evaluate
    // estava rodando. É um erro de TIMING/transição, não uma falha real do
    // número/conta — trata igual "número reciclado" (tenta outro número em
    // vez de desistir de vez), já que o número comprado nem chegou a ser
    // usado de verdade nesse caso.
    if (/execution context was destroyed/i.test(e?.message || "")) {
      log(`conta ${id}: navegação inesperada no meio do processo (${e?.message}) — tentando de novo com outro número`);
      if (compra && compra.ok) await cancelarECair(compra, apiKey);
      return { ok: false, tentarOutro: true, error: e?.message };
    }
    log(`conta ${id}: falha ao criar chave PIX — ${e?.message || e}`);
    if (compra && compra.ok) await cancelarECair(compra, apiKey);
    return { ok: false, error: e?.message || String(e) };
  }
}

// Pedido do usuário 2026-08-11: "o bot notificou chave cadastrada com
// sucesso e parou de cadastrar, corrija... faça o processo tudo novamente"
// — não é mais "1 clique = 1 chave": agora fica criando chave DEPOIS de
// chave, sem parar, até o usuário clicar em Parar (cancelarCriarChavePix).
// Qualquer falha de navegação (campo/botão não achado, número reciclado,
// código atrasado, contexto destruído por navegação inesperada) é tratada
// igual — loga e tenta de novo com outro número, nunca fica "parado". Só um
// teto de segurança (30 falhas SEGUIDAS sem nenhum sucesso no meio) evita
// ficar girando pra sempre gastando crédito da API se algo estiver
// realmente quebrado (ex.: layout do site mudou de vez).
async function criarChavePix({ id, proxy, provedorNome, apiKey }) {
  if (!id) return { ok: false, error: "id da conta não informado" };
  if (!apiKey) return { ok: false, error: `API Key do provedor "${provedorNome || "?"}" não configurada (engrenagem na lista de Provedores).` };
  const ctrl = { cancelado: false };
  cancelamentosChavePix.set(String(id), ctrl);
  const checarCancelado = () => { if (ctrl.cancelado) throw new Error("CANCELADO_PELO_USUARIO"); };
  const MAX_FALHAS_SEGUIDAS = 30;
  // Pedido do usuário 2026-08-11 ("certifique-se que o bot não vai ficar
  // comprando vários e vários números e gastando saldo pela API") — número
  // reciclado não conta mais pro teto de falhas REAIS (ver comentário mais
  // abaixo), mas ainda precisa de um teto PRÓPRIO: cada tentativa, mesmo a
  // que dá em número reciclado, já comprou um número de verdade (o SMS já
  // chegou e foi confirmado — o cancelamento depois disso normalmente não
  // devolve o crédito, só evita continuar usando aquele número). Se o
  // provedor ficar devolvendo só número reciclado sem parar, o bot para por
  // segurança em vez de continuar comprando pra sempre.
  const MAX_RECICLADOS_SEGUIDOS = 15;
  let criadas = 0;
  let falhasSeguidas = 0;
  let reciclSeguidos = 0;
  try {
    const { page } = await getOuAbrirJanela({ id, proxy });
    checarCancelado();
    for (;;) {
      checarCancelado();
      // Pedido do usuário 2026-08-11 ("ainda está horrível o botão de
      // parar, demora funcionar") — checarCancelado() sozinho só interrompe
      // em pontos específicos do código; entre um ponto e outro (ex.: no
      // meio de um page.evaluate ou de uma navegação) o clique em Parar não
      // tinha efeito nenhum até o próximo checkpoint, que podia demorar
      // vários segundos. Fix: corrida (Promise.race) contra um watcher que
      // checa ctrl.cancelado a cada 150ms — o loop de fora devolve o
      // controle pro usuário quase na hora que clica em Parar, mesmo que a
      // tentativa em andamento continue terminando sozinha em segundo
      // plano (ela mesma vai se interromper nos próprios checkpoints
      // internos um instante depois, e cancelarECair ainda libera o número
      // comprado quando isso acontecer).
      const r = await new Promise((resolve, reject) => {
        let resolvido = false;
        const watcher = setInterval(() => {
          if (ctrl.cancelado && !resolvido) {
            resolvido = true;
            clearInterval(watcher);
            reject(new Error("CANCELADO_PELO_USUARIO"));
          }
        }, 50);
        tentarUmaChavePix({ page, id, provedorNome, apiKey, checarCancelado, deveCancelar: () => ctrl.cancelado })
          .then((v) => { if (!resolvido) { resolvido = true; clearInterval(watcher); resolve(v); } })
          .catch((e) => { if (!resolvido) { resolvido = true; clearInterval(watcher); reject(e); } });
      });
      if (r.ok) {
        criadas++;
        falhasSeguidas = 0;
        reciclSeguidos = 0;
        log(`conta ${id}: chave #${criadas} cadastrada (Celular ${r.numero}) — continuando pra próxima`);
        continue;
      }
      // BUG real 2026-08-11 (reportado pelo usuário: "parou de cadastrar
      // chave após clicar em cadastrar outra chave pois já existia dono") —
      // número reciclado (chaveJaTemDono) é um resultado NORMAL/esperado
      // (o provedor de SMS às vezes devolve um número que já foi usado como
      // chave por outra conta antes) e não indica que o fluxo está
      // quebrado — só precisa comprar outro número e tentar de novo. Antes
      // isso contava igual a uma falha de navegação/seletor real pro teto
      // de 30 falhas SEGUIDAS, e como o provedor pode devolver vários
      // números reciclados em sequência, isso batia o teto rápido e parava
      // o bot sem ter nada de fato quebrado. Agora só o teto de segurança
      // conta falhas REAIS (campo/botão não achado, timeout de código,
      // navegação inesperada) — número reciclado não conta pro teto, só
      // loga e tenta de novo, igual o usuário pediu.
      const motivo = r.chaveJaTemDono ? "número reciclado" : r.tentarOutro ? "falha de navegação/código" : (r.error || "falha desconhecida");
      if (r.chaveJaTemDono) {
        reciclSeguidos++;
        log(`conta ${id}: tentativa não deu — ${motivo} (${reciclSeguidos}/${MAX_RECICLADOS_SEGUIDOS} reciclados seguidos) — tentando de novo com outro número`);
        if (reciclSeguidos >= MAX_RECICLADOS_SEGUIDOS) {
          log(`conta ${id}: ${MAX_RECICLADOS_SEGUIDOS} números reciclados seguidos — parando pra não continuar gastando saldo da API à toa (provedor pode estar sem números novos pra esse serviço)`);
          return { ok: criadas > 0, criadas, error: `Parou depois de ${MAX_RECICLADOS_SEGUIDOS} números reciclados seguidos — provedor pode estar sem números novos.` };
        }
      } else {
        falhasSeguidas++;
        reciclSeguidos = 0;
        log(`conta ${id}: tentativa não deu — ${motivo} (${falhasSeguidas}/${MAX_FALHAS_SEGUIDAS} falhas seguidas) — tentando de novo`);
        if (falhasSeguidas >= MAX_FALHAS_SEGUIDAS) {
          log(`conta ${id}: ${MAX_FALHAS_SEGUIDAS} falhas seguidas sem nenhum sucesso — parando (algo deve estar errado no fluxo)`);
          return { ok: criadas > 0, criadas, error: `Parou depois de ${MAX_FALHAS_SEGUIDAS} falhas seguidas — última: ${motivo}` };
        }
      }
    }
  } catch (e) {
    if (e?.message === "CANCELADO_PELO_USUARIO") {
      log(`conta ${id}: criação de chaves PIX parada pelo usuário (${criadas} criada(s))`);
      return { ok: criadas > 0, criadas, error: "Cancelado", cancelado: true };
    }
    log(`conta ${id}: falha ao criar chave PIX — ${e?.message || e}`);
    return { ok: criadas > 0, criadas, error: e?.message || String(e) };
  } finally {
    cancelamentosChavePix.delete(String(id));
  }
}

// Libera o número comprado no provedor se algo falhar no meio do fluxo, pra
// não pagar por um número que nunca foi usado de verdade.
async function cancelarECair(compra, apiKey) {
  if (!compra || !compra.ok) return;
  try { await smsApi.cancelarNumero({ apiKey, id: compra.id }); } catch {}
}

module.exports = { abrirConta, fecharConta, copiarChaves, deletarChaves, contaEstaAberta, salvarLogin, criarChavePix, cancelarCriarChavePix };
