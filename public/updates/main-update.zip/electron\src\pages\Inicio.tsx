import { useEffect, useRef, useState } from "react";
import { q, run, getSetting, setSetting, getApi, log } from "@/lib/api";
import { useUI } from "@/stores/ui";
import { useAuth } from "@/stores/auth";
import {
  FolderOpen, Trash2, Smartphone, Globe, KeyRound, Plus, Minus,
  Play, Square, RefreshCw, Key, Check, Loader2, Eye, EyeOff, X, HelpCircle, Link2,
  QrCode, CheckCircle2,
} from "lucide-react";
import { PlansModal } from "@/components/PlansModal";
import { useCloudSession, planLabel, formatExpiry } from "@/stores/cloud-session";


type Toggle = { key: string; label: string; help?: string };

const FUNCS: Toggle[] = [
  { key: "func_proxy_off", label: "Proxy desativado" },
  { key: "func_captcha", label: "Resolver captcha" },
  { key: "func_sem_envelopes", label: "Sem anúncios", help: "Remove anúncios de bônus e promoções." },
  { key: "func_modo_retrato", label: "Modo retrato" },
  { key: "func_bloquear_2guia", label: "Bloquear 2ª guia" },
  { key: "func_modo_escadinha", label: "Escadinha", help: "Ao abrir diversas telas usa o link de uma para criar a próxima conta." },
];

type MultiLink = { url: string; selected: boolean };

const NAV: Toggle[] = [
  { key: "nav_modo_android", label: "Modo Aplicativo" },
  { key: "nav_chrome_indetectavel", label: "Modo Mobile" },
  { key: "nav_senhas", label: "Senhas" },
];

const NAV_ICONS: Record<string, any> = {
  nav_modo_android: Smartphone,
  nav_chrome_indetectavel: Globe,
  nav_senhas: KeyRound,
};

// const SUPORTE_URL removido — substituído pelo botão Token
const PROXY_EMPTY_MESSAGE = "Não tem proxy aplicada.";

async function hasAppliedProxy() {
  const rows = await q<{ id: number; host: string; port: number; username: string | null; password: string | null }>(`
    SELECT id, host, port, username, password FROM proxies
    WHERE TRIM(COALESCE(host, '')) <> ''
      AND CAST(port AS INTEGER) > 0
      AND TRIM(COALESCE(username, '')) <> ''
      AND TRIM(COALESCE(password, '')) <> ''
    LIMIT 1
  `);
  return rows.some((p) => {
    const host = String(p.host || "").trim();
    const port = Number(p.port);
    const username = String(p.username || "").trim();
    const password = String(p.password || "").trim();
    return /^[a-z0-9.-]+$/i.test(host) && port > 0 && port <= 65535 && username.length > 0 && password.length > 0;
  });
}

export function Inicio() {
  const [vals, setVals] = useState<Record<string, string>>({});
  const [logs, setLogs] = useState<any[]>([]);
  const [delay, setDelay] = useState("");
  const [delayPorLink, setDelayPorLink] = useState(false);
  const [headlessMode, setHeadlessMode] = useState(false); // Chrome sem janela nenhuma (--headless=new) — risco de quebrar resolução de captcha (GeeTest), ver aviso no checkbox
  const [qrQueue, setQrQueue] = useState<{ id: string; dataUrl: string; valor: number | null; tela: string | number | null; login?: string; at: number; paid?: boolean }[]>([]);
  const [qrIndex, setQrIndex] = useState(0);
  const [qtdContas, setQtdContas] = useState(1);
  const [dep1, setDep1] = useState("10");
  const [dep2, setDep2] = useState("30");
  const [link, setLink] = useState("");
  const [busy, setBusy] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [updateProgress, setUpdateProgress] = useState(0);
  const [updateStep, setUpdateStep] = useState("");
  const [senhasOpen, setSenhasOpen] = useState(false);
  const [senhaCadastro, setSenhaCadastro] = useState("");
  const [senhaSaque, setSenhaSaque] = useState<string[]>(["", "", "", "", "", ""]);
  const [showCad, setShowCad] = useState(false);
  const [showSaq, setShowSaq] = useState(false);
  const [savingSenhas, setSavingSenhas] = useState(false);
  const [multiOpen, setMultiOpen] = useState(false);
  const [multiLinks, setMultiLinks] = useState<MultiLink[]>([]);
  const [savingMulti, setSavingMulti] = useState(false);
  const [savedMultiCount, setSavedMultiCount] = useState(0);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkText, setBulkText] = useState("");
  const [playChoiceOpen, setPlayChoiceOpen] = useState(false);
  const [capsolverKey, setCapsolverKey] = useState("");
  const [showCapsolverKey, setShowCapsolverKey] = useState(false);
  const [capsolverBalance, setCapsolverBalance] = useState<string>("");
  const [testingCapsolver, setTestingCapsolver] = useState(false);
  const [solveCaptchaKey, setSolveCaptchaKey] = useState("");
  const [showSolveCaptchaKey, setShowSolveCaptchaKey] = useState(false);
  const [solveCaptchaBalance, setSolveCaptchaBalance] = useState<string>("");
  const [testingSolveCaptcha, setTestingSolveCaptcha] = useState(false);
  const [twoCaptchaKey, setTwoCaptchaKey] = useState("");
  const [showTwoCaptchaKey, setShowTwoCaptchaKey] = useState(false);
  const [twoCaptchaBalance, setTwoCaptchaBalance] = useState<string>("");
  const [testingTwoCaptcha, setTestingTwoCaptcha] = useState(false);
  const logRef = useRef<HTMLDivElement>(null);
  const { running, setRunning, showToast } = useUI();
  const user = useAuth((s) => s.user);
  const updateProgressRef = useRef(0);
  const editingRef = useRef<Set<string>>(new Set());
  const isEditing = (k: string) => editingRef.current.has(k);
  const editProps = (key: string) => ({
    onFocus: () => { editingRef.current.add(key); },
    onBlurCapture: () => {
      // remove after persist's onBlur handler completes
      setTimeout(() => editingRef.current.delete(key), 0);
    },
  });

  async function load() {
    const keys = [...FUNCS, ...NAV].map((t) => t.key);
    // Otimização 2026-08-18 (reportado pelo usuário: "sinto o bot pesado ao
    // abrir telas") — cada getSetting()/q() é um round-trip de IPC pro
    // processo main; antes eram ~20 chamadas em SEQUÊNCIA (uma espera a
    // outra terminar) toda vez que essa aba monta E de novo a cada 4s (ver
    // setInterval abaixo). Nenhuma depende do resultado das outras — dá pra
    // disparar todas de uma vez e esperar juntas (Promise.all), mesmo
    // resultado, uma fração do tempo de espera.
    const [
      settingsOut, proxyAplicada, delayVal, delayPorLinkVal, headlessVal,
      qtdContasVal, dep1Val, dep2Val, linkVal, capsolverVal, solveCaptchaVal,
      twoCaptchaVal, multiLinksRaw, rows,
    ] = await Promise.all([
      Promise.all(keys.map((k) => getSetting(k, "0"))),
      hasAppliedProxy(),
      getSetting("exec_delay_seg", ""),
      getSetting("exec_delay_por_link", "0"),
      getSetting("exec_headless", "0"),
      getSetting("exec_qtd_contas", "1"),
      getSetting("exec_dep_1", "10"),
      getSetting("exec_dep_2", "30"),
      getSetting("exec_link", ""),
      getSetting("capsolver_api_key", ""),
      getSetting("solvecaptcha_api_key", ""),
      getSetting("twocaptcha_api_key", ""),
      getSetting("exec_multi_links", ""),
      q<any>("SELECT * FROM logs WHERE source LIKE 'operacao%' OR source IS NULL ORDER BY id DESC LIMIT 200"),
    ]);
    const out: Record<string, string> = {};
    keys.forEach((k, i) => { out[k] = settingsOut[i]; });
    if (out.func_proxy_off === "1" && !proxyAplicada) {
      out.func_proxy_off = "0";
      await setSetting("func_proxy_off", "0");
      await setSetting("proxy_enabled", "0");
    }
    setVals(out);
    if (!isEditing("exec_delay_seg")) setDelay(delayVal);
    setDelayPorLink(delayPorLinkVal === "1");
    setHeadlessMode(headlessVal === "1");
    if (!isEditing("exec_qtd_contas")) setQtdContas(parseInt(qtdContasVal, 10) || 1);
    // Não substitui o que o usuário digitou/apagou — só usa o fallback quando
    // a setting nunca foi salva (null). Permite valor vazio enquanto edita.
    if (!isEditing("exec_dep_1")) setDep1(dep1Val);
    if (!isEditing("exec_dep_2")) setDep2(dep2Val);
    if (!isEditing("exec_link")) setLink(linkVal);
    if (!isEditing("capsolver_api_key")) setCapsolverKey(capsolverVal);
    if (!isEditing("solvecaptcha_api_key")) setSolveCaptchaKey(solveCaptchaVal);
    if (!isEditing("twocaptcha_api_key")) setTwoCaptchaKey(twoCaptchaVal);
    try {
      const arr = multiLinksRaw ? JSON.parse(multiLinksRaw) : [];
      const norm = normalizeMulti(arr);
      setSavedMultiCount(norm.filter((m) => m.selected && m.url.trim()).length);
    } catch { setSavedMultiCount(0); }
    // Pedido do usuário 2026-08-10: log de giros (Auto Slot) aparecia fora
    // de ordem entre telas (ex.: Tela 2, Tela 4, Tela 3...) — cada linha de
    // progresso (ver logSystemProgress/settingsStore.cjs) fica com o `id`
    // fixo desde a PRIMEIRA vez que aquela tela logou um giro; como as N
    // telas rodam em paralelo, qual delas responde primeiro é uma corrida
    // de rede, não a ordem numérica das telas. Reordena só as SEQUÊNCIAS
    // contíguas de linhas de progresso (kind começando com "auto-slot")
    // por número de tela — não toca em nenhuma outra linha do log.
    const getCtx = (r: any) => { try { return JSON.parse(r.context_json || "{}"); } catch { return {}; } };
    const isProgress = (r: any) => /^auto-slot/.test(String(getCtx(r).kind || ""));
    const getTela = (r: any) => { const t = Number(getCtx(r).tela); return Number.isFinite(t) ? t : 0; };
    let i = 0;
    while (i < rows.length) {
      if (isProgress(rows[i])) {
        let j = i;
        while (j < rows.length && isProgress(rows[j])) j++;
        const slice = rows.slice(i, j).sort((a, b) => getTela(a) - getTela(b));
        rows.splice(i, j - i, ...slice);
        i = j;
      } else i++;
    }
    setLogs(rows);
  }
  useEffect(() => {
    load();
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, []);

  // Log do Sistema: mantém o scroll sempre no final (mais recente embaixo),
  // igual o Log de Operações — sem isso ficava preso no topo a cada reload.
  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [logs]);

  useEffect(() => {
    let off: (() => void) | undefined;
    getApi().then((api) => {
      off = api.onUpdateProgress?.(({ percent, message }) => {
        updateProgressRef.current = percent;
        setUpdateProgress(percent);
        setUpdateStep(message);
      });
    });
    return () => off?.();
  }, []);

  // QR de depósito capturado (ver src/window/qrCapture.cjs) — hidrata a
  // fila já capturada nesta sessão ao montar, e assina novas capturas ao
  // vivo. Sempre pula pro mais recente quando um novo chega (é o que faz
  // sentido — o usuário quer ver o QR que acabou de aparecer).
  useEffect(() => {
    let offCaptured: (() => void) | undefined;
    let offPaid: (() => void) | undefined;
    getApi().then((api: any) => {
      api.getQrQueue?.().then((list: any[]) => {
        if (Array.isArray(list) && list.length) {
          setQrQueue(list);
          setQrIndex(list.length - 1);
        }
      });
      offCaptured = api.onQrCaptured?.((entry: any) => {
        setQrQueue((prev) => {
          const next = [...prev, entry];
          setQrIndex(next.length - 1);
          return next;
        });
      });
      // Pagamento confirmado (ver watchForPaymentConfirmation em
      // qrCapture.cjs) — só marca o QR já existente na fila como pago, não
      // mexe no índice atual (não força o usuário a sair de onde estava
      // olhando).
      offPaid = api.onQrPaid?.(({ id }: { id: string }) => {
        setQrQueue((prev) => prev.map((q) => (q.id === id ? { ...q, paid: true } : q)));
      });
    });
    return () => { offCaptured?.(); offPaid?.(); };
  }, []);

  async function applyProxyEnabledRows(on: boolean) {
    try {
      await run("UPDATE proxies SET enabled=?", [on ? 1 : 0]);
    } catch (e) {
      console.warn("applyProxyEnabledRows failed", e);
    }
  }

  async function toggle(key: string) {
    const next = vals[key] === "1" ? "0" : "1";
    if (key === "func_proxy_off" && next === "1") {
      if (!(await hasAppliedProxy())) {
        showToast(PROXY_EMPTY_MESSAGE, "error");
        setVals((v) => ({ ...v, [key]: "0" }));
        await setSetting(key, "0");
        await setSetting("proxy_enabled", "0");
        await applyProxyEnabledRows(false);
        return;
      }
    }
    setVals((v) => ({ ...v, [key]: next }));
    await setSetting(key, next);
    if (key === "func_proxy_off") {
      await setSetting("proxy_enabled", next);
      await applyProxyEnabledRows(next === "1");
    }
    if (key === "func_sem_envelopes") {
      // Avisa as janelas já abertas na hora — sem isso, desmarcar só fazia
      // efeito na próxima navegação (o fechador de popup ficava rodando
      // por até 10 minutos mesmo depois de desmarcado).
      try { await (window as any).api?.setPopupCloserEnabled?.(next === "1"); } catch {}
    }
  }

  async function toggleProxy() {
    if (vals.func_proxy_off === "1") {
      setVals((v) => ({ ...v, func_proxy_off: "0" }));
      await setSetting("func_proxy_off", "0");
      await setSetting("proxy_enabled", "0");
      await applyProxyEnabledRows(false);
      showToast("Proxy desligada", "success");
      return;
    }
    if (!(await hasAppliedProxy())) {
      showToast(PROXY_EMPTY_MESSAGE, "error");
      setVals((v) => ({ ...v, func_proxy_off: "0" }));
      await setSetting("func_proxy_off", "0");
      await setSetting("proxy_enabled", "0");
      await applyProxyEnabledRows(false);
      return;
    }
    setVals((v) => ({ ...v, func_proxy_off: "1" }));
    await setSetting("func_proxy_off", "1");
    await setSetting("proxy_enabled", "1");
    await applyProxyEnabledRows(true);
    showToast("Proxy ligada", "success");
  }

  async function toggleNav(key: string) {
    const wasOn = vals[key] === "1";
    const next: Record<string, string> = { ...vals };
    // mutually exclusive: turning one on disables the others
    for (const t of NAV) next[t.key] = "0";
    next[key] = wasOn ? "0" : "1";
    setVals(next);
    await Promise.all(NAV.map((t) => setSetting(t.key, next[t.key])));
    if (key === "nav_senhas" && !wasOn) {
      await openSenhas();
    }
  }

  async function openSenhas() {
    setSenhaCadastro(await getSetting("senha_cadastro", ""));
    const raw = await getSetting("senha_saque", "");
    const arr = raw.split("").slice(0, 6);
    while (arr.length < 6) arr.push("");
    setSenhaSaque(arr);
    setSenhasOpen(true);
  }

  async function salvarSenhas() {
    setSavingSenhas(true);
    try {
      await setSetting("senha_cadastro", senhaCadastro);
      await setSetting("senha_saque", senhaSaque.join(""));
      showToast("Senhas salvas", "success");
      setSenhasOpen(false);
    } catch (e) { showToast(String(e), "error"); }
    finally { setSavingSenhas(false); }
  }

  async function persist(key: string, value: string) { await setSetting(key, value); }

  async function salvarCapsolver(value: string) {
    const v = value.trim();
    setCapsolverKey(v);
    await setSetting("capsolver_api_key", v);
    if (v) showToast("Chave CapSolver salva", "success");
  }

  async function testarCapsolver() {
    const key = capsolverKey.trim();
    if (!key) { showToast("Cole sua API key primeiro", "error"); return; }
    setTestingCapsolver(true);
    setCapsolverBalance("");
    try {
      const res = await fetch("https://api.capsolver.com/getBalance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientKey: key }),
      });
      const json = await res.json();
      if (json.errorId) {
        showToast(`CapSolver: ${json.errorCode || json.errorDescription || "erro"}`, "error");
        setCapsolverBalance("inválida");
      } else {
        const bal = Number(json.balance || 0).toFixed(3);
        setCapsolverBalance(`$${bal}`);
        showToast(`Saldo CapSolver: $${bal}`, "success");
      }
    } catch (e: any) {
      showToast(`Falha ao consultar: ${e?.message || e}`, "error");
      setCapsolverBalance("falhou");
    } finally {
      setTestingCapsolver(false);
    }
  }

  async function salvarSolveCaptcha(value: string) {
    const v = value.trim();
    setSolveCaptchaKey(v);
    await setSetting("solvecaptcha_api_key", v);
    if (v) showToast("Chave SolveCaptcha salva", "success");
  }

  async function salvarTwoCaptcha(value: string) {
    const v = value.trim();
    setTwoCaptchaKey(v);
    await setSetting("twocaptcha_api_key", v);
    if (v) showToast("Chave 2Captcha salva", "success");
  }

  async function testarInPhpProvider(opts: {
    name: string;
    host: string;
    key: string;
    setBalance: (s: string) => void;
    setTesting: (b: boolean) => void;
  }) {
    const key = opts.key.trim();
    if (!key) { showToast("Cole sua API key primeiro", "error"); return; }
    opts.setTesting(true);
    opts.setBalance("");
    try {
      const url = `https://${opts.host}/res.php?key=${encodeURIComponent(key)}&action=getbalance&json=1`;
      const res = await fetch(url);
      const json = await res.json();
      if (Number(json.status) !== 1) {
        showToast(`${opts.name}: ${json.request || "erro"}`, "error");
        opts.setBalance("inválida");
      } else {
        const bal = Number(json.request || 0).toFixed(3);
        opts.setBalance(`$${bal}`);
        showToast(`Saldo ${opts.name}: $${bal}`, "success");
      }
    } catch (e: any) {
      showToast(`Falha ao consultar: ${e?.message || e}`, "error");
      opts.setBalance("falhou");
    } finally {
      opts.setTesting(false);
    }
  }



  const MULTI_SLOTS = 50;

  function normalizeMulti(arr: any): MultiLink[] {
    if (!Array.isArray(arr)) arr = [];
    const out: MultiLink[] = arr.map((it: any) => {
      if (typeof it === "string") return { url: it, selected: true };
      return { url: String(it?.url || ""), selected: it?.selected !== false };
    });
    while (out.length < MULTI_SLOTS) out.push({ url: "", selected: false });
    return out.slice(0, MULTI_SLOTS);
  }

  async function openMultiLinks() {
    const raw = await getSetting("exec_multi_links", "");
    let arr: any[] = [];
    try { arr = raw ? JSON.parse(raw) : []; } catch { arr = []; }
    setMultiLinks(normalizeMulti(arr));
    setMultiOpen(true);
  }

  async function salvarMultiLinks() {
    setSavingMulti(true);
    try {
      const clean = multiLinks
        .map((m) => ({ url: m.url.trim(), selected: m.selected }))
        .filter((m) => m.url);
      await setSetting("exec_multi_links", JSON.stringify(clean));
      const selCount = clean.filter((m) => m.selected).length;
      setSavedMultiCount(selCount);
      showToast(`${clean.length} link(s) salvos · ${selCount} selecionado(s)`, "success");
      setMultiOpen(false);
    } catch (e) { showToast(String(e), "error"); }
    finally { setSavingMulti(false); }
  }

  async function play() {
    if (savedMultiCount > 0) {
      setPlayChoiceOpen(true);
      return;
    }
    await executarPlay("solo");
  }

  // Aceita o link digitado sem protocolo (ex: "meusite.com") — o Electron
  // recusa loadURL sem um esquema válido (http/https), dando ERR_INVALID_URL.
  function normalizeUrl(raw: string): string {
    const v = raw.trim();
    if (!v) return v;
    if (/^[a-zA-Z][a-zA-Z0-9+\-.]*:\/\//.test(v)) return v; // já tem protocolo
    return `https://${v}`;
  }

  async function executarPlay(mode: "solo" | "multi") {
    setPlayChoiceOpen(false);
    if (mode === "solo" && !link.trim()) { showToast("Informe um link primeiro", "error"); return; }
    setBusy(true);
    try {
      await setSetting("exec_link", link);
      const api = await getApi();
      const accounts = await q("SELECT * FROM accounts WHERE status='active' ORDER BY id LIMIT ?", [qtdContas]);
      // BUG real 2026-08-18 (reportado pelo usuário: "delay por link deve
      // ser funcional... se não estiver selecionado não deve ter delay
      // mesmo se configuramos alguns segundos") — antes o checkbox só era
      // salvo/lido (delayPorLink), nunca CONSULTADO aqui; o delay
      // configurado sempre era aplicado, com ou sem o checkbox marcado.
      const delaySec = delayPorLink ? (parseInt(delay, 10) || 0) : 0;
      if (mode === "multi") {
        const raw = await getSetting("exec_multi_links", "");
        let parsed: any[] = [];
        try { parsed = raw ? JSON.parse(raw) : []; } catch {}
        const links: string[] = (Array.isArray(parsed) ? parsed : [])
          .map((it) => (typeof it === "string" ? { url: it, selected: true } : { url: String(it?.url || ""), selected: it?.selected !== false }))
          .filter((m) => m.selected && m.url.trim())
          .map((m) => normalizeUrl(m.url));
        if (links.length === 0) { showToast("Nenhum link múltiplo selecionado", "error"); return; }
        if (api.openChromiumMulti) {
          await api.openChromiumMulti(links, qtdContas, accounts, delaySec, headlessMode);
        } else if (api.openChromium) {
          // Fallback: abre um por um
          for (let i = 0; i < Math.min(qtdContas, links.length); i++) {
            await api.openChromium(links[i], 1, accounts.slice(i, i + 1), delaySec, headlessMode);
          }
        } else {
          await api.startWorkers(qtdContas, accounts);
        }
        await log("info", "operacao", `Play multi: ${links.length} links / ${qtdContas} contas`, null, user?.id);
        showToast(`${qtdContas} Chromium aberto(s) (multi)`, "success");
      } else {
        if (api.openChromium) {
          await api.openChromium(normalizeUrl(link), qtdContas, accounts, delaySec, headlessMode);
        } else {
          await api.startWorkers(qtdContas, accounts);
        }
        await log("info", "operacao", `Play: ${qtdContas} Chromium em ${link}`, null, user?.id);
        showToast(`${qtdContas} Chromium aberto(s)`, "success");
      }
      setRunning(true);
    } catch (e) {
      showToast(String(e), "error");
    } finally { setBusy(false); }
  }

  async function stop() {
    setBusy(true);
    try {
      const api = await getApi();
      if (api.closeChromium) await api.closeChromium();
      await api.stopWorkers();
      setRunning(false);
      // QR de depósito capturado é das contas que acabaram de ser
      // encerradas — não faz sentido continuar mostrando.
      try { await api.clearQrQueue?.(); } catch {}
      setQrQueue([]);
      setQrIndex(0);
      showToast("Encerrado", "info");
    } finally { setBusy(false); }
  }

  async function atualizar() {
    setUpdating(true);
    setUpdateProgress(0);
    setUpdateStep("Iniciando...");
    try {
      const api = await getApi();
      if (!api.installUpdate) {
        showToast("Atualização automática disponível apenas no aplicativo instalado", "error");
        return;
      }
      const r = await api.installUpdate();
      if (!r.ok) throw new Error(r.error || "Falha ao atualizar");
      if (r.hasUpdate === false) showToast(r.note || "Você já está na última versão", "info");
      else showToast("Atualização concluída. Reiniciando...", "success");
    } catch (e) {
      showToast(String(e), "error");
    } finally {
      setTimeout(() => {
        setUpdating(false);
        updateProgressRef.current = 0;
        setUpdateProgress(0);
        setUpdateStep("");
      }, 300);
    }
  }

  // Token modal — exige identificação (login+senha do cloud) antes dos planos
  const [tokenStep, setTokenStep] = useState<"closed" | "identify" | "plans">("closed");
  const [tokenIdentity, setTokenIdentity] = useState<{ login: string; password: string } | null>(null);
  const [identLogin, setIdentLogin] = useState("");
  const [identPwd, setIdentPwd] = useState("");

  function openToken() {
    if (tokenIdentity) { setTokenStep("plans"); return; }
    setTokenStep("identify");
  }
  function confirmIdentity() {
    if (!identLogin.trim() || !identPwd) return;
    setTokenIdentity({ login: identLogin.trim().toLowerCase(), password: identPwd });
    setTokenStep("plans");
  }

  return (
    <div className="h-full max-h-screen p-2 flex flex-col gap-2 overflow-hidden">
      <header className="shrink-0 flex items-baseline gap-3">
        <h1 className="text-xl font-semibold text-white leading-none">Início</h1>
        <p className="text-xs text-muted truncate">Configurações de navegação, funcionalidades e log do sistema.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-2 flex-1 min-h-0 overflow-hidden">
        {/* ============ Configuração de Navegação ============ */}
        <section className="card flex flex-col overflow-hidden min-h-0">

          <div className="bg-black text-white text-xs font-semibold text-center py-1.5 border-b border-border">
            Configuração de Navegação
          </div>
          <div className="p-1.5 space-y-1">
            {NAV.map((t) => {
              const Icon = NAV_ICONS[t.key];
              const isSenhas = t.key === "nav_senhas";
              const on = vals[t.key] === "1";
              if (isSenhas) {
                return (
                  <button
                    key={t.key}
                    onClick={openSenhas}
                    className="w-full flex items-center justify-center gap-2 px-3 py-1 rounded-md border border-border bg-panel2 text-white text-xs font-semibold hover:bg-panel2/70 transition"
                  >
                    {Icon && <Icon className="w-3.5 h-3.5" />}
                    {t.label}
                  </button>
                );
              }
              return (
                <button
                  key={t.key}
                  onClick={() => toggleNav(t.key)}
                  className={`w-full flex items-center justify-between px-3 py-1 rounded-md border text-xs font-medium transition ${
                    on ? "bg-success/10 border-success text-white" : "bg-panel2 border-border text-slate-200 hover:bg-panel2/70"
                  }`}
                >
                  <span className="flex items-center gap-2">
                    {Icon && <Icon className="w-3.5 h-3.5" />}
                    {t.label}
                  </span>
                  <span className={`w-4 h-4 rounded-sm flex items-center justify-center ${on ? "bg-success" : "bg-neutral-700"}`}>
                    {on && <Check className="w-3 h-3 text-black" />}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="bg-black text-white text-xs font-semibold text-center py-1 border-y border-border">
            Ajustes de Execução
          </div>
          <div className="p-1.5 space-y-1 overflow-y-auto min-h-0 flex-1">

            <div>
              <label className="label !mb-0.5">Delay (segundos):</label>
              <input className="input text-center !py-1 !text-xs" placeholder="(SEGUNDOS)" value={delay}
                {...editProps("exec_delay_seg")}
                onChange={(e) => setDelay(e.target.value)} onBlur={() => persist("exec_delay_seg", delay)} />
            </div>
            <label className="flex items-center gap-2 text-xs text-white">
              <input type="checkbox" checked={delayPorLink}
                className="accent-success"
                onChange={(e) => { setDelayPorLink(e.target.checked); persist("exec_delay_por_link", e.target.checked ? "1" : "0"); }} />
              Delay por Link
            </label>
            <div>
              <label className="label !mb-0.5">Quantidade de Contas:</label>
              <div className="flex items-center gap-1.5">
                <button className="btn-ghost px-1.5 py-1 border border-border" onClick={() => { const v = Math.max(1, qtdContas - 1); setQtdContas(v); persist("exec_qtd_contas", String(v)); }}>
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <input className="input text-center !py-1 !text-xs" value={qtdContas}
                  {...editProps("exec_qtd_contas")}
                  onChange={(e) => { const v = Math.max(1, parseInt(e.target.value || "1", 10) || 1); setQtdContas(v); }}
                  onBlur={() => persist("exec_qtd_contas", String(qtdContas))} />
                <button className="btn-ghost px-1.5 py-1 border border-border" onClick={() => { const v = qtdContas + 1; setQtdContas(v); persist("exec_qtd_contas", String(v)); }}>
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div>
              <label className="label !mb-0.5">Valores Para Depósito:</label>
              <div className="grid grid-cols-2 gap-2">
                <input className="input text-center !py-1 !text-xs" value={dep1} {...editProps("exec_dep_1")} onChange={(e) => setDep1(e.target.value)} onBlur={() => persist("exec_dep_1", dep1)} />
                <input className="input text-center !py-1 !text-xs" value={dep2} {...editProps("exec_dep_2")} onChange={(e) => setDep2(e.target.value)} onBlur={() => persist("exec_dep_2", dep2)} />
              </div>
            </div>

            {/* ===== Operação Oculta (headless) ===== */}
            <button
              type="button"
              onClick={() => { const v = !headlessMode; setHeadlessMode(v); persist("exec_headless", v ? "1" : "0"); }}
              title="Chrome roda sem NENHUMA janela visível (nem minimizada, nem na barra de tarefas) — 100% em segundo plano. Risco: alguns sistemas anti-bot (GeeTest incluso) detectam esse modo e podem falhar na resolução do captcha durante o cadastro."
              className={`w-full flex items-center gap-2.5 rounded-lg border px-3 py-2 transition-colors text-left ${
                headlessMode ? "bg-warning/10 border-warning" : "bg-panel2 border-border hover:bg-panel2/70"
              }`}
            >
              <span className={`w-8 h-8 shrink-0 rounded-md flex items-center justify-center ${headlessMode ? "bg-warning text-black" : "bg-black text-neutral-400"}`}>
                <EyeOff className="w-4 h-4" />
              </span>
              <span className="flex-1 min-w-0">
                <span className="block text-sm font-bold text-white leading-tight">Operação Oculta</span>
                <span className="block text-[10px] text-muted leading-tight">Cadastra sem abrir nenhuma janela na tela</span>
              </span>
              <span className={`w-4 h-4 shrink-0 rounded-sm border flex items-center justify-center ${headlessMode ? "border-warning bg-warning" : "border-neutral-600 bg-panel2"}`}>
                {headlessMode && <Check className="w-3 h-3 text-black" />}
              </span>
            </button>
            <p className={`text-center text-lg font-extrabold tracking-wide ${headlessMode ? "text-warning" : "text-neutral-600"}`}>
              {headlessMode ? "ATIVADO" : "DESATIVADO"}
            </p>
          </div>
        </section>

        {/* ============ Funcionalidades ============ */}
        <section className="card flex flex-col overflow-hidden min-h-0">
          <div className="bg-black text-white text-xs font-semibold text-center py-1.5 border-b border-border">
            Funcionalidades
          </div>
          <div className="flex-1 min-h-0 overflow-hidden">
          <div className="p-2 grid grid-cols-1 sm:grid-cols-2 gap-x-2 gap-y-1">

            {FUNCS.map((t) => {
              const on = vals[t.key] === "1";
              if (t.key === "func_proxy_off") {
                return (
                  <button
                    key={t.key}
                    type="button"
                    onClick={toggleProxy}
                    aria-pressed={on}
                    className={`flex items-center gap-2 text-xs leading-tight cursor-pointer select-none rounded-md px-2 py-1 text-left transition-colors ${
                      on ? "bg-success/10 text-white" : "text-neutral-300 hover:bg-panel2/60"
                    }`}
                  >
                    <span
                      className={`w-4 h-4 shrink-0 rounded-sm border flex items-center justify-center ${
                        on ? "border-success bg-success" : "border-neutral-600 bg-panel2"
                      }`}
                    >
                      {on && <Check className="w-3 h-3 text-black" />}
                    </span>
                    <span className="truncate flex-1">
                      Proxy{" "}
                      <span className={on ? "text-success font-semibold" : "text-danger font-semibold"}>
                        {on ? "On" : "Off"}
                      </span>
                    </span>
                  </button>
                );
              }
              return (
                <label
                  key={t.key}
                  className={`flex items-center gap-2 text-xs leading-tight cursor-pointer select-none rounded-md px-2 py-1 transition-colors ${
                    on ? "bg-success/10 text-white" : "text-neutral-300 hover:bg-panel2/60"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={on}
                    onChange={() => toggle(t.key)}
                    className="sr-only"
                  />
                  <span
                    className={`w-4 h-4 shrink-0 rounded-sm border flex items-center justify-center ${
                      on ? "border-success bg-success" : "border-neutral-600 bg-panel2"
                    }`}
                  >
                    {on && <Check className="w-3 h-3 text-black" />}
                  </span>
                  <span className="truncate flex-1">
                    {t.label}
                  </span>
                  {/* BUG real 2026-08-18 (reportado pelo usuário: passar o
                      mouse na "?" da Escadinha não mostrava nada) — o texto
                      de ajuda (t.help) já existia nos dados, só faltava o
                      atributo title de verdade nesse span; corrige pra
                      TODOS os toggles com help, não só Escadinha. */}
                  {t.help && <span className="text-muted text-[10px] cursor-help" title={t.help}>?</span>}
                </label>
              );
            })}
          </div>
          {/* Campo da API CapSolver removido — chave embutida no bot, créditos consumidos da conta Pandora */}

          {/* ===== QR de Depósito capturado (Operação Oculta) =====
              Fica no espaço sobrando embaixo da lista de Funcionalidades.
              Contador + setas voltar/avançar embaixo dele; fica verde com
              selo "PAGO" quando o pagamento é confirmado (ver
              deposit:qrPaid, qrCapture.cjs). */}
          <div className="mt-1 mx-2 mb-2 rounded-lg border border-border bg-panel2/40 p-1.5 flex flex-col items-center gap-0.5">
            <div className="w-full flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-[11px] font-semibold text-white">
                <QrCode className="w-3.5 h-3.5 text-success" /> QR de Depósito
              </span>
              {qrQueue.length > 0 && (
                <span className="text-[10px] text-muted">{qrIndex + 1}/{qrQueue.length}</span>
              )}
            </div>
            {qrQueue.length > 0 ? (
              <>
                <div className={`relative rounded-md p-1.5 transition-colors ${qrQueue[qrIndex]?.paid ? "bg-success ring-2 ring-success animate-pulse" : "bg-white"}`}>
                  <img src={qrQueue[qrIndex]?.dataUrl} alt="QR de depósito"
                    className="w-full max-w-[200px] aspect-square object-contain rounded-sm" />
                  {qrQueue[qrIndex]?.paid && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-1 bg-success/90 rounded-md">
                      <CheckCircle2 className="w-10 h-10 text-black" />
                      <span className="text-black text-sm font-extrabold tracking-wide">PAGO</span>
                    </div>
                  )}
                </div>
                <div className="text-[10px] text-muted text-center leading-tight">
                  {qrQueue[qrIndex]?.valor != null && <span className="text-success font-semibold">R$ {Number(qrQueue[qrIndex].valor).toFixed(2)}</span>}
                  {qrQueue[qrIndex]?.tela != null && <span> — Tela {qrQueue[qrIndex].tela}</span>}
                </div>
                <div className="flex items-center gap-2">
                  <button type="button"
                    onClick={() => setQrIndex((i) => (i - 1 + qrQueue.length) % qrQueue.length)}
                    className="px-2.5 py-1 rounded-md border border-border bg-panel2 hover:bg-panel2/70 text-white text-[11px] font-semibold transition-colors">
                    Voltar
                  </button>
                  <button type="button"
                    onClick={() => setQrIndex((i) => (i + 1) % qrQueue.length)}
                    className="px-2.5 py-1 rounded-md border border-border bg-panel2 hover:bg-panel2/70 text-white text-[11px] font-semibold transition-colors">
                    Avançar
                  </button>
                </div>
              </>
            ) : (
              <p className="text-[10px] text-muted text-center py-4">Nenhum QR capturado ainda</p>
            )}
          </div>
          </div>

        </section>


        {/* ============ Log de Operações ============ */}
        <section className="card overflow-hidden flex flex-col min-h-0">
          <CloudSessionBanner />
          <div className="bg-black text-white text-xs font-semibold py-1.5 px-2 border-b border-border flex items-center justify-between">

            <span>Log de Operações:</span>
            <div className="flex gap-2">
              <button
                onClick={async () => {
                  try {
                    const api: any = await getApi();
                    if (api && typeof api.openLogsFile === "function") {
                      const r = await api.openLogsFile({});
                      if (r?.ok) showToast(`Logs abertos: ${r.path}`, "success");
                      else showToast(`Falha ao abrir logs: ${r?.error || "desconhecida"}`, "error");
                    } else {
                      showToast("Atualize o bot para a versão mais recente.", "error");
                    }
                  } catch (e: any) { showToast(`Erro: ${e?.message || e}`, "error"); }
                }}
                className="flex items-center gap-1 px-2 py-1 rounded bg-panel2 border border-border text-white text-xs hover:bg-panel2/70">
                <FolderOpen className="w-3 h-3" /> Abrir
              </button>
              <button
                onClick={async () => {
                  try {
                    const api: any = await getApi();
                    if (api && typeof api.openDiagFile === "function") {
                      const r = await api.openDiagFile({});
                      if (r?.ok) showToast(`DIAG copiado p/ área de transferência (${r.bytes} bytes) — ${r.path}`, "success");
                      else showToast(`Falha DIAG: ${r?.error || "desconhecida"} — ${r?.path || ""}`, "error");
                    } else {
                      showToast("Atualize o bot para usar exportação DIAG.", "error");
                    }
                  } catch (e: any) { showToast(`Erro: ${e?.message || e}`, "error"); }
                }}
                className="flex items-center gap-1 px-2 py-1 rounded bg-blue-600 border border-border text-white text-xs hover:bg-blue-500">
                <FolderOpen className="w-3 h-3" /> DIAG
              </button>
              <button onClick={async () => { await q("DELETE FROM logs"); setLogs([]); }}
                className="flex items-center gap-1 px-2 py-1 rounded bg-danger text-white text-xs hover:bg-danger/90">
                <Trash2 className="w-3 h-3" /> Clear
              </button>
            </div>
          </div>
          <div ref={logRef} className="p-2 font-mono text-[11px] space-y-1 overflow-y-auto min-h-0 flex-1 bg-panel">
            {logs.length === 0 ? (
              <p className="text-muted">Emulação: Modo Aplicativo</p>
            ) : (
              [...logs].reverse().map((l: any) => (
                <div key={l.id} className="flex gap-2">
                  <span className={l.level === "error" ? "text-danger" : l.level === "warn" ? "text-warning" : "text-white"}>{l.message}</span>
                </div>
              ))
            )}
          </div>
        </section>
      </div>

      {/* ============ Barra inferior: Link + Play + Atualizações + Suporte ============ */}
      <section className="card p-2 flex flex-row items-center gap-2 shrink-0 overflow-hidden">
        <label className="text-xs font-semibold text-white whitespace-nowrap px-1">Link:</label>
        <input
          className="input flex-1 min-w-[220px] h-8 py-1 text-xs"
          placeholder="https://..."
          value={link}
          {...editProps("exec_link")}
          onChange={(e) => setLink(e.target.value)}
          onBlur={() => persist("exec_link", link)}
        />
        <button
          type="button"
          onClick={openMultiLinks}
          className="h-8 inline-flex items-center justify-center gap-1.5 px-3 rounded-md bg-panel2 border border-border text-white text-xs font-semibold hover:bg-panel2/70 whitespace-nowrap shrink-0"
        >
          <Link2 className="w-3.5 h-3.5 text-success" />
          Múltiplos Links
        </button>
        {!running ? (
          <button onClick={play} disabled={busy}
            className="h-8 inline-flex items-center justify-center gap-1.5 px-5 rounded-md bg-success text-black font-bold text-xs hover:bg-success/90 disabled:opacity-50 whitespace-nowrap shrink-0">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-black" />}
            Play
          </button>
        ) : (
          <button onClick={stop} disabled={busy}
            className="h-8 inline-flex items-center justify-center gap-1.5 px-5 rounded-md bg-danger text-white font-bold text-xs hover:bg-danger/90 disabled:opacity-50 whitespace-nowrap shrink-0">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Square className="w-4 h-4 fill-white" />}
            Stop
          </button>
        )}
        <button onClick={atualizar} disabled={updating}
          className="h-8 inline-flex items-center justify-center gap-1.5 px-4 rounded-md bg-white text-black font-semibold text-xs hover:bg-neutral-200 disabled:opacity-50 whitespace-nowrap shrink-0">
          {updating ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          Atualizações
        </button>
        <button onClick={openToken}
          className="h-8 inline-flex items-center justify-center gap-1.5 px-4 rounded-md bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/20 font-semibold text-xs whitespace-nowrap shrink-0">
          <Key className="w-4 h-4" />
          Token
        </button>
      </section>

      {/* ============ Modal Progresso Atualização ============ */}
      {updating && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70">
          <div className="w-[360px] bg-panel border border-border rounded-lg shadow-2xl overflow-hidden">
            <div className="flex items-center gap-2 px-3 py-2 bg-panel2 border-b border-border text-white text-sm font-semibold">
              <RefreshCw className="w-4 h-4 text-success animate-spin" />
              Atualizando aplicativo
            </div>
            <div className="px-4 py-5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted truncate">{updateStep || "Aguarde..."}</span>
                <span className="text-success font-mono">{updateProgress}%</span>
              </div>
              <div className="w-full h-2 rounded-full bg-panel2 overflow-hidden border border-border">
                <div
                  className="h-full bg-success transition-[width] duration-200 ease-out"
                  style={{ width: `${updateProgress}%` }}
                />
              </div>
              <p className="text-[11px] text-muted text-center">
                Não feche o aplicativo durante a atualização.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ============ Modal Gerenciador de Senhas ============ */}
      {senhasOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={() => setSenhasOpen(false)}>
          <div className="w-[360px] bg-panel border border-border rounded-lg shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-3 py-2 bg-panel2 border-b border-border">
              <div className="flex items-center gap-2 text-white text-sm font-semibold">
                <KeyRound className="w-4 h-4 text-success" />
                Gerenciador de Senhas
              </div>
              <button onClick={() => setSenhasOpen(false)} className="text-muted hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="px-4 py-4 space-y-5">
              <div className="flex items-center justify-between">
                <div className="px-3 py-1 rounded-md bg-white text-black text-xs font-semibold">
                  Segurança &amp; Senhas
                </div>
                <HelpCircle className="w-4 h-4 text-warning" />
              </div>

              <div>
                <div className="text-center text-sm text-white mb-2">Senha de Cadastro</div>
                <div className="flex items-center gap-2">
                  <input
                    type={showCad ? "text" : "password"}
                    value={senhaCadastro}
                    onChange={(e) => setSenhaCadastro(e.target.value)}
                    className="input flex-1 text-center tracking-widest border-success/60"
                  />
                  <button onClick={() => setShowCad((v) => !v)} className="text-muted hover:text-white">
                    {showCad ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <div className="text-center text-sm text-white mb-2">Senha de Saque</div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 grid grid-cols-6 gap-1">
                    {senhaSaque.map((d, i) => (
                      <input
                        key={i}
                        maxLength={1}
                        type={showSaq ? "text" : "password"}
                        value={d}
                        onChange={(e) => {
                          const v = e.target.value.replace(/\D/g, "").slice(0, 1);
                          const next = [...senhaSaque];
                          next[i] = v;
                          setSenhaSaque(next);
                          if (v && i < 5) {
                            const el = document.getElementById(`saq-${i + 1}`) as HTMLInputElement | null;
                            el?.focus();
                          }
                        }}
                        id={`saq-${i}`}
                        className="input text-center px-0 py-2"
                      />
                    ))}
                  </div>
                  <button onClick={() => setShowSaq((v) => !v)} className="text-muted hover:text-white">
                    {showSaq ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>


              <p className="text-xs text-center text-sky-400">
                ⓘ Senhas em branco serão geradas aleatoriamente por conta.
              </p>
            </div>

            <button
              onClick={salvarSenhas}
              disabled={savingSenhas}
              className="w-full py-3 bg-success hover:bg-success/90 text-black font-bold text-sm disabled:opacity-50"
            >
              {savingSenhas ? "Salvando..." : "Salvar"}
            </button>
          </div>
        </div>
      )}

      {/* ============ Modal Múltiplos Links ============ */}
      {multiOpen && (() => {
        const filled = multiLinks.filter((m) => m.url.trim());
        const selCount = filled.filter((m) => m.selected).length;
        return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={() => setMultiOpen(false)}>
          <div className="w-[560px] max-h-[88vh] bg-panel border border-border rounded-lg shadow-2xl overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-3 py-2 bg-panel2 border-b border-border">
              <div className="flex items-center gap-2 text-white text-sm font-semibold">
                <Link2 className="w-4 h-4 text-success" />
                Múltiplos Links
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => { setBulkText(multiLinks.map((m) => m.url).filter((u) => u.trim()).join("\n")); setBulkOpen(true); }}
                  className="px-2 py-1 rounded text-[11px] font-semibold uppercase tracking-wider bg-black hover:bg-zinc-900 text-white border border-zinc-700"
                  title="Colar vários links de uma vez"
                >
                  Vários Links
                </button>
                <button
                  onClick={() => {
                    if (!multiLinks.some((m) => m.url.trim())) return;
                    if (!confirm("Excluir todos os links?")) return;
                    setMultiLinks(Array.from({ length: MULTI_SLOTS }, () => ({ url: "", selected: false })));
                  }}
                  className="px-2 py-1 rounded text-[11px] font-semibold uppercase tracking-wider bg-red-600/90 hover:bg-red-600 text-white border border-red-700 inline-flex items-center gap-1"
                  title="Excluir todos os links"
                >
                  <Trash2 className="w-3 h-3" />
                  Excluir tudo
                </button>
                <button onClick={() => setMultiOpen(false)} className="text-muted hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="px-4 py-3 space-y-2 overflow-y-auto">
              <p className="text-xs text-muted">
                Cole vários links de uma vez no botão <b>Vários Links</b> acima, ou edite cada slot abaixo. Marque a caixinha dos que deseja abrir ao executar.
              </p>
              <label className="flex items-center gap-2 px-2 py-1.5 rounded border border-border bg-panel2 cursor-pointer select-none">
                <input
                  type="checkbox"
                  className="accent-success w-4 h-4 shrink-0"
                  checked={filled.length > 0 && filled.every((m) => m.selected)}
                  ref={(el) => {
                    if (el) el.indeterminate = selCount > 0 && selCount < filled.length;
                  }}
                  onChange={(e) => {
                    const check = e.target.checked;
                    setMultiLinks((prev) =>
                      prev.map((m) => (m.url.trim() ? { ...m, selected: check } : m))
                    );
                  }}
                />
                <span className="text-xs text-white font-semibold">Selecionar todos</span>
                <span className="text-[11px] text-muted ml-auto">{selCount}/{filled.length}</span>
              </label>
              <div className="space-y-1.5">
                {multiLinks.map((m, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <span className="text-[11px] text-muted w-5 text-right">{i + 1}.</span>
                    <input
                      type="checkbox"
                      className="accent-success w-4 h-4 shrink-0"
                      checked={m.selected}
                      onChange={(e) => {
                        const next = [...multiLinks];
                        next[i] = { ...next[i], selected: e.target.checked };
                        setMultiLinks(next);
                      }}
                      title="Incluir este link na execução"
                    />
                    <input
                      className="input flex-1 font-mono text-xs h-8"
                      placeholder={`https://exemplo${i + 1}.com`}
                      value={m.url}
                      onChange={(e) => {
                        const next = [...multiLinks];
                        next[i] = { ...next[i], url: e.target.value };
                        setMultiLinks(next);
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const next = [...multiLinks];
                        next.splice(i, 1);
                        next.push({ url: "", selected: false });
                        setMultiLinks(next);
                      }}
                      className="shrink-0 w-7 h-7 inline-flex items-center justify-center rounded border border-border bg-panel2 text-muted hover:text-white hover:bg-red-600/80 hover:border-red-700"
                      title="Excluir este link"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-between text-[11px] pt-1">
                <span className="text-muted">{filled.length}/{MULTI_SLOTS} links preenchidos</span>
                <span className="text-success">{selCount} selecionado(s) p/ executar</span>
              </div>
            </div>

            <button
              onClick={salvarMultiLinks}
              disabled={savingMulti}
              className="w-full py-3 bg-success hover:bg-success/90 text-black font-bold text-sm disabled:opacity-50"
            >
              {savingMulti ? "Salvando..." : "Salvar"}
            </button>
          </div>
        </div>
        );
      })()}

      {/* ============ Modal Vários Links (colar em massa) ============ */}
      {bulkOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80" onClick={() => setBulkOpen(false)}>
          <div className="w-[560px] max-h-[88vh] bg-panel border border-border rounded-lg shadow-2xl overflow-hidden flex flex-col" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-3 py-2 bg-panel2 border-b border-border">
              <div className="flex items-center gap-2 text-white text-sm font-semibold">
                <Link2 className="w-4 h-4 text-success" />
                Vários Links — colar em massa
              </div>
              <button onClick={() => setBulkOpen(false)} className="text-muted hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 overflow-y-auto">
              <p className="text-xs text-muted">
                Cole <b>um link por linha</b>. Ao salvar, eles serão organizados nos slots automaticamente (máx {MULTI_SLOTS}).
              </p>
              <textarea
                value={bulkText}
                onChange={(e) => setBulkText(e.target.value)}
                rows={14}
                autoFocus
                placeholder={"https://exemplo1.com\nhttps://exemplo2.com\nhttps://exemplo3.com"}
                className="w-full bg-panel2 border border-border rounded px-3 py-2 text-xs text-white font-mono"
              />
              <p className="text-[11px] text-muted">
                {bulkText.split(/\r?\n/).map((s) => s.trim()).filter(Boolean).length} link(s) detectado(s)
              </p>
            </div>
            <button
              onClick={() => {
                const links = bulkText
                  .split(/\r?\n/)
                  .map((s) => s.trim())
                  .filter(Boolean)
                  .slice(0, MULTI_SLOTS)
                  .map((url) => ({ url, selected: true }));
                while (links.length < MULTI_SLOTS) links.push({ url: "", selected: false });
                setMultiLinks(links);
                setBulkOpen(false);
                showToast(`${links.filter((l) => l.url).length} link(s) preenchidos`, "success");
              }}
              className="w-full py-3 bg-success hover:bg-success/90 text-black font-bold text-sm"
            >
              Aplicar
            </button>
          </div>
        </div>
      )}



      {/* ============ Modal escolha Play: Solo / Múltiplos ============ */}
      {playChoiceOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={() => setPlayChoiceOpen(false)}>
          <div className="w-[400px] bg-panel border border-border rounded-lg shadow-2xl overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-3 py-2 bg-panel2 border-b border-border">
              <div className="flex items-center gap-2 text-white text-sm font-semibold">
                <Play className="w-4 h-4 text-success" />
                Como deseja executar?
              </div>
              <button onClick={() => setPlayChoiceOpen(false)} className="text-muted hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3">
              <p className="text-xs text-muted">Você tem <b>{savedMultiCount}</b> link(s) salvos em Múltiplos Links.</p>
              <button
                onClick={() => executarPlay("solo")}
                className="w-full flex items-center justify-between px-3 py-3 rounded-md bg-panel2 border border-border hover:bg-panel2/70 text-white text-sm"
              >
                <span className="flex items-center gap-2">
                  <Link2 className="w-4 h-4 text-success" /> Link solo
                </span>
                <span className="text-[11px] text-muted truncate max-w-[180px]">{link || "(vazio)"}</span>
              </button>
              <button
                onClick={() => executarPlay("multi")}
                className="w-full flex items-center justify-between px-3 py-3 rounded-md bg-success/10 border border-success hover:bg-success/20 text-white text-sm"
              >
                <span className="flex items-center gap-2">
                  <Link2 className="w-4 h-4 text-success" /> Múltiplos links
                </span>
                <span className="text-[11px] text-success">{savedMultiCount} salvos</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============ Modal: identificação para comprar token ============ */}
      {tokenStep === "identify" && (
        <div className="fixed inset-0 z-[100] bg-black/80 grid place-items-center p-4">
          <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-xl shadow-2xl">
            <div className="px-4 py-3 border-b border-zinc-800 flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">Identifique-se para comprar</h3>
              <button onClick={() => setTokenStep("closed")} className="text-zinc-400 text-xl leading-none">×</button>
            </div>
            <div className="p-4 space-y-3">
              <p className="text-[11px] text-zinc-400">Use seu login e senha do token (Cloud). Se ainda não tem, crie pela tela de login.</p>
              <div><label className="text-[11px] text-zinc-400">Login</label>
                <input value={identLogin} onChange={(e) => setIdentLogin(e.target.value)} autoFocus className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-sm text-white" /></div>
              <div><label className="text-[11px] text-zinc-400">Senha</label>
                <input type="password" value={identPwd} onChange={(e) => setIdentPwd(e.target.value)} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-sm text-white" /></div>
              <button onClick={confirmIdentity} className="w-full bg-emerald-500 hover:bg-emerald-400 text-black font-semibold text-sm py-2.5 rounded">
                Ver planos
              </button>
            </div>
          </div>
        </div>
      )}

      <PlansModal
        open={tokenStep === "plans"}
        onClose={() => setTokenStep("closed")}
        identity={tokenIdentity}
        title="Comprar / renovar Token"
      />
    </div>
  );
}

function CloudSessionBanner() {
  const session = useCloudSession((s) => s.session);
  if (!session) return null;
  const expired = session.expires_at ? new Date(session.expires_at) < new Date() : false;
  return (
    <div className="px-2 py-1.5 border-b border-border bg-panel2/60 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px]">
      <span className="text-white"><span className="text-muted">Login:</span> <b>{session.login}</b></span>
      <span className="text-white"><span className="text-muted">Acesso:</span> <b className="text-emerald-400">{planLabel(session.plan_key)}</b></span>
      <span className={expired ? "text-red-400" : "text-white"}>
        <span className="text-muted">Encerra em:</span> <b>{formatExpiry(session.expires_at)}</b>
      </span>
    </div>
  );
}

