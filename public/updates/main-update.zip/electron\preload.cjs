const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  query: (sql, params) => ipcRenderer.invoke("db:query", sql, params),
  run: (sql, params) => ipcRenderer.invoke("db:run", sql, params),
  openFile: (opts) => ipcRenderer.invoke("dialog:openFile", opts),
  importExtension: () => ipcRenderer.invoke("ext:import"),
  getExtensionInfo: () => ipcRenderer.invoke("ext:getInfo"),
  removeExtension: () => ipcRenderer.invoke("ext:remove"),
  saveFile: (opts, contentBase64) => ipcRenderer.invoke("dialog:saveFile", opts, contentBase64),
  startWorkers: (count, accounts) => ipcRenderer.invoke("workers:start", count, accounts),
  stopWorkers: () => ipcRenderer.invoke("workers:stop"),
  countWorkers: () => ipcRenderer.invoke("workers:count"),
  openChromium: (url, count, accounts, delaySec, headless) => ipcRenderer.invoke("chrome:open", url, count, accounts, delaySec, headless),
  openChromiumMulti: (links, count, accounts, delaySec, headless) => ipcRenderer.invoke("chrome:openMulti", links, count, accounts, delaySec, headless),
  closeChromium: () => ipcRenderer.invoke("chrome:close"),
  refreshChromiumSelection: (spec) => ipcRenderer.invoke("chrome:refreshControlSelection", spec),
  setChromiumProxyEnabled: (enabled) => ipcRenderer.invoke("chrome:setProxyEnabled", enabled),
  setChromiumMirrorEnabled: (enabled) => ipcRenderer.invoke("chrome:setMirrorEnabled", enabled),
  setPopupCloserEnabled: (enabled) => ipcRenderer.invoke("chrome:setPopupCloserEnabled", enabled),
  setBlockedDomains: (list) => ipcRenderer.invoke("chrome:setBlockedDomains", list),
  setAccountOverlay: (state) => ipcRenderer.invoke("chrome:setAccountOverlay", state),
  setChromiumSpeedMultiplier: (value) => ipcRenderer.invoke("chrome:setSpeedMultiplier", value),
  onChromiumSpeedReset: (callback) => {
    const listener = (_event, data) => { try { callback(data); } catch {} };
    ipcRenderer.on("chrome:speedReset", listener);
    return () => ipcRenderer.removeListener("chrome:speedReset", listener);
  },
  onChromiumProxyToggled: (callback) => {
    const listener = (_event, data) => { try { callback(data); } catch {} };
    ipcRenderer.on("chrome:proxyToggled", listener);
    return () => ipcRenderer.removeListener("chrome:proxyToggled", listener);
  },
  reloadChromium: () => ipcRenderer.invoke("chrome:reload"),
  navigateChromium: (url) => ipcRenderer.invoke("chrome:navigate", url),
  reportChromium: () => ipcRenderer.invoke("chrome:report"), // botão "Relatório de Apostas" — arquivo próprio, ver src/ipc/reportHandler.cjs
  bausChromium: () => ipcRenderer.invoke("chrome:baus"), // botão "Página de Baús" — arquivo próprio, ver src/ipc/bausHandler.cjs
  preencherDadosChromium: () => ipcRenderer.invoke("chrome:preencherDados"), // botão "Preencher Dados" — arquivo próprio, ver src/ipc/preencherDadosHandler.cjs
  clickSaquesChromium: () => ipcRenderer.invoke("chrome:clickSaques"),
  searchSlotChromium: (slot, cardIndex) => ipcRenderer.invoke("chrome:searchSlot", slot, cardIndex),
  apiSpinRun: (count, opts) => ipcRenderer.invoke("chrome:apiSpinRun", { count, opts }),
  wgSpinRun: (count, opts) => ipcRenderer.invoke("chrome:wgSpinRun", { count, opts }), // Auto Slot via API pura pra WG (Lucky Dog)
  ppSpinRun: (count, opts) => ipcRenderer.invoke("chrome:ppSpinRun", { count, opts }), // Auto Slot via API pura pra PP (Plushie Wins)
  clickSpinRun: (count, opts) => ipcRenderer.invoke("chrome:clickSpinRun", { count, opts }), // Auto Slot por CLIQUE (autoplay nativo) pra jogos de protocolo cifrado (Fortune Ox)
  cadastrarPixChromium: (url, keys, tipo) => ipcRenderer.invoke("chrome:cadastrarPix", url, keys, tipo), // fluxo antigo — mantido só como fallback, não usado mais na UI
  cadastrarPixV2: () => ipcRenderer.invoke("chrome:cadastrarPixV2"),
  sacarV2: () => ipcRenderer.invoke("chrome:sacarV2"), // teste isolado do fluxo de saque reescrito (temporário)
  preencherSaqueChromium: () => ipcRenderer.invoke("chrome:preencherSaque"),
  depositarChromium: (value) => ipcRenderer.invoke("chrome:depositar", value),
  getQrQueue: () => ipcRenderer.invoke("deposit:getQrQueue"),
  clearQrQueue: () => ipcRenderer.invoke("deposit:clearQrQueue"),
  onQrCaptured: (cb) => {
    const listener = (_e, entry) => cb(entry);
    ipcRenderer.on("deposit:qrCaptured", listener);
    return () => ipcRenderer.removeListener("deposit:qrCaptured", listener);
  },
  onQrPaid: (cb) => {
    const listener = (_e, payload) => cb(payload);
    ipcRenderer.on("deposit:qrPaid", listener);
    return () => ipcRenderer.removeListener("deposit:qrPaid", listener);
  },
  openExternal: (url) => ipcRenderer.invoke("app:openExternal", url),
  reload: () => ipcRenderer.invoke("app:reload"),
  checkUpdate: () => ipcRenderer.invoke("app:checkUpdate"),
  installUpdate: () => ipcRenderer.invoke("app:installUpdate"),
  onUpdateProgress: (callback) => {
    const listener = (_event, data) => callback(data);
    ipcRenderer.on("app:updateProgress", listener);
    return () => ipcRenderer.removeListener("app:updateProgress", listener);
  },
  appInfo: () => ipcRenderer.invoke("app:info"),
  focusMain: () => ipcRenderer.invoke("app:focusMain"),
  listMonitors: () => ipcRenderer.invoke("app:listMonitors"),
  // Aba Telas → "Posições Personalizadas": abre uma janela real por tela e
  // devolve as posições onde o usuário largou. Ver src/window/overlayPositions.cjs
  abrirOverlayPosicoes: (opts) => ipcRenderer.invoke("overlay:abrirPosicoes", opts),
  openLogsFile: (opts) => ipcRenderer.invoke("logs:openFile", opts || {}),
  openDiagFile: (opts) => ipcRenderer.invoke("logs:openDiag", opts || {}),
  readDiagFile: () => ipcRenderer.invoke("logs:readDiag"),
  clearDiagFile: () => ipcRenderer.invoke("logs:clearDiag"),
  backupAccountsFile: () => ipcRenderer.invoke("accounts:backup"),
  onAccountsChanged: (callback) => {
    const listener = (_event, data) => { try { callback(data); } catch {} };
    ipcRenderer.on("accounts:changed", listener);
    return () => ipcRenderer.removeListener("accounts:changed", listener);
  },
  onLogsUpdated: (callback) => {
    const listener = () => { try { callback(); } catch {} };
    ipcRenderer.on("logs:updated", listener);
    return () => ipcRenderer.removeListener("logs:updated", listener);
  },
  // Aba "Mercado Pago" — ver src/ipc/mercadoPagoHandler.cjs
  abrirContaMP: (conta) => ipcRenderer.invoke("mp:abrirConta", conta),
  fecharContaMP: (conta) => ipcRenderer.invoke("mp:fecharConta", conta),
  copiarChavesMP: (conta) => ipcRenderer.invoke("mp:copiarChaves", conta),
  deletarChavesMP: (conta) => ipcRenderer.invoke("mp:deletarChaves", conta),
  contaEstaAbertaMP: (conta) => ipcRenderer.invoke("mp:contaEstaAberta", conta),
  // Controles de janela (barra de título custom / modo compacto) — janela é
  // frameless, a UI desenha min/expandir/max/fechar e chama estes.
  winMinimize: () => ipcRenderer.invoke("win:minimize"),
  winToggleMaximize: () => ipcRenderer.invoke("win:toggleMaximize"),
  winClose: () => ipcRenderer.invoke("win:close"),
  winSetCompact: (on, width) => ipcRenderer.invoke("win:setCompact", on, width),
  winSetWide: (on, extra) => ipcRenderer.invoke("win:setWide", on, extra), // aba API: alarga a janela p/ o painel de log
  winSetAlwaysOnTop: (on) => ipcRenderer.invoke("win:setAlwaysOnTop", on),
  // Gravador de cliques (aba Operação) — ver src/ipc/autoClickHandler.cjs
  // Janelas separadas (Config Auto Click, Bloqueios, Extensão)
  abrirPopup: (nome) => ipcRenderer.invoke("popup:abrir", nome),
  fecharPopup: (nome) => ipcRenderer.invoke("popup:fechar", nome),
  // Selo de apostas validas na tela — ver src/ipc/rolloverHandler.cjs
  betsVarrer: (opts) => ipcRenderer.invoke("bets:varrer", opts),
  betsPararVarredura: () => ipcRenderer.invoke("bets:pararVarredura"),
  betsListar: () => ipcRenderer.invoke("bets:listar"), // tabela de bets capturada dos jogos
  rolloverLigar: (cfg) => ipcRenderer.invoke("rollover:ligar", cfg),
  rolloverDesligar: () => ipcRenderer.invoke("rollover:desligar"),
  rolloverAtualizar: () => ipcRenderer.invoke("rollover:atualizar"),
  rolloverConsultar: () => ipcRenderer.invoke("rollover:consultar"),
  saldoConsultar: () => ipcRenderer.invoke("saldo:consultar"),
  autoClickIniciarCaptura: () => ipcRenderer.invoke("autoclick:iniciarCaptura"),
  autoClickPararCaptura: () => ipcRenderer.invoke("autoclick:pararCaptura"),
  autoClickIniciar: (cfg) => ipcRenderer.invoke("autoclick:iniciar", cfg),
  autoClickParar: () => ipcRenderer.invoke("autoclick:parar"),
  autoClickEstado: () => ipcRenderer.invoke("autoclick:estado"),
  onAutoClickCapturado: (cb) => {
    const listener = (_e, p) => { try { cb(p); } catch {} };
    ipcRenderer.on("autoclick:capturado", listener);
    return () => ipcRenderer.removeListener("autoclick:capturado", listener);
  },
  onAutoClickParou: (cb) => {
    const listener = (_e, p) => { try { cb(p); } catch {} };
    ipcRenderer.on("autoclick:parou", listener);
    return () => ipcRenderer.removeListener("autoclick:parou", listener);
  },
  salvarLoginMP: (conta) => ipcRenderer.invoke("mp:salvarLogin", conta),
  criarChavePixMP: (conta) => ipcRenderer.invoke("mp:criarChavePix", conta),
  cancelarCriarChavePixMP: (conta) => ipcRenderer.invoke("mp:cancelarCriarChavePix", conta),
  onContaFechadaMP: (callback) => {
    const listener = (_e, data) => { try { callback(data); } catch {} };
    ipcRenderer.on("mp:janelaFechada", listener);
    return () => ipcRenderer.removeListener("mp:janelaFechada", listener);
  },
});

contextBridge.exposeInMainWorld("contasAPI", {
  listar: () => ipcRenderer.invoke("contas:listar"),
  remover: (id) => ipcRenderer.invoke("contas:remover", id),
  removerVarios: (ids) => ipcRenderer.invoke("contas:removerVarios", ids),
  removerTodos: () => ipcRenderer.invoke("contas:removerTodos"),
  definirProxy: (id, proxy) => ipcRenderer.invoke("contas:definirProxy", id, proxy),
  abrirBackup: () => ipcRenderer.invoke("contas:abrirBackup"),
  abrirSelecionadas: (contas, delaySec) => ipcRenderer.invoke("contas:abrirSelecionadas", contas, delaySec),
  aoAtualizar: (cb) => {
    const listener = (_event, data) => { try { cb(data); } catch {} };
    ipcRenderer.on("contas:atualizou", listener);
    return () => ipcRenderer.removeListener("contas:atualizou", listener);
  },
});

contextBridge.exposeInMainWorld("pandoraCloud", {
  getDeviceId: () => ipcRenderer.invoke("pandora:device-id"),
  signPayload: (bodyString) => ipcRenderer.invoke("pandora:sign-payload", bodyString),
});

contextBridge.exposeInMainWorld("multibotAPI", {
  mode: () => ipcRenderer.invoke("multibot:mode"),
  list: () => ipcRenderer.invoke("multibot:list"),
  create: (name, importSettings) => ipcRenderer.invoke("multibot:create", name, importSettings),
  rename: (id, name) => ipcRenderer.invoke("multibot:rename", id, name),
  remove: (id) => ipcRenderer.invoke("multibot:delete", id),
  open: (id, session) => ipcRenderer.invoke("multibot:open", id, session),
  consumeSession: () => ipcRenderer.invoke("multibot:consume-session"),
});
