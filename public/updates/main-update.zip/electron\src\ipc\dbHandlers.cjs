// ============================================================================
// IPC: db:query / db:run — acesso direto ao SQLite (settings/accounts/logs/...)
// usado pela UI React. db:run também sincroniza a senha de saque em memória
// e notifica a janela principal quando a tabela `accounts` muda.
// ============================================================================
const state = require("../state.cjs");
const { saveDB } = require("../../db.cjs");
const { getSettingSync } = require("../settings/settingsStore.cjs");
const { appendSecDiag } = require("../security/securityPin.cjs");

function registerDbHandlers(ipcMain) {
  ipcMain.handle("db:query", (_e, sql, params) => {
    try {
      const stmt = state.db.prepare(sql);
      stmt.bind(params || []);
      const rows = [];
      while (stmt.step()) rows.push(stmt.getAsObject());
      stmt.free();
      return { ok: true, rows };
    } catch (err) { return { ok: false, error: String(err) }; }
  });
  ipcMain.handle("db:run", async (_e, sql, params) => {
    const t0 = Date.now();
    const isAccounts = /\baccounts\b/i.test(String(sql || ""));
    const op = (String(sql || "").trim().split(/\s+/)[0] || "").toUpperCase();
    if (isAccounts) {
      const safe = (params || []).map((p, i) => (typeof p === "string" && /pass|senha|pin/i.test(String(sql).slice(0, 200)) && i >= 2) ? String(p).replace(/./g, "•") : p);
      console.log(`[contas-db] db:run ${op} sql="${String(sql).slice(0, 140).replace(/\s+/g, " ")}" params=${JSON.stringify(safe)}`);
    }
    try {
      const stmt = state.db.prepare(sql);
      stmt.run(params || []);
      stmt.free();
      // Não espera o disco — a mudança já está aplicada em memória (acima).
      // saveDB() é debounced (até SAVE_DEBOUNCE_MS) e grava em segundo plano;
      // aguardar aqui fazia CADA insert/update/delete (salvar chave pix,
      // excluir, etc.) levar até 1.5s mesmo sem nada rodando.
      saveDB(state.db, state.dbPath).catch(() => {});
      try {
        const text = String(sql || "");
        const p = Array.isArray(params) ? params : [];
        if (/\bsettings\b/i.test(text) && /senha_saque/i.test(JSON.stringify(p))) {
          const raw = String(getSettingSync("senha_saque", "")).replace(/\D/g, "").slice(0, 6);
          if (/^\d{6}$/.test(raw)) {
            global.__pandoraAutoWithdrawPin = raw;
            for (const w of state.chromeWins) {
              try { if (w && !w.isDestroyed()) w._withdrawPin = raw; } catch {}
            }
            appendSecDiag("senha de saque sincronizada após salvar em Início (6 dígitos)");
          }
        }
      } catch {}
      const lastIdRow = state.db.exec("SELECT last_insert_rowid()");
      const changes = state.db.getRowsModified();
      const lastId = lastIdRow[0]?.values?.[0]?.[0];
      if (isAccounts) {
        console.log(`[contas-db] db:run ${op} OK changes=${changes} lastId=${lastId} (${Date.now() - t0}ms)`);
        try {
          if (state.mainWin && !state.mainWin.isDestroyed()) {
            state.mainWin.webContents.send("accounts:changed", { action: op.toLowerCase(), changes, lastId, via: "db:run" });
          }
        } catch {}
      }
      return { ok: true, changes, lastId };
    } catch (err) {
      if (isAccounts) console.error(`[contas-db] db:run ${op} FALHOU: ${String(err)}`);
      return { ok: false, error: String(err) };
    }
  });
}

module.exports = { registerDbHandlers };
