// ============================================================================
// IPC: chrome:depositar — navega para /home/mine, clica na aba "Depósito"
// (ou botão recarregar), preenche o valor configurado e submete.
// ============================================================================
const state = require("../state.cjs");
const { getSettingSync } = require("../settings/settingsStore.cjs");
const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");
const { watchForDepositQr } = require("../window/qrCapture.cjs");

function registerDepositHandler(ipcMain) {
  ipcMain.handle("chrome:depositar", async (_e, value) => {
    const parseDepositSetting = (raw) => parseFloat(String(raw || "").replace(",", ".")) || 0;
    // BUG real 2026-08-09 (reportado pelo usuário: faixa 10-30 colocou o
    // MESMO valor — 13 — em TODAS as telas) — antes um único valor era
    // sorteado UMA VEZ (em Operacao.tsx) e reaplicado igual em cada janela.
    // Agora, se vier { min, max }, sorteia um valor NOVO por janela dentro
    // do loop abaixo; "val" fixo só continua existindo como fallback pra
    // quem ainda chamar com um valor único (compatibilidade).
    let rangeMin = null, rangeMax = null;
    if (value && typeof value === "object" && Number.isFinite(Number(value.min)) && Number.isFinite(Number(value.max))) {
      rangeMin = Math.min(Number(value.min), Number(value.max));
      rangeMax = Math.max(Number(value.min), Number(value.max));
    }
    let val = String((value && typeof value === "object" ? value.value : value) || "").trim();
    // Pedido do usuário 2026-08-09: aba Operação nunca deve cair no valor
    // configurado em Início (exec_dep_1) nem vice-versa — cada botão só usa
    // a própria configuração. Sem valor explícito, cai só em op_dep_1.
    if (!parseDepositSetting(val)) {
      val = String(getSettingSync("op_dep_1", "10") || "10").trim();
    }
    if (!parseDepositSetting(val)) val = "10";
    if (!val && rangeMin === null) return 0;
    const sortearValorPorJanela = () => {
      if (rangeMin === null) return val;
      if (rangeMin === rangeMax) return String(rangeMin);
      return String(Math.floor(Math.random() * (rangeMax - rangeMin + 1)) + rangeMin);
    };
    const tryNativeDepositClick = async (win) => {
      try {
        if (!win || win.isDestroyed()) return false;
        const wc = win.webContents;
        const ok = await wc.executeJavaScript(`(() => {
          console.log('-> [Pandora Core] Iniciando varredura segura do botão Depósito...');

          // 1. Abordagem via texto direto nas tags HTML básicas
          const tags = document.querySelectorAll('div, span, button');
          for (let i = 0; i < tags.length; i++) {
            const node = tags[i];

            // Validação estrita para garantir que o nó é um elemento válido e contém o texto
            if (node && node.textContent && node.textContent.trim() === 'Depósito') {

              // Se o elemento possui a função nativa de clique, executa
              if (typeof node.click === 'function') {
                node.click();
                console.log('-> [Pandora Core] Sucesso: Clique processado no nó principal.');
                return true;
              }

              // Fallback para o elemento pai (usando parentElement de forma segura)
              const pai = node.parentElement;
              if (pai && typeof pai.click === 'function') {
                pai.click();
                console.log('-> [Pandora Core] Sucesso: Clique processado no elemento pai.');
                return true;
              }
            }
          }

          console.error('-> [Pandora Core] Erro: Botão "Depósito" não pôde ser acionado de forma segura.');
          return false;
        })();`, true);
        return !!ok;
      } catch {}
      return false;
    };
    const buildScript = (v, reqId) => `(() => {
      const value = ${JSON.stringify(v)};
      const REQ_ID = ${JSON.stringify(reqId)};
      const TAG = '[PANDORA-DEPOSITO]';
      try { console.log(TAG, 'inject req=' + REQ_ID + ' url=' + location.href + ' value=' + value); } catch {}
      // 2026-08-09: avisa pixModalEnhancer.cjs que um depósito de VERDADE
      // está em andamento agora — ele só aumenta o QR quando essa flag
      // está "fresca" (ver checagem lá), nunca em QR de indicação/outro
      // contexto. Substitui a tentativa anterior de adivinhar pelo texto da
      // tela (frágil — não sabíamos a redação exata do modal desse site).
      try { window.__pandoraDepositoAtivoEm = Date.now(); } catch {}
      // dedupe por requestId — só ignora se for o MESMO request já submetido
      try {
        if (window.__pandoraDepositReqId === REQ_ID && window.__pandoraDepositSubmittedAt) {
          console.log(TAG, 'req já submetido, ignorando re-injeção');
          return;
        }
        if (window.__pandoraDepositReqId !== REQ_ID) {
          window.__pandoraDepositReqId = REQ_ID;
          window.__pandoraDepositSubmittedAt = 0;
          window.__pandoraDepositSubmitting = false;
          window.__pandoraDepositLoop = false;
        }
      } catch {}
      if (window.__pandoraDepositLoop) { try { console.log(TAG, 'loop ativo, ignorando re-injeção'); } catch {}; return; }
      window.__pandoraDepositLoop = true;
      const visible = (el) => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return false;
        const s = getComputedStyle(el);
        return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity || '1') > 0.05;
      };
      const setNativeValue = (el, v) => {
        try {
          const proto = Object.getPrototypeOf(el);
          const desc = Object.getOwnPropertyDescriptor(proto, 'value')
                    || Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value');
          if (desc && desc.set) desc.set.call(el, v); else el.value = v;
        } catch { try { el.value = v; } catch(e){} }
        try { el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: v })); } catch { try { el.dispatchEvent(new Event('input', { bubbles: true })); } catch(e){} }
        try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch(e){}
      };
      const realClick = (el) => {
        if (!el) return;
        try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
        const r = el.getBoundingClientRect();
        const x = r.left + Math.max(2, r.width / 2), y = r.top + Math.max(2, r.height / 2);
        const opts = { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0, view:window };
        try { el.dispatchEvent(new PointerEvent('pointerover', { ...opts, pointerType:'mouse', buttons:0, isPrimary:true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseover', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointermove', { ...opts, pointerType:'mouse', buttons:0, isPrimary:true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mousemove', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerType:'mouse', buttons:1, isPrimary:true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerType:'mouse', buttons:0, isPrimary:true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseup', opts)); } catch {}
        try { el.dispatchEvent(new MouseEvent('click', opts)); } catch {}
        try { el.dispatchEvent(new TouchEvent('touchstart', { bubbles:true, cancelable:true, touches:[new Touch({ identifier:1, target:el, clientX:x, clientY:y })], targetTouches:[], changedTouches:[] })); } catch {}
        try { el.dispatchEvent(new TouchEvent('touchend', { bubbles:true, cancelable:true, touches:[], targetTouches:[], changedTouches:[new Touch({ identifier:1, target:el, clientX:x, clientY:y })] })); } catch {}
        try { el.click(); } catch {}
      };
      const isDisabledButton = (el) => {
        if (!el) return true;
        const cls = String(el.className || '').toLowerCase();
        return !!(el.disabled || el.getAttribute('disabled') !== null || el.getAttribute('aria-disabled') === 'true' || /disabled|is-disabled|loading/.test(cls));
      };
      const submitClickOnce = (el) => {
        if (!el || isDisabledButton(el)) return false;
        try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
        try { el.focus({ preventScroll: true }); } catch { try { el.focus(); } catch {} }
        const r = el.getBoundingClientRect();
        const x = r.left + Math.max(2, r.width / 2), y = r.top + Math.max(2, r.height / 2);
        const opts = { bubbles:true, cancelable:true, clientX:x, clientY:y, button:0, view:window };
        try { el.dispatchEvent(new PointerEvent('pointerover', { ...opts, pointerType:'mouse', buttons:0, isPrimary:true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseover', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerType:'mouse', buttons:1, isPrimary:true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerType:'mouse', buttons:0, isPrimary:true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseup', opts)); } catch {}
        try { el.dispatchEvent(new MouseEvent('click', opts)); return true; } catch {}
        try { el.click(); return true; } catch {}
        return false;
      };
      const findDepositInput = () => {
        const all = Array.from(document.querySelectorAll('input'));
        const candidates = all.filter((i) => visible(i) && !i.disabled && !i.readOnly && i.type !== 'hidden' && i.type !== 'checkbox' && i.type !== 'radio' && i.type !== 'submit' && i.type !== 'button');
        // 1) por keyword no placeholder/name/id/className
        const byKey = candidates.find((i) => {
          const h = ((i.placeholder || '') + ' ' + (i.name || '') + ' ' + (i.id || '') + ' ' + (i.className || '')).toLowerCase();
          return /valor|amount|recarga|recharge|m[íi]nimo|minimo|m[áa]ximo|maximo|quantia|montante|dep[óo]sito|deposit/.test(h);
        });
        if (byKey) return byKey;
        // 2) input dentro do container do botão "Deposite agora"
        const submit = document.getElementById('depositSubmitClick') || document.querySelector('[class*="_btn_127z8_"]');
        if (submit) {
          let p = submit.parentElement;
          for (let depth = 0; depth < 8 && p; depth++, p = p.parentElement) {
            const inp = Array.from(p.querySelectorAll('input')).find((i) => candidates.includes(i));
            if (inp) return inp;
          }
        }
        // 3) qualquer input numérico visível
        return candidates.find((i) => i.type === 'number' || i.inputMode === 'numeric' || i.inputMode === 'decimal') || candidates[0];
      };
      const findDepositTab = () => {
        const tab = document.querySelector('#depositClick');
        if (tab && visible(tab)) return tab;
        const exact = Array.from(document.querySelectorAll('span[class*="_text_"], span')).find((n) => visible(n) && /^dep[óo]sito$/i.test((n.textContent || '').trim()));
        if (exact && visible(exact)) return exact;
        const tabs = Array.from(document.querySelectorAll('[role="tab"], [class*="tabbar-item"]'));
        return tabs.find((n) => {
          if (!visible(n)) return false;
          const t = (n.textContent || '').trim().toLowerCase();
          return /^dep[óo]sito$/.test(t);
        });
      };
      const findRechargeBtn = () => {
        const reCharge = document.querySelector('button._reCharge_1f2no_76, ._reCharge_1f2no_76, button[class*="_reCharge_"], [class*="_reCharge_"]');
        if (reCharge && visible(reCharge)) return reCharge;
        const exact = document.querySelector('button.registerRechargeBtn, .registerRechargeBtn');
        if (exact && visible(exact)) return exact;
        const nodes = Array.from(document.querySelectorAll('button, a, [role="button"]'));
        const found = nodes.find((n) => {
          if (!visible(n)) return false;
          const t = (n.textContent || '').trim().toLowerCase();
          return /^(depositar|recarregar|recarga|deposit|dep[óo]sito)$/i.test(t);
        });
        if (found) return found;
        const uiBtns = Array.from(document.querySelectorAll('button.ui-button'));
        return uiBtns.find((b) => visible(b) && /^dep[óo]sito$/i.test((b.textContent || '').trim()));
      };
      const findSubmitBtn = () => {
        const byId = document.getElementById('depositSubmitClick');
        if (byId && visible(byId) && !isDisabledButton(byId)) return byId;
        const byCls = document.querySelector('._btn_127z8_157, [class*="_btn_127z8_"]');
        if (byCls && visible(byCls) && !isDisabledButton(byCls) && /^deposite agora$/i.test((byCls.textContent || '').trim())) return byCls;
        const btns = Array.from(document.querySelectorAll('button, [role="button"], .ui-button'));
        return btns.find((b) => visible(b) && !isDisabledButton(b) && /^deposite agora$/i.test((b.textContent || '').trim()));
      };
      const submitDeposit = () => {
        if (window.__pandoraDepositSubmitting) { try { console.log(TAG, 'submit já em andamento, ignorando'); } catch {}; return; }
        window.__pandoraDepositSubmitting = true;
        let attempts = 0;
        const trySubmit = () => {
          attempts++;
          // se já submeteu nesta mesma request, aborta
          try {
            if (window.__pandoraDepositReqId === REQ_ID && window.__pandoraDepositSubmittedAt) { console.log(TAG, 'req já submetida, abort'); return; }
          } catch {}
          // re-aplica valor caso o site tenha limpado o input
          try {
            const inp2 = findDepositInput();
            if (inp2 && String(inp2.value || '').trim() !== String(value).trim()) {
              try { inp2.focus(); } catch {}
              setNativeValue(inp2, value);
              try { console.log(TAG, 'valor reaplicado antes do submit try=' + attempts); } catch {}
            }
          } catch {}
          const sb = findSubmitBtn();
          if (sb) {
            try { console.log(TAG, 'clicando "Deposite agora" com 1 click try=' + attempts); } catch {}
            if (submitClickOnce(sb)) {
              try { window.__pandoraDepositSubmittedAt = Date.now(); } catch {}
              return;
            }
          }
          if (attempts < 12) setTimeout(trySubmit, 400);
          else { try { console.log(TAG, 'submit não encontrado'); } catch {} }
        };
        setTimeout(trySubmit, 600);
      };
      let lastClickAt = 0, tries = 0;
      const loop = () => {
        tries++;
        const inp = findDepositInput();
        if (inp) {
          try { inp.focus(); } catch {}
          setNativeValue(inp, value);
          try { console.log(TAG, 'valor preenchido try=' + tries); } catch {}
          submitDeposit();
          window.__pandoraDepositLoop = false;
          return;
        }
        if (Date.now() - lastClickAt > 800) {
          const tab = findDepositTab();
          if (tab) {
            try { console.log(TAG, 'clicando tab #depositClick try=' + tries); } catch {}
            realClick(tab);
            lastClickAt = Date.now();
          } else {
            const btn = findRechargeBtn();
            if (btn) {
              try { console.log(TAG, 'clicando botão recarregar try=' + tries); } catch {}
              realClick(btn);
              lastClickAt = Date.now();
            }
          }
        }
        if (tries < 80) setTimeout(loop, 350);
        else { try { console.log(TAG, 'desistiu try=' + tries); } catch {}; window.__pandoraDepositLoop = false; }
      };
      loop();

    })();`;

    let n = 0;
    const wins = (typeof getSelectedChromeWins === 'function' ? getSelectedChromeWins() : state.chromeWins.filter(w => w && !w.isDestroyed()));
    try { console.log('[deposit] disparando para ' + wins.length + ' janela(s) value=' + val); } catch {}
    const injectAllFrames = (wc, script) => {
      try { wc.executeJavaScript(script, true).catch(()=>{}); } catch {}
      try {
        const frames = (wc.mainFrame && typeof wc.mainFrame.framesInSubtree !== 'undefined') ? wc.mainFrame.framesInSubtree : [];
        for (const f of frames) {
          if (!f || f === wc.mainFrame) continue;
          try { f.executeJavaScript(script, true).catch(()=>{}); } catch {}
        }
      } catch {}
    };
    for (const win of wins) {
      try {
        if (!win || win.isDestroyed()) continue;
        const wc = win.webContents;
        const valDaJanela = sortearValorPorJanela();
        const reqId = 'dep-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8);
        const script = buildScript(valDaJanela, reqId);
        try { console.log('[deposit] tela #' + (win._pandoraOrder || '?') + ' valor sorteado=' + valDaJanela); } catch {}
        const currentUrl = (() => { try { return wc.getURL(); } catch { return ''; } })();
        let onMine = false;
        try { onMine = /\/home\/mine(\/|\?|#|$)/.test(new URL(currentUrl).pathname); } catch {}
          // BUG real 2026-08-10 (reportado pelo usuário: scroll/layout da
        // Página de Baús "bugou de novo" depois de clicar em Depositar) —
        // as chamadas atrasadas abaixo (setTimeout até 7s) continuavam
        // disparando mesmo que o usuário já tivesse navegado pra OUTRA tela
        // nesse meio-tempo (ex.: clicou Depositar e, antes de 7s, clicou em
        // Página de Baús). Elas setam window.__pandoraDepositoAtivoEm na
        // página ATUAL (não sabem que mudou) — o pixModalEnhancer.cjs então
        // confundia o QR de indicação dos Baús com um QR de pagamento de
        // verdade de novo. Agora cada chamada atrasada confere se a janela
        // ainda está em /home/mine antes de fazer qualquer coisa.
        const stillOnDepositPage = () => {
          try { return /\/home\/mine(\/|\?|#|$)/.test(new URL(wc.getURL()).pathname); } catch { return false; }
        };
        const inject = () => { if (stillOnDepositPage()) injectAllFrames(wc, script); };
          const clickThenInject = () => { if (!stillOnDepositPage()) return; tryNativeDepositClick(win).finally(() => setTimeout(inject, 260)); };
        if (!onMine) {
          try {
            await wc.executeJavaScript(`(() => { try { location.href = new URL('/home/mine', location.origin).toString(); return true; } catch(e) { return false; } })();`, true);
          } catch {}
            const handler = () => { wc.removeListener('did-finish-load', handler); setTimeout(clickThenInject, 1500); setTimeout(clickThenInject, 3000); setTimeout(clickThenInject, 5000); };
          wc.once('did-finish-load', handler);
            setTimeout(clickThenInject, 3500);
            setTimeout(clickThenInject, 7000);
        } else {
            clickThenInject();
            setTimeout(clickThenInject, 1200);
            setTimeout(clickThenInject, 3500);
        }
        try { watchForDepositQr(win, { valor: parseDepositSetting(valDaJanela), tela: win._pandoraOrder || null }); } catch {}
        n++;
      } catch (e) { try { console.log('[deposit] err', e && e.message); } catch {} }
    }
    return n;
  });

  // Hidratação inicial da fila de QR capturados (a UI também recebe ao vivo
  // via evento "deposit:qrCaptured", isso aqui é só pra não perder o que já
  // foi capturado nesta sessão ao trocar de aba/reabrir a tela).
  ipcMain.handle("deposit:getQrQueue", () => {
    const { getQrQueue } = require("../window/qrCapture.cjs");
    return getQrQueue();
  });

  // Chamado no STOP (Início) — limpa os QR já capturados, já que são das
  // contas que acabaram de ser encerradas.
  ipcMain.handle("deposit:clearQrQueue", () => {
    const { clearQrQueue } = require("../window/qrCapture.cjs");
    clearQrQueue();
    return { ok: true };
  });
}

module.exports = { registerDepositHandler };
