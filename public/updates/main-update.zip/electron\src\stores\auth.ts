import { create } from "zustand";
import { persist } from "zustand/middleware";
import bcrypt from "bcryptjs";
import { q, log } from "@/lib/api";
import type { User, Role } from "@/types";

interface AuthState {
  user: User | null;
  login: (username: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  logout: () => void;
  hasRole: (...roles: Role[]) => boolean;
}

export const useAuth = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      async login(username, password) {
        const rows = await q<User & { password_hash: string }>(
          "SELECT * FROM users WHERE username = ? AND active = 1",
          [username]
        );
        if (!rows.length) return { ok: false, error: "Usuário não encontrado" };
        const u = rows[0];
        if (!bcrypt.compareSync(password, u.password_hash)) {
          await log("warn", "auth", `Login falhou para ${username}`);
          return { ok: false, error: "Senha incorreta" };
        }
        const { password_hash, ...safe } = u;
        set({ user: safe as User });
        await log("info", "auth", `Login OK: ${username}`, null, u.id);
        return { ok: true };
      },
      logout() { set({ user: null }); },
      hasRole(...roles) {
        const u = get().user;
        if (!u) return false;
        if (u.role === "admin") return true;
        return roles.includes(u.role);
      },
    }),
    {
      name: "pandora-auth-session",
      // Persistimos apenas o usuário (sem credenciais); a sessão Cloud é
      // verificada continuamente pelo heartbeat em outro lugar.
      partialize: (s) => ({ user: s.user }),
    },
  ),
);
