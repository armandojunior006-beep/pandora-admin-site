// ============================================================================
// IPC: admin:* — painel administrativo (login com senha com hash + gestão das
// contas operacionais: login, senha e token de acesso de cada uma).
// A tabela `admins` é independente da tabela `accounts` (contas capturadas
// pelo bot nos sites operados) — um admin é quem pode ABRIR o painel.
// ============================================================================
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const state = require("../state.cjs");
const { saveDB } = require("../../db.cjs");

const SALT_ROUNDS = 10;

function genToken() {
  return crypto.randomBytes(24).toString("hex");
}

function countAdmins() {
  const res = state.db.exec("SELECT COUNT(*) FROM admins");
  return (res && res[0] && res[0].values && res[0].values[0] && res[0].values[0][0]) || 0;
}

function findAdminByUsername(username) {
  const stmt = state.db.prepare("SELECT id, username, password_hash, token FROM admins WHERE username = ?");
  stmt.bind([String(username || "").trim()]);
  let row = null;
  if (stmt.step()) row = stmt.getAsObject();
  stmt.free();
  return row;
}

function registerAdminHandlers(ipcMain) {
  // Diz para a UI se já existe algum admin (decide se mostra "criar conta" ou "login").
  ipcMain.handle("admin:hasAdmin", () => {
    try { return { ok: true, hasAdmin: countAdmins() > 0 }; }
    catch (e) { return { ok: false, error: e?.message || String(e) }; }
  });

  // Bootstrap: só cria se NÃO existir nenhum admin ainda — evita que qualquer
  // um crie um segundo admin sem estar autenticado. Para admins adicionais,
  // use admin:createAdmin (exige estar logado — ver nota abaixo).
  ipcMain.handle("admin:setup", async (_e, username, password) => {
    try {
      const u = String(username || "").trim();
      const p = String(password || "");
      if (!u || u.length < 3) return { ok: false, error: "Usuário precisa ter ao menos 3 caracteres" };
      if (!p || p.length < 6) return { ok: false, error: "Senha precisa ter ao menos 6 caracteres" };
      if (countAdmins() > 0) return { ok: false, error: "Já existe um admin configurado — use o login" };
      const hash = bcrypt.hashSync(p, SALT_ROUNDS);
      const token = genToken();
      const stmt = state.db.prepare("INSERT INTO admins (username, password_hash, token) VALUES (?,?,?)");
      stmt.run([u, hash, token]);
      stmt.free();
      await saveDB(state.db, state.dbPath);
      console.log(`[admin] conta admin criada: ${u}`);
      return { ok: true, username: u, token };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  ipcMain.handle("admin:login", async (_e, username, password) => {
    try {
      const row = findAdminByUsername(username);
      if (!row) return { ok: false, error: "Usuário ou senha inválidos" };
      const matches = bcrypt.compareSync(String(password || ""), row.password_hash);
      if (!matches) return { ok: false, error: "Usuário ou senha inválidos" };
      const token = row.token || genToken();
      const stmt = state.db.prepare("UPDATE admins SET token = ?, last_login_at = datetime('now') WHERE id = ?");
      stmt.run([token, row.id]);
      stmt.free();
      await saveDB(state.db, state.dbPath);
      return { ok: true, username: row.username, token };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  // Cria um admin adicional — exige o token de um admin já logado (evita que
  // a própria tela de "criar admin" seja usada para burlar o login).
  ipcMain.handle("admin:createAdmin", async (_e, requesterToken, username, password) => {
    try {
      const requester = state.db.exec("SELECT id FROM admins WHERE token = ?", [String(requesterToken || "")]);
      if (!requester || !requester[0] || !requester[0].values.length) {
        return { ok: false, error: "Sessão de admin inválida" };
      }
      const u = String(username || "").trim();
      const p = String(password || "");
      if (!u || u.length < 3) return { ok: false, error: "Usuário precisa ter ao menos 3 caracteres" };
      if (!p || p.length < 6) return { ok: false, error: "Senha precisa ter ao menos 6 caracteres" };
      const hash = bcrypt.hashSync(p, SALT_ROUNDS);
      const token = genToken();
      const stmt = state.db.prepare("INSERT INTO admins (username, password_hash, token) VALUES (?,?,?)");
      stmt.run([u, hash, token]);
      stmt.free();
      await saveDB(state.db, state.dbPath);
      return { ok: true, username: u };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  ipcMain.handle("admin:changePassword", async (_e, token, oldPassword, newPassword) => {
    try {
      const stmt = state.db.prepare("SELECT id, password_hash FROM admins WHERE token = ?");
      stmt.bind([String(token || "")]);
      let row = null;
      if (stmt.step()) row = stmt.getAsObject();
      stmt.free();
      if (!row) return { ok: false, error: "Sessão de admin inválida" };
      if (!bcrypt.compareSync(String(oldPassword || ""), row.password_hash)) {
        return { ok: false, error: "Senha atual incorreta" };
      }
      if (!newPassword || String(newPassword).length < 6) return { ok: false, error: "Nova senha precisa ter ao menos 6 caracteres" };
      const hash = bcrypt.hashSync(String(newPassword), SALT_ROUNDS);
      const up = state.db.prepare("UPDATE admins SET password_hash = ? WHERE id = ?");
      up.run([hash, row.id]);
      up.free();
      await saveDB(state.db, state.dbPath);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  // ---- Gestão das contas operacionais (login, senha, token de acesso) ----
  ipcMain.handle("admin:listAccounts", (_e, adminToken) => {
    try {
      const requester = state.db.exec("SELECT id FROM admins WHERE token = ?", [String(adminToken || "")]);
      if (!requester || !requester[0] || !requester[0].values.length) {
        return { ok: false, error: "Sessão de admin inválida" };
      }
      const stmt = state.db.prepare(
        "SELECT id, label, username, password, token, status, created_at, updated_at FROM accounts ORDER BY id DESC"
      );
      const rows = [];
      while (stmt.step()) rows.push(stmt.getAsObject());
      stmt.free();
      return { ok: true, accounts: rows };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });

  ipcMain.handle("admin:setAccountToken", async (_e, adminToken, accountId, accessToken) => {
    try {
      const requester = state.db.exec("SELECT id FROM admins WHERE token = ?", [String(adminToken || "")]);
      if (!requester || !requester[0] || !requester[0].values.length) {
        return { ok: false, error: "Sessão de admin inválida" };
      }
      const stmt = state.db.prepare("UPDATE accounts SET token = ?, updated_at = datetime('now') WHERE id = ?");
      stmt.run([String(accessToken || ""), Number(accountId)]);
      stmt.free();
      await saveDB(state.db, state.dbPath);
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e?.message || String(e) };
    }
  });
}

module.exports = { registerAdminHandlers };
