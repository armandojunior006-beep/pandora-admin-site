import { useEffect, useState } from "react";
import { Loader2, X, Copy, Check, QrCode } from "lucide-react";
import QRCode from "qrcode";
import {
  fetchPlans, createPayment, getPaymentStatus,
  type Plan, type CreatePaymentArgs,
} from "@/lib/cloud-api";

type Mode = "select" | "qr" | "success";

export interface PlansModalProps {
  open: boolean;
  onClose: () => void;
  // Credenciais para vincular o pagamento (usuário logado OU criar conta na hora)
  identity: { login: string; password: string } | { newLogin: string; newPassword: string } | null;
  title?: string;
  onPaid?: (token: string) => void;
}

export function PlansModal({ open, onClose, identity, title = "Comprar token", onPaid }: PlansModalProps) {
  const [mode, setMode] = useState<Mode>("select");
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loadingPlans, setLoadingPlans] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [qrImage, setQrImage] = useState<string | null>(null);
  const [qrText, setQrText] = useState<string>("");
  const [paymentId, setPaymentId] = useState<string | null>(null);
  // Segurança 2026-08-18: token opaco devolvido por createPayment, exigido
  // pra consultar /status (ver IDOR corrigido em cloud-api.ts).
  const [pollToken, setPollToken] = useState<string | null>(null);
  const [paidToken, setPaidToken] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open) return;
    setMode("select"); setErr(null); setPaidToken(null); setPaymentId(null); setPollToken(null);
    setPlans([]); setLoadingPlans(true);
    fetchPlans()
      .then(setPlans)
      .catch((e) => setErr(e.message))
      .finally(() => setLoadingPlans(false));
  }, [open]);

  // Polling do status
  useEffect(() => {
    if (mode !== "qr" || !paymentId || !pollToken) return;
    let stopped = false;
    const tick = async () => {
      try {
        const r = await getPaymentStatus(paymentId, pollToken);
        if (stopped) return;
        if (r.status === "paid" && r.token) {
          setPaidToken(r.token); setMode("success");
          onPaid?.(r.token);
          return;
        }
      } catch {}
      if (!stopped) setTimeout(tick, 3000);
    };
    const t = setTimeout(tick, 3000);
    return () => { stopped = true; clearTimeout(t); };
  }, [mode, paymentId, pollToken, onPaid]);

  async function buy(plan: Plan) {
    if (!identity) { setErr("Identificação ausente"); return; }
    setBusy(true); setErr(null);
    try {
      const args: CreatePaymentArgs = "login" in identity
        ? { plan_key: plan.key, login: identity.login, password: identity.password }
        : { plan_key: plan.key, new_login: identity.newLogin, new_password: identity.newPassword };
      const r = await createPayment(args);
      setPaymentId(r.payment_id);
      setPollToken(r.poll_token);
      setQrText(r.qr_code_text || "");
      if (r.qr_code_image) setQrImage(r.qr_code_image);
      else if (r.qr_code_text) {
        const img = await QRCode.toDataURL(r.qr_code_text, { width: 260, margin: 1 });
        setQrImage(img);
      }
      setMode("qr");
    } catch (e: any) {
      setErr(e.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[100] bg-black/80 grid place-items-center p-4">
      <div className="w-full max-w-md bg-zinc-950 border border-zinc-800 rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800">
          <h3 className="text-sm font-semibold text-white">{title}</h3>
          <button onClick={onClose} className="p-1 rounded hover:bg-white/10 text-zinc-400"><X className="w-4 h-4" /></button>
        </div>
        <div className="p-4">
          {err && <p className="text-xs text-red-400 mb-3 border border-red-500/30 bg-red-500/10 rounded p-2">{err}</p>}

          {mode === "select" && (
            <div className="space-y-2">
              <p className="text-[11px] text-zinc-500 uppercase tracking-wider mb-2">Escolha um plano</p>
              {loadingPlans && !err && <p className="text-zinc-500 text-sm">Carregando planos...</p>}
              {!loadingPlans && plans.length === 0 && !err && (
                <p className="text-zinc-500 text-sm">Nenhum plano disponível no momento. Fale com o suporte.</p>
              )}
              {plans.map((p) => (
                <button key={p.key} disabled={busy} onClick={() => buy(p)}
                  className="w-full text-left flex items-center justify-between gap-3 px-4 py-3 rounded-lg border border-zinc-800 bg-zinc-900/60 hover:bg-zinc-900 transition disabled:opacity-50">
                  <div>
                    <p className="text-white font-semibold">{p.label}</p>
                    <p className="text-[11px] text-zinc-500">{p.duration_days ? `${p.duration_days} dias de acesso` : "Acesso vitalício"}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-red-400 font-bold text-lg">R$ {(p.price_cents/100).toFixed(2).replace(".",",")}</p>
                    {busy && <Loader2 className="w-3 h-3 animate-spin inline ml-1" />}
                  </div>
                </button>
              ))}
            </div>
          )}

          {mode === "qr" && (
            <div className="space-y-3 text-center">
              <p className="text-[11px] text-zinc-500 uppercase tracking-wider">Pague com Pix</p>
              <div className="bg-white p-3 rounded-lg inline-block">
                {qrImage ? <img src={qrImage} alt="QR Code Pix" className="w-[240px] h-[240px]" />
                  : <div className="w-[240px] h-[240px] grid place-items-center text-black"><QrCode className="w-16 h-16" /></div>}
              </div>
              <div className="bg-zinc-900 border border-zinc-800 rounded p-2 text-left">
                <p className="text-[10px] text-zinc-500 uppercase mb-1">Pix copia e cola</p>
                <p className="text-[10px] text-zinc-300 break-all font-mono">{qrText}</p>
              </div>
              <button
                onClick={() => { navigator.clipboard.writeText(qrText); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
                className="w-full inline-flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold py-2 rounded">
                {copied ? <><Check className="w-3 h-3"/> Copiado!</> : <><Copy className="w-3 h-3"/> Copiar código Pix</>}
              </button>
              <p className="text-[11px] text-zinc-500 flex items-center justify-center gap-2">
                <Loader2 className="w-3 h-3 animate-spin" />
                Aguardando confirmação do pagamento...
              </p>
            </div>
          )}

          {mode === "success" && paidToken && (
            <div className="space-y-3 text-center">
              <div className="w-12 h-12 rounded-full bg-red-600/20 grid place-items-center mx-auto">
                <Check className="w-6 h-6 text-red-400" />
              </div>
              <p className="text-white font-semibold">Pagamento confirmado!</p>
              <div className="bg-red-600/10 border border-red-600/40 rounded p-3 font-mono text-red-300 text-sm break-all select-all">{paidToken}</div>
              <button
                onClick={() => { navigator.clipboard.writeText(paidToken); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
                className="w-full inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold py-2 rounded">
                {copied ? <><Check className="w-3 h-3"/> Copiado!</> : <><Copy className="w-3 h-3"/> Copiar token</>}
              </button>
              <div className="text-left space-y-2 pt-1">
                <div className="border border-amber-500/40 bg-amber-500/10 rounded p-2.5">
                  <p className="text-[11px] font-bold text-amber-300 uppercase tracking-wider mb-0.5">⚠️ Guarde em local seguro</p>
                  <p className="text-[11px] text-amber-200/90 leading-snug">Este token é único e funciona em apenas 1 dispositivo. Não compartilhe.</p>
                </div>
                <div className="border border-sky-500/40 bg-sky-500/10 rounded p-2.5">
                  <p className="text-[11px] font-bold text-sky-300 uppercase tracking-wider mb-0.5">Próximo passo</p>
                  <p className="text-[11px] text-sky-200/90 leading-snug">Faça login no app e cole este token na tela de confirmação. A conta será automaticamente vinculada a este dispositivo e a contagem do plano começa a partir daí.</p>
                </div>
              </div>
              <button onClick={onClose} className="w-full text-xs text-zinc-400 hover:text-white py-2">Fechar</button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
