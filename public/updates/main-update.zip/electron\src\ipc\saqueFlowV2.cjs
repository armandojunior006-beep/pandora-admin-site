// ============================================================================
// Saque Flow V2 — reescrita do zero igual o PIX V2 (pixFlowV2.cjs), 100%
// baseada em detecção de elementos DOM (querySelector + .click()/dispatchEvent
// no próprio elemento), SEM clique por coordenada de tela. Fluxo: navega pra
// tela de saque -> clica "TUDO" -> preenche senha de 6 dígitos -> clica
// "Confirmar Retirada" (uma única vez).
// ============================================================================
const { appendSecDiag } = require("../security/securityPin.cjs");
const { getWithdrawPin } = require("../security/securityPin.cjs");
const { logSystem } = require("../settings/settingsStore.cjs");

// BUG GRAVE real 2026-08-09 (ver comentário igual em pixFlowV2.cjs) — mesma
// classe de bug: domínio de teste (voy-hallwaypg.com) cravado na URL,
// arrancando a janela pro site errado no meio da operação de saque. Corrigido
// do mesmo jeito: só o caminho é fixo, o domínio vem sempre da janela atual.
const STEP1_PATH = "/home/withdraw?active=20";

function log(msg) {
  try { appendSecDiag("[SAQUE-V2] " + msg); } catch {}
}

function urlOnCurrentSite(wc, path) {
  try {
    const cur = new URL(wc.getURL());
    return cur.origin + path;
  } catch (e) {
    log("AVISO: não consegui ler o domínio atual da janela (" + (e && e.message) + ") — usando fallback de teste");
    return "https://voy-hallwaypg.com" + path;
  }
}

// Script injetado: clica "TUDO", preenche a senha de 6 dígitos e — só em
// Operação Oculta (autoClick=true) — clica em "Confirmar saque/Retirada"
// UMA ÚNICA VEZ. Com janela visível (autoClick=false), para logo depois de
// confirmar que o botão habilitou, deixando a confirmação pro usuário
// clicar manualmente (pedido do usuário 2026-08-08).
function buildStep1Script(pin6, autoClick) {
  return `(async () => {
    if (window.__pandoraSaqueV2Busy) return { ok: false, reason: 'já rodando' };
    if (window.__pandoraSaqueV2Clicked) return { ok: false, reason: 'já clicou antes' };
    window.__pandoraSaqueV2Busy = true;
    const PIN = ${JSON.stringify(String(pin6 || "").replace(/\D/g, "").slice(0, 6))};
    const AUTO_CLICK = ${JSON.stringify(!!autoClick)};
    if (!Array.isArray(window.__pandoraSaqueV2Log)) window.__pandoraSaqueV2Log = [];
    const log = (m) => { try { window.__pandoraSaqueV2Log.push(String(m)); } catch {} };
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const visible = (el) => {
      if (!el || !el.isConnected) return false;
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 1 && r.height > 1 && s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.01;
    };
    const domClick = (el) => {
      if (!el) return false;
      try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
      const r = el.getBoundingClientRect();
      const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      try {
        const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
        el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true, touches: [touch], targetTouches: [touch], changedTouches: [touch] }));
      } catch {}
      try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 1, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try {
        const touch = new Touch({ identifier: Date.now(), target: el, clientX: cx, clientY: cy });
        el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true, touches: [], targetTouches: [], changedTouches: [touch] }));
      } catch {}
      try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, pointerType: 'touch', button: 0, buttons: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, button: 0, clientX: cx, clientY: cy })); } catch {}
      try { el.click(); } catch {}
      return true;
    };
    const findByText = (regex, sel) => Array.from(document.querySelectorAll(sel || 'button, [role="button"], a, li, div, span'))
      .filter(visible).find(el => regex.test((el.innerText || el.textContent || '').trim()));
    const findKeyboardKey = (ch) => {
      const sel = '.ui-number-keyboard__key, .van-number-keyboard .van-key, .van-key, [class*="number-keyboard"] [class*="key"], [class*="keyboard"] button, [data-key]';
      return Array.from(document.querySelectorAll(sel)).filter(visible).find(k => {
        const t = String((k.innerText || k.textContent || k.getAttribute('data-key') || k.getAttribute('aria-label') || '')).trim();
        return t === String(ch);
      });
    };
    const findPasswordGroup = () => {
      const lis = Array.from(document.querySelectorAll('li.ui-password-input__item, .ui-password-input__item, .van-password-input__item')).filter(visible);
      if (lis.length >= 6) return lis[0].parentElement || lis[0];
      return null;
    };
    const describeEl = (el) => el ? (el.tagName + (el.id ? '#' + el.id : '') + (el.className ? '.' + String(el.className).replace(/\\s+/g, '.').slice(0, 60) : '') + ' texto="' + (el.innerText || el.textContent || '').trim().slice(0, 30) + '"') : 'null';
    const parseBRL = (raw) => {
      const m = String(raw || '').match(/(\\d{1,3}(?:\\.\\d{3})*(?:,\\d{2})?|\\d+(?:[.,]\\d{2})?)/);
      if (!m) return null;
      let s = m[1];
      if (s.includes(',')) s = s.replace(/\\./g, '').replace(',', '.');
      else if ((s.match(/\\./g) || []).length > 1) s = s.replace(/\\./g, '');
      const n = parseFloat(s);
      return isFinite(n) && n > 0 ? n : null;
    };
    try {
      // 1) Lê o "Saldo" mostrado no topo da tela — usa o texto visível da
      // página inteira (document.body.innerText) em vez de vasculhar nó por
      // nó: "Saldo" e o valor são elementos SEPARADOS na tela (rótulo cinza
      // + número em laranja), então procurar um único elemento com os dois
      // juntos falhava sempre. innerText já lê na ordem visual certa.
      // BUG real (2026-08-08): conta com saldo R$21,50 acabou preenchendo
      // R$250 no campo — a regex antiga aceitava QUALQUER número (com ou
      // sem centavos) até 10 caracteres depois de "saldo", então pegou um
      // número de outro texto da tela (limite/promo tipo "...250" sem
      // centavos) em vez do saldo de verdade. Agora exige centavos
      // (",dd") obrigatoriamente — todo saldo de verdade vem formatado
      // como moeda (21,50), um limite/contador solto normalmente não tem
      // centavos — e encurta a distância aceita depois de "saldo".
      log('procurando "Saldo" na tela (url atual: ' + location.href + ')');
      const dl1 = Date.now() + 15000;
      let saldoValor = null;
      while (Date.now() < dl1) {
        const texto = document.body ? document.body.innerText : '';
        const m = texto.match(/saldo[^\\d]{0,6}(\\d{1,3}(?:\\.\\d{3})*,\\d{2})/i);
        if (m) { saldoValor = parseBRL(m[1]); if (saldoValor !== null) { log('saldo encontrado no texto da página -> R$' + saldoValor); break; } }
        await sleep(300);
      }
      if (saldoValor === null) { log('FALHA: valor de "Saldo" não encontrado em 15s'); return { ok: false }; }

      // 2) Campo de valor do saque — na tela real o placeholder é algo como
      // "R$  Mínimo10, Máximo14999" (sem a palavra "valor"), por isso busca
      // por esse padrão em vez de "valor/amount".
      log('procurando campo de valor do saque');
      const dl1b = Date.now() + 8000;
      let valorInp = null;
      while (Date.now() < dl1b) {
        valorInp = Array.from(document.querySelectorAll('input')).filter(visible)
          .find(i => /m[íi]nimo|m[áa]ximo|valor|amount|quantia|r\\$/i.test((i.placeholder || '') + ' ' + (i.name || '') + ' ' + (i.id || '')));
        if (valorInp) break;
        await sleep(300);
      }
      if (!valorInp) { log('FALHA: campo de valor do saque não encontrado em 8s'); return { ok: false }; }
      // BUG real #2 (2026-08-08): a plataforma só aceita valor INTEIRO de
      // saque (sem centavos) — mandar "21,50" fazia o campo mascarado
      // interpretar errado (virava "215"). Arredonda pra BAIXO (nunca pra
      // cima — não pode pedir mais do que o saldo real tem) e manda só o
      // número inteiro, sem vírgula/ponto nenhum.
      const valorStr = String(Math.floor(saldoValor));
      log('preenchendo campo de valor com R$' + valorStr + ' (digitando char a char) -> ' + describeEl(valorInp));
      const proto = valorInp.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
      try { valorInp.focus(); } catch {}
      setter.call(valorInp, '');
      valorInp.dispatchEvent(new Event('input', { bubbles: true }));
      await sleep(100);
      let acc = '';
      for (const ch of valorStr) {
        acc += ch;
        setter.call(valorInp, acc);
        try { valorInp.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: ch })); } catch {}
        try { valorInp.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: ch })); } catch { valorInp.dispatchEvent(new Event('input', { bubbles: true })); }
        try { valorInp.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: ch })); } catch {}
        await sleep(70);
      }
      valorInp.dispatchEvent(new Event('change', { bubbles: true }));
      try { valorInp.blur(); } catch {}
      await sleep(600);
      log('valor no campo depois de preencher: "' + valorInp.value + '" (pedido: R$' + valorStr + ')');
      log('url depois de preencher valor: ' + location.href);

      // 2) Preenche a senha de 6 dígitos
      log('aguardando prompt de senha (6 dígitos)');
      const dl2 = Date.now() + 15000;
      let grp = null;
      while (Date.now() < dl2) {
        grp = findPasswordGroup();
        if (grp) break;
        await sleep(300);
      }
      if (!grp) { log('FALHA: prompt de senha não apareceu em 15s'); return { ok: false }; }
      log('prompt encontrado, abrindo teclado');
      try { grp.click(); } catch {}
      await sleep(150);
      const kbDeadline = Date.now() + 3000;
      let kbReady = false;
      while (Date.now() < kbDeadline) {
        if (findKeyboardKey('0') || findKeyboardKey('1')) { kbReady = true; break; }
        await sleep(100);
      }
      if (!kbReady) log('teclado não apareceu em 3s, tentando digitar mesmo assim');
      for (const ch of PIN) {
        const k = findKeyboardKey(ch);
        if (k) { domClick(k); log('dígito ' + ch + ' clicado'); }
        else { log('dígito ' + ch + ' — tecla NÃO encontrada'); }
        await sleep(120);
      }
      await sleep(300);

      // 3) Espera o botão "Confirmar saque" HABILITAR de verdade (o site só
      // libera depois de validar valor+senha), aguarda mais 2s de margem
      // (pedido do usuário — dá tempo do site assentar/validar por completo
      // antes do clique) e clica UMA ÚNICA VEZ.
      // Texto do botão varia por plataforma — "Confirmar saque" numas,
      // "Confirmar Retirada" noutras (pedido do usuário 2026-08-08).
      log('procurando botão "Confirmar saque"/"Confirmar Retirada"');
      const dl3 = Date.now() + 15000;
      let btn = null;
      while (Date.now() < dl3) {
        btn = Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible)
          .find(b => /confirmar\\s+(saque|retirada)/i.test((b.innerText || b.textContent || '').trim()) && !b.disabled);
        if (btn) break;
        await sleep(300);
      }
      if (!btn) { log('FALHA: botão "Confirmar saque/Retirada" não habilitou em 15s'); return { ok: false }; }
      if (!AUTO_CLICK) {
        log('botão "' + (btn.innerText || btn.textContent || '').trim() + '" encontrado e habilitado — janela visível, confirmação fica manual (usuário clica)');
        return { ok: true };
      }
      log('botão habilitado ("' + (btn.innerText || btn.textContent || '').trim() + '") — Operação Oculta, aguardando 2s antes de clicar sozinho');
      await sleep(2000);
      window.__pandoraSaqueV2Clicked = true;
      domClick(btn);
      log('clicou em "' + (btn.innerText || btn.textContent || '').trim() + '" (único clique)');

      // Verificação pós-clique (bug real 2026-08-09, reportado pelo usuário:
      // o log dizia "sacada" mas o saque não caiu de verdade) — clicar no
      // botão NÃO é garantia de sucesso: pode existir um SEGUNDO popup de
      // confirmação ("Tem certeza?"), captcha, ou erro silencioso (senha
      // incorreta, saldo insuficiente, limite). Antes isso era reportado como
      // sucesso só por ter clicado; agora espera até 10s observando a tela.
      log('aguardando confirmação real do saque (sucesso/erro/segundo popup/saldo)');
      // BUG real (2026-08-09): usuário confirmou que o saque CAIU de verdade,
      // mas nenhum texto de sucesso/erro apareceu em 10s — o site desse
      // cassino aparentemente não mostra nenhuma mensagem reconhecível (ou
      // some rápido demais). Texto sozinho não é confiável aqui, então agora
      // combina 3 sinais indiretos, qualquer um já confirma sucesso:
      //   1) texto de sucesso/erro explícito (like antes)
      //   2) o SALDO exibido na tela caiu em relação ao que lemos antes de
      //      clicar (evidência mais forte — dinheiro realmente saiu)
      //   3) o botão "Confirmar..." e o campo de valor desapareceram/
      //      resetaram sem nenhum erro visível (indício de formulário
      //      enviado com sucesso e tela voltou ao estado neutro)
      let resultado = null; // 'success' | 'error' | null (nunca resolveu)
      let erroTxt = '';
      const dl4 = Date.now() + 10000;
      while (Date.now() < dl4 && !resultado) {
        // Segundo popup de confirmação — botão diferente do que já clicamos,
        // com texto tipo "Confirmar"/"OK"/"Sim", dentro de um modal visível.
        const modalBtn = Array.from(document.querySelectorAll('button, [role="button"]')).filter(visible)
          .find(b => b !== btn && /^(confirmar|confirm|ok|sim|yes)$/i.test((b.innerText || b.textContent || '').trim()));
        if (modalBtn) {
          log('segundo popup de confirmação encontrado ("' + (modalBtn.innerText || modalBtn.textContent || '').trim() + '") — clicando');
          domClick(modalBtn);
          await sleep(800);
          continue;
        }
        const txt = document.body ? document.body.innerText.toLowerCase() : '';
        if (/(saque solicitado|retirada solicitada|solicita[çc][ãa]o (de saque|enviada)|sucesso|processando (saque|retirada)|aguarde a (an[aá]lise|aprova[çc][ãa]o))/.test(txt)) {
          resultado = 'success';
          log('sinal 1 (texto de sucesso) encontrado');
          break;
        }
        if (/(senha (incorreta|inv[aá]lida)|saldo insuficiente|valor m[íi]nimo|limite (di[aá]rio|excedido)|n[aã]o foi poss[ií]vel|falha ao (processar|solicitar)|erro ao processar)/.test(txt)) {
          const m = txt.match(/(senha (incorreta|inv[aá]lida)|saldo insuficiente|valor m[íi]nimo[^.]{0,40}|limite (di[aá]rio|excedido)|n[aã]o foi poss[ií]vel[^.]{0,40}|falha ao (processar|solicitar)[^.]{0,40}|erro ao processar[^.]{0,40})/);
          erroTxt = m ? m[0] : 'erro não identificado no texto da página';
          resultado = 'error';
          log('sinal (texto de erro) encontrado: ' + erroTxt);
          break;
        }
        const mSaldo = txt.match(/saldo[^\\d]{0,6}(\\d{1,3}(?:\\.\\d{3})*,\\d{2})/i);
        if (mSaldo) {
          const saldoAgora = parseBRL(mSaldo[1]);
          if (saldoAgora !== null && saldoAgora < saldoValor - 0.01) {
            resultado = 'success';
            log('sinal 2 (saldo caiu de R$' + saldoValor + ' para R$' + saldoAgora + ') — saque confirmado');
            break;
          }
        }
        const btnSumiu = !visible(btn) || !document.body.contains(btn);
        const campoLimpo = !valorInp.value || valorInp.value.trim() === '';
        if (btnSumiu && campoLimpo && !/erro|falha|incorret|inv[aá]lid|insuficiente/.test(txt)) {
          resultado = 'success';
          log('sinal 3 (botão sumiu + campo de valor limpo, sem texto de erro na tela) — assumindo sucesso');
          break;
        }
        await sleep(500);
      }
      if (resultado === 'success') {
        log('CONFIRMADO: saque concluído de verdade');
        return { ok: true, valor: saldoValor, sacado: true };
      }
      if (resultado === 'error') {
        log('FALHA: saque rejeitado pelo site — "' + erroTxt + '"');
        return { ok: false, error: 'saque rejeitado: ' + erroTxt, sacado: false };
      }
      log('AVISO: clicou mas não achou confirmação nem erro em 10s — não marcando como sacado (pode ter travado num popup não reconhecido)');
      return { ok: false, error: 'sem confirmação de sucesso após o clique (verifique manualmente)', sacado: false };
    } catch (e) {
      log('ERRO: ' + (e && e.message ? e.message : String(e)));
      return { ok: false, error: String(e && e.message ? e.message : e) };
    } finally {
      window.__pandoraSaqueV2Busy = false;
    }
  })();`;
}

// Drena window.__pandoraSaqueV2Log por polling e joga cada linha nova pro
// nosso log assim que aparece.
function startLogDrain(win, wc) {
  let drainedCount = 0;
  const timer = setInterval(async () => {
    if (win.isDestroyed()) { clearInterval(timer); return; }
    try {
      const lines = await wc.executeJavaScript("(window.__pandoraSaqueV2Log || [])", true);
      if (Array.isArray(lines)) {
        for (let i = drainedCount; i < lines.length; i++) log(lines[i]);
        drainedCount = lines.length;
      }
    } catch {}
  }, 400);
  return () => clearInterval(timer);
}

// PASSO 1: navega pra tela de saque, clica TUDO, preenche senha, confirma.
async function runStep1(win) {
  if (!win || win.isDestroyed()) return { ok: false, error: "janela inválida" };
  const wc = win.webContents;
  const pin = String(getWithdrawPin(win) || "").replace(/\D/g, "").slice(0, 6);
  if (!/^\d{6}$/.test(pin)) {
    log("abortado: senha de saque não configurada/inválida");
    return { ok: false, error: "senha de saque (6 dígitos) não configurada em Início" };
  }
  const step1Url = urlOnCurrentSite(wc, STEP1_PATH);
  log("navegando para " + step1Url);
  try { await wc.loadURL(step1Url); } catch (e) {
    log("falha ao navegar — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao navegar" };
  }
  await new Promise((r) => setTimeout(r, 1200));
  const stopDrain = startLogDrain(win, wc);
  // Clique automático em "Confirmar saque/Retirada" só em Operação Oculta
  // (win._headless, setado em openOneRealChromeWindow) — com janela visível
  // o usuário confirma manualmente (pedido do usuário 2026-08-08).
  const autoClick = !!win._headless;
  log(`injetando script (TUDO + senha 6${autoClick ? " + Confirmar (auto, Operação Oculta)" : " — SEM clicar, confirmação manual"})`);
  try {
    const res = await wc.executeJavaScript(buildStep1Script(pin, autoClick), true);
    setTimeout(stopDrain, 4000); // dá tempo do polling pegar as últimas linhas
    // Log no Log de Operações (pedido do usuário 2026-08-08) — só quando de
    // fato clicou sozinho (Operação Oculta); confirmação manual não conta
    // como "sacada" ainda (quem vai clicar é o usuário).
    if (res?.ok && res?.sacado) {
      try {
        const tela = win._pandoraOrder || "?";
        logSystem(`Tela ${tela} sacada saldo R$${Number(res.valor ?? 0).toFixed(2)}`, { kind: "saque-v2", tela, valor: res.valor }, "success", "operacao-saque");
      } catch {}
    }
    return res || { ok: true };
  } catch (e) {
    stopDrain();
    log("falha ao injetar script — " + (e && e.message ? e.message : String(e)));
    return { ok: false, error: "falha ao injetar script" };
  }
}

function registerSaqueFlowV2Handler(ipcMain) {
  const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");
  ipcMain.handle("chrome:sacarV2", async () => {
    const wins = getSelectedChromeWins();
    if (!wins.length) return { ok: false, error: "Nenhuma tela selecionada/aberta" };
    const results = await Promise.all(wins.map((w) => runStep1(w)));
    const ok = results.filter((r) => r.ok).length;
    // Motivos das que falharam (pedido do usuário 2026-08-09: "Concluído —
    // 0/1" sem dizer POR QUE não dava pra saber se foi senha errada, saldo
    // insuficiente, popup não reconhecido etc.) — a UI (Operacao.tsx) mostra
    // isso junto do resultado em vez de só o placar.
    const falhas = results.map((r, i) => ({ tela: wins[i]?._pandoraOrder || i + 1, motivo: r.error || r.reason || null })).filter((f) => f.motivo);
    return { ok: true, windows: wins.length, sucesso: ok, falhas };
  });
}

module.exports = { runStep1, registerSaqueFlowV2Handler };
