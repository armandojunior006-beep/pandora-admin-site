import { useEffect, useState } from "react";
import { useAuth } from "@/stores/auth";
import { Loader2, ArrowRight, Key, UserPlus, ShieldCheck, RefreshCw } from "lucide-react";
import { getApi } from "@/lib/api";
import pandoraLogo from "@/assets/logo.png";
import { PlansModal } from "./PlansModal";
import { cloudLogin, registerAccount, confirmToken } from "@/lib/cloud-api";
import { useCloudSession } from "@/stores/cloud-session";

type Identity = { login: string; password: string } | { newLogin: string; newPassword: string };

// Aplica zoom 0.82 enquanto a tela de Login está montada, restaura ao desmontar.
function useLoginZoom() {
  useEffect(() => {
    const prevBody = document.body.style.zoom;
    const prevBg = document.body.style.backgroundColor;
    (document.body.style as any).zoom = "0.82";
    document.body.style.backgroundColor = "#000";
    return () => {
      (document.body.style as any).zoom = prevBody;
      document.body.style.backgroundColor = prevBg;
    };
  }, []);
}



export function Login() {
  useLoginZoom();
  const login = useAuth((s) => s.login);

  const setSession = useCloudSession((s) => s.setSession);
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showPlans, setShowPlans] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [plansIdentity, setPlansIdentity] = useState<Identity | null>(null);
  const [tokenPrompt, setTokenPrompt] = useState<{ login: string; password: string } | null>(null);
  const [showPassword, setShowPassword] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [updMsg, setUpdMsg] = useState<string | null>(null);

  // Mesmo fluxo do botão "Atualizações" da tela Início (Inicio.tsx atualizar())
  // — aqui pra usuário novo conseguir atualizar antes mesmo de ter token.
  async function atualizar() {
    setUpdating(true); setUpdMsg(null); setErr(null);
    try {
      const api = await getApi();
      const r = await api.installUpdate();
      if (!r.ok) throw new Error(r.error || "Falha ao atualizar");
      if (r.hasUpdate === false) setUpdMsg(r.note || "Você já está na última versão");
      else setUpdMsg("Atualização concluída. Reiniciando...");
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setUpdating(false);
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true); setErr(null);
    // 1) Login local admin (admin/admin) para uso interno do app
    // Protegido por try/catch (bug real 2026-08-09, reportado no Multi Bot):
    // quando essa janela é um processo Electron novinho (userData recém
    // criado do launcher/perfil), pode existir uma janela de tempo em que a
    // UI já carregou mas o handler IPC "db:query" ainda não foi registrado
    // (registerIpc() ainda rodando) — invoke() rejeitava sem handler, a
    // exceção não era pega em lugar nenhum, e o botão ficava travado em
    // "Verificando" pra sempre (setLoading(false) nunca era chamado).
    let local: { ok: boolean; error?: string };
    try {
      local = await login(u, p);
    } catch (e: any) {
      local = { ok: false, error: e?.message || "Falha no login local" };
    }
    if (local.ok) { setLoading(false); return; }
    // 2) Login na Cloud
    try {
      const r = await cloudLogin(u.trim().toLowerCase(), p);
      if (r.ok) {
        // Sempre pede o token após login bem-sucedido
        setTokenPrompt({ login: u.trim().toLowerCase(), password: p });
        setLoading(false);
        return;
      }
    } catch (e: any) {
      setErr(e.message || local.error || "Falha no login");
      setLoading(false);
      return;
    }
    setErr(local.error || "Login ou senha incorretos");
    setLoading(false);
  }

  function openTokenForExistingUser() {
    if (!u || !p) { setErr("Digite login e senha primeiro para vincular o pagamento."); return; }
    setPlansIdentity({ login: u.trim().toLowerCase(), password: p });
    setShowPlans(true);
  }

  async function onTokenConfirmed(login: string, password: string, token: string, plan_key: string, expires_at: string | null) {
    setSession({ login, token, plan_key, expires_at, confirmed_at: new Date().toISOString() });
    // Libera UI do app marcando login local
    await useAuth.getState().login("admin", "admin07982176");
  }

  return (
    // h-full (não h-screen/vh) — dentro do body com zoom 0.82 (useLoginZoom),
    // unidade de viewport (vh) desconta errado (mesmo bug que já pegou o
    // Canvas do Silk antes: Chromium não compensa o zoom pra vw/vh dos
    // descendentes). height:100% em cascata (html→body→#root→aqui, todo
    // mundo com height:100%, não vh) escala certo porque é relativo ao pai
    // já zoomado. min-h-0 evita que o conteúdo force altura maior que o pai.
    <main className="relative isolate h-full min-h-0 w-full overflow-hidden bg-black text-white">
      <div className="relative z-10 grid h-full min-h-0 w-full grid-cols-1 lg:grid-cols-2">
        <section className="relative hidden h-full min-h-0 w-full lg:flex flex-col justify-between overflow-hidden border-r border-border bg-black/35 p-12 xl:p-16">
          <div className="pointer-events-none absolute inset-0 z-10 bg-[linear-gradient(rgba(255,255,255,0.055)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.055)_1px,transparent_1px)] bg-[size:48px_48px] opacity-50" />
          <img src={pandoraLogo} alt="" aria-hidden="true"
               className="pointer-events-none absolute z-10 left-1/2 top-1/2 w-[78%] max-w-[760px] -translate-x-1/2 -translate-y-1/2 opacity-[0.08] grayscale" />

          <div className="relative z-20 flex h-full w-full flex-col justify-between">
            <div className="flex items-center gap-3">
              <img src={pandoraLogo} alt="Spider Bot" className="w-10 h-10 rounded-xl object-contain bg-black" />
              <div className="leading-tight">
                <p className="text-sm font-medium tracking-wide text-white">Spider Bot</p>
                <p className="text-[9px] uppercase tracking-[0.28em] text-muted">Automation Suite</p>
              </div>
            </div>
            <div className="max-w-xl">
              <p className="mb-5 text-[10px] uppercase tracking-[0.34em] text-muted">Acesso por token</p>
              <h1 className="font-display text-5xl xl:text-6xl leading-[0.94] tracking-tightest text-white">
                Token ativo.<br /><span className="text-mutedStrong">Operação liberada.</span>
              </h1>
              <p className="mt-8 max-w-md text-sm leading-6 text-mutedStrong">
                Cada token funciona em 1 dispositivo. Compre planos via Pix direto no app.
              </p>
            </div>
            <div className="flex items-center gap-4 text-[10px] uppercase tracking-[0.22em] text-muted">
              <span>1 dispositivo</span><span className="h-3 w-px bg-border" /><span>Pix instantâneo</span><span className="h-3 w-px bg-border" /><span>Sync Pay</span>
            </div>
          </div>
        </section>

        <section className="relative flex h-full min-h-0 w-full items-center justify-center overflow-hidden bg-black/55 px-6 py-16 sm:px-10 lg:px-16">
          <div className="pointer-events-none absolute inset-0 z-10 bg-[radial-gradient(circle_at_70%_45%,rgba(136,0,0,0.18),transparent_42%)]" />

          <div className="relative z-20 w-full max-w-sm">
            <div className="mb-10 flex items-center justify-between">
              <div className="lg:hidden flex items-center gap-3">
                <img src={pandoraLogo} alt="Spider Bot" className="w-10 h-10 rounded-xl object-contain bg-black" />
                <div><p className="text-sm font-medium text-white">Spider Bot</p><p className="text-[9px] text-muted uppercase tracking-[0.28em]">Automation</p></div>
              </div>
              <img src={pandoraLogo} alt="" className="ml-auto hidden lg:block w-11 h-11 rounded-xl border border-border bg-white/[0.03] object-contain p-2" />
            </div>

            <p className="text-[10px] uppercase tracking-[0.3em] text-muted mb-3">Acesso</p>
            <h2 className="font-display text-3xl font-light text-white tracking-tightest mb-1">Entrar no painel</h2>
            <p className="text-sm text-mutedStrong mb-10">Use seu login e senha. Token é solicitado em seguida.</p>

            <form onSubmit={submit} className="space-y-5">
              <div>
                <label className="label">Login</label>
                <input className="w-full bg-transparent border-0 border-b border-border focus:border-white px-0 py-2.5 text-white text-base focus:outline-none transition-colors"
                  placeholder="Digite seu login" autoComplete="username"
                  value={u} onChange={(e) => setU(e.target.value)} autoFocus />
              </div>
              <div>
                <div className="flex items-center justify-between">
                  <label className="label">Senha</label>
                  <button type="button" onClick={() => setShowPassword((v) => !v)}
                    className="text-[10px] uppercase tracking-[0.18em] text-muted hover:text-white transition-colors">
                    {showPassword ? "Ocultar" : "Mostrar"}
                  </button>
                </div>
                <input type={showPassword ? "text" : "password"} className="w-full bg-transparent border-0 border-b border-border focus:border-white px-0 py-2.5 text-white text-base focus:outline-none transition-colors"
                  placeholder="Digite sua senha" autoComplete="current-password"
                  value={p} onChange={(e) => setP(e.target.value)} />
              </div>
              {err && <div className="flex items-center gap-2 text-xs text-white border-l-2 border-white pl-3 py-1">{err}</div>}

              <button className="group w-full flex items-center justify-between px-5 py-3.5 mt-2 bg-white text-black font-medium text-sm hover:bg-neutral-200 transition-colors disabled:opacity-50 rounded-md" disabled={loading}>
                <span className="uppercase tracking-[0.18em] text-xs">{loading ? "Verificando" : "Entrar"}</span>
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />}
              </button>

              <div className="grid grid-cols-2 gap-2 pt-2">
                <button type="button" onClick={openTokenForExistingUser}
                  className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-md border border-white/30 text-white text-xs font-semibold uppercase tracking-[0.14em] hover:bg-white/5">
                  <Key className="w-3.5 h-3.5" /> Token
                </button>
                <button type="button" onClick={() => setShowRegister(true)}
                  className="flex items-center justify-center gap-2 px-3 py-2.5 rounded-md border border-white/15 text-mutedStrong text-xs font-semibold uppercase tracking-[0.14em] hover:bg-white/5 hover:text-white">
                  <UserPlus className="w-3.5 h-3.5" /> Criar conta
                </button>
              </div>

              <button type="button" onClick={atualizar} disabled={updating}
                className="w-full flex items-center justify-center gap-2 px-3 py-2.5 rounded-md border border-red-600/40 text-mutedStrong text-xs font-semibold uppercase tracking-[0.14em] hover:bg-red-600/10 hover:text-white disabled:opacity-50">
                {updating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                {updating ? "Atualizando..." : "Atualizar"}
              </button>
              {updMsg && <p className="text-xs text-mutedStrong text-center">{updMsg}</p>}
            </form>
          </div>
        </section>
      </div>

      <PlansModal open={showPlans} onClose={() => setShowPlans(false)} identity={plansIdentity} title="Comprar Token" />
      {showRegister && (
        <RegisterModal
          onClose={() => setShowRegister(false)}
          onCreated={(login, pwd) => {
            setU(login); setP(pwd);
            setShowRegister(false);
            // Conta já foi criada (com CPF) no RegisterModal — usar identidade existente
            setPlansIdentity({ login, password: pwd });
            setShowPlans(true);
          }}
        />
      )}
      {tokenPrompt && (
        <TokenPromptModal
          login={tokenPrompt.login}
          password={tokenPrompt.password}
          onClose={() => setTokenPrompt(null)}
          onConfirmed={async (token, plan_key, expires_at) => {
            // Protegido (bug real 2026-08-09): se o bypass de login local
            // (useAuth dentro de onTokenConfirmed) falhar por qualquer
            // motivo, essa era uma promise não capturada — o modal nunca
            // fechava e o app ficava preso na tela de login mesmo com o
            // token já confirmado no servidor. Agora fecha o modal e mostra
            // o erro de qualquer forma, em vez de travar silenciosamente.
            try {
              await onTokenConfirmed(tokenPrompt.login, tokenPrompt.password, token, plan_key, expires_at);
            } catch (e: any) {
              setErr(e?.message || "Token confirmado, mas houve um erro ao liberar o app — reinicie e faça login de novo.");
            } finally {
              setTokenPrompt(null);
            }
          }}
        />
      )}
    </main>
  );
}

function RegisterModal({ onClose, onCreated }: { onClose: () => void; onCreated: (login: string, pwd: string) => void }) {
  const [login, setLogin] = useState("");
  const [pwd, setPwd] = useState("");
  const [cpf, setCpf] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  function formatCpf(v: string) {
    const d = v.replace(/\D/g, "").slice(0, 11);
    return d
      .replace(/^(\d{3})(\d)/, "$1.$2")
      .replace(/^(\d{3})\.(\d{3})(\d)/, "$1.$2.$3")
      .replace(/\.(\d{3})(\d)/, ".$1-$2");
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr(null);
    try {
      const cpfDigits = cpf.replace(/\D/g, "");
      if (cpfDigits.length !== 11) throw new Error("CPF inválido (11 dígitos)");
      await registerAccount(login.trim().toLowerCase(), pwd, cpfDigits);
      onCreated(login.trim().toLowerCase(), pwd);
    } catch (e: any) { setErr(e.message || String(e)); }
    finally { setBusy(false); }
  }

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 grid place-items-center p-4">
      <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-xl shadow-2xl">
        <div className="px-4 py-3 border-b border-zinc-800 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white">Criar conta</h3>
          <button onClick={onClose} className="text-zinc-400 text-xl leading-none">×</button>
        </div>
        <form onSubmit={submit} className="p-4 space-y-3">
          <div><label className="text-[11px] text-zinc-400">Login</label>
            <input value={login} onChange={(e) => setLogin(e.target.value)} required minLength={3} autoFocus className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-sm text-white outline-none focus:border-red-600" /></div>
          <div><label className="text-[11px] text-zinc-400">Senha</label>
            <input type="password" value={pwd} onChange={(e) => setPwd(e.target.value)} required minLength={4} className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-sm text-white outline-none focus:border-red-600" /></div>
          <div><label className="text-[11px] text-zinc-400">CPF</label>
            <input value={cpf} onChange={(e) => setCpf(formatCpf(e.target.value))} required inputMode="numeric" placeholder="000.000.000-00" className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-sm text-white outline-none focus:border-red-600" /></div>
          {err && <p className="text-xs text-red-400">{err}</p>}
          <button disabled={busy} className="w-full bg-red-600 hover:bg-red-500 text-white font-semibold text-sm py-2.5 rounded disabled:opacity-50">
            {busy ? "Criando..." : "Criar conta e comprar token"}
          </button>
          <p className="text-[10px] text-zinc-500 text-center">CPF é usado no pagamento Pix. Em seguida você escolhe o plano.</p>
        </form>
      </div>
    </div>
  );
}

function TokenPromptModal({
  login, password, onClose, onConfirmed,
}: {
  login: string; password: string; onClose: () => void;
  onConfirmed: (token: string, plan_key: string, expires_at: string | null) => void;
}) {
  const [token, setToken] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr(null);
    try {
      const t = token.trim();
      const r = await confirmToken(login, password, t);
      onConfirmed(t, r.plan_key, r.expires_at);
    } catch (e: any) { setErr(e.message || String(e)); }
    finally { setBusy(false); }
  }

  return (
    <div className="fixed inset-0 z-[110] bg-black/85 grid place-items-center p-4">
      <div className="w-full max-w-sm bg-zinc-950 border border-zinc-800 rounded-xl shadow-2xl">
        <div className="px-4 py-3 border-b border-zinc-800 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-red-400" />
          <h3 className="text-sm font-semibold text-white">Confirme seu Token</h3>
        </div>
        <form onSubmit={submit} className="p-4 space-y-3">
          <p className="text-xs text-zinc-400">Cole o token que apareceu após a compra. A contagem do plano começa a partir desta confirmação.</p>
          <div>
            <label className="text-[11px] text-zinc-400">Token</label>
            <input value={token} onChange={(e) => setToken(e.target.value)} required minLength={8} autoFocus
              placeholder="cole seu token"
              className="w-full bg-zinc-900 border border-zinc-800 rounded px-3 py-2 text-sm text-white font-mono" />
          </div>
          {err && <p className="text-xs text-red-400">{err}</p>}
          <button disabled={busy || !token.trim()} className="w-full bg-red-600 hover:bg-red-500 text-white font-semibold text-sm py-2.5 rounded disabled:opacity-50">
            {busy ? "Confirmando..." : "Confirmar Token"}
          </button>
          <button type="button" onClick={onClose} className="w-full text-xs text-zinc-500 hover:text-white py-1">Cancelar</button>
        </form>
      </div>
    </div>
  );
}
