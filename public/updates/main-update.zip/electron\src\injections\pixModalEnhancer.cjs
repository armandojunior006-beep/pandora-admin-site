// ============================================================================
// Modal PIX: maximizar QR Code
// ============================================================================

function attachPixModalEnhancer(win) {
  if (!win || win.isDestroyed()) return;
  // IMPORTANTE: o enhancer só atua quando detecta um canvas PIX (title contém "br.gov.bcb.pix").
  // Não aplica nenhum CSS global — assim a tela de cadastro/captcha não é afetada.
  const js = `(() => {
    if (window.__pandoraPixEnhancer) return;
    window.__pandoraPixEnhancer = true;
    // BUG real 2026-08-09 (reportado pelo usuário com foto: um QR saiu
    // visivelmente menor que outro, mesmo os dois sendo o "mesmo" QR de
    // pagamento) — esse enhancer só reconhecia <canvas> com
    // title/aria-label batendo "br.gov.bcb.pix"/"qrcode"/"qr-code". Vários
    // desses sites (confirmado: os mesmos que qrCapture.cjs já lida) geram
    // o QR como <img src="data:image/...">, não <canvas> — pra esses,
    // isPixCanvas NUNCA batia, o script inteiro virava um no-op silencioso,
    // e o QR ficava do tamanho NATURAL que o site decidisse (inconsistente
    // entre janelas/telas). Agora reconhece as DUAS formas — <canvas> pelo
    // title/aria-label de antes, OU <img data:image> "quadrado-ish"
    // (mesma heurística de tamanho já usada em qrCapture.cjs, pra achar o
    // MESMO elemento que a captura acha, não um ícone pequeno qualquer).
    // BUG real 2026-08-09 (reportado pelo usuário: baixar o limiar pra 24px
    // pegou algum OUTRO elemento pequeno da página — não o QR — e forçou
    // ele pra 300px, distorcendo o layout inteiro, "deu zoom"). REVERTIDO
    // pro limiar de 100px — o requisito de ser data:image sozinho não é
    // filtro forte o bastante (existem outros ícones/logos pequenos em
    // data:image na página); precisa do tamanho mínimo também pra não
    // pegar elemento errado. Mantém só o resto dos fixes desse dia
    // (detecção de <img> além de <canvas>, observer de atributo "src",
    // poll mais longo).
    const isSquareish = (r) => r && r.width > 100 && r.height > 100 && Math.abs(r.width - r.height) < r.width * 0.35;
    const isPixCanvas = (el) => {
      if (!el || el.tagName !== 'CANVAS') return false;
      const t = (el.getAttribute('title') || '') + ' ' + (el.getAttribute('aria-label') || '');
      return /br\\.gov\\.bcb\\.pix|qrcode\\.|qr-code/i.test(t);
    };
    const isPixImg = (el) => {
      if (!el || el.tagName !== 'IMG') return false;
      if (!el.src || !el.src.startsWith('data:image')) return false;
      try { return isSquareish(el.getBoundingClientRect()); } catch (e) { return false; }
    };
    const isPixQr = (el) => isPixCanvas(el) || isPixImg(el);
    const styleQr = (qr) => {
      try {
        // Antes: min(70vh, 90vw) — em janela de tamanho normal isso deixava o
        // QR gigante (até 70% da altura da tela). Agora tem um teto absoluto
        // de 300px, ainda encolhendo em janelas pequenas.
        qr.style.setProperty('width', 'min(300px, 50vh, 70vw)', 'important');
        qr.style.setProperty('height', 'min(300px, 50vh, 70vw)', 'important');
        qr.style.setProperty('max-width', '300px', 'important');
        qr.style.setProperty('max-height', '300px', 'important');
        qr.style.setProperty('padding', '0', 'important');
        qr.style.setProperty('margin', '8px auto', 'important');
        qr.style.setProperty('background', 'transparent', 'important');
        qr.style.setProperty('box-shadow', 'none', 'important');
        qr.style.setProperty('border', '0', 'important');
        qr.style.setProperty('display', 'block', 'important');
        qr.style.setProperty('object-fit', 'contain', 'important');
        qr.style.setProperty('image-rendering', 'pixelated', 'important');
      } catch(e) {}
      // remove fundo branco dos containers diretos
      let p = qr.parentElement;
      for (let i = 0; i < 3 && p; i++, p = p.parentElement) {
        try {
          p.style.setProperty('background', 'transparent', 'important');
          p.style.setProperty('padding', '0', 'important');
          p.style.setProperty('border', '0', 'important');
          p.style.setProperty('box-shadow', 'none', 'important');
        } catch(e) {}
      }
    };
    const enhance = () => {
      try {
        // BUG GRAVE real 2026-08-09 (usuário lembrou: "mecheu no tamanho da
        // tela!!! parece que deu zoom" — reportado 08/08 bem no meio do
        // trabalho de aumentar o QR PIX, nunca investigado a fundo até
        // agora): isPixImg só exigia <img data:image> quadrada > 100px —
        // SEM checar contexto nenhum (nem texto "pix" por perto). Qualquer
        // ícone quadrado de outra tela (ex.: o mascote/baú do Relatório de
        // Apostas) podia ser confundido com QR, e o enhancer força
        // display:flex + reordena elementos com !important no container —
        // uma tela sem NADA a ver com PIX ficava com o layout destruído.
        // BUG real 2026-08-09 (2ª rodada — a guarda de "pix" na página
        // inteira não bastou: a Página de Baús também menciona "pix" em
        // algum canto — rodapé/menu de pagamento — e o enhancer voltou a
        // confundir um ícone dela com QR). Agora exige um sinal ESPECÍFICO
        // de modal de pagamento de verdade (copia-e-cola, chave PIX, QR
        // Code) dentro do PRÓPRIO container candidato — não a página
        // inteira — antes de aplicar qualquer estilo agressivo.
        // 2026-08-09 (3ª rodada): tentativa de adivinhar pelo texto do modal
        // ("copia e cola"/"chave pix") deixou o QR de depósito REAL pequeno
        // de novo — não sabíamos a redação exata desse site. Trocado por um
        // sinal explícito: depositHandler.cjs marca
        // window.__pandoraDepositoAtivoEm = Date.now() bem no início do
        // fluxo de depósito de verdade. Só aumenta o QR se esse aviso
        // existir e for recente (< 60s) — nunca em QR de indicação/baús ou
        // qualquer outro contexto, sem depender de adivinhar texto de tela.
        const depositoRecente = () => {
          try {
            var t = window.__pandoraDepositoAtivoEm;
            return typeof t === 'number' && (Date.now() - t) < 60000;
          } catch (e) { return false; }
        };
        if (!depositoRecente()) return;
        // BUG real 2026-08-10 (reportado pelo usuário: "abriu grande mas
        // depois volta a ficar pequeno") — o dataset.pandoraPix='1' no
        // MODAL fazia esse bloco rodar só UMA vez pra sempre por modal. Se
        // o site troca/re-renderiza o QR depois (código PIX expira e é
        // atualizado) ou reseta o style do próprio elemento sozinho (re-
        // render de framework), a marca no modal continuava lá e essa
        // reaplicação nunca mais rodava — o QR ficava pequeno de vez.
        // Agora reaplica o estilo (idempotente, custo baixo) em TODA
        // passada do poll/observer, sem depender de marca nenhuma.
        // Pedido do usuário 2026-08-10: "deve aumentar QR code somente
        // nessa parte do qr code e ponto" — reportou "zoom" na tela ao
        // voltar/navegar. Causa: além de redimensionar o QR, este bloco
        // também forçava display:flex + reordenava elementos (order 2/3)
        // no CONTAINER (modal) inteiro — se isPixQr acabasse batendo num
        // elemento fora do modal real de pagamento (ex.: flag ainda
        // "fresca" ao navegar pra outra tela), essa reflow no container
        // é o que dava a impressão de "zoom"/layout quebrado na página
        // inteira, não o redimensionamento do próprio QR (que fica restrito
        // ao próprio elemento). Removida toda a manipulação do modal —
        // agora só toca no elemento do QR em si, nada mais.
        const qrs = Array.from(document.querySelectorAll('canvas, img')).filter(isPixQr);
        qrs.forEach(qr => { styleQr(qr); });
      } catch(e) {}
    };
    enhance();
    // BUG real 2026-08-09 (reportado pelo usuário: de 10, 1 ainda ficou
    // pequeno mesmo já reconhecendo <img>) — o observer só via elementos
    // NOVOS sendo inseridos (childList/subtree). Muitos desses sites
    // colocam a <img> vazia/placeholder no DOM primeiro e só preenchem o
    // atributo src DEPOIS (via JS, sem inserir nenhum nó novo) — nesse
    // caso o observer nunca disparava de novo, e enhance() só via a img
    // ainda sem "src" (falhava o isPixImg, que exige data:image), NUNCA
    // reavaliando depois que o src real chegasse. Agora observa também
    // mudança do atributo "src" — cobre os dois jeitos do site montar o
    // QR. Reforço extra: poll curto (500ms, só primeiros 8s) como rede de
    // segurança pra qualquer outro padrão de timing não coberto pelo
    // observer, desliga sozinho depois — mesmo espírito das outras
    // heurísticas best-effort desse arquivo, custo baixo.
    new MutationObserver(enhance).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['src'] });
    // BUG real 2026-08-10 (reportado pelo usuário: valores aleatórios ok,
    // mas "o qr code não abriu grande como deveria" no botão Depositar da
    // aba Operação — só no cadastro automático que abria certo) — esse poll
    // rápido (500ms) só rodava por 20s a partir do did-finish-load da
    // página. No cadastro automático o depósito acontece rápido, dentro
    // dessa janela de 20s — funciona. No botão manual, a tela já está
    // aberta há muito mais que 20s quando o usuário clica em "Depositar";
    // o poll já tinha parado, e o MutationObserver sozinho não reage a
    // mudança de TAMANHO/CSS do QR (só a inserção de nó novo ou troca do
    // atributo "src") — se o QR aparecer com o layout ainda "assentando"
    // (transição/animação do modal), nunca era reavaliado depois. Agora o
    // poll roda pra sempre (nunca clearInterval) — custo é baixíssimo
    // porque enhance() já retorna de imediato sempre que depositoRecente()
    // é falso (ou seja, na esmagadora maioria do tempo em que não há
    // depósito ativo).
    setInterval(enhance, 500);
  })();`;
  // BUG real 2026-08-10 (reportado pelo usuário: QR não abriu grande nem no
  // botão manual nem no depósito automático pós-cadastro, mesmo já com a
  // flag __pandoraDepositoAtivoEm sendo setada) — este apply() só injetava
  // no FRAME PRINCIPAL (win.webContents.executeJavaScript). O próprio
  // qrCapture.cjs já documentava que "o formulário de depósito às vezes
  // roda dentro de um iframe de pagamento de terceiros" — se o QR estiver
  // num iframe desses, o script nunca nem chegava a rodar naquele contexto,
  // então a checagem de depositoRecente() era irrelevante (o código-alvo
  // simplesmente não existia lá). Agora injeta no frame principal E em
  // todo subframe, igual ao padrão já usado em depositHandler.cjs/
  // qrCapture.cjs (injectAllFrames / scan de frames).
  const apply = () => {
    try { win.webContents.executeJavaScript(js, true).catch(() => {}); } catch {}
    try {
      const frames = (win.webContents.mainFrame && win.webContents.mainFrame.framesInSubtree) || [];
      for (const f of frames) {
        if (!f || f === win.webContents.mainFrame) continue;
        try { f.executeJavaScript(js, true).catch(() => {}); } catch {}
      }
    } catch {}
  };
  win.webContents.on('did-finish-load', apply);
  win.webContents.on('did-frame-finish-load', apply);
  win.webContents.on('did-navigate-in-page', apply);
}




module.exports = { attachPixModalEnhancer };
