// Preload dedicado às janelas Chromium (slots / cassino).
// Carregado em TODOS os frames graças a `nodeIntegrationInSubFrames: true`,
// inclusive em iframes Out-Of-Process (OOPIF) do motor PG SOFT.

// ===== Geetest/WebSQL + Camada de Imunidade DOM =====
(function() {
  try {
    // Força o Geetest a ignorar o WebSQL e usar localStorage/IndexedDB como fallback
    Object.defineProperty(window, 'openDatabase', {
      value: undefined,
      writable: false,
      configurable: false
    });
    console.log('[Pandora Core] WebSQL desativado com sucesso para forçar fallback estável.');
  } catch (e) {
    console.error('[Pandora Core] Erro ao desativar openDatabase:', e);
  }

  // Mantém a blindagem do .closest criada anteriormente
  if (!window.closest) window.closest = function() { return null; };
  if (!document.closest) document.closest = function() { return null; };
  if (window.EventTarget && !window.EventTarget.prototype.closest) {
    window.EventTarget.prototype.closest = function() { return null; };
  }
})();

// ===== Ponte: clique humanizado nativo via IPC (sendInputEvent no main) =====
try {
  const { ipcRenderer } = require("electron");
  window.__pandoraHumanClick = function (x, y) {
    try {
      return ipcRenderer.invoke("pandora:human-click", { x: Math.round(x), y: Math.round(y) });
    } catch (e) {
      return Promise.resolve({ ok: false, error: e && e.message });
    }
  };
} catch (_) {}

// ===== Anti-fingerprint: esconde navigator.webdriver (Geetest/geeGuard) =====
try {
  Object.defineProperty(navigator, "webdriver", {
    get: () => undefined,
    configurable: true,
  });
} catch (_) {}
try {
  // Também remove a propriedade caso já tenha sido definida como true.
  delete Object.getPrototypeOf(navigator).webdriver;
} catch (_) {}

// ===== Detecta páginas de cadastro/onboarding para PULAR hooks de tempo =====
// O Time-Warp invalida a validação comportamental do Geetest e trava o cadastro.
// Em fluxos de onboarding mantemos o relógio 100% nativo (sem hooks injetados).
function __pandoraEhPaginaCadastro() {
  try {
    const href = (location && location.href ? location.href : "").toLowerCase();
    if (!href) return false;
    return /register|registro|cadastro|signup|sign-up|onboard|onboarding/.test(href);
  } catch (_) {
    return false;
  }
}
const __PANDORA_SKIP_TIME_HOOKS = __pandoraEhPaginaCadastro();
//
// Com `contextIsolation: false`, o preload compartilha o objeto `window`
// com o main world da página — então hookamos as APIs de tempo diretamente.

// ===== Bloqueio de fullscreen (preserva comportamento existente) =====
try {
  const ignorar = () => Promise.resolve();
  const desativarFs = () => {
    try {
      if (typeof Element !== "undefined") {
        try { Element.prototype.requestFullscreen = ignorar; } catch (_) {}
        try { Element.prototype.webkitRequestFullscreen = ignorar; } catch (_) {}
        try { Element.prototype.mozRequestFullScreen = ignorar; } catch (_) {}
        try { Element.prototype.msRequestFullscreen = ignorar; } catch (_) {}
      }
      if (typeof document !== "undefined" && document.documentElement) {
        try { document.documentElement.requestFullscreen = ignorar; } catch (_) {}
        try { document.documentElement.webkitRequestFullscreen = ignorar; } catch (_) {}
        try { document.documentElement.mozRequestFullScreen = ignorar; } catch (_) {}
        try { document.documentElement.msRequestFullscreen = ignorar; } catch (_) {}
      }
    } catch (_) {}
  };
  desativarFs();
  try { window.addEventListener("DOMContentLoaded", desativarFs); } catch (_) {}
  try { window.addEventListener("load", desativarFs); } catch (_) {}
} catch (_) {}

// ===== Speedhack: Time-Warp total (performance.now + Date.now + rAF) =====
try {
  if (__PANDORA_SKIP_TIME_HOOKS) {
    try {
      console.log(
        "-> [Pandora Core Engine] Time-Warp DESABILITADO (página de cadastro/onboarding):",
        window.location.href
      );
    } catch (_) {}
  } else if (!window.__pandoraSpeedHookInstalled) {
    window.__pandoraSpeedHookInstalled = true;
    window.__pandoraSpeedMultiplier = window.__pandoraSpeedMultiplier || 1.0;

    try {
      const { ipcRenderer } = require("electron");
      ipcRenderer.on("pandora:set-speed", (_event, multiplier) => {
        const m = parseFloat(multiplier);
        const v = isFinite(m) && m > 0 ? Math.max(1, Math.min(25, m)) : 1.0;
        window.__pandoraSpeedMultiplier = v;
        try {
          console.log(
            "-> [Pandora Core Engine] Speed IPC recebido:",
            v + "x",
            "frame:",
            window.location.href
          );
        } catch (_) {}
      });
    } catch (_) {}

    // Armazena as funções nativas de tempo
    const nativeNow = performance.now.bind(performance);
    const nativeDateNow = Date.now.bind(Date);
    const nativeRAF = window.requestAnimationFrame.bind(window);
    const nativeFnToString = Function.prototype.toString;

    // Variáveis de controle do relógio virtual (só usadas quando multiplier > 1)
    let baseRealTime = nativeNow();
    let baseVirtualTime = nativeNow();
    let baseDateRealTime = nativeDateNow();
    let baseDateVirtualTime = nativeDateNow();
    let lastMultiplier = 1.0;

    function syncBase() {
      const currentReal = nativeNow();
      const currentRealDate = nativeDateNow();
      baseVirtualTime =
        baseVirtualTime + (currentReal - baseRealTime) * lastMultiplier;
      baseRealTime = currentReal;
      baseDateVirtualTime =
        baseDateVirtualTime +
        (currentRealDate - baseDateRealTime) * lastMultiplier;
      baseDateRealTime = currentRealDate;
    }

    function getVirtualNow() {
      const multiplier = parseFloat(window.__pandoraSpeedMultiplier) || 1.0;
      // Fast path: sem aceleração, devolve tempo nativo idêntico (não quebra boot/loader)
      if (multiplier === 1.0 && lastMultiplier === 1.0) {
        return nativeNow();
      }
      if (multiplier !== lastMultiplier) {
        syncBase();
        lastMultiplier = multiplier;
      }
      return baseVirtualTime + (nativeNow() - baseRealTime) * multiplier;
    }

    function getVirtualDateNow() {
      const multiplier = parseFloat(window.__pandoraSpeedMultiplier) || 1.0;
      if (multiplier === 1.0 && lastMultiplier === 1.0) {
        return nativeDateNow();
      }
      if (multiplier !== lastMultiplier) {
        syncBase();
        lastMultiplier = multiplier;
      }
      return baseDateVirtualTime + (nativeDateNow() - baseDateRealTime) * multiplier;
    }

    // Mascara a função substituída como "native code" para evitar
    // detecção anti-tamper (toString) por parte do motor PG SOFT.
    function maskNative(hooked, original) {
      try {
        const nativeStr = nativeFnToString.call(original);
        const proxyToString = function toString() { return nativeStr; };
        // também mascara o próprio toString do proxy
        try {
          proxyToString.toString = function () {
            return nativeFnToString.call(Function.prototype.toString);
          };
        } catch (_) {}
        hooked.toString = proxyToString;
      } catch (_) {}
      return hooked;
    }

    // 1. Hook em performance.now (instância + protótipo — alguns engines
    //    chamam Performance.prototype.now.call(performance) e burlariam o
    //    hook se sobrescrevêssemos apenas a propriedade own.)
    try {
      const originalPerfNow = performance.now;
      const hookedPerfNow = function now() {
        return getVirtualNow();
      };
      maskNative(hookedPerfNow, originalPerfNow);
      try { performance.now = hookedPerfNow; } catch (_) {}
      try {
        if (typeof Performance !== "undefined" && Performance.prototype) {
          Performance.prototype.now = hookedPerfNow;
        }
      } catch (_) {}
    } catch (_) {}

    // 2. Hook em Date.now
    try {
      const originalDateNow = Date.now;
      const hookedDateNow = function now() {
        return Math.floor(getVirtualDateNow());
      };
      maskNative(hookedDateNow, originalDateNow);
      Date.now = hookedDateNow;
    } catch (_) {}

    // 3. Hook em requestAnimationFrame passando tempo virtualizado
    try {
      const originalRAF = window.requestAnimationFrame;
      const hookedRAF = function requestAnimationFrame(callback) {
        return nativeRAF(function (realTs) {
          const multiplier = parseFloat(window.__pandoraSpeedMultiplier) || 1.0;
          // Fast path: passa exatamente o timestamp nativo (compatível com loader)
          if (multiplier === 1.0 && lastMultiplier === 1.0) {
            try { callback(realTs); } catch (_) {}
            return;
          }
          try {
            callback(getVirtualNow());
          } catch (e) {
            try { callback(realTs); } catch (_) {}
          }
        });
      };
      maskNative(hookedRAF, originalRAF);
      window.requestAnimationFrame = hookedRAF;
    } catch (_) {}

    // 4. Hook em setTimeout / setInterval — encurta o delay pelo multiplicador
    //    para que callbacks agendados (animações, lógica de jogo, spins) rodem
    //    "no tempo virtual". Mantém-se em passthrough quando multiplier === 1.
    try {
      const nativeSetTimeout = window.setTimeout.bind(window);
      const originalSetTimeout = window.setTimeout;
      const hookedSetTimeout = function setTimeout(handler, timeout) {
        const args = Array.prototype.slice.call(arguments, 2);
        const m = parseFloat(window.__pandoraSpeedMultiplier) || 1.0;
        let t = Number(timeout) || 0;
        if (m > 1 && t > 0) t = t / m;
        return nativeSetTimeout.apply(null, [handler, t].concat(args));
      };
      maskNative(hookedSetTimeout, originalSetTimeout);
      window.setTimeout = hookedSetTimeout;
    } catch (_) {}

    try {
      const nativeSetInterval = window.setInterval.bind(window);
      const originalSetInterval = window.setInterval;
      const hookedSetInterval = function setInterval(handler, timeout) {
        const args = Array.prototype.slice.call(arguments, 2);
        const m = parseFloat(window.__pandoraSpeedMultiplier) || 1.0;
        let t = Number(timeout) || 0;
        if (m > 1 && t > 0) t = t / m;
        return nativeSetInterval.apply(null, [handler, t].concat(args));
      };
      maskNative(hookedSetInterval, originalSetInterval);
      window.setInterval = hookedSetInterval;
    } catch (_) {}

    // 5. Hook no construtor Date — `new Date()` sem argumentos retorna
    //    o tempo virtual. Mantém todas as outras assinaturas (parsing,
    //    componentes, timestamp explícito) com o comportamento nativo.
    try {
      const NativeDate = window.Date;
      function HookedDate(...args) {
        if (!(this instanceof HookedDate)) {
          return new NativeDate(getVirtualDateNow()).toString();
        }
        if (args.length === 0) {
          return new NativeDate(getVirtualDateNow());
        }
        return new NativeDate(...args);
      }
      HookedDate.prototype = NativeDate.prototype;
      try { Object.setPrototypeOf(HookedDate, NativeDate); } catch (_) {}
      try { HookedDate.UTC = NativeDate.UTC; } catch (_) {}
      try { HookedDate.parse = NativeDate.parse; } catch (_) {}
      try { HookedDate.now = Date.now; } catch (_) {}
      try {
        const nativeStr = nativeFnToString.call(NativeDate);
        HookedDate.toString = function () { return nativeStr; };
      } catch (_) {}
      try { window.Date = HookedDate; } catch (_) {}
    } catch (_) {}

    try {
      console.log(
        "-> [Pandora Core Engine] Time-Warp aplicado (passthrough@1x) no frame:",
        window.location.href
      );
    } catch (_) {}
  }
} catch (e) {
  try {
    console.error("-> [Pandora Core Engine] Erro ao injetar hooks de tempo:", e);
  } catch (_) {}
}

// ===== Popup killer (Cash_Hunters port) — roda em todo frame =====
try {
  const fs = require("fs");
  const path = require("path");
  const candidates = [
    path.join(__dirname, "popup-killer-injected.js"),
    path.join(process.resourcesPath || "", "app", "electron", "popup-killer-injected.js"),
    path.join(process.resourcesPath || "", "app.asar", "electron", "popup-killer-injected.js"),
  ];
  let src = "";
  for (const p of candidates) {
    try { if (p && fs.existsSync(p)) { src = fs.readFileSync(p, "utf8"); break; } } catch (_) {}
  }
  if (src) {
    // eval no mundo principal (contextIsolation:false já compartilha o window)
    // Usamos new Function para evitar eval direct e manter strict-mode isolado.
    try { (new Function(src))(); }
    catch (e) { try { console.error("[pandora-popup] erro carregando script:", e && e.message); } catch (_) {} }
  }
} catch (e) {
  try { console.error("[pandora-popup] erro inicializando popup-killer:", e && e.message); } catch (_) {}
}

// ===== Auto-aceitar banners de cookies/consent =====
// Roda assim que a tela abre e fica varrendo por ~30s. Clica em qualquer
// botão/link cujo texto bata com padrões comuns de "aceitar tudo".
(function() {
  try {
    const ACCEPT_PATTERNS = /^(aceitar(\s+(tudo|todos|todas))?|aceito|concordo|ok|entendi|permitir(\s+(tudo|todos))?|continuar|prosseguir|sim|allow(\s+all)?|accept(\s+all|\s+cookies)?|agree|got\s+it|i\s+agree|consent|enable\s+all)$/i;
    const KEEP_BTN_SELECTORS = [
      'button', 'a', '[role="button"]', 'input[type="button"]', 'input[type="submit"]',
      '.cookie-accept', '.accept-cookies', '#accept-cookies', '#cookie-accept',
      '[id*="accept" i]', '[class*="accept" i]', '[id*="consent" i]', '[class*="consent" i]',
      '[data-testid*="accept" i]', '[aria-label*="accept" i]', '[aria-label*="aceitar" i]'
    ].join(',');

    function isVisible(el) {
      if (!el || !el.getBoundingClientRect) return false;
      const r = el.getBoundingClientRect();
      if (r.width < 4 || r.height < 4) return false;
      const cs = window.getComputedStyle ? window.getComputedStyle(el) : null;
      if (cs && (cs.display === 'none' || cs.visibility === 'hidden' || parseFloat(cs.opacity) === 0)) return false;
      return true;
    }

    function textOf(el) {
      try { return (el.innerText || el.textContent || el.value || el.getAttribute('aria-label') || '').trim().toLowerCase(); }
      catch (_) { return ''; }
    }

    function tryAccept() {
      try {
        const nodes = document.querySelectorAll(KEEP_BTN_SELECTORS);
        for (const el of nodes) {
          if (!isVisible(el)) continue;
          const t = textOf(el);
          if (!t) continue;
          if (ACCEPT_PATTERNS.test(t) || /aceitar|accept|allow|concordo|permitir|consent/i.test(t)) {
            // Evita botões claramente negativos
            if (/recus|reject|decline|negar|n[ãa]o|cancel/i.test(t)) continue;
            try { el.click(); } catch (_) {}
            try { console.log('[pandora-consent] clicou em:', t.slice(0, 60)); } catch (_) {}
            return true;
          }
        }
      } catch (_) {}
      return false;
    }

    let attempts = 0;
    const maxAttempts = 60; // ~30s a 500ms
    const iv = setInterval(() => {
      attempts++;
      try { tryAccept(); } catch (_) {}
      if (attempts >= maxAttempts) clearInterval(iv);
    }, 500);
    try { window.addEventListener('DOMContentLoaded', tryAccept); } catch (_) {}
    try { window.addEventListener('load', tryAccept); } catch (_) {}
  } catch (_) {}
})();
