// ============================================================================
// FASE 2 — Shim de compatibilidade: faz uma Page do Puppeteer (Chrome real via
// CDP) se parecer o suficiente com uma BrowserWindow/webContents do Electron
// pra reaproveitar SEM REESCREVER auto-register.cjs, geetest-attach.cjs,
// browserInjections.cjs, autoLogin.cjs, pixModalEnhancer.cjs — todos esses
// arquivos só chamam um punhado de métodos/eventos do webContents; em vez de
// portar centenas de KB de lógica de automação já testada em produção,
// implementamos ESSE subconjunto por cima do CDP diretamente.
//
// Cobertura (o que cada arquivo realmente usa, levantado por grep):
//   webContents: getURL, executeJavaScript, session(.webRequest), mainFrame,
//                debugger, id, sendInputEvent, reload(IgnoringCache), on/once
//                pra: did-finish-load, did-frame-finish-load, did-navigate,
//                did-navigate-in-page, dom-ready, did-start-navigation,
//                console-message, page-title-updated, frame-created,
//                enter-html-full-screen, did-frame-navigate, render-process-gone,
//                unresponsive, preload-error
//   win: isDestroyed, on/once("closed"), close, loadURL, setFullScreen,
//        setFullScreenable, setTitle
// ============================================================================
const { EventEmitter } = require("events");
const state = require("../../state.cjs");

let _idCounter = 1;

// Logger compartilhado pro diag file — usado por loadURL (ver histórico:
// [[pandorabot-console-error-swallowed]], erros de CDP escondidos atrás de
// `.catch(() => {})` já custaram horas de investigação nesse projeto).
function diagLineShared(msg) {
  try {
    const { queueDiagLine } = require("../../../auto-register.cjs");
    if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [webContentsShim] ${msg}\r\n`);
  } catch {}
}

// -- Frame shim: cada Frame do Puppeteer ganha um .executeJavaScript() igual
// ao Electron (frame.executeJavaScript(js, userGesture) já existe em
// browserInjections.cjs's getAllFrames-style code). Puppeteer's Frame já tem
// .evaluate(), só precisamos aceitar STRING (IIFE) como o Electron aceita.
function wrapFrame(frame, cdpForFrame) {
  if (!frame) return null;
  if (frame.__pandoraShimmed) return frame.__pandoraShimmed;
  const shim = {
    _frame: frame,
    get frames() { return (frame.childFrames() || []).map((f) => wrapFrame(f)); },
    // BUG corrigido: "url" era um valor fixo (frame.url() calculado só na
    // hora do wrap) e o shim inteiro fica em cache pra sempre por frame
    // (__pandoraShimmed logo abaixo) — então se a MESMA aba navegasse pra
    // outra URL sem o frame do Puppeteer trocar de objeto (comportamento
    // normal numa navegação de página inteira no mesmo tab), a url ficava
    // congelada na primeira que carregou (ex.: splash.html) pra sempre.
    // Isso explicava "speedhack funciona na PG, não na WG": jogos da PG
    // carregam num IFRAME novo (frame novo = wrap novo = url fresca), o
    // Lucky Dog da WG navega a aba inteira (mesmo frame = shim velho).
    get url() { return frame.url(); },
    async executeJavaScript(script) {
      return frame.evaluate(script);
    },
  };
  try { frame.__pandoraShimmed = shim; } catch {}
  return shim;
}

// -- Debugger shim: Electron's webContents.debugger é praticamente um
// cliente CDP cru (attach/sendCommand(method,params,sessionId)/on('message',
// (event,method,params,sessionId))) — mapeia pra CDPSession do Puppeteer,
// que é a MESMA coisa por baixo, incluindo sub-sessões pra targets anexados
// via Target.setAutoAttach (ex.: iframe OOPIF cross-origin do GeeTest):
// Puppeteer expõe cada sub-sessão nova via evento "sessionattached" na
// sessão pai — encaminhamos os eventos crus dela como se fossem da sessão
// principal, só carimbando o sessionId, igual o Electron faz com flatten:true.
function wrapDebugger(cdp) {
  const dbg = new EventEmitter();
  dbg.__attached = false;
  dbg.attach = async () => { dbg.__attached = true; };
  dbg.detach = async () => { dbg.__attached = false; };
  dbg.isAttached = () => dbg.__attached;

  const sessionsById = new Map(); // sessionId -> CDPSession
  const knownMethods = [
    "Network.responseReceived", "Network.requestWillBeSent",
    "Target.attachedToTarget", "Target.detachedFromTarget",
    "Page.frameNavigated", "Page.loadEventFired",
    // Runtime.bindingCalled: dispara quando a página chama uma função criada
    // via Runtime.addBinding (Runtime.addBinding, não confundir com
    // page.exposeFunction do Puppeteer — mirrorMode.cjs usa addBinding cru
    // via wc.debugger pra criar window.__pandoraMirror). Faltava aqui, então
    // o modo espelho nunca recebia o clique/tecla capturado na janela
    // mestre em Chrome real — a mensagem simplesmente não era encaminhada.
    "Runtime.bindingCalled",
  ];
  const wireSession = (session, sessionId) => {
    if (sessionId) sessionsById.set(sessionId, session);
    for (const method of knownMethods) {
      session.on(method, (params) => dbg.emit("message", {}, method, params, sessionId));
    }
    // Sub-sessões de targets anexados dentro DESSA sessão (aninhamento, ex.:
    // iframe dentro de iframe) — Puppeteer expõe recursivamente.
    session.on("sessionattached", (child) => {
      const childId = typeof child.id === "function" ? child.id() : child._sessionId;
      wireSession(child, childId);
    });
  };
  wireSession(cdp, undefined);

  dbg.sendCommand = async (method, params, sessionId) => {
    const target = (sessionId && sessionsById.get(sessionId)) || cdp;
    return target.send(method, params || {});
  };
  return dbg;
}

// -- Session shim: só o suficiente pra registerWebRequestWatcher (geetest-attach.cjs)
// funcionar — webRequest.onBeforeRequest via CDP Network domain.
function wrapSession(cdp) {
  let networkEnabled = false;
  const listeners = [];
  const ensureNetwork = async () => {
    if (networkEnabled) return;
    networkEnabled = true;
    try { await cdp.send("Network.enable"); } catch {}
    cdp.on("Network.requestWillBeSent", (params) => {
      for (const l of listeners) {
        try {
          l({ url: params.request && params.request.url, webContentsId: undefined }, (cb) => { try { cb && cb({}); } catch {} });
        } catch {}
      }
    });
  };
  return {
    webRequest: {
      onBeforeRequest(_filter, handler) {
        listeners.push(handler);
        ensureNetwork().catch(() => {});
      },
    },
  };
}

// Tradução mínima do "keyCode" estilo Electron (usado por securityPin.cjs
// pra digitar PIN e mirrorMode.cjs pra replicar teclado) pro formato que o
// CDP Input.dispatchKeyEvent espera (key/code/windowsVirtualKeyCode/text).
// Cobre: 1 char (dígitos/letras — o caso mais comum, PIN de 6 dígitos) +
// teclas nomeadas usadas no código (Escape, Enter, Backspace, Tab, setas).
const __PANDORA_KEYMAP = {
  Enter: { key: "Enter", code: "Enter", vk: 13 },
  Escape: { key: "Escape", code: "Escape", vk: 27 },
  Backspace: { key: "Backspace", code: "Backspace", vk: 8 },
  Tab: { key: "Tab", code: "Tab", vk: 9 },
  Delete: { key: "Delete", code: "Delete", vk: 46 },
  ArrowLeft: { key: "ArrowLeft", code: "ArrowLeft", vk: 37 },
  ArrowRight: { key: "ArrowRight", code: "ArrowRight", vk: 39 },
  ArrowUp: { key: "ArrowUp", code: "ArrowUp", vk: 38 },
  ArrowDown: { key: "ArrowDown", code: "ArrowDown", vk: 40 },
  " ": { key: " ", code: "Space", vk: 32, text: " " },
  Space: { key: " ", code: "Space", vk: 32, text: " " },
};
function resolveKeyInfo(keyCode) {
  const kc = String(keyCode == null ? "" : keyCode);
  if (__PANDORA_KEYMAP[kc]) return __PANDORA_KEYMAP[kc];
  if (kc.length === 1) {
    const isDigit = /[0-9]/.test(kc);
    const code = isDigit ? "Digit" + kc : /[a-zA-Z]/.test(kc) ? "Key" + kc.toUpperCase() : kc;
    return { key: kc, code, vk: kc.toUpperCase().charCodeAt(0), text: kc };
  }
  return { key: kc, code: kc, vk: 0 };
}
// Electron manda modifiers como array de strings; CDP quer um bitmask.
function modsToBits(mods) {
  if (!Array.isArray(mods)) return 0;
  let bits = 0;
  if (mods.includes("alt")) bits |= 1;
  if (mods.includes("control") || mods.includes("ctrl")) bits |= 2;
  if (mods.includes("meta") || mods.includes("command")) bits |= 4;
  if (mods.includes("shift")) bits |= 8;
  return bits;
}

// Cria o objeto "webContents" shim por cima de um Page + CDPSession do Puppeteer.
function createWebContentsShim(page, cdp, browser) {
  const emitter = new EventEmitter();
  const id = _idCounter++;
  let destroyed = false;
  let lastUrl = "";
  // Estado de navegação por página (ver loadURL mais abaixo) — 2026-08-10.
  let __pandoraNavGen = 0;
  let __pandoraNavPending = false;

  page.on("close", () => { destroyed = true; });
  browser.on("disconnected", () => { destroyed = true; });

  // --- Navegação / ciclo de vida (mapeando nomes de evento Electron) ---
  page.on("load", () => emitter.emit("did-finish-load"));
  page.on("domcontentloaded", () => emitter.emit("dom-ready"));
  page.on("framenavigated", (frame) => {
    lastUrl = page.url();
    if (frame === page.mainFrame()) emitter.emit("did-navigate", {}, frame.url());
    else emitter.emit("did-frame-finish-load", {}, false, 0, 0);
  });
  page.on("console", (msg) => {
    // Assinatura Electron: (event, level, message, line, sourceId)
    let text = "";
    try { text = msg.text(); } catch {}
    emitter.emit("console-message", {}, 1, text, 0, "");
  });
  page.on("frameattached", (frame) => {
    emitter.emit("frame-created", {}, { frame: wrapFrame(frame) });
  });
  page.on("error", (err) => emitter.emit("render-process-gone", {}, { reason: "crashed", exitCode: -1, message: err && err.message }));

  // CDP direto pra sinais mais finos que o Puppeteer não expõe em alto nível:
  //   - Page.navigatedWithinDocument  == did-navigate-in-page (SPA/hash/pushState)
  //   - Page.frameStartedLoading      == did-start-navigation
  //   - Page.lifecycleEvent (name=load) por frame == did-frame-finish-load (mais fiel que framenavigated)
  (async () => {
    try {
      await cdp.send("Page.enable");
      cdp.on("Page.navigatedWithinDocument", () => emitter.emit("did-navigate-in-page", {}, page.url()));
      cdp.on("Page.frameStartedLoading", () => emitter.emit("did-start-navigation", {}, page.url(), false, true));
      cdp.on("Page.lifecycleEvent", (p) => {
        if (p.name === "load") emitter.emit("did-frame-finish-load", {}, true, 0, 0);
      });
    } catch (e) { console.warn("[realchrome-shim] Page.enable falhou:", e?.message); }
  })();

  const wc = Object.assign(emitter, {
    id,
    isDestroyed: () => destroyed || page.isClosed(),
    getURL: () => { try { return page.url(); } catch { return lastUrl; } },
    session: wrapSession(cdp),
    debugger: wrapDebugger(cdp),

    // Equivalente fiel ao webContents.executeJavaScript(script, userGesture):
    // roda via CDP Runtime.evaluate (não via page.evaluate(), que serializa
    // o argumento como função — nossos scripts são strings IIFE prontas,
    // igual o Electron consome).
    async executeJavaScript(script) {
      if (destroyed) throw new Error("webContents destruído");
      const r = await cdp.send("Runtime.evaluate", {
        expression: script,
        awaitPromise: true,
        returnByValue: true,
        userGesture: true,
      });
      if (r.exceptionDetails) {
        const msg = (r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text || "erro no executeJavaScript";
        throw new Error(msg);
      }
      return r.result ? r.result.value : undefined;
    },

    // ignoreCache:true — muitos sites desse nicho são PWA com service worker
    // agressivo; um reload normal pode servir do cache e parecer que "não
    // atualizou nada" mesmo tendo recarregado de verdade.
    async reload() { try { await cdp.send("Page.reload", { ignoreCache: true }); } catch { await page.reload(); } },
    async reloadIgnoringCache() { try { await cdp.send("Page.reload", { ignoreCache: true }); } catch { await page.reload(); } },
    async stop() { try { await cdp.send("Page.stopLoading"); } catch {} },
    // 2026-08-09: era um `.catch(() => {})` mudo — se o goto() falhasse
    // (timeout, net::ERR_ABORTED, frame detached etc.) a janela ficava
    // parada/em branco sem NENHUM rastro no diag log, e ficávamos chutando
    // teorias de "precisa de delay" às cegas. Continua NÃO rejeitando (a
    // maioria dos ~15 call-sites de win.loadURL no projeto faz
    // `try { win.loadURL(x); } catch {}` síncrono, sem await — uma rejeição
    // aqui viraria unhandled rejection nesses call-sites) — mas agora loga
    // origem/destino/erro real no diag log e resolve `true`/`false` pra quem
    // quiser checar explicitamente (ver navigateHandler.cjs).
    async loadURL(url) {
      const from = (() => { try { return page.url(); } catch { return "?"; } })();
      // BUG real 2026-08-10 (reportado pelo usuário: clicou em "Página de
      // Baús", a tela entrou e voltou pra Home sozinha — só reproduzia com
      // várias telas simultâneas, nunca uma por uma) — page.goto() não
      // cancelava nenhuma navegação anterior ainda em andamento na MESMA
      // página. Se dois loadURL() chegam próximos (ex.: um clique em
      // "Página Inicial" que ficou lento por proxy sob carga, seguido pelo
      // clique real do usuário em "Página de Baús"), os dois goto() corriam
      // em paralelo sem nenhuma coordenação — sob latência de proxy com
      // várias janelas, o mais ANTIGO podia terminar DEPOIS do mais novo e
      // "ganhar" a corrida, deixando a tela na URL errada mesmo com o
      // usuário já tendo navegado pra outro lugar. Confirmado pelo usuário:
      // cada navegação precisa ser ENCERRADA antes da próxima começar.
      // Agora: 1) se já existe uma navegação pendente nessa mesma página,
      // manda Page.stopLoading pra ela ANTES de iniciar a nova (o navegador
      // aborta de vez a antiga, não corre risco de "ganhar" depois); 2) um
      // contador de geração garante que, mesmo se a antiga ainda resolver
      // de alguma forma, o resultado dela é descartado (nunca tratado como
      // sucesso) — só a navegação mais recente é que conta.
      __pandoraNavGen++;
      const myGen = __pandoraNavGen;
      if (__pandoraNavPending) {
        try { await cdp.send("Page.stopLoading"); } catch {}
      }
      __pandoraNavPending = true;
      try {
        await page.goto(url, { waitUntil: "domcontentloaded", timeout: 20000 });
        if (myGen !== __pandoraNavGen) {
          diagLineShared(`loadURL descartado (superado por navegação mais nova): ${from} -> ${url}`);
          return false;
        }
        __pandoraNavPending = false;
        return true;
      } catch (e) {
        if (myGen === __pandoraNavGen) __pandoraNavPending = false;
        if (myGen !== __pandoraNavGen) return false;
        diagLineShared(`loadURL FALHOU: ${from} -> ${url} | ${e?.message || e}`);
        return false;
      }
    },
    async goBack() { await page.goBack().catch(() => {}); },
    async goForward() { await page.goForward().catch(() => {}); },
    canGoBack: () => true, // Puppeteer não expõe isso de forma síncrona; otimista (goBack() é no-op seguro se não houver histórico)
    canGoForward: () => true,
    navigationHistory: null, // código que usa isso tem fallback pra canGoBack/canGoForward direto
    async sendInputEvent(ev) {
      try {
        if (ev.type === "mouseMove") await cdp.send("Input.dispatchMouseEvent", { type: "mouseMoved", x: ev.x, y: ev.y });
        else if (ev.type === "mouseDown") await cdp.send("Input.dispatchMouseEvent", { type: "mousePressed", x: ev.x, y: ev.y, button: ev.button || "left", clickCount: ev.clickCount || 1 });
        else if (ev.type === "mouseUp") await cdp.send("Input.dispatchMouseEvent", { type: "mouseReleased", x: ev.x, y: ev.y, button: ev.button || "left", clickCount: ev.clickCount || 1 });
        else if (ev.type === "mouseWheel") await cdp.send("Input.dispatchMouseEvent", { type: "mouseWheel", x: ev.x, y: ev.y, deltaX: ev.deltaX || 0, deltaY: ev.deltaY || 0 });
        // Teclado — usado por securityPin.cjs (digitar PIN de 6 dígitos) e
        // mirrorMode.cjs (replicar teclado do mestre nos followers). Sem
        // isso as duas features ficavam mudas em Chrome real (chamadas
        // silenciosamente engolidas pelo try/catch, sem nenhum erro visível).
        else if (ev.type === "keyDown" || ev.type === "rawKeyDown") {
          const info = resolveKeyInfo(ev.keyCode);
          await cdp.send("Input.dispatchKeyEvent", {
            type: "keyDown", key: info.key, code: info.code,
            windowsVirtualKeyCode: info.vk, nativeVirtualKeyCode: info.vk,
            modifiers: modsToBits(ev.modifiers),
          });
        } else if (ev.type === "keyUp") {
          const info = resolveKeyInfo(ev.keyCode);
          await cdp.send("Input.dispatchKeyEvent", {
            type: "keyUp", key: info.key, code: info.code,
            windowsVirtualKeyCode: info.vk, nativeVirtualKeyCode: info.vk,
            modifiers: modsToBits(ev.modifiers),
          });
        } else if (ev.type === "char") {
          const info = resolveKeyInfo(ev.keyCode);
          const text = info.text || (info.key && info.key.length === 1 ? info.key : "");
          await cdp.send("Input.dispatchKeyEvent", {
            type: "char", key: info.key, text, unmodifiedText: text,
            modifiers: modsToBits(ev.modifiers),
          });
        }
      } catch {}
    },

    // Usado só pelo indicador visual "MESTRE" do modo espelho
    // (applyMasterIndicator). Implementado via injeção de <style> com ID,
    // igual Electron faz internamente — a "key" devolvida é esse ID.
    async insertCSS(css) {
      const key = "pandora_css_" + Math.random().toString(36).slice(2);
      await this.executeJavaScript(`(() => { try { var s=document.createElement('style'); s.id=${JSON.stringify(key)}; s.textContent=${JSON.stringify(String(css || ""))}; (document.head||document.documentElement).appendChild(s); } catch(e){} })();`);
      return key;
    },
    async removeInsertedCSS(key) {
      await this.executeJavaScript(`(() => { try { var s=document.getElementById(${JSON.stringify(key)}); if (s && s.parentNode) s.parentNode.removeChild(s); } catch(e){} })();`);
    },
  });

  // mainFrame vivo (não fixo): page.mainFrame() é chamado de novo a cada
  // acesso, então sempre reflete a navegação atual da aba.
  Object.defineProperty(wc, "mainFrame", {
    get() { return wrapFrame(page.mainFrame()); },
    enumerable: true,
    configurable: true,
  });

  // Injeção "em todos os frames" — usado por executeInAllFrames (browserInjections.cjs)
  // e getAllFrames (geetest-attach.cjs). Puppeteer's page.frames() já dá a
  // árvore inteira sem precisar navegar por frame.frames recursivamente.
  wc.__getAllFrames = () => page.frames().map((f) => wrapFrame(f));

  return wc;
}

// Cria o objeto "win" shim (equivalente a uma BrowserWindow) por cima de um
// Browser+Page+CDPSession do Puppeteer.
function createWindowShim({ browser, page, cdp, chromePid = null }) {
  const winEmitter = new EventEmitter();
  const webContents = createWebContentsShim(page, cdp, browser);
  let destroyed = false;
  const diagLine = (msg) => {
    try {
      const { queueDiagLine } = require("../../../auto-register.cjs");
      if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [win-lifecycle] ${msg}\r\n`);
    } catch {}
  };
  // Diag 2026-08-09 (investigação "Stop não fecha"): se o transporte CDP cair
  // sozinho (sem o Chrome real ter fechado — teoria: instabilidade da conexão
  // já vista travando Runtime.evaluate/api-inspect), esse "disconnected"
  // dispara, marcamos destroyed=true e emitimos "closed" — e
  // registerChromeWin (windowManager.cjs) TIRA essa janela de
  // state.chromeWins na hora. Resultado: closeChromiumWindows() não encontra
  // mais nada pra fechar (Stop "não faz nada"), mesmo com a janela do Chrome
  // real ainda visível na tela, travada. Log aqui prova ou descarta isso.
  browser.on("disconnected", () => {
    diagLine(`browser "disconnected" disparou — chromePid=${chromePid}, destroyed antes=${destroyed}`);
    destroyed = true;
    winEmitter.emit("closed");
  });
  page.on("close", () => {
    diagLine(`page "close" disparou — chromePid=${chromePid}, destroyed antes=${destroyed}`);
    destroyed = true;
  });

  // Cache atualizado periodicamente (não dá pra fazer getContentSize()/
  // isFocused() de verdade síncronos com Chrome real — precisam de um
  // round-trip CDP). Usado SÓ pelo modo espelho (mirrorMode.cjs): getContentSize
  // pra converter coordenadas normalizadas de volta em pixels, isFocused
  // como parte do "gate" que só replica evento se a janela mestre estiver
  // mesmo em foco. Antes rodava sempre (mesmo com modo espelho desligado),
  // gastando 1 round-trip CDP/seg à toa em CADA janela aberta — com várias
  // janelas isso soma bastante CPU/CDP sem nenhum uso real. Agora só liga o
  // poll de verdade enquanto o modo espelho estiver ativo (checa a cada 1s
  // se precisa ligar/desligar; o poll em si, quando ligado, também é 1s).
  const liveMetrics = { size: [800, 600], focused: true };
  let pollTimer = null;
  const stopPoll = () => { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } };
  const fetchMetricsOnce = async () => {
    if (destroyed || page.isClosed()) return;
    try {
      const r = await cdp.send("Runtime.evaluate", {
        expression: "[window.innerWidth, window.innerHeight, document.hasFocus()]",
        returnByValue: true,
      });
      const v = r && r.result && r.result.value;
      if (Array.isArray(v) && v.length === 3) {
        liveMetrics.size = [v[0], v[1]];
        liveMetrics.focused = !!v[2];
      }
    } catch {}
  };
  const startPoll = () => {
    if (pollTimer) return;
    // BUG real 2026-08-10 (reportado pelo usuário: modo espelho "não
    // replica" e "às vezes buga") — liveMetrics.size começava sempre no
    // fallback fixo 800x600 e só era atualizado pelo poll ABAIXO, que
    // demorava até 1s pra rodar a primeira vez. Qualquer clique replicado
    // ANTES desse primeiro poll usava esse tamanho errado pra converter a
    // posição normalizada (nx/ny) de volta em pixel — clique caía fora do
    // lugar. Também o poll de 1s em 1s deixava o tamanho/foco até 1s
    // desatualizado o tempo todo, causando cliques levemente errados e
    // gate de foco (isFocused) falso-negativo (dropava eventos legítimos).
    // Agora busca o valor real IMEDIATAMENTE ao ligar (sem esperar o
    // primeiro tick) e reduz o intervalo pra 200ms enquanto o modo espelho
    // estiver ativo — mais round-trips CDP, mas só enquanto o usuário
    // liga essa função explicitamente, e a precisão importa mais aqui do
    // que economia de CPU.
    fetchMetricsOnce();
    pollTimer = setInterval(fetchMetricsOnce, 200);
  };
  const metricsTimer = setInterval(() => {
    if (destroyed || page.isClosed()) { clearInterval(metricsTimer); stopPoll(); return; }
    if (state.mirrorEnabled) startPoll(); else stopPoll();
  }, 1000);
  winEmitter.on("closed", () => { clearInterval(metricsTimer); stopPoll(); });

  const win = Object.assign(winEmitter, {
    webContents,
    isDestroyed: () => destroyed,
    // Bug real 2026-08-09 (reportado pelo usuário: clicar em "Pausar" não
    // fechava a janela) — browser.close() é uma negociação graciosa via CDP
    // (Browser.close) que pode ficar pendurada pra sempre se a página tiver
    // MUITO tráfego CDP concorrente na fila (ex.: heartbeat do wg-check
    // rodando em cima da splash local, ver applyApiInspectToTarget) ou se o
    // processo já estiver travado/zumbi por qualquer motivo — o app ficava
    // esperando uma promise que nunca resolve nem rejeita. Corrida contra um
    // timeout de 5s: se o close gracioso não terminar a tempo, mata o
    // processo do Chrome direto (SIGKILL) — bruto, mas garante que a janela
    // SEMPRE some quando o usuário manda fechar.
    async close() {
      // Diag 2026-08-09: close() era uma caixa-preta total — nenhum log,
      // então não dava pra saber SE browser.close() travava, lançava erro,
      // ou se resolvia "com sucesso" sem a janela real sumir (o que o vídeo
      // do usuário sugere ser o caso: app marcou "Encerrado" mas a janela
      // continuou visível). Loga cada etapa pra próxima vez que reproduzir
      // ficar óbvio no diag-auto-register.txt o que de fato aconteceu.
      const t0 = Date.now();
      const diagLine = (msg) => {
        try {
          const { queueDiagLine } = require("../../../auto-register.cjs");
          if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [close] ${msg}\r\n`);
        } catch {}
      };
      // Checa se o PID ainda existe de verdade no Windows — usado depois de
      // browser.close() "resolver OK" pra não confiar cegamente que a
      // promise ter resolvido normal significa que o processo REALMENTE
      // morreu (pedido do usuário 2026-08-09: garantir que nunca sobra
      // Chrome zumbi pesando a máquina, nem em modo normal nem oculto).
      const isPidAlive = (pid) => new Promise((resolve) => {
        if (!pid) return resolve(false);
        require("child_process").exec(`tasklist /FI "PID eq ${pid}" /FO CSV /NH`, (err, stdout) => {
          resolve(!err && String(stdout || "").includes(String(pid)));
        });
      });
      const forceKillTree = (pid, reason) => {
        try {
          diagLine(`forceKillTree(${pid}) — motivo: ${reason}`);
          if (pid) require("child_process").exec(`taskkill /PID ${pid} /T /F`, (err, stdout, stderr) => {
            diagLine(`taskkill /PID ${pid} resultado: err=${err?.message || "-"} stdout=${String(stdout || "").trim()} stderr=${String(stderr || "").trim()}`);
          });
        } catch (e) { diagLine(`forceKillTree falhou ao disparar: ${e?.message}`); }
      };
      diagLine(`iniciando close() — chromePid=${chromePid} browserProcessPid=${browser.process()?.pid}`);
      try {
        await Promise.race([
          browser.close(),
          new Promise((_, rej) => setTimeout(() => rej(new Error("close timeout 5s")), 5000)),
        ]);
        diagLine(`browser.close() resolveu OK em ${Date.now() - t0}ms`);
        // Verificação extra: dá 1.5s de graça (o processo pode levar um
        // instante pra terminar de verdade após a promise resolver) e então
        // confere se o PID ainda existe — se sim, o "close gracioso" só
        // fechou a conexão CDP mas o processo do Chrome ficou pra trás
        // (zumbi), e forçamos o kill mesmo sem ter caído no catch.
        const pidToCheck = chromePid || browser.process()?.pid;
        if (pidToCheck) {
          setTimeout(async () => {
            const alive = await isPidAlive(pidToCheck);
            diagLine(`checagem pós-close: PID ${pidToCheck} ainda vivo? ${alive}`);
            if (alive) forceKillTree(pidToCheck, "browser.close() resolveu OK mas o processo continuou vivo (zumbi)");
          }, 1500);
        }
      } catch (e) {
        diagLine(`browser.close() falhou/travou em ${Date.now() - t0}ms: ${e?.message} — indo pro fallback SIGKILL/taskkill`);
        // Reforço 2026-08-09: browser.process()?.kill("SIGKILL") sozinho se
        // mostrou insuficiente no vídeo que o usuário mandou (janela
        // continuava na tela mesmo depois do app marcar "Encerrado") — Chrome
        // é lançado com pipe:true (CDP via stdio, não porta TCP), e nesse
        // modo o handle de processo que o Puppeteer guarda pode não refletir
        // mais o processo REAL do Chrome nessa hora. Por isso usa o PID
        // capturado no MOMENTO DO LANÇAMENTO (chromePid, thread desde
        // openOneRealChromeWindow — ver comentário lá) como fonte primária, e
        // browser.process() só como reforço extra. taskkill /T mata a ÁRVORE
        // inteira (processo + filhos) por PID, direto do Windows — não
        // depende de nenhum handle do Node estar íntegro pra funcionar.
        try {
          const killed = browser.process()?.kill("SIGKILL");
          diagLine(`SIGKILL via browser.process(): ${killed}`);
        } catch (e2) { diagLine(`SIGKILL via browser.process() falhou: ${e2?.message}`); }
        try {
          const pid = chromePid || browser.process()?.pid;
          diagLine(`taskkill /PID ${pid} /T /F disparado`);
          if (pid) require("child_process").exec(`taskkill /PID ${pid} /T /F`, (err, stdout, stderr) => {
            diagLine(`taskkill /PID ${pid} resultado: err=${err?.message || "-"} stdout=${String(stdout || "").trim()} stderr=${String(stderr || "").trim()}`);
          });
          else diagLine(`taskkill NÃO disparado — nenhum pid disponível (chromePid=${chromePid}, browser.process()=${browser.process()})`);
        } catch (e3) { diagLine(`taskkill falhou ao disparar: ${e3?.message}`); }
      }
    },
    async loadURL(url) { return await webContents.loadURL(url); },
    async loadFile() { /* não aplicável — Chrome real não carrega splash local do app */ },
    setFullScreen() {},
    setFullScreenable() {},
    setTitle() {},
    getBounds() { return { x: 0, y: 0, width: 0, height: 0 }; }, // preenchido externamente se necessário
    setBounds() {},
    setSkipTaskbar() {},
    setOpacity() {},
    getTitle: () => "",
    setIcon() {},
    setAppDetails() {},
    getContentSize: () => liveMetrics.size,
    isFocused: () => liveMetrics.focused,
  });
  return win;
}

module.exports = { createWindowShim, createWebContentsShim };
