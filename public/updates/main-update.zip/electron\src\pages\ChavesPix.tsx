import { useEffect, useRef, useState } from "react";
import { q, run, log } from "@/lib/api";
import { useAuth } from "@/stores/auth";
import { useUI } from "@/stores/ui";
import type { PixKey } from "@/types";
import { Plus, Trash2, X, KeyRound, Upload } from "lucide-react";

const TYPES: { value: PixKey["key_type"]; label: string }[] = [
  { value: "cpf", label: "CPF" },
  { value: "cnpj", label: "CNPJ" },
  { value: "email", label: "Email" },
  { value: "phone", label: "Telefone" },
  { value: "evp", label: "Aleatória (EVP)" },
];

const PAGE_SIZE = 10;

export function ChavesPix() {
  const [list, setList] = useState<PixKey[]>([]);
  const [open, setOpen] = useState(false);
  const [tipo, setTipo] = useState<PixKey["key_type"]>("phone");
  const [bloco, setBloco] = useState("");
  const [page, setPage] = useState(1);
  const [modalKey, setModalKey] = useState(0); // muda a cada abertura -> força o React a remontar o modal do zero
  const savingRef = useRef(false); // ref (não state) — trava clique duplo sem forçar re-render/"Salvando…"
  // confirm() nativo é bloqueante e no Electron deixa o foco bagunçado depois
  // (o campo de texto do modal seguinte parava de aceitar clique/digitação) —
  // por isso excluir/limpar usa um modal próprio em vez de confirm().
  const [confirmAlvo, setConfirmAlvo] = useState<{ id: number } | "all" | null>(null);
  const { user } = useAuth();
  const { showToast } = useUI();

  async function load() {
    setList(await q(`SELECT * FROM pix_keys ORDER BY id DESC`));
  }
  useEffect(() => { load(); }, []);

  async function copiarChave(valor: string) {
    try {
      await navigator.clipboard.writeText(valor);
      showToast("Chave copiada!", "success");
    } catch {
      showToast("Não foi possível copiar a chave", "error");
    }
  }

  function openModal() {
    setTipo("phone"); setBloco(""); setModalKey((k) => k + 1); setOpen(true);
  }

  async function importarArquivo() {
    try {
      const r = await (window as any).api?.openFile?.({
        title: "Importar chaves PIX",
        filters: [{ name: "Texto/CSV", extensions: ["txt", "csv"] }],
        properties: ["openFile"],
      });
      if (!r) return;
      const texto = atob(r.data);
      const linhas = texto.split(/\r?\n|,|;/).map((s: string) => s.trim()).filter(Boolean);
      if (!linhas.length) { showToast("Arquivo vazio ou sem chaves válidas", "warning"); return; }
      // Abre o mesmo modal de "Nova chave" já preenchido com o conteúdo do
      // arquivo — assim dá pra revisar/ajustar o tipo antes de salvar, em
      // vez de inserir direto sem conferência.
      setTipo("phone");
      setBloco(linhas.join("\n"));
      setModalKey((k) => k + 1);
      setOpen(true);
      showToast(`${linhas.length} chave(s) carregada(s) de "${r.name}" — revise e clique em Salvar`, "info");
    } catch {
      showToast("Falha ao importar arquivo", "error");
    }
  }

  async function salvar() {
    if (savingRef.current) return; // evita inserir duplicado se clicar várias vezes seguidas
    const linhas = bloco.split(/\r?\n|,|;/).map((s) => s.trim()).filter(Boolean);
    if (linhas.length === 0) { showToast("Cole pelo menos uma chave", "warning"); return; }
    savingRef.current = true;
    // source "operacao-pix" (não "pix") pra cair no filtro 'operacao%' do
    // painel "Log de Operações" (Início) — pedido do usuário 2026-08-09:
    // clicar em cadastrar chave não aparecia em lugar nenhum do log.
    try {
      await log("info", "operacao-pix", "Cadastrando chave Pix...", null, user?.id);
      let n = 0;
      for (const v of linhas) {
        await run(
          `INSERT INTO pix_keys (key_type, key_value, status) VALUES (?,?,?)`,
          [tipo, v, "active"]
        );
        n++;
      }
      await log("info", "operacao-pix", `Cadastro de chave Pix concluído — ${n} chave(s) (${tipo})`, null, user?.id);
      setOpen(false);
      showToast(`${n} chave(s) cadastrada(s)`, "success");
      load();
    } finally {
      savingRef.current = false;
    }
  }

  async function remove(id: number) {
    await run("DELETE FROM pix_keys WHERE id=?", [id]);
    showToast("Chave excluída", "success"); load();
  }

  async function limparTudo() {
    await run("DELETE FROM pix_keys", []);
    showToast("Todas as chaves removidas", "success"); load();
  }

  async function confirmarExclusao() {
    if (confirmAlvo === "all") await limparTudo();
    else if (confirmAlvo) await remove(confirmAlvo.id);
    setConfirmAlvo(null);
  }

  return (
    <div className="p-3 h-full flex flex-col">
      <header className="flex items-center justify-between mb-2">
        <div>
          <h1 className="text-base font-semibold flex items-center gap-1.5">
            <KeyRound className="w-4 h-4 text-amber-400" /> Chaves PIX
          </h1>
          <p className="text-[11px] text-muted">{list.length} chave(s) cadastrada(s)</p>
        </div>
        <div className="flex gap-1.5">
          {list.length > 0 && (
            <button className="btn-ghost text-danger !px-2 !py-1 !text-xs" onClick={() => setConfirmAlvo("all")}>
              <Trash2 className="w-3.5 h-3.5" /> Limpar tudo
            </button>
          )}
          <button className="btn-ghost !px-2 !py-1 !text-xs" onClick={importarArquivo}>
            <Upload className="w-3.5 h-3.5" /> Importar
          </button>
          <button className="btn-primary !px-2 !py-1 !text-xs" onClick={openModal}>
            <Plus className="w-3.5 h-3.5" /> Nova chave
          </button>
        </div>
      </header>

      {(() => {
        const totalPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
        const currentPage = Math.min(page, totalPages);
        const startIdx = (currentPage - 1) * PAGE_SIZE;
        const pageItems = list.slice(startIdx, startIdx + PAGE_SIZE);
        return (
          <>
            <div className="card overflow-hidden">
              <table className="w-full text-xs">
                <thead className="bg-panel2 text-muted text-[10px] uppercase">
                  <tr>
                    <th className="text-left px-2 py-1.5">Tipo</th>
                    <th className="text-left px-2 py-1.5">Chave</th>
                    <th className="text-left px-2 py-1.5">Status</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {pageItems.map((k) => (
                    <tr key={k.id} className="border-t border-border hover:bg-panel2/40">
                      <td className="px-2 py-1">
                        <span className="badge bg-amber-500/15 text-amber-400 uppercase">{k.key_type}</span>
                      </td>
                      <td
                        className="px-2 py-1 font-mono text-[11px] cursor-pointer hover:text-amber-400 hover:underline"
                        title="Clique para copiar"
                        onClick={() => copiarChave(k.key_value)}
                      >
                        {k.key_value}
                      </td>
                      <td className="px-2 py-1">
                        <span className={`badge ${k.status === "active" ? "bg-success/15 text-success" : "bg-muted/20 text-muted"}`}>
                          {k.status}
                        </span>
                      </td>
                      <td className="px-2 py-1 text-right">
                        <button className="btn-ghost text-danger !p-1" onClick={() => setConfirmAlvo({ id: k.id })}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {list.length === 0 && (
                    <tr><td colSpan={4} className="px-2 py-6 text-center text-muted text-xs">Nenhuma chave cadastrada.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
            {list.length > 0 && (
              <div className="flex items-center justify-between mt-2 text-[11px]">
                <span className="text-muted">
                  Página {currentPage} de {totalPages} · {list.length} chave(s)
                </span>
                <div className="flex gap-1.5">
                  <button
                    className="btn-ghost !px-2 !py-1 !text-xs"
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={currentPage <= 1}
                  >
                    ← Anterior
                  </button>
                  <button
                    className="btn-ghost !px-2 !py-1 !text-xs"
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={currentPage >= totalPages}
                  >
                    Próxima →
                  </button>
                </div>
              </div>
            )}
          </>
        );
      })()}


      {confirmAlvo && (
        <div className="fixed inset-0 bg-black/50 grid place-items-center p-2 z-50" onClick={() => setConfirmAlvo(null)}>
          <div className="card p-4 w-full max-w-sm" onClick={(e) => e.stopPropagation()}>
            <h2 className="font-semibold text-sm mb-2">
              {confirmAlvo === "all" ? "Excluir TODAS as chaves cadastradas?" : "Excluir chave?"}
            </h2>
            <div className="flex justify-end gap-2 mt-3">
              <button className="btn-ghost !px-2 !py-1 !text-xs" onClick={() => setConfirmAlvo(null)}>Cancelar</button>
              <button className="btn-primary bg-danger hover:bg-danger/90 !px-2 !py-1 !text-xs" onClick={confirmarExclusao}>Excluir</button>
            </div>
          </div>
        </div>
      )}

      {open && (
        <div key={modalKey} className="fixed inset-0 bg-black/50 grid place-items-center p-2 z-50" onClick={() => setOpen(false)}>
          <div className="card p-0 w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-3 py-2 border-b border-border bg-panel2 shrink-0">
              <h2 className="font-semibold text-sm">Nova chave PIX</h2>
              <button onClick={() => setOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            <div className="p-3 flex-1 min-h-0 flex flex-col overflow-auto">
              <div className="flex items-center gap-2 mb-2">
                <label className="text-xs text-muted whitespace-nowrap">Tipo:</label>
                <select
                  className="input flex-1 !py-1 !text-xs"
                  value={tipo}
                  onChange={(e) => setTipo(e.target.value as PixKey["key_type"])}
                >
                  {TYPES.map((t) => <option key={t.value} value={t.value}>{t.label}</option>)}
                </select>
              </div>
              <label className="label !mb-1">Chaves (uma por linha)</label>
              <textarea
                autoFocus
                placeholder={"Cole aqui as chaves, uma por linha…\nEx:\n11999998888\n11988887777"}
                className="input font-mono w-full resize-none !text-xs flex-1 min-h-[140px]"
                value={bloco}
                onChange={(e) => setBloco(e.target.value)}
              />
              <p className="text-[11px] text-muted mt-1">
                {bloco.split(/\r?\n|,|;/).map((s) => s.trim()).filter(Boolean).length} chave(s) detectada(s)
              </p>
            </div>
            <div className="flex justify-end gap-2 px-3 py-2 border-t border-border bg-panel2 shrink-0">
              <button className="btn-ghost !px-2 !py-1 !text-xs" onClick={() => setOpen(false)}>Cancelar</button>
              <button className="btn-primary !px-2 !py-1 !text-xs" onClick={salvar}>Salvar</button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
