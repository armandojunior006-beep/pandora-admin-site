// ============================================================================
// Device ID (HWID) estável da máquina — mesmo algoritmo já usado pelo canal
// IPC "pandora:device-id" (Pandora Cloud), reaproveitado aqui pra vincular
// a licença ao computador. Se node-machine-id falhar, cai num ID persistido
// em disco (userData/device-id.txt) como fallback.
// ============================================================================
const crypto = require("crypto");
const os = require("os");

async function getDeviceId() {
  try {
    const { machineIdSync } = require("node-machine-id");
    const raw = machineIdSync(true) || "";
    const hash = crypto.createHash("sha256").update("pandora-bot:" + raw).digest("hex");
    return { hash, name: `${os.hostname()} (${process.platform})` };
  } catch (e) {
    // Bug real 2026-08-09 (reportado pelo usuário: "Este token já está em
    // uso em outro dispositivo" toda hora, inclusive deslogando sozinho no
    // meio do uso) — machineIdSync falha dentro do Electron empacotado (por
    // isso o fallback abaixo SEMPRE é usado, não só ocasionalmente), e o
    // arquivo do fallback ficava dentro de userData/ — que MUDA conforme a
    // parte do app rodando (Pandora Bot normal vs Multi Bot launcher vs cada
    // perfil do Multi Bot têm userData PRÓPRIO, ver multibot.cjs). Cada um
    // gerava seu próprio ID aleatório, então o mesmo computador "virava"
    // vários dispositivos diferentes dependendo de qual atalho abria — daí o
    // token ficar "ocupado" o tempo todo, mesmo sendo a MESMA máquina. Agora
    // salva em app.getPath("appData") (a pasta MÃE de userData, ex.:
    // %APPDATA% — a MESMA pasta não importa qual parte do app/perfil rodou),
    // então todo mundo cai no mesmo ID estável.
    const { app } = require("electron");
    const fs = require("fs");
    const path = require("path");
    const f = path.join(app.getPath("appData"), "pandora-bot-device-id.txt");
    let raw = "";
    try { raw = fs.readFileSync(f, "utf8"); } catch {}
    if (!raw) {
      raw = crypto.randomBytes(32).toString("hex");
      try { fs.writeFileSync(f, raw); } catch {}
    }
    const hash = crypto.createHash("sha256").update("pandora-bot:" + raw).digest("hex");
    return { hash, name: `${os.hostname()} (${process.platform})` };
  }
}

module.exports = { getDeviceId };
