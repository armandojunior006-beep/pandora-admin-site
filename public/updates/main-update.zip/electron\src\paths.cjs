// ============================================================================
// Caminhos do projeto — ponto único de verdade para todo caminho que no
// main.cjs original era resolvido com `__dirname` (que apontava para a pasta
// onde main.cjs mora). Como o código agora está espalhado em vários
// arquivos sob src/, cada um teria um __dirname diferente; em vez de
// recalcular "quantos ../ preciso" em cada módulo, todo mundo importa
// ROOT_DIR daqui — que é sempre a pasta que contém main.cjs (a raiz do app),
// exatamente como o antigo __dirname.
// ============================================================================
const path = require("path");

// src/paths.cjs -> sobe um nível para chegar na raiz do app (onde fica main.cjs).
const ROOT_DIR = path.resolve(__dirname, "..");

module.exports = { ROOT_DIR };
