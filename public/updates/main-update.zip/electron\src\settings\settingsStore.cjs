// ============================================================================
// Banco de dados / settings (tabela `settings`) + log do sistema (tabela `logs`)
// ============================================================================
const { app } = require("electron");
const path = require("path");
const fs = require("fs");
const { createDB, saveDB } = require("../../db.cjs");
const state = require("../state.cjs");

async function initDB() {
  const userData = app.getPath("userData");
  if (!fs.existsSync(userData)) fs.mkdirSync(userData, { recursive: true });
  state.dbPath = path.join(userData, "onboarding.sqlite");
  state.db = await createDB(state.dbPath);
}

function getSettingSync(key, fallback = "") {
  try {
    const stmt = state.db.prepare("SELECT value FROM settings WHERE key=?");
    stmt.bind([key]);
    let v = fallback;
    if (stmt.step()) v = stmt.getAsObject().value ?? fallback;
    stmt.free();
    return v;
  } catch { return fallback; }
}

async function setSettingSync(key, value) {
  const stmt = state.db.prepare("INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  stmt.run([key, value]);
  stmt.free();
  await saveDB(state.db, state.dbPath);
  // Sidecar para configs que precisam ser lidas ANTES de app.ready (próximo boot).
  if (key === "gpu_mode") {
    try {
      const f = path.join(app.getPath("userData"), "gpu_mode.txt");
      fs.writeFileSync(f, String(value || "GPU"));
    } catch {}
  }
}

// ============================================================================
// LOG DO SISTEMA (tabela `logs`) — usado pela aba "Início"
// Helper centralizado para gravar eventos visíveis na UI (login/senha/device).
// ============================================================================
function logSystem(message, context, level = "info", source = "sistema") {
  try {
    if (!state.db) return;
    const stmt = state.db.prepare("INSERT INTO logs (level, source, message, context_json) VALUES (?,?,?,?)");
    stmt.run([String(level), String(source), String(message || ""), JSON.stringify(context || {})]);
    stmt.free();
    try { saveDB && saveDB(state.db, state.dbPath).catch(() => {}); } catch {}
    // Notifica a aba Início para recarregar a lista de logs em tempo real.
    try {
      if (state.mainWin && !state.mainWin.isDestroyed()) state.mainWin.webContents.send("logs:updated");
    } catch {}
  } catch (e) {
    try { console.warn("[logSystem] falha:", e?.message || e); } catch {}
  }
}

// Variante de logSystem pra progresso de giro (Auto Slot PG/WG/PP) — pedido
// do usuário 2026-08-08: "giro 65/500" criando uma linha NOVA a cada giro
// inundava o Log de Operações (fica inviável de acompanhar com várias
// telas rodando). Em vez de INSERT sempre, atualiza a MESMA linha (uma por
// `key`, tipicamente tela+slot) — a UI edita o texto no lugar, sem crescer.
// A mensagem final (ex.: "GIROS COMPLETOS") deve usar logSystem() normal
// (INSERT), não essa — faz sentido ficar registrada como um evento à parte.
const progressLogIds = new Map(); // key -> id da linha em `logs`
function logSystemProgress(key, message, context, level = "info", source = "sistema") {
  try {
    if (!state.db) return;
    const existingId = progressLogIds.get(key);
    if (existingId != null) {
      const upd = state.db.prepare("UPDATE logs SET level=?, source=?, message=?, context_json=?, created_at=datetime('now') WHERE id=?");
      upd.run([String(level), String(source), String(message || ""), JSON.stringify(context || {}), existingId]);
      upd.free();
    } else {
      const stmt = state.db.prepare("INSERT INTO logs (level, source, message, context_json) VALUES (?,?,?,?)");
      stmt.run([String(level), String(source), String(message || ""), JSON.stringify(context || {})]);
      stmt.free();
      try {
        const idRow = state.db.exec("SELECT last_insert_rowid() AS id");
        const newId = idRow?.[0]?.values?.[0]?.[0];
        if (newId != null) progressLogIds.set(key, newId);
      } catch {}
    }
    try { saveDB && saveDB(state.db, state.dbPath).catch(() => {}); } catch {}
    try {
      if (state.mainWin && !state.mainWin.isDestroyed()) state.mainWin.webContents.send("logs:updated");
    } catch {}
  } catch (e) {
    try { console.warn("[logSystemProgress] falha:", e?.message || e); } catch {}
  }
}
// Libera a chave quando uma rodada de giros termina (chamar ao logar "GIROS
// COMPLETOS" ou erro definitivo) — sem isso, a PRÓXIMA rodada do mesmo
// tela+slot ficaria "colada" atualizando a linha da rodada ANTERIOR (que já
// devia ter virado histórico) em vez de começar uma linha nova.
function clearProgressLog(key) {
  progressLogIds.delete(key);
}

function describeDevice(profile) {
  if (!profile) return "Desktop padrão";
  const so = profile.os === "ios" ? "iOS" : "Android";
  return `${profile.name} (${so})`;
}

// Exposto globalmente para que módulos auxiliares (captcha-solver.cjs)
// leiam settings/gravem log sem precisar receber db por parâmetro.
global.__pandoraGetSetting = getSettingSync;
global.__pandoraLogSystem = logSystem;

module.exports = {
  initDB,
  getSettingSync,
  setSettingSync,
  logSystem,
  logSystemProgress,
  clearProgressLog,
  describeDevice,
};
