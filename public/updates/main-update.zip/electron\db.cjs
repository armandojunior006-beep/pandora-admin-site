// ============================================================================
// db.cjs — camada de banco de dados (SQLite via sql.js, 100% WASM/JS, sem
// binário nativo para compilar). Usado por src/settings/settingsStore.cjs e
// por todos os handlers que fazem db:query/db:run direto (accounts, logs,
// proxies, pix_keys) e agora também pela tabela `admins` do painel.
//
// API exposta — a mesma que o resto do código já espera (idêntica ao sql.js):
//   const db = await createDB(dbPath);
//   const stmt = db.prepare(sql); stmt.bind(params); stmt.step(); stmt.getAsObject(); stmt.free();
//   db.exec(sql) -> [{ columns, values }]
//   db.getRowsModified() -> number
//   await saveDB(db, dbPath) -> persiste o banco inteiro em disco
// ============================================================================
const fs = require("fs");
const path = require("path");
const initSqlJs = require("sql.js");

let SQLPromise = null;
function loadSqlJs() {
  if (!SQLPromise) {
    SQLPromise = initSqlJs({
      // sql.js precisa localizar o .wasm em runtime — resolve sempre a partir
      // da pasta real do pacote instalado (funciona tanto em dev quanto
      // empacotado, desde que node_modules/sql.js seja copiado no build).
      locateFile: (file) => path.join(path.dirname(require.resolve("sql.js")), file),
    });
  }
  return SQLPromise;
}

// Schema base. Cada CREATE TABLE usa IF NOT EXISTS para não quebrar bancos
// já existentes; colunas novas adicionadas depois de um release (ex.:
// accounts.token) são migradas via ensureColumn logo abaixo.
const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS logs (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  level        TEXT NOT NULL DEFAULT 'info',
  source       TEXT NOT NULL DEFAULT 'sistema',
  message      TEXT NOT NULL DEFAULT '',
  context_json TEXT NOT NULL DEFAULT '{}',
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS accounts (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  label      TEXT,
  username   TEXT,
  password   TEXT,
  token      TEXT,
  notes      TEXT NOT NULL DEFAULT '{}',
  status     TEXT NOT NULL DEFAULT 'ativo',
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS proxies (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  label    TEXT,
  host     TEXT NOT NULL,
  port     INTEGER NOT NULL,
  username TEXT,
  password TEXT,
  protocol TEXT NOT NULL DEFAULT 'http',
  country  TEXT,
  enabled  INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS pix_keys (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  key_value  TEXT NOT NULL,
  key_type   TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Painel administrativo: quem pode abrir o painel de contas. Independente
-- da tabela "accounts" (que são as contas operacionais capturadas pelo bot).
CREATE TABLE IF NOT EXISTS admins (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  token         TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  last_login_at TEXT
);

-- Usado por src/stores/auth.ts (useAuth.login) — tanto pro login local
-- admin/admin quanto pelo bypass "admin"/"admin07982176" chamado logo após
-- confirmar um token na nuvem (Login.tsx onTokenConfirmed), pra liberar a UI
-- do app sem depender de sessão. Em bancos NOVOS (perfis do Multi Bot, por
-- exemplo) essa tabela não existia — SELECT * FROM users lançava "no such
-- table: users", o bypass pós-token falhava silenciosamente, e o app nunca
-- saía da tela de login mesmo com o token confirmado com sucesso no servidor
-- (bug real 2026-08-09). O seed do admin roda em migrate() logo abaixo.
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'operator',
  full_name     TEXT,
  active        INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
`;

// Adiciona colunas novas em bancos criados por versões antigas do app, sem
// perder dados existentes (ALTER TABLE ADD COLUMN é idempotente aqui porque
// ignoramos o erro "duplicate column").
function ensureColumn(db, table, column, definition) {
  try {
    db.run(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  } catch (e) {
    if (!/duplicate column/i.test(e && e.message || "")) throw e;
  }
}

function migrate(db) {
  db.exec(SCHEMA_SQL);
  ensureColumn(db, "accounts", "token", "TEXT");
  // 2026-08-20: Proxies.tsx grava label/country desde sempre, mas o schema
  // original da tabela `proxies` nunca teve essas colunas — INSERT falhava
  // com "no such column" toda vez que o usuário salvava um proxy novo.
  ensureColumn(db, "proxies", "label", "TEXT");
  ensureColumn(db, "proxies", "country", "TEXT");
  // 2026-08-22: o schema de `logs` neste arquivo nunca teve user_id, mas
  // log() (src/lib/api) insere com user_id — bancos criados por este schema
  // quebravam TODA operação que loga (cadastro de chave PIX, proxy, etc.)
  // com "table logs has no column named user_id". Agora migra a coluna.
  ensureColumn(db, "logs", "user_id", "INTEGER");
  ensureUsersSeed(db);
}

// Garante o usuário "admin" (bcrypt de "admin07982176") em qualquer banco,
// novo ou antigo — mesma senha hardcoded que Login.tsx usa no bypass pós-
// confirmação de token. Idempotente: só insere se ainda não existir.
function ensureUsersSeed(db) {
  try {
    const r = db.exec("SELECT COUNT(*) FROM users WHERE username = 'admin'");
    const count = r[0]?.values?.[0]?.[0] ?? 0;
    if (count > 0) return;
    const bcrypt = require("bcryptjs");
    const hash = bcrypt.hashSync("admin07982176", 10);
    db.run(
      "INSERT INTO users (username, password_hash, role, full_name, active) VALUES (?,?,?,?,1)",
      ["admin", hash, "admin", "Administrador"]
    );
  } catch (e) {
    console.warn("[db] falha ao semear usuário admin:", e?.message || e);
  }
}

async function createDB(dbPath) {
  const SQL = await loadSqlJs();
  let db;
  if (dbPath && fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
  }
  migrate(db);
  return db;
}

// saveDB é chamado A CADA log gravado (persistAutoRegisterLog em
// auto-register.cjs chama isso em praticamente toda etapa do cadastro —
// dezenas de vezes por janela). db.export() serializa o banco INTEIRO
// (sql.js é 100% em memória) e fs.writeFileSync grava esse buffer inteiro
// no disco — SÍNCRONO, bloqueando a thread principal — TODA vez. Com várias
// janelas cadastrando ao mesmo tempo, cada uma logando dezenas de linhas,
// isso significava dezenas de serializações+gravações completas do banco
// por segundo, todas na mesma thread que processa CDP/IPC de tudo — a causa
// real da lentidão geral (modal demorando, clique em Registro travando),
// independente de proxy (é 100% CPU/disco local, nada de rede).
// Agora: debounced — várias chamadas próximas no tempo colam numa única
// gravação de verdade, no máximo a cada SAVE_DEBOUNCE_MS.
const SAVE_DEBOUNCE_MS = 1500;
let _saveTimer = null;
let _savePending = null;
let _pendingDb = null;
let _pendingPath = null;

function flushSaveDB() {
  if (_saveTimer) { clearTimeout(_saveTimer); _saveTimer = null; }
  if (!_pendingDb || !_pendingPath) return;
  try {
    const data = _pendingDb.export();
    fs.writeFileSync(_pendingPath, Buffer.from(data));
  } catch (e) { console.warn("[db] flushSaveDB falhou:", e?.message); }
  _pendingDb = null;
  _pendingPath = null;
  _savePending = null;
}

async function saveDB(db, dbPath) {
  if (!db || !dbPath) return;
  _pendingDb = db;
  _pendingPath = dbPath;
  if (_savePending) return _savePending; // já tem uma gravação agendada — essa chamada "pega carona"
  _savePending = new Promise((resolve) => {
    _saveTimer = setTimeout(() => {
      try {
        const data = _pendingDb.export();
        fs.writeFileSync(_pendingPath, Buffer.from(data));
      } catch (e) { console.warn("[db] saveDB falhou:", e?.message); }
      _pendingDb = null;
      _pendingPath = null;
      _saveTimer = null;
      _savePending = null;
      resolve();
    }, SAVE_DEBOUNCE_MS);
  });
  return _savePending;
}

module.exports = { createDB, saveDB, flushSaveDB };
