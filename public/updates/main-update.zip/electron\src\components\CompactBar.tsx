import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { Home, BarChart3, Archive, RotateCw, Download, KeyRound, Search, Copy, Eye, Wifi } from "lucide-react";
import { getSetting, setSetting, log } from "@/lib/api";
import { useAuth } from "@/stores/auth";
import { useUI } from "@/stores/ui";
import { clicarRelatorioDeApostas } from "@/pages/reportButtonAction";
import { clicarPaginaDeBaus } from "@/pages/bausButtonAction";

// Ribbon do modo compacto — reutiliza os MESMOS window.api.* e settings op_*
// da aba Operação (nenhuma lógica de automação nova). Primeira versão:
// Navegação + Depósito + Chaves PIX. Demais controles entram depois.
const TIPOS_PIX = ["Selecione o tipo de chave", "CPF", "CNPJ", "Email", "Telefone", "Aleatória (EVP)"];

function Sec({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col rounded-md border border-border overflow-hidden bg-panel2/40 min-w-0">
      <div className="bg-black text-white text-[10px] font-semibold text-center py-0.5 border-b border-border">{title}</div>
      <div className="p-1.5 flex flex-col gap-1 flex-1 justify-center">{children}</div>
    </div>
  );
}

const btn = "flex items-center justify-center gap-1 py-1 px-2 rounded text-[11px] font-semibold whitespace-nowrap leading-none";

export function CompactBar() {
  const { user } = useAuth();
  const { showToast } = useUI();
  const [dep1, setDep1] = useState("10");
  const [dep2, setDep2] = useState("30");
  const [tipo, setTipo] = useState(TIPOS_PIX[0]);
  const [espelho, setEspelho] = useState(false);
  const [exibir, setExibir] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [proxyBlocked, setProxyBlocked] = useState(false);
  const [janelas, setJanelas] = useState("");
  const [slot, setSlot] = useState("");

  useEffect(() => {
    (async () => {
      setDep1(await getSetting("op_dep_1", "10"));
      setDep2(await getSetting("op_dep_2", "30"));
      setTipo(await getSetting("op_pix_tipo", TIPOS_PIX[0]));
      setEspelho((await getSetting("op_modo_espelho", "0")) === "1");
      setExibir((await getSetting("op_exibir_dados", "0")) === "1");
      setSpeed(parseInt(await getSetting("op_speed", "1")) || 1);
      setProxyBlocked((await getSetting("op_bloquear_proxy", "0")) === "1");
      setJanelas(await getSetting("op_janelas", ""));
      setSlot(await getSetting("op_slot", ""));
    })();
  }, []);

  const api = () => (window as any).api;
  const act = (src: string, msg: string) => { log("info", "operacao", `[${src}] ${msg}`, null, user?.id).catch(() => {}); };

  // Ajusta a largura da janela ao conteúdo real do ribbon (sem espaço preto
  // sobrando). Mede depois do render e reporta ao main (win:setCompact width).
  const rowRef = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const measure = () => {
      const el = rowRef.current;
      if (!el) return;
      // Largura CSS do conteúdo + padding lateral do container (px-1 = 8px).
      // O main converte pra DIP usando o zoom real da janela (getZoomFactor),
      // por isso mando a largura CSS crua aqui.
      const wCss = Math.ceil(el.getBoundingClientRect().width) + 8;
      try { api()?.winSetCompact?.(true, wCss); } catch {}
    };
    measure();
    // remede quando os rótulos mudam (ex.: Proxy on/off muda a largura)
    const t = setTimeout(measure, 150);
    return () => clearTimeout(t);
  }, [proxyBlocked, espelho, exibir, tipo]);

  // Toggles reutilizam os MESMOS window.api.* da aba Operação.
  async function toggleEspelho() {
    const next = !espelho; setEspelho(next); await setSetting("op_modo_espelho", next ? "1" : "0");
    try { const r = await api()?.setChromiumMirrorEnabled?.(next); act("Espelho", r?.enabled ? `ATIVADO (mestre #${r.master || "?"})` : "DESATIVADO"); } catch (e: any) { showToast(`Espelho: ${e?.message || e}`, "error"); }
  }
  async function toggleExibir() {
    const next = !exibir; setExibir(next); await setSetting("op_exibir_dados", next ? "1" : "0");
    try { await api()?.setAccountOverlay?.({ enabled: next }); } catch {}
    act("Exibir Dados", next ? "ATIVADO" : "DESATIVADO");
  }
  async function onSpeed(v: number) {
    setSpeed(v); try { api()?.setChromiumSpeedMultiplier?.(v); } catch {} await setSetting("op_speed", String(v));
  }
  async function toggleProxy() {
    const nextBlocked = !proxyBlocked; const enableProxy = !nextBlocked;
    setProxyBlocked(nextBlocked); await setSetting("op_bloquear_proxy", nextBlocked ? "1" : "0");
    try { const r = await api()?.setChromiumProxyEnabled?.(enableProxy); const n = r?.affected ?? 0; act("Proxy", enableProxy ? `ATIVADA em ${n} tela(s)` : `DESATIVADA em ${n} tela(s)`); } catch (e: any) { showToast(`Proxy: ${e?.message || e}`, "error"); }
  }
  function onJanelas(v: string) {
    setJanelas(v); try { api()?.refreshChromiumSelection?.(v); } catch {} setSetting("op_janelas", v).catch(() => {});
  }
  async function buscarSlot() {
    const name = (slot || "").trim(); if (!name) { showToast("Digite o nome do slot", "error"); return; }
    await setSetting("op_slot", name);
    try { const cardIndex = /^lucky dog$/i.test(name) ? 1 : 0; const n = await api()?.searchSlotChromium?.(name, cardIndex); act("Slot", `Buscar "${name}" → ${n || 0} tela(s)`); showToast(`Slot "${name}" → ${n || 0} tela(s)`, "success"); } catch (e: any) { showToast(`Slot: ${e?.message || e}`, "error"); }
  }

  async function depositar() {
    try {
      const toNum = (v: string, f: number) => { const n = parseFloat(String(v || "").replace(",", ".")); return Number.isFinite(n) && n > 0 ? n : f; };
      const minN = toNum(dep1, 10), maxN = toNum(dep2, 30);
      const lo = Math.min(minN, maxN), hi = Math.max(minN, maxN);
      await setSetting("op_dep_1", String(minN)); await setSetting("op_dep_2", String(maxN));
      const n = await api()?.depositarChromium?.({ min: lo, max: hi });
      act("Depósito", `faixa ${lo}-${hi} → ${n || 0} tela(s)`); showToast(`Depositar → ${n || 0} tela(s)`, "success");
    } catch (e: any) { showToast(`Depósito: ${e?.message || e}`, "error"); }
  }

  return (
    <div className="h-full w-full bg-black/95 px-1 py-1.5 overflow-x-auto">
      <div ref={rowRef} className="flex items-stretch gap-1.5 h-full min-w-max w-max">
        <Sec title="Navegação">
          <div className="grid grid-cols-2 gap-1">
            <button className={`${btn} btn-ghost border border-border`} onClick={async () => { try { const n = await api()?.navigateChromium?.("/"); act("Navegação", `Início → ${n || 0}`); } catch (e: any) { showToast(String(e), "error"); } }}><Home className="w-3 h-3" /> Início</button>
            <button className={`${btn} btn-ghost border border-border`} onClick={async () => { try { const r = await clicarRelatorioDeApostas(); act("Navegação", `Relatório → ${r.length}`); } catch (e: any) { showToast(String(e), "error"); } }}><BarChart3 className="w-3 h-3" /> Relatório</button>
            <button className={`${btn} btn-ghost border border-border`} onClick={async () => { try { const n = await clicarPaginaDeBaus(); act("Navegação", `Baús → ${n}`); } catch (e: any) { showToast(String(e), "error"); } }}><Archive className="w-3 h-3" /> Baús</button>
            <button className={`${btn} btn-ghost border border-border`} onClick={async () => { try { const n = await api()?.reloadChromium?.(); act("Navegação", `Atualizar → ${n || 0}`); } catch (e: any) { showToast(String(e), "error"); } }}><RotateCw className="w-3 h-3" /> Atualizar</button>
          </div>
        </Sec>

        <Sec title="Depósito">
          <div className="grid grid-cols-2 gap-1">
            <input className="input !py-0.5 !text-[11px] text-center !w-14" value={dep1} onChange={(e) => setDep1(e.target.value)} onBlur={() => setSetting("op_dep_1", dep1)} />
            <input className="input !py-0.5 !text-[11px] text-center !w-14" value={dep2} onChange={(e) => setDep2(e.target.value)} onBlur={() => setSetting("op_dep_2", dep2)} />
          </div>
          <button className={`${btn} bg-success text-black hover:bg-success/90`} onClick={depositar}><Download className="w-3 h-3" /> Depositar</button>
        </Sec>

        <Sec title="Chaves PIX">
          <select className="input !py-0.5 !text-[11px]" value={tipo} onChange={(e) => { setTipo(e.target.value); setSetting("op_pix_tipo", e.target.value); }}>
            {TIPOS_PIX.map((t) => <option key={t}>{t}</option>)}
          </select>
          <button className={`${btn} bg-warning text-black hover:bg-warning/90`} onClick={async () => { const r = await api()?.cadastrarPixV2?.(); showToast(`Chaves PIX → ${r?.sucesso || 0}/${r?.windows || 0}`, "success"); act("PIX", `Cadastrar → ${r?.sucesso || 0}/${r?.windows || 0}`); }}>Cadastrar Chaves PIX</button>
          <button className={`${btn} bg-success text-black hover:bg-success/90`} onClick={async () => { const r = await api()?.sacarV2?.(); showToast(`Sacar → ${r?.sucesso || 0}/${r?.windows || 0}`, "success"); act("Saque", `Sacar → ${r?.sucesso || 0}/${r?.windows || 0}`); }}><KeyRound className="w-3 h-3" /> Sacar</button>
        </Sec>

        <Sec title="Ferramentas">
          <div className="grid grid-cols-2 gap-1">
            <button onClick={toggleEspelho} className={`${btn} border ${espelho ? "bg-warning text-black border-warning" : "btn-ghost border-border"}`}><Copy className="w-3 h-3" /> Espelho</button>
            <button onClick={toggleExibir} className={`${btn} border ${exibir ? "bg-warning text-black border-warning" : "btn-ghost border-border"}`}><Eye className="w-3 h-3" /> Dados</button>
          </div>
          <button onClick={toggleProxy} className={`${btn} border ${proxyBlocked ? "btn-ghost border-border text-danger" : "bg-success text-black border-success"}`}><Wifi className="w-3 h-3" /> {proxyBlocked ? "Ativar Proxy" : "Desativar Proxy"}</button>
          <div className="grid grid-cols-5 gap-0.5">
            {[1, 2, 4, 8, 12].map((v) => (
              <button key={v} onClick={() => onSpeed(v)}
                className={"py-0.5 text-[10px] rounded border transition " + (speed === v ? "bg-success text-white border-success font-bold" : "bg-transparent border-success/40 text-success hover:bg-success/10")}>
                {v}x
              </button>
            ))}
          </div>
        </Sec>

        <Sec title="Controles">
          <div>
            <label className="text-[9px] uppercase tracking-wider text-success block mb-0.5">Janelas p/ controlar</label>
            <input className="input !py-0.5 !text-[11px] text-center" value={janelas} onChange={(e) => onJanelas(e.target.value)} placeholder="Ex: 1, 2-4 ou 1,3" />
          </div>
          <div>
            <label className="text-[9px] uppercase tracking-wider text-success block mb-0.5">Slot para buscar</label>
            <div className="flex gap-1">
              <input className="input flex-1 !py-0.5 !text-[11px]" value={slot} onChange={(e) => setSlot(e.target.value)} onBlur={() => setSetting("op_slot", slot)} placeholder="mayan destiny" />
              <button onClick={buscarSlot} className={`${btn} btn-ghost border border-border`}><Search className="w-3 h-3" /></button>
            </div>
          </div>
        </Sec>
      </div>
    </div>
  );
}
