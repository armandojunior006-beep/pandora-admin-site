// ============================================================================
// IPC: chrome:report — botão "Relatório de Apostas" (aba Operação). Arquivo
// PRÓPRIO, separado de navigateHandler.cjs (regra do usuário 2026-08-09: cada
// botão/ação nova entra em arquivo dedicado — ver [[pandorabot-one-file-per-feature]]).
//
// Navega cada janela selecionada pra "<origin da própria janela>
// /home/report?reportCurrent=1" — nunca URL absoluta fixa, funciona em
// qualquer domínio-espelho aberto.
//
// CAUSA RAIZ REAL do bug "tela em branco / aba errada" (resolvida 2026-08-09,
// depois de uma investigação enorme — motor Chrome real vs Electron, stealth,
// proxy, popup closer, técnica de clique, timing, etc., nenhum disso era a
// causa): src/injections/pixModalEnhancer.cjs (o "maximizador de QR do PIX")
// rodava SEM NENHUMA restrição de URL em toda janela — se confundisse algum
// ícone quadrado da tela de Relatório com um QR code, forçava
// `display:flex` + reordenação de elementos com `!important` no container,
// destruindo o layout de uma tela que não tinha nada a ver com PIX. Corrigido
// lá (agora exige a palavra "pix" na página antes de agir). Este arquivo
// nunca teve o bug — é só o consumidor que sofria o efeito colateral.
// ============================================================================
const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");

const REPORT_PATH = "/home/report?reportCurrent=1";

// Bug real 2026-08-09 (mesmo padrão achado no bausHandler.cjs, print do
// usuário: janela "presa" num domínio de CDN em vez do site real) — origin
// só era validado por ser http(s), sem checar se batia com o padrão real
// dos grupos do site (91-/a8-/dz-/we-/w1-/voy- + "pg.com" — ver
// [[pandorabot-domain-groups]]). Agora exige esse padrão.
//
// BUG real 2026-08-10 (reportado pelo usuário no perfil FILHAS do Multi
// Bot: clicou em "Relatório de Apostas" com 4 telas selecionadas, só foi
// numa — as outras 3 usavam domínios "antiquepg.com"/"droughtpg.com"/
// "chimneypg.com", sem NENHUM prefixo de grupo, e o regex exigia o
// prefixo obrigatoriamente) — nem todo domínio-espelho válido tem prefixo
// de grupo (91-/a8-/etc.); alguns são só "<nome>pg.com" direto. Prefixo
// agora é OPCIONAL — continua rejeitando hosts de CDN (não terminam em
// "pg<tld>" de forma alguma), só não exige mais o prefixo específico.
//
// BUG real 2026-08-19 (reportado pelo usuário: "Relatório de Apostas" não
// ia pra lugar nenhum no versopg.vip) — o regex exigia TLD ".com" fixo
// (`pg\.com$`); "versopg.vip" termina em ".vip", então caía em "sem origin
// conhecida" e o loadURL nem era chamado. TLD agora aceita .com OU .vip.
const DOMAIN_GROUP_RE = /^(?:www\.)?(?:(?:91|a8|dz|we|w1|voy)-)?[a-z0-9]+pg\.(?:com|vip)$/i;
// Pedido do usuário 2026-08-19: novo grupo de casas "OKOK" (nome sempre
// contém "okok", ex.: okok.net) — padrão de domínio bem diferente do
// "<algo>pg.com/.vip" (nem termina em "pg", nem TLD conhecido). Aceita
// qualquer host que contenha "okok", igual o resto aceita "pg" antes do TLD.
const OKOK_GROUP_RE = /okok/i;
// Pedido do usuário 2026-08-20: novo grupo "888" (821win.win) — domínio
// único confirmado, sem padrão de mirror informado ainda (diferente de OKOK,
// que usa substring solta porque o usuário confirmou vários mirrors
// "okok*"). Match exato até vir confirmação de outros domínios do grupo.
const GRUPO_888_RE = /^(?:www\.)?821win\.win$/i;
// Pedido do usuário 2026-08-22: novo grupo "5gbet" (5gbet.com) — match exato
// até vir confirmação de mirrors (mesmo critério do 888).
const GRUPO_5GBET_RE = /^(?:www\.)?5gbet\.com$/i;
function isKnownGameOrigin(originStr) {
  try {
    const host = new URL(originStr).hostname;
    return DOMAIN_GROUP_RE.test(host) || OKOK_GROUP_RE.test(host) || GRUPO_888_RE.test(host) || GRUPO_5GBET_RE.test(host);
  } catch { return false; }
}

function registerReportHandler(ipcMain) {
  ipcMain.handle("chrome:report", () => {
    const diagLine = (msg) => {
      try {
        const { queueDiagLine } = require("../../auto-register.cjs");
        if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [chrome:report] ${msg}\r\n`);
      } catch {}
    };
    let n = 0;
    let idx = 0;
    for (const win of getSelectedChromeWins()) {
      idx++;
      const telaNum = idx;
      try {
        if (!win || win.isDestroyed() || win._proxyReady === false) continue;
        // Bug corrigido em 2026-08-09: origin de uma página de erro do
        // Chrome (chrome-error://chromewebdata/) NÃO lança e NÃO fica
        // vazio — devolve a string literal "null", que gera um destino
        // inválido ("null/home/report..."). Exige http(s) explicitamente.
        let origin = "";
        let originFonte = "";
        try {
          const o = new URL(win.webContents.getURL()).origin;
          if (isKnownGameOrigin(o)) { origin = o; originFonte = "getURL"; }
        } catch {}
        if (!origin) {
          try {
            const o = new URL(win._targetUrl || "").origin;
            if (isKnownGameOrigin(o)) { origin = o; originFonte = "_targetUrl"; }
          } catch {}
        }
        if (!origin) {
          diagLine(`tela #${telaNum} pulada — sem origin conhecida (getURL="${(() => { try { return win.webContents.getURL(); } catch { return "?"; } })()}", _targetUrl="${win._targetUrl || ""}")`);
          continue;
        }
        if (originFonte === "_targetUrl") {
          diagLine(`tela #${telaNum} getURL() não batia com domínio conhecido — usando _targetUrl (${origin}) em vez disso`);
        }
        const dest = origin + REPORT_PATH;
        Promise.resolve(win.loadURL(dest)).then((ok) => {
          diagLine(`tela #${telaNum} -> ${dest} : ${ok === false ? "FALHOU" : "ok"}`);
        }).catch((e) => {
          diagLine(`tela #${telaNum} -> ${dest} : erro inesperado no loadURL: ${e?.message || e}`);
        });
        n++;
      } catch {}
    }
    return n;
  });
}

module.exports = { registerReportHandler };
