// ============================================================================
// IPC: chrome:baus — botão "Página de Baús" (aba Operação). Arquivo PRÓPRIO,
// separado de navigateHandler.cjs (regra do usuário 2026-08-09: cada botão/
// ação nova entra em arquivo dedicado — ver [[pandorabot-one-file-per-feature]]).
//
// ZERADO E RECONSTRUÍDO DO ZERO 2026-08-10 (pedido explícito do usuário) —
// a versão anterior navegava direto por URL pra
// "/home/event/detail?current=1&template=15&eventId=786", e sofria de uma
// corrida de navegação (duas chamadas de loadURL numa mesma janela podiam
// terminar fora de ordem, deixando a tela de volta na Home) — corrigida na
// raiz em webContentsShim.cjs, mas o usuário pediu pra reconstruir esse
// botão de um jeito que nem dependa de loadURL nenhum: em vez de montar uma
// URL, agora clica na sequência real que um usuário faria no site —
//   1) clica em "Ofertas" (item da barra de navegação inferior do site)
//   2) clica no 2º banner da lista ("ATIVIDADES DA PLATAFORMA" — imagem
//      com classe "lobby-image"/"_one-pic_", confirmado pelo usuário)
// Tudo via clique real (DOM events) dentro da PRÓPRIA página atual — sem
// nenhuma navegação por URL, então a corrida de loadURL nem entra em jogo.
// ============================================================================
const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");

// Pedido do usuário 2026-08-10: "só funciona se eu estiver na Home, pois
// somente lá tem o Ofertas" — o item "Ofertas" da barra de navegação
// inferior só existe na Home do site; em qualquer outra tela (ex.: dentro
// de um slot, no Saque, etc.) o botão não achava nada. Checagem rápida
// ANTES do script principal: se "Ofertas" não estiver visível na tela
// atual, navega pra Home (origin + "/") primeiro — só então injeta o
// script de clicar em Ofertas/banner. Usa win.loadURL normal (a corrida de
// navegação já foi corrigida na raiz em webContentsShim.cjs).
const CHECK_OFERTAS_SCRIPT = `(() => {
  try {
    const visible = (el) => {
      if (!el || !el.isConnected) return false;
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      const s = getComputedStyle(el);
      return s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.05;
    };
    const achou = Array.from(document.querySelectorAll('[role="tab"], [class*="tabbar"] *, nav *, footer *, button, a, span, div'))
      .filter(visible)
      .some((el) => /^ofertas$/i.test((el.textContent || '').trim()));
    return achou;
  } catch (e) { return false; }
})();`;

// Texto-alvo do banner, usado só como preferência (ver findBanners/alvo no
// script) — se não achar esse texto perto de nenhum banner, cai no 2º
// banner da lista por posição (índice 1), do jeito que o usuário descreveu.
const BANNER_TEXT = "ATIVIDADES DA PLATAFORMA";

// Pedido do usuário 2026-08-19 (versopg.vip, banner "PROMOVER PARA GANHAR
// DINHEIRO"): tentativa por texto FALHOU (confirmado pelo usuário — clicava
// no banner errado) porque o print real mostrou que o texto do banner é
// pintado DENTRO da imagem (arte gráfica), não existe como texto no DOM —
// nenhum seletor de texto jamais vai bater nele. O `src` da imagem, por
// outro lado, foi IDÊNTICO nas duas vezes que o usuário mandou o HTML real
// (".../2072503030861660162.avif" e depois "...webp" — mesmo id de asset,
// só mudou o formato de imagem negociado pelo navegador). Casa por esse id.
const BANNER_IMG_ID = "2072503030861660162";

function buildBausScript() {
  const bannerText = JSON.stringify(BANNER_TEXT);
  const bannerImgId = JSON.stringify(BANNER_IMG_ID);
  return `(async () => {
    try {
      if (window.__pandoraBausBusy) return { ok: false, reason: 'já rodando' };
      window.__pandoraBausBusy = true;
      const BANNER_TEXT = ${bannerText};
      const BANNER_IMG_ID = ${bannerImgId};
      const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
      const visible = (el) => {
        if (!el || !el.isConnected) return false;
        const r = el.getBoundingClientRect();
        if (r.width < 2 || r.height < 2) return false;
        const s = getComputedStyle(el);
        return s.display !== 'none' && s.visibility !== 'hidden' && Number(s.opacity || 1) > 0.05;
      };
      const realClick = (el) => {
        if (!el) return;
        try { el.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
        const r = el.getBoundingClientRect();
        const x = r.left + Math.max(2, r.width / 2), y = r.top + Math.max(2, r.height / 2);
        const opts = { bubbles: true, cancelable: true, clientX: x, clientY: y, button: 0, view: window };
        try { el.dispatchEvent(new PointerEvent('pointerover', { ...opts, pointerType: 'mouse', buttons: 0, isPrimary: true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseover', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', { ...opts, pointerType: 'mouse', buttons: 1, isPrimary: true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mousedown', opts)); } catch {}
        try { el.dispatchEvent(new PointerEvent('pointerup', { ...opts, pointerType: 'mouse', buttons: 0, isPrimary: true })); } catch {}
        try { el.dispatchEvent(new MouseEvent('mouseup', opts)); } catch {}
        try { el.dispatchEvent(new MouseEvent('click', opts)); } catch {}
        try { el.click(); } catch {}
      };
      const findOfertas = () => Array.from(document.querySelectorAll('[role="tab"], [class*="tabbar"] *, nav *, footer *, button, a, span, div'))
        .filter(visible)
        .find((el) => /^ofertas$/i.test((el.textContent || '').trim()));

      // 1) clica em "Ofertas" na barra inferior do site.
      let ofertas = null;
      const dl1 = Date.now() + 8000;
      while (Date.now() < dl1) {
        ofertas = findOfertas();
        if (ofertas) break;
        await sleep(200);
      }
      if (!ofertas) { window.__pandoraBausBusy = false; return { ok: false, reason: 'aba "Ofertas" não encontrada em 8s' }; }
      realClick(ofertas);
      await sleep(700);

      // 2) espera os banners aparecerem e escolhe o alvo: primeiro tenta achar
      // um banner cujo texto/alt/title perto bata com "ATIVIDADES DA
      // PLATAFORMA"; se não achar, usa o 2º banner da lista (índice 1).
      const findBanners = () => Array.from(document.querySelectorAll('img.lobby-image, img[class*="_one-pic_"], img[class*="lobby-image"]')).filter(visible);
      let banners = [];
      const dl2 = Date.now() + 8000;
      while (Date.now() < dl2) {
        banners = findBanners();
        if (banners.length >= 2) break;
        await sleep(200);
      }
      if (!banners.length) { window.__pandoraBausBusy = false; return { ok: false, reason: 'nenhum banner encontrado depois de "Ofertas"' }; }
      const acharPorTexto = (texto) => banners.find((el) => {
        let p = el;
        for (let i = 0; i < 5 && p; i++, p = p.parentElement) {
          const t = ((p.innerText || '') + ' ' + (p.getAttribute('alt') || '') + ' ' + (p.getAttribute('title') || '')).toUpperCase();
          if (t.includes(texto)) return true;
        }
        return false;
      });
      // Pedido do usuário 2026-08-19 (versopg.vip, banner "PROMOVER PARA
      // GANHAR DINHEIRO"): casa pelo id do asset da imagem (ver
      // BANNER_IMG_ID acima) — prioridade máxima, é o único sinal estável
      // confirmado nas duas vezes que o usuário mandou o HTML real.
      let alvo = banners.find((el) => (el.getAttribute('src') || '').includes(BANNER_IMG_ID));
      let porImgId = !!alvo;
      if (!alvo) alvo = acharPorTexto(BANNER_TEXT);
      let porTexto = !!alvo;
      if (!alvo) alvo = banners[1] || banners[0];
      const target = alvo.closest('a, button, [role="button"], [onclick], [class*="pic"], [class*="banner"], [class*="lobby-image"]') || alvo;
      realClick(target);
      window.__pandoraBausBusy = false;
      return { ok: true, porImgId, porTexto, totalBanners: banners.length };
    } catch (e) {
      try { window.__pandoraBausBusy = false; } catch {}
      return { ok: false, reason: 'erro: ' + (e && e.message ? e.message : String(e)) };
    }
  })();`;
}

function registerBausHandler(ipcMain) {
  ipcMain.handle("chrome:baus", async () => {
    const diagLine = (msg) => {
      try {
        const { queueDiagLine } = require("../../auto-register.cjs");
        if (typeof queueDiagLine === "function") queueDiagLine(`[${new Date().toISOString()}] [chrome:baus] ${msg}\r\n`);
      } catch {}
    };
    const runOne = async (win, telaNum) => {
      if (!win || win.isDestroyed() || win._proxyReady === false) return false;
      const wc = win.webContents;
      try {
        // Pedido do usuário 2026-08-19: alguns grupos de casas (nome do
        // domínio ou host bate no padrão da chave) não clicam em
        // Ofertas+banner — navegam direto pra URL fixa da página de baús
        // (mesmo padrão já usado antes pro grupo 821win.win). Cada domínio
        // tem seu próprio eventId (configurado no painel admin da casa),
        // por isso a tabela — vai crescendo conforme o usuário confirma
        // cada domínio novo, nunca adivinhar um eventId sem confirmação.
        let origemAtual = "";
        let hostAtual = "";
        try { origemAtual = new URL(wc.getURL()).origin; hostAtual = new URL(wc.getURL()).hostname; } catch {}
        const URL_DIRETA_POR_GRUPO = [
          { grupo: "OKOK", teste: /okok/i, eventId: 241 },
          { grupo: "DY", teste: /quiabopg\.vip$/i, eventId: 953 },
          { grupo: "garrafapg.vip", teste: /garrafapg\.vip$/i, eventId: 967 },
          { grupo: "888", teste: /^(?:www\.)?821win\.win$/i, eventId: 1443 },
        ];
        const grupoDireto = URL_DIRETA_POR_GRUPO.find((g) => g.teste.test(hostAtual) || g.teste.test(origemAtual));
        if (grupoDireto) {
          const destino = origemAtual + `/home/event/detail?current=1&template=15&eventId=${grupoDireto.eventId}`;
          const ok = await wc.loadURL(destino).catch(() => false);
          diagLine(`tela #${telaNum} -> ${destino} (grupo ${grupoDireto.grupo}, URL direta) : ${ok === false ? "FALHOU" : "ok"}`);
          return ok !== false;
        }
        const temOfertas = await wc.executeJavaScript(CHECK_OFERTAS_SCRIPT, true).catch(() => false);
        if (!temOfertas) {
          let origin = "";
          try {
            const o = new URL(wc.getURL()).origin;
            if (/^https?:\/\//i.test(o)) origin = o;
          } catch {}
          if (!origin) { diagLine(`tela #${telaNum} pulada — sem origin http(s) válido pra voltar pra Home`); return false; }
          diagLine(`tela #${telaNum}: "Ofertas" não visível na tela atual — navegando pra Home antes`);
          const ok = await wc.loadURL(origin + "/").catch(() => false);
          if (ok === false) { diagLine(`tela #${telaNum} : navegação pra Home falhou`); return false; }
          await new Promise((r) => setTimeout(r, 1200));
        }
        const res = await wc.executeJavaScript(buildBausScript(), true);
        if (res && res.ok) {
          diagLine(`tela #${telaNum} -> Ofertas > banner${res.porImgId ? " (achado por id da imagem)" : res.porTexto ? " (achado por texto ATIVIDADES DA PLATAFORMA)" : " (2º da lista, " + res.totalBanners + " banners)"} : ok`);
          return true;
        }
        diagLine(`tela #${telaNum} : FALHOU — ${(res && res.reason) || "sem detalhe"}`);
        return false;
      } catch (e) {
        diagLine(`tela #${telaNum} : erro inesperado: ${e?.message || e}`);
        return false;
      }
    };
    const wins = getSelectedChromeWins();
    const results = await Promise.all(wins.map((win, i) => runOne(win, i + 1)));
    return results.filter(Boolean).length;
  });
}

module.exports = { registerBausHandler };
