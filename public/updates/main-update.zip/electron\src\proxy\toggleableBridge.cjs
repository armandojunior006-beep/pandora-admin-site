// ============================================================================
// Bridge de proxy "liga/desliga a quente" pra janelas de Chrome real via CDP.
//
// Problema: Chrome real recebe o proxy como flag de linha de comando
// (--proxy-server) no momento do launch — diferente da janela Electron, não
// dá pra chamar algo tipo session.setProxy() depois pra trocar em tempo real
// (isso exigiria relançar o processo do Chrome, perdendo a aba/estado).
//
// Solução: em vez de apontar --proxy-server DIRETO pro bridge anonimizado do
// proxy-chain (getOrCreateProxyBridge, fixo), cria um servidor proxy LOCAL
// próprio (ProxyChain.Server) cujo prepareRequestFunction decide, a cada
// requisição, se encaminha pro upstream (proxy ligado) ou deixa direto (proxy
// desligado) — o Chrome sempre aponta pra ESSE endereço fixo, então o F8
// (setProxyEnabledForWindows) só precisa virar uma flag em memória, sem
// nunca precisar relançar o Chrome.
// ============================================================================
const http = require("http");
const ProxyChain = require("proxy-chain");
const { buildUpstreamProxyUrl, proxyProtocolCandidates } = require("./proxyManager.cjs");

// Testa se o bridge local consegue abrir um túnel CONNECT de verdade pro
// upstream configurado no momento — é exatamente o passo que falha com
// ERR_TUNNEL_CONNECTION_FAILED no Chrome quando o protocolo "adivinhado"
// (http/socks5) está errado pro provedor. Só confere o handshake do túnel
// (não busca conteúdo nenhum), então é rápido.
function testBridgeTunnel(localUrl, timeoutMs = 6000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = (ok) => { if (!done) { done = true; resolve(ok); } };
    try {
      const u = new URL(localUrl);
      const req = http.request({ host: u.hostname, port: u.port, method: "CONNECT", path: "api.ipify.org:443", timeout: timeoutMs });
      req.on("connect", (res, socket) => { try { socket.destroy(); } catch {} finish(res.statusCode === 200); });
      req.on("timeout", () => { try { req.destroy(); } catch {} finish(false); });
      req.on("error", () => finish(false));
      req.end();
    } catch { finish(false); }
  });
}

async function createToggleableProxyBridge(proxy) {
  let enabled = true;
  let currentUpstream = "";
  const candidates = proxyProtocolCandidates(proxy);
  currentUpstream = buildUpstreamProxyUrl(proxy, candidates[0]);

  const server = new ProxyChain.Server({
    port: 0,
    prepareRequestFunction: () => ({
      upstreamProxyUrl: enabled ? currentUpstream : null,
    }),
  });

  await new Promise((resolve, reject) => {
    server.listen((err) => (err ? reject(err) : resolve()));
  });

  const localUrl = `http://127.0.0.1:${server.port}`;

  // Valida o protocolo ANTES do Chrome sequer abrir — sem isso, um protocolo
  // adivinhado errado (ex.: proxy é HTTP-only mas salvamos como socks5 por
  // padrão) fazia TODA navegação falhar pra sempre com túnel, sem nenhuma
  // tentativa de correção (setProtocol existia mas nunca era chamado).
  for (let i = 0; i < candidates.length; i++) {
    if (i > 0) currentUpstream = buildUpstreamProxyUrl(proxy, candidates[i]);
    const ok = await testBridgeTunnel(localUrl);
    if (ok) {
      if (i > 0) console.log(`[proxy] ${proxy.host}:${proxy.port} — protocolo ${candidates[0]} falhou, usando ${candidates[i]}`);
      break;
    }
    if (i === candidates.length - 1) console.warn(`[proxy] ${proxy.host}:${proxy.port} — nenhum protocolo (${candidates.join(", ")}) abriu túnel; seguindo com ${candidates[0]} mesmo assim`);
  }

  return {
    localUrl,
    isEnabled: () => enabled,
    setEnabled(next) { enabled = !!next; },
    // Se o protocolo preferido falhar (ex.: veio marcado http mas é
    // socks5), permite trocar o upstream sem recriar o servidor inteiro.
    setProtocol(protocol) { currentUpstream = buildUpstreamProxyUrl(proxy, protocol); },
    async close() { try { await server.close(true); } catch {} },
  };
}

module.exports = { createToggleableProxyBridge };
