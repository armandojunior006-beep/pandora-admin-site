// ============================================================================
// IPC: chrome:cadastrarPix — orquestra o cadastro de chave PIX no modal de
// saque: preenche o telefone, seleciona o tipo PHONE, nome/CPF aleatórios e
// confirma. Lida também com o fluxo de senha de segurança quando a rota
// exige (/home/security) antes de abrir o formulário de PIX.
// ============================================================================
const state = require("../state.cjs");
const { saveDB } = require("../../db.cjs");
const { getSettingSync } = require("../settings/settingsStore.cjs");
const { getSelectedChromeWins } = require("../window/chromiumWindows.cjs");
const { getWithdrawPin, scheduleSecurityPinFill, appendSecDiag } = require("../security/securityPin.cjs");

function registerPixHandler(ipcMain) {
  ipcMain.handle("chrome:cadastrarPix", async (_e, urlOrPath, keys, tipo) => {

    const list = Array.isArray(keys) ? keys.filter(Boolean).map(String) : [];
    if (!list.length) return { ok: false, error: "Nenhuma chave disponível" };
    const input = String(urlOrPath || "");
    let pathPart = input;
    try {
      if (/^https?:\/\//i.test(input)) {
        const u = new URL(input);
        pathPart = u.pathname + u.search + u.hash;
      }
    } catch {}
    if (pathPart && !pathPart.startsWith("/")) pathPart = "/" + pathPart;
    const isSecurity = /\/home\/security\b/.test(pathPart) || /[?&]active=5\b/.test(pathPart);

    const nomeRealCfg = "";
    const cpfRealCfg = "";
    const randNome = () => {
      const nomes = ['Lucas','Mariana','Bruno','Camila','Pedro','Ana','Rafael','Juliana','Felipe','Larissa','Gustavo','Beatriz','Thiago','Carolina','Diego','Patricia'];
      const sobr  = ['Silva','Souza','Oliveira','Santos','Pereira','Lima','Costa','Almeida','Rodrigues','Ferreira','Gomes','Martins','Araujo','Ribeiro'];
      return nomes[Math.floor(Math.random()*nomes.length)] + ' ' + sobr[Math.floor(Math.random()*sobr.length)];
    };
    const randCpf = () => { let s=''; for (let i=0;i<11;i++) s+=Math.floor(Math.random()*10); return s; };

    // Script "leve" — só clica em #addAccountClick quando estamos em withdraw active=10.
    // O modal de cadastro é orquestrado nativamente pelo main process via sendInputEvent.
    const fillScript = (chave, tipoChave) => `(() => {
      const VALUE = ${JSON.stringify(String(chave))};
      const TIPO  = ${JSON.stringify(String(tipoChave || ""))};
      if (window.__pandoraPixFillBusy) return;
      window.__pandoraPixFillBusy = true;
      const log = (m) => console.log('__PANDORA_PIX_FILL__', m);
      const sleep = (ms) => new Promise(r => setTimeout(r, ms));
      const visible = (el) => !!(el && el.offsetParent !== null);
      const setNative = (el, val) => {
        const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
        setter.call(el, val);
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      };
      const findInput = () => {
        const inputs = Array.from(document.querySelectorAll('input, textarea')).filter(visible);
        const bad = /(search|busca|cupom|coupon|cpf-cnpj|usuario|user|email-login|senha|password|amount|valor)/i;
        const score = (el) => {
          const id = (el.id || '') + ' ' + (el.name || '') + ' ' + (el.placeholder || '') + ' ' + (el.getAttribute('aria-label') || '');
          if (bad.test(id)) return -1;
          let s = 0;
          if (/pix|chave|key|telefone|phone|celular/i.test(id)) s += 5;
          if (TIPO === 'phone' && /tel/i.test((el.getAttribute('inputmode') || '') + ' ' + (el.type || ''))) s += 3;
          if (el.type === 'text' || el.type === 'tel' || el.type === 'number') s += 1;
          return s;
        };
        let best = null, bestS = 0;
        for (const el of inputs) { const s = score(el); if (s > bestS) { bestS = s; best = el; } }
        return best;
      };
      const findSubmit = () => {
        const btns = Array.from(document.querySelectorAll('button, [role="button"], a')).filter(visible);
        const re = /(confirmar|cadastrar|adicionar|salvar|continuar|próximo|proximo|enviar)/i;
        return btns.find(b => re.test((b.innerText || b.textContent || '').trim()));
      };
      (async () => {
        try {
          const here = new URL(window.location.href);
          const isWithdraw = /\\/home\\/withdraw/i.test(here.pathname) && here.searchParams.get('active') === '10';
          if (isWithdraw) {
            if (window.__pandoraPixAddClicked) { window.__pandoraPixFillBusy = false; return; }
            const dl = Date.now() + 30000;
            let addBtn = null;
            while (Date.now() < dl) {
              addBtn = document.querySelector('#addAccountClick');
              if (addBtn) break;
              await sleep(400);
            }
            if (addBtn) {
              try { addBtn.click(); window.__pandoraPixAddClicked = true; log('clicou #addAccountClick'); } catch (e) {}
            } else {
              log('#addAccountClick não encontrado');
            }
            window.__pandoraPixFillBusy = false;
            return;
          }
        } catch (e) {}

        const deadline = Date.now() + 30000;
        let inp = null;
        while (Date.now() < deadline) {
          inp = findInput();
          if (inp) break;
          await sleep(400);
        }
        if (!inp) { log('input não encontrado'); window.__pandoraPixFillBusy = false; return; }
        try { inp.focus(); } catch (e) {}
        setNative(inp, VALUE);
        await sleep(250);
        if (inp.value !== VALUE) setNative(inp, VALUE);
        log('preencheu: ' + VALUE);
        await sleep(500);
        // Igual ao orchestratePixForm: clica no submit UMA VEZ só. Sem essa
        // trava, cada runFill() reagendado (250ms/4s/12s/25s/40s) reenchia e
        // clicava de novo se a tela não saísse do lugar (ex.: erro "chave já
        // vinculada" sem redirecionar) — era o "fica clicando Confirmar
        // infinitamente" relatado, só que vindo desse fluxo, não do modal.
        if (window.__pandoraPixSubmitClicked) {
          log('submit já clicado antes nesta página — ignorando reenvio');
        } else {
          const btn = findSubmit();
          if (btn) {
            window.__pandoraPixSubmitClicked = true;
            try { btn.click(); log('clicou submit (única vez)'); } catch (e) {}
          }
        }
        const digits = (inp.value || '').replace(/\\D/g, '');
        if (digits.length >= 11 && !window.__pandoraPixRedirected) {
          window.__pandoraPixRedirected = true;
          await sleep(1200);
          try {
            const u = new URL(window.location.href);
            u.searchParams.set('active', '10');
            u.pathname = '/home/withdraw';
            u.searchParams.delete('redirect');
            window.location.href = u.toString();
            log('redirect active=10');
          } catch (e) {}
        }
        window.__pandoraPixFillBusy = false;
      })();
    })();`;

    // Orquestração do modal de cadastro de chave PIX — reescrita do zero usando seletores exatos.
    async function orchestratePixForm(win, chave) {
      try {
        if (!win || win.isDestroyed()) return;
        if (win.__pandoraPixOrchestrating) return;
        // __pandoraPixOrchestrating só evita rodar duas vezes AO MESMO TEMPO —
        // não impede reagendamentos futuros (essa função é chamada de novo em
        // 1.5s/6s/14s, independente do resultado da vez anterior). Sem essa
        // segunda trava, se o modal continuasse visível por qualquer motivo
        // (site demorou a fechar, alguma falha na detecção), cada reagendamento
        // preenchia os campos de novo e clicava em Confirmar de novo — isso é
        // exatamente o "fica clicando em Confirmar várias e várias vezes"
        // relatado, mesmo já clicando só 1x por chamada. Uma vez que clicou de
        // verdade (ver mais abaixo), nenhuma chamada futura clica de novo.
        if (win.__pandoraPixClickDone) {
          try { appendSecDiag("[PIX] já clicou Confirmar antes nessa janela — ignorando chamada agendada"); } catch {}
          return;
        }
        win.__pandoraPixOrchestrating = true;
        const wc = win.webContents;
        const exec = (s) => wc.executeJavaScript(s, true).catch(() => null);
        const sleep = (ms) => new Promise(r => setTimeout(r, ms));
        const nativeClick = (x, y) => {
          // Instrumentação temporária: loga TODO clique real disparado nessa
          // janela (com de onde na call stack veio) — pra provar de vez se é
          // o nosso código clicando mais de uma vez ou se a repetição vista
          // na tela vem de outro lugar (site, popup closer, etc.).
          try {
            const caller = (new Error().stack || "").split("\n")[2] || "";
            appendSecDiag(`[PIX] nativeClick DISPARADO x=${x} y=${y} de: ${caller.trim()}`);
          } catch {}
          try {
            wc.sendInputEvent({ type: 'mouseMove', x, y });
            wc.sendInputEvent({ type: 'mouseDown', x, y, button: 'left', clickCount: 1 });
            wc.sendInputEvent({ type: 'mouseUp', x, y, button: 'left', clickCount: 1 });
          } catch {}
        };
        const tapLikeSpider = async (x, y, label = "tap") => {
          const px = Math.round(x), py = Math.round(y);
          const isMobile = !!(await exec(`(() => ((globalThis.navigator?.maxTouchPoints || 0) > 0) || /Android|iPhone|iPad|Mobile/i.test(globalThis.navigator?.userAgent || ""))()`));
          try { appendSecDiag(`[PIX-SPIDER] tap ${label} mode=${isMobile ? 'touch' : 'mouse'} x=${px} y=${py}`); } catch {}
          if (isMobile && wc.debugger) {
            let attachedHere = false;
            try {
              if (!wc.debugger.isAttached()) { wc.debugger.attach('1.3'); attachedHere = true; }
              await wc.debugger.sendCommand('Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 1 });
              await wc.debugger.sendCommand('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [{ x: px, y: py, radiusX: 2, radiusY: 2, force: 1, id: 1 }] });
              await sleep(70);
              await wc.debugger.sendCommand('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
              if (attachedHere) { try { wc.debugger.detach(); } catch {} }
              return true;
            } catch (e) {
              try { appendSecDiag(`[PIX-SPIDER] touch CDP falhou em ${label}: ${e && e.message ? e.message : String(e)} — fallback mouse`); } catch {}
              if (attachedHere) { try { wc.debugger.detach(); } catch {} }
            }
          }
          nativeClick(px, py);
          return true;
        };
        const phoneDigits = String(chave).replace(/\D/g, '').slice(0, 11);
        const nomeReal = nomeRealCfg || randNome();
        const cpfReal = cpfRealCfg && cpfRealCfg.length === 11 ? cpfRealCfg : randCpf();

        try { appendSecDiag("[PIX] orquestração iniciada (chave=" + phoneDigits + ")"); } catch {}

        // 1) Aguarda modal real — usa input[data-input-name="name"] como marcador
        const dl = Date.now() + 60000;
        let modalReady = false;
        while (Date.now() < dl) {
          if (win.isDestroyed()) { win.__pandoraPixOrchestrating = false; return; }
          modalReady = !!(await exec(`!!document.querySelector('input[data-input-name="name"]')`));
          if (modalReady) break;
          await sleep(200);
        }
        if (!modalReady) {
          try { appendSecDiag("[PIX] timeout aguardando modal (input name não apareceu)"); } catch {}
          win.__pandoraPixOrchestrating = false;
          return;
        }
        try { appendSecDiag("[PIX] modal detectado — aguardando render completo"); } catch {}
        // Espera de segurança após o modal aparecer: dá tempo para a animação
        // do dialog terminar e para o componente ui-select-single montar seus listeners.
        await sleep(900);
        // Aguarda explicitamente o trigger .ui-select-single existir e estar visível dentro do modal
        {
          const triggerDl = Date.now() + 4000;
          while (Date.now() < triggerDl) {
            const ready = !!(await exec(`(() => {
              const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
              const nameInp = document.querySelector('input[data-input-name="name"]');
              if (!nameInp) return false;
              let modal = nameInp.closest('[role="dialog"], .ui-dialog, .ui-modal, [class*="dialog"], [class*="modal"], [class*="popup"]');
              if (!modal) { let p = nameInp.parentElement; for (let i = 0; i < 6 && p; i++) { modal = p; p = p.parentElement; } }
              if (!modal) return false;
              return Array.from(modal.querySelectorAll('.ui-select-single')).some(visible);
            })()`));
            if (ready) break;
            await sleep(200);
          }
        }
        try { appendSecDiag("[PIX] trigger pronto, iniciando seleção"); } catch {}

        // Estratégia Spider BOT: depois que o modal abriu, faz somente:
        // 1) localizar o controle com texto exato CPF/PHONE/EMAIL;
        // 2) clique nativo no centro;
        // 3) aguardar 500ms;
        // 4) localizar a opção PHONE/Telefone visível e clicar por coordenada.
        const selectPhonePixTypeSpider = async () => {
          const diag = (msg) => { try { appendSecDiag("[PIX-SPIDER] " + msg); } catch {} };
          // Bypass forçado: NÃO confiar na leitura cega de texto da página.
          // O usuário pediu para sempre executar o clique completo.
          diag("alreadyPhone bypass=false (forçado pelo usuário)");

          // Orquestração forçada: dispara mouse + touch no trigger,
          // espera 700ms, localiza opção PHONE/Celular/Telefone (texto ou índice),
          // dispara mouse + touch + scrollIntoView no alvo.
          const result = await exec(`(async () => {
            const log = [];
            try {
              const trigger = document.querySelector('.ui-select-single__content') || document.querySelector('.ui-select-single');
              if (!trigger) { return { ok: false, step: 'no-trigger', log }; }
              log.push('trigger=' + (trigger.tagName || '') + '.' + String(trigger.className || '').slice(0,60));

              ['mousedown','click','mouseup'].forEach(evt => {
                try { trigger.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true })); } catch {}
              });
              try { trigger.dispatchEvent(new TouchEvent('touchstart', { bubbles: true })); } catch {}
              try { trigger.dispatchEvent(new TouchEvent('touchend', { bubbles: true })); } catch {}

              await new Promise(r => setTimeout(r, 300));

              let opcoes = Array.from(document.querySelectorAll('.ui-select-single__option, .v-dropdown__item, li, span, div'))
                .filter(el => {
                  const txt = (el.textContent || '').trim().toUpperCase();
                  return txt === 'PHONE' || txt === 'CELULAR' || txt === 'TELEFONE';
                });
              log.push('byText=' + opcoes.length);

              let opcaoAlvo = null;
              if (opcoes.length > 0) {
                opcaoAlvo = opcoes[0];
              } else {
                const todas = Array.from(document.querySelectorAll('.ui-select-single__option, [class*="option"], [class*="item"]'));
                log.push('byIndex=' + todas.length);
                if (todas.length > 1) opcaoAlvo = todas[1];
                else if (todas.length === 1) opcaoAlvo = todas[0];
              }

              if (!opcaoAlvo) { return { ok: false, step: 'no-alvo', log }; }
              log.push('alvo=' + (opcaoAlvo.textContent || '').trim().slice(0, 40));

              try { opcaoAlvo.scrollIntoView({ block: 'center' }); } catch {}
              try { opcaoAlvo.dispatchEvent(new MouseEvent('mousedown', { bubbles: true })); } catch {}
              try { opcaoAlvo.click(); } catch {}
              try { opcaoAlvo.dispatchEvent(new MouseEvent('mouseup', { bubbles: true })); } catch {}
              try { opcaoAlvo.dispatchEvent(new TouchEvent('touchstart', { bubbles: true })); } catch {}
              try { opcaoAlvo.dispatchEvent(new TouchEvent('touchend', { bubbles: true })); } catch {}

              await new Promise(r => setTimeout(r, 200));
              return { ok: true, step: 'clicked', log };
            } catch (e) {
              return { ok: false, step: 'exception', error: String(e && e.message || e), log };
            }
          })()`);
          diag("result=" + JSON.stringify(result || null));
          await sleep(200);
          const stateAfter = await exec(`(() => {
            const body = globalThis.document?.body?.innerText || "";
            const hasName = !!document.querySelector('input[data-input-name="name"]');
            const triggerTxt = Array.from(document.querySelectorAll('.ui-select-single, .v-select, .dropdown-trigger')).map(el => (el.innerText || el.textContent || '').trim()).join(' | ');
            return { modalText: /adicionar\\s+pix/i.test(body), hasName, triggerTxt: triggerTxt.slice(0, 200) };
          })()`);
          diag("after=" + JSON.stringify(stateAfter || null));
          diag("done");
          return !!(result && result.ok);
        };

        const spiderPhoneSelected = await selectPhonePixTypeSpider();
        await sleep(200);

        // 2) Localiza o dropdown DENTRO do modal (irmão/ancestral do input name)
        //    e retorna coordenadas do trigger ui-select-single — APENAS dentro do modal
        //    IGNORA inputs, mensagens de erro, tooltips e menus de contexto.
        const findTriggerRect = async () => await exec(`(() => {
          const visible = (el) => {
            if (!el || el.nodeType !== 1) return false;
            const r = el.getBoundingClientRect();
            const s = getComputedStyle(el);
            return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none';
          };
          const VALID_TXT = /(CPF|CNPJ|EMAIL|EVP|PHONE|Phone|Telefone|Celular|Tipo|Selecione)/i;
          const BAD_TXT = /(Todos os status|status|não está preenchido|preenchido|Colar|erro|inválido|alert)/i;
          const isRealSelectTrigger = (el) => {
            if (!el) return false;
            // Rejeita se for input/textarea ou estiver dentro de mensagem de erro/alerta
            if (el.matches('input, textarea, [role="alert"], .ui-error, .ui-message--error')) return false;
            if (el.closest('[role="alert"], .ui-error, .ui-message--error, .ui-toast, .ui-tooltip, .ui-context-menu')) return false;
            // Rejeita se conter input/textarea visível (campo de texto, não trigger)
            if (Array.from(el.querySelectorAll('input, textarea')).some(i => i.offsetParent !== null)) return false;
            // Deve conter texto válido e NÃO ser mensagem de erro/contexto
            const txt = (el.innerText || el.textContent || '').trim();
            if (BAD_TXT.test(txt)) return false;
            if (!VALID_TXT.test(txt)) return false;
            // Deve parecer um select: ter caret/seta/arrow ou ter aria-expanded/role=listbox
            const hasCaret = !!el.querySelector('[class*="caret"], [class*="arrow"], [class*="chevron"], svg, [class*="icon"]');
            const hasPopup = el.getAttribute('aria-haspopup') === 'listbox' || el.getAttribute('aria-expanded') !== null || el.getAttribute('role') === 'combobox' || el.getAttribute('role') === 'button';
            return hasCaret || hasPopup;
          };
          const nameInp = document.querySelector('input[data-input-name="name"]');
          if (!nameInp) return null;
          // Determina o modal/dialog container (até 6 níveis acima)
          let modal = nameInp.closest('[role="dialog"], .ui-dialog, .ui-modal, [class*="dialog"], [class*="modal"], [class*="popup"]');
          if (!modal) {
            let p = nameInp.parentElement;
            for (let i = 0; i < 6 && p; i++) { modal = p; p = p.parentElement; }
          }
          if (!modal) return null;
          // Procura SOMENTE dentro do modal
          const cands = Array.from(modal.querySelectorAll('.ui-select-single')).filter(visible).filter(isRealSelectTrigger);
          // Prioriza o que tem texto válido e NÃO é "Todos os status"
          let trigger = cands.find(el => {
            const t = (el.innerText || el.textContent || '').trim();
            return VALID_TXT.test(t) && !/(Todos os status|status)/i.test(t);
          });
          if (!trigger && cands.length) trigger = cands[0];
          if (!trigger) return null;
          try { trigger.scrollIntoView({ block: 'center' }); } catch {}
          const r = trigger.getBoundingClientRect();
          // Marca o elemento pra cliques JS subsequentes
          trigger.setAttribute('data-pandora-trigger', '1');
          return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2), txt: (trigger.innerText||trigger.textContent||'').trim().slice(0,40) };
        })()`);

        // 3) Verifica se PHONE já está selecionado no trigger (mesmo escopo: dentro do modal)
        const isPhoneSelected = async () => !!(await exec(`(() => {
          const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none'; };
          const BAD_TXT = /(Todos os status|status|não está preenchido|preenchido|Colar|erro|inválido|alert)/i;
          const isRealSelect = (el) => {
            if (!el) return false;
            if (el.matches('input, textarea, [role="alert"], .ui-error, .ui-message--error')) return false;
            if (el.closest('[role="alert"], .ui-error, .ui-message--error, .ui-toast, .ui-tooltip, .ui-context-menu')) return false;
            if (Array.from(el.querySelectorAll('input, textarea')).some(i => i.offsetParent !== null)) return false;
            const txt = (el.innerText || el.textContent || '').trim();
            if (BAD_TXT.test(txt)) return false;
            return true;
          };
          const nameInp = document.querySelector('input[data-input-name="name"]');
          if (!nameInp) return false;
          let modal = nameInp.closest('[role="dialog"], .ui-dialog, .ui-modal, [class*="dialog"], [class*="modal"], [class*="popup"]');
          if (!modal) { let p = nameInp.parentElement; for (let i = 0; i < 6 && p; i++) { modal = p; p = p.parentElement; } }
          if (!modal) return false;
          const cands = Array.from(modal.querySelectorAll('.ui-select-single')).filter(visible).filter(isRealSelect);
          return cands.some(el => /\\b(PHONE|Phone|Telefone|Celular|Mobile)\\b/i.test((el.innerText||el.textContent||'').trim()));
        })()`));

        // Clique JS direto no trigger (sem coordenadas) — abre o dropdown via dispatch + .click()
        // Reforçado: dispara eventos na ordem exata do navegador, clica no wrapper e no inner,
        // e tenta focar o modal antes para evitar fechamento por perda de foco.
        const clickTriggerJS = async () => !!(await exec(`(() => {
          const t = document.querySelector('[data-pandora-trigger="1"]');
          if (!t) return false;
          // Foca o input name para garantir que o modal esteja ativo e não perca foco
          try {
            const nameInp = document.querySelector('input[data-input-name="name"]');
            if (nameInp && nameInp.focus) nameInp.focus();
          } catch {}
          // Tenta clicar tanto no wrapper quanto no inner clickable
          const inner = t.querySelector('.ui-select-single__inner, .ui-select-single__content, [class*="inner"], [class*="content"], input, .ui-select-single__caret, [class*="caret"], [class*="arrow"], svg') || t;
          const r = (inner === t ? t : inner).getBoundingClientRect();
          const tR = t.getBoundingClientRect();
          // Centro do inner/elemento clicável, limitado à área do trigger
          const cx = Math.round(Math.max(tR.left + 2, Math.min(tR.right - 2, r.left + r.width/2)));
          const cy = Math.round(Math.max(tR.top + 2, Math.min(tR.bottom - 2, r.top + r.height/2)));
          const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, button: 0, pointerType: 'mouse', isPrimary: true };
          for (const target of [inner, t]) {
            for (const ev of ['pointerover','pointerenter','mouseover','mouseenter','pointerdown','mousedown','focus','pointerup','mouseup','click']) {
              try {
                if (ev === 'focus') { target.focus && target.focus(); continue; }
                const Ev = ev.startsWith('pointer') && window.PointerEvent ? PointerEvent : MouseEvent;
                target.dispatchEvent(new Ev(ev, opts));
              } catch {}
            }
            try { target.click(); } catch {}
          }
          return true;
        })()`));

        // 4) Localiza coords do option PHONE — escopo GLOBAL (Vue/Element teleporta o menu pro body)
        //    Aceita variações: PHONE, Phone, Telefone, Celular, Mobile
        const PHONE_RX = "/(\\\\bPHONE\\\\b|\\\\bPhone\\\\b|Telefone|Celular|\\\\bMobile\\\\b)/i";
        const OPTION_SEL = "'.ui-options__option, .ui-select-dropdown__item, .ui-select__item, .ui-select-single__option, [role=\"option\"], li.ui-option, li[class*=\"option\"], .ui-popup__content > *, .ui-overlay__content > *'";
        const FLOATING_SEL = "'body > .ui-select-single__dropdown, body > .ui-select-dropdown, body > .ui-popup, body > .ui-popover, body > .ui-overlay, body > ul, body > div[class*=\"dropdown\"], body > div[class*=\"popup\"], body > div[class*=\"popover\"], body > div[class*=\"overlay\"]'";
        // Código que deve ser injetado DENTRO de cada IIFE executada na página (escopo isolado do executeJavaScript)
        const OPTION_FILTER_SRC = `const BAD_OPTION_TXT = /(Colar|não está preenchido|preenchido|erro|inválido|alert|mensagem)/i;
const optionText = (el) => ((el && (el.innerText || el.textContent)) || '').trim();
const isOptionLike = (el) => {
  if (!el || el.nodeType !== 1) return false;
  if (typeof el.matches === 'function' && el.matches('input, textarea, [role="alert"], .ui-error, .ui-message--error')) return false;
  if (typeof el.closest === 'function' && el.closest('[role="alert"], .ui-error, .ui-message--error, .ui-toast, .ui-tooltip, .ui-context-menu')) return false;
  const txt = optionText(el);
  if (BAD_OPTION_TXT.test(txt)) return false;
  return true;
};
const collectOpenOptions = (visible, optionSel, floatingSel) => {
  const containers = Array.from(document.querySelectorAll(floatingSel)).filter(visible).filter((c) => {
    if (!c || !c.querySelector) return false;
    if (c.querySelector('input[data-input-name="name"]')) return false;
    const txt = optionText(c);
    return txt && /(CPF|CNPJ|EMAIL|EVP|PHONE|Telefone|Celular|Mobile|Selecione)/i.test(txt) && !BAD_OPTION_TXT.test(txt);
  });
  let rows = [];
  for (const container of containers) {
    let found = Array.from(container.querySelectorAll(optionSel)).filter(visible).filter(isOptionLike);
    if (!found.length) found = Array.from(container.children || []).filter(visible).filter(isOptionLike);
    found = found.filter((el) => {
      const txt = optionText(el);
      return txt.length > 0 && txt.length < 80 && /(CPF|CNPJ|EMAIL|EVP|PHONE|Telefone|Celular|Mobile|Selecione)/i.test(txt);
    });
    rows = rows.concat(found);
  }
  rows = rows.filter((el) => !rows.some((other) => other !== el && other.contains && other.contains(el) && optionText(other) === optionText(el)));
  const seen = new Set();
  return rows.filter((el) => {
    const r = el.getBoundingClientRect();
    const key = [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height), optionText(el)].join('|');
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
};`;
        // Busca ampla: qualquer elemento flutuante/teleportado visível com texto de PHONE
        const findPhoneOptionRect = async () => await exec(`(() => {
          ${OPTION_FILTER_SRC}
          const visible = (el) => {
            if (!el || el.nodeType !== 1) return false;
            const r = el.getBoundingClientRect();
            const s = getComputedStyle(el);
            return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0';
          };
          const rx = ${PHONE_RX};
          // Busca SOMENTE no dropdown/popover flutuante teleportado para o body.
          const all = collectOpenOptions(visible, ${OPTION_SEL}, ${FLOATING_SEL});
          const p = all.find(o => rx.test((o.innerText || o.textContent || '').trim()));
          // Fallback cirúrgico: se o texto PHONE não apareceu, clica na segunda linha aberta.
          const chosen = p || (all.length > 1 ? all[1] : null);
          if (!chosen) return null;
          try { chosen.scrollIntoView({ block: 'center' }); } catch {}
          const r = chosen.getBoundingClientRect();
          return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2), txt: (chosen.innerText||chosen.textContent||'').trim().slice(0,40), byIndex: !p, index: p ? all.indexOf(p) : 1, count: all.length };
        })()`);

        // Diagnóstico: lista os textos das opções visíveis quando não encontramos PHONE
        const dumpVisibleOptions = async () => await exec(`(() => {
          ${OPTION_FILTER_SRC}
          const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0'; };
          const all = collectOpenOptions(visible, ${OPTION_SEL}, ${FLOATING_SEL});
          return all.slice(0, 20).map(o => (o.innerText || o.textContent || '').trim().slice(0, 60));
        })()`);

        // Verifica se o dropdown realmente abriu (options visíveis > 0)
        const isDropdownOpen = async () => !!(await exec(`(() => {
          ${OPTION_FILTER_SRC}
          const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0'; };
          const all = collectOpenOptions(visible, ${OPTION_SEL}, ${FLOATING_SEL});
          return all.length > 0;
        })()`));

        const clickOpenOptionByIndex = async (idx) => !!(await exec(`(() => {
          ${OPTION_FILTER_SRC}
          const visible = (el) => { if (!el || el.nodeType !== 1) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0'; };
          const all = collectOpenOptions(visible, ${OPTION_SEL}, ${FLOATING_SEL});
          const target = all[Math.max(0, Math.min(Number('__PANDORA_IDX__') || 0, all.length - 1))];
          if (!target) return false;
          try { target.scrollIntoView({ block: 'center', inline: 'center' }); } catch {}
          const r = target.getBoundingClientRect();
          const cx = r.left + r.width/2, cy = r.top + r.height/2;
          const opts = { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy, button: 0, buttons: 1, pointerType: 'mouse', isPrimary: true };
          const chain = [target];
          try { if (target.parentElement) chain.push(target.parentElement); } catch {}
          for (const el of chain) {
            for (const ev of ['pointerover','pointerenter','mouseover','mouseenter','pointerdown','mousedown','pointerup','mouseup','click']) {
              try {
                const Ev = ev.startsWith('pointer') && window.PointerEvent ? PointerEvent : MouseEvent;
                el.dispatchEvent(new Ev(ev, ev.includes('up') || ev === 'click' ? Object.assign({}, opts, { buttons: 0 }) : opts));
              } catch {}
            }
            try { el.click && el.click(); } catch {}
          }
          return true;
        })()`.replace('__PANDORA_IDX__', String(idx))));

        // 5) Se PHONE ainda não selecionado, abre o dropdown e clica em PHONE
        let phoneSelected = await isPhoneSelected();
        if (!phoneSelected && spiderPhoneSelected) {
          const aliveAfterSpider = !!(await exec(`!!document.querySelector('input[data-input-name="name"]')`));
          phoneSelected = aliveAfterSpider;
          try { appendSecDiag("[PIX-SPIDER] seleção aceita por estado do modal após tap: " + phoneSelected); } catch {}
        }
        if (phoneSelected) {
          try { appendSecDiag("[PIX] PHONE já estava selecionado"); } catch {}
        } else if (false) {
          // TRAVA ESTRITA: loop persistente até PHONE estar realmente selecionado.
          // Enquanto o modal estiver aberto, continua tentando. Sem fallback "seguindo mesmo assim".
          const MAX_ATTEMPTS = 60; // ~2 min de teto de segurança
          for (let attempt = 0; attempt < MAX_ATTEMPTS && !phoneSelected; attempt++) {
            // Confere se o modal ainda está aberto antes de cada tentativa
            const modalAlive = !!(await exec(`!!document.querySelector('input[data-input-name="name"]')`));
            if (!modalAlive) {
              try { appendSecDiag("[PIX] modal fechou inesperadamente durante seleção PHONE — abortando"); } catch {}
              win.__pandoraPixOrchestrating = false;
              return;
            }

            // (Re)localiza o trigger se ele sumiu ou ainda não foi marcado
            let trig = null;
            const stillThere = !!(await exec(`!!document.querySelector('[data-pandora-trigger="1"]')`));
            if (!stillThere) trig = await findTriggerRect();
            else {
              trig = await exec(`(() => {
                const t = document.querySelector('[data-pandora-trigger="1"]');
                if (!t) return null;
                try { t.scrollIntoView({ block: 'center' }); } catch {}
                const r = t.getBoundingClientRect();
                return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2), txt: (t.innerText||t.textContent||'').trim().slice(0,40) };
              })()`);
              if (!trig) trig = await findTriggerRect();
            }
            if (!trig) {
              try { appendSecDiag("[PIX] trigger não localizado (tentativa " + (attempt+1) + ") — aguardando e retry"); } catch {}
              await sleep(600);
              continue;
            }

            try { appendSecDiag("[PIX] abrindo dropdown trigger txt=" + trig.txt + " (tentativa " + (attempt+1) + "/" + MAX_ATTEMPTS + ")"); } catch {}
            // Antes de clicar, garante que o modal está ativo e focado
            await exec(`(() => {
              try {
                const nameInp = document.querySelector('input[data-input-name="name"]');
                if (nameInp && nameInp.focus) nameInp.focus();
              } catch {}
            })()`);
            await sleep(50);
            // Clique nativo preciso no centro do trigger: um único disparo e espera forçada
            // para o dropdown renderizar antes de qualquer verificação/retry.
            nativeClick(trig.x, trig.y);
            await sleep(500);

            // Verifica se o dropdown realmente abriu; se não, tenta novamente sem dar Escape
            const open = await isDropdownOpen();
            if (!open) {
              try { appendSecDiag("[PIX] dropdown não detectado após 500ms (tentativa " + (attempt+1) + ") — tentando clique JS e aguardando"); } catch {}
              await clickTriggerJS();
              await sleep(500);
            }
            const openAfterJs = await isDropdownOpen();
            if (!openAfterJs) {
              try { appendSecDiag("[PIX] dropdown não abriu após clique JS (tentativa " + (attempt+1) + ") — retry lento"); } catch {}
              await sleep(600);
              continue;
            }

            // espera o option PHONE aparecer (até ~5s por tentativa)
            let opt = null;
            for (let w = 0; w < 25; w++) {
              // Reconfirma que o modal ainda está aberto enquanto aguarda
              const stillAlive = !!(await exec(`!!document.querySelector('input[data-input-name="name"]')`));
              if (!stillAlive) {
                try { appendSecDiag("[PIX] modal fechou inesperadamente durante seleção PHONE — abortando"); } catch {}
                win.__pandoraPixOrchestrating = false;
                return;
              }
              opt = await findPhoneOptionRect();
              if (opt) break;
              await sleep(200);
            }
            if (!opt) {
              // Dump das opções visíveis para descobrir o texto exato
              let visibleTxts = [];
              try { visibleTxts = await dumpVisibleOptions(); } catch {}
              try { appendSecDiag("[PIX] PHONE não apareceu (tentativa " + (attempt+1) + ") — opções visíveis: [" + (visibleTxts||[]).join(" | ") + "]"); } catch {}
              try { wc.sendInputEvent({ type: 'keyDown', keyCode: 'Escape' }); wc.sendInputEvent({ type: 'keyUp', keyCode: 'Escape' }); } catch {}
              await sleep(600);
              continue;
            }
            try { appendSecDiag("[PIX] opção alvo localizada (txt=" + opt.txt + ", index=" + opt.index + ", byIndex=" + (!!opt.byIndex) + ", total=" + opt.count + ") em x=" + opt.x + " y=" + opt.y); } catch {}

            // ESTRATÉGIA SPIDER BOT: clique nativo por coordenada PRIMEIRO (page.mouse.click equivalente).
            // O dispatchEvent de DOM fica como fallback porque alguns SPAs Vue/Element rejeitam eventos sintéticos.
            try { appendSecDiag("[PIX] clicando PHONE NATIVO em x=" + opt.x + " y=" + opt.y + " txt=" + (opt.txt||'') + " byIndex=" + !!opt.byIndex); } catch {}
            nativeClick(opt.x, opt.y);
            await sleep(180);
            // Reforço: também clica via DOM dispatchEvent (caso o native miss)
            await clickOpenOptionByIndex(opt.index || 1);
            await sleep(700);

            phoneSelected = await isPhoneSelected();
            if (phoneSelected) { try { appendSecDiag("[PIX] PHONE selecionado com sucesso (tentativa " + (attempt+1) + ")"); } catch {} break; }
            try { appendSecDiag("[PIX] PHONE não confirmou seleção (tentativa " + (attempt+1) + ") — retry"); } catch {}
            await sleep(400);
          }
        }
        // TRAVA: só prossegue se PHONE foi 100% confirmado
        if (!phoneSelected) {
          try { appendSecDiag("[PIX] ABORT: PHONE não foi selecionado após esgotar tentativas — NÃO preenchendo campos"); } catch {}
          win.__pandoraPixOrchestrating = false;
          return;
        }
        // Espera o DOM trocar a estrutura CPF -> PHONE antes de preencher
        await sleep(300);

        // 6) Preenche os 3 campos do modal usando seletores estáveis
        await exec(`(() => {
          const setNative = (el, val) => {
            if (!el) return false;
            const proto = HTMLInputElement.prototype;
            const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
            try { el.focus(); } catch {}
            setter.call(el, val);
            el.dispatchEvent(new Event('input', { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            try { el.blur(); } catch {}
            return true;
          };
          const visible = (el) => !!(el && el.offsetParent !== null);
          // Nome
          const nome = document.querySelector('input[data-input-name="name"]');
          if (nome && visible(nome)) setNative(nome, ${JSON.stringify(nomeReal)});
          // Chave PIX (telefone) — maxlength 11
          let chaveInp = document.querySelector('input[maxlength="11"]');
          if (!chaveInp || !visible(chaveInp)) {
            chaveInp = Array.from(document.querySelectorAll('input')).filter(visible).find(i => /chave do PIX/i.test(i.placeholder||''));
          }
          if (chaveInp) setNative(chaveInp, ${JSON.stringify(phoneDigits)});
          // CPF — maxlength 14
          let cpfInp = document.querySelector('input[maxlength="14"]');
          if (!cpfInp || !visible(cpfInp)) {
            cpfInp = Array.from(document.querySelectorAll('input')).filter(visible).find(i => /CPF/i.test(i.placeholder||''));
          }
          if (cpfInp) setNative(cpfInp, ${JSON.stringify(cpfReal)});
        })()`);
        await sleep(120);
        try { appendSecDiag("[PIX] campos preenchidos (nome/chave/cpf)"); } catch {}

        // Detecta toast/alerta VISÍVEL depois de clicar Confirmar. O site usa
        // a MESMA classe CSS (.ui-toast/.van-toast) tanto pra erro quanto
        // sucesso ("Adicionado com êxito") — por isso retorna também se é
        // sucesso, pra quem chama poder tratar cada caso direito (achar que
        // "Adicionado com êxito" é erro e ABORTAR no meio foi exatamente o
        // bug que travava a janela: parava achando que tinha falhado quando
        // na verdade tinha funcionado).
        const SUCCESS_TOAST_RX = /(sucesso|êxito|exito|conclu[íi]do|adicionad[oa]\s+com)/i;
        const checkPixToast = async () => await exec(`(() => {
          const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0'; };
          const cands = Array.from(document.querySelectorAll('.ui-toast, .van-toast, [role="alert"], .ui-message--error, .ui-notify, [class*="toast" i], [class*="error" i], [class*="alert" i]')).filter(visible);
          for (const el of cands) {
            const t = (el.innerText || el.textContent || '').trim();
            if (t && t.length < 300) return t;
          }
          // fallback: procura qualquer texto visível na tela batendo com o padrão
          // "chave já usada/cadastrada/existente" mesmo sem estar num toast reconhecido
          const all = Array.from(document.querySelectorAll('body *')).filter((el) => el.children.length === 0 && visible(el));
          const rx = /(chave.*(j[áa]|existe|cadastrad|utilizad|em uso|duplicad)|already.*(exist|use)|key.*already)/i;
          for (const el of all) {
            const t = (el.innerText || el.textContent || '').trim();
            if (t && t.length < 200 && rx.test(t)) return t;
          }
          return '';
        })()`);

        // 7) Clica em Confirmar (#bindWithdrawAccountNextClick) — SÓ UMA VEZ
        // de verdade. Antes, o loop clicava de novo sempre que o toast ainda
        // não tinha aparecido 350ms depois do clique — mas o site faz uma
        // chamada ao servidor pra validar (ex.: "esta conta de saque já foi
        // vinculada por outro membro"), e com a proxy mais lenta essa resposta
        // podia demorar mais que isso, fazendo o código clicar Confirmar de
        // novo (e de novo) achando que o clique não tinha "pegado" — quando na
        // verdade só estava esperando a resposta do servidor chegar. Agora:
        // espera o botão ficar pronto, clica EXATAMENTE UMA VEZ, e só então
        // fica só observando (sem clicar de novo) até aparecer o toast, o
        // modal fechar, ou estourar o tempo.
        let confirmed = false, pixErrorMsg = "";
        let btn = null;
        const findEnd = Date.now() + 8000;
        while (Date.now() < findEnd) {
          btn = await exec(`(() => {
            const visible = (el) => !!(el && el.offsetParent !== null);
            let b = document.getElementById('bindWithdrawAccountNextClick');
            if (!b || !visible(b)) {
              b = Array.from(document.querySelectorAll('button')).find(x => visible(x) && /^\\s*confirmar\\s*$/i.test((x.innerText||x.textContent||'').trim()));
            }
            if (!b) return null;
            try { b.scrollIntoView({ block: 'center' }); } catch {}
            const r = b.getBoundingClientRect();
            return { x: Math.round(r.left + r.width/2), y: Math.round(r.top + r.height/2), disabled: !!b.disabled || /disabled/i.test(b.className||'') };
          })()`);
          if (!btn) {
            try { appendSecDiag("[PIX] botão Confirmar não encontrado — aguardando"); } catch {}
            await sleep(400);
            continue;
          }
          if (btn.disabled) {
            try { appendSecDiag("[PIX] botão Confirmar está disabled — aguardando"); } catch {}
            await sleep(500);
            btn = null;
            continue;
          }
          break;
        }
        if (!btn) {
          try { appendSecDiag("[PIX] botão Confirmar nunca ficou pronto — desistindo sem clicar"); } catch {}
        } else {
          try { appendSecDiag("[PIX] clicando Confirmar em x=" + btn.x + " y=" + btn.y + " (única vez)"); } catch {}
          win.__pandoraPixClickDone = true;
          // Interruptor geral: uma vez que clicou em Confirmar de verdade, o
          // script de CADASTRO DE CONTA (auto-register.cjs) não deve mais se
          // reinjetar nessa janela em nenhuma navegação futura — camada extra
          // de segurança além do guard local, pra garantir que nada mais
          // tenta clicar em nada nessa janela depois disso.
          win.__pandoraRegistrationFinished = true;
          nativeClick(btn.x, btn.y);
          // Removido: um segundo clique aqui (via .click() direto no DOM,
          // 100ms depois) mandava o formulário DUAS vezes pro site — o
          // nativeClick acima já é confirmado 100% confiável (o toast de
          // erro/sucesso sempre aparece depois dele nos logs). Esse segundo
          // envio duplicado é o motivo mais provável do site reagir "em
          // dobro" (toast/travamento) e do campo de telefone ficar preso
          // logo depois, impedindo trocar a chave manualmente.
          await sleep(100);
          // Aguarda a resposta do servidor (toast de sucesso/erro ou o modal
          // fechando) por até 10s, checando periodicamente — SEM clicar de novo.
          const waitEnd = Date.now() + 10000;
          while (Date.now() < waitEnd) {
            await sleep(400);
            const toastMsg = await checkPixToast().catch(() => "");
            if (toastMsg) {
              if (SUCCESS_TOAST_RX.test(toastMsg)) {
                confirmed = true;
                try { appendSecDiag("[PIX] SUCESSO confirmado por toast — parando (cadastro concluído): " + toastMsg); } catch {}
              } else {
                pixErrorMsg = toastMsg;
                try { appendSecDiag("[PIX] ERRO detectado após clicar Confirmar — parando (ex.: conta já vinculada/chave já usada): " + toastMsg); } catch {}
              }
              break;
            }
            const gone = await exec(`(() => { const b = document.getElementById('bindWithdrawAccountNextClick'); return !b || !(b.offsetParent !== null); })()`);
            if (gone) { confirmed = true; try { appendSecDiag("[PIX] modal fechou — cadastro enviado"); } catch {} break; }
          }
          if (!confirmed && !pixErrorMsg) {
            try { appendSecDiag("[PIX] cliquei uma vez em Confirmar mas não vi resposta do site em 10s — não vou clicar de novo"); } catch {}
          }
          // Erro tipo "chave já vinculada": o toast do site fica em cima do
          // campo do telefone, cobrindo ele e impedindo clicar lá pra trocar
          // a chave manualmente (print confirmou isso). Fecha o modal
          // sozinho pra devolver a tela limpa — sem isso, o usuário ficava
          // "preso" achando que era o bot clicando repetido.
          if (pixErrorMsg) {
            await sleep(600);
            try { appendSecDiag("[PIX] forçando fechamento do modal via JS (display:none + Esc)"); } catch {}
            // Fecha via JS direto (esconde o modal + dispara Esc) em vez de
            // procurar/clicar um ícone de fechar por coordenada — não depende
            // de achar o elemento certo nem de um segundo nativeClick, então
            // não trava esperando executeJavaScript e não arrisca clicar em
            // outra coisa por engano.
            const forceCloseResult = await Promise.race([
              exec(`(() => {
                try {
                  const visible = (el) => { if (!el) return false; const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 2 && r.height > 2 && s.visibility !== 'hidden' && s.display !== 'none' && s.opacity !== '0'; };
                  const pixInput = Array.from(document.querySelectorAll('input')).filter(visible).find(i => /pix|chave/i.test((i.placeholder||'') + ' ' + (i.getAttribute('data-input-name')||'')));
                  let modal = null;
                  if (pixInput) {
                    let n = pixInput.parentElement;
                    for (let i = 0; i < 10 && n; i++, n = n.parentElement) {
                      const cls = (n.className || '') + '';
                      if (/popup|modal|dialog/i.test(cls)) { modal = n; break; }
                    }
                  }
                  let closed = false;
                  if (modal) { try { modal.style.setProperty('display', 'none', 'important'); closed = true; } catch {} }
                  try { document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', bubbles: true })); } catch {}
                  return closed;
                } catch (e) { return false; }
              })()`),
              new Promise((resolve) => setTimeout(() => resolve("TIMEOUT"), 4000)),
            ]);
            try { appendSecDiag("[PIX] resultado do fechamento forçado: " + JSON.stringify(forceCloseResult)); } catch {}
          }
        }

        win.__pandoraPixOrchestrating = false;
      } catch (err) {
        try { appendSecDiag("[PIX] erro fatal: " + (err && err.message ? err.message : String(err))); } catch {}
        try { win.__pandoraPixOrchestrating = false; } catch {}
      }
    }


    const mesmasChaves = String(getSettingSync("op_mesmas_chaves", "0")) === "1";
    const usadas = new Set();
    let n = 0, i = 0;
    for (const win of getSelectedChromeWins()) {
      try {
        if (!win || win.isDestroyed() || win._proxyReady === false) continue;
        const chave = mesmasChaves ? list[0] : list[i % list.length]; i++;
        usadas.add(chave);
        let target = "";
        if (pathPart) {
          let origin = "";
          try { origin = new URL(win.webContents.getURL()).origin; } catch {}
          if (!origin) { try { origin = new URL(win._targetUrl || input).origin; } catch {} }
          if (origin) target = origin + pathPart;
        }
        const runFill = () => {
          try { win.webContents.executeJavaScript(fillScript(chave, tipo), true).catch(() => {}); } catch {}
        };
        if (target) {
          if (isSecurity) {
            // Página de definição de senha de saque (12 dígitos = 2x6).
            // Roda o preenchedor de PIN + clique no Confirmar. Após a
            // confirmação, o watcher recarrega limpo em /home/withdraw?active=10.
            // Aqui anexamos um listener que, ao chegar em active=10, dispara
            // o fillScript (clica no "Adicionar"/#addAccountClick) e o
            // orchestratePixForm (seleciona PHONE, preenche nome/telefone/CPF).
            scheduleSecurityPinFill(win, getWithdrawPin(win), "pix");
            if (win.__pandoraPixActive10Watcher) {
              try { win.webContents.removeListener("did-finish-load", win.__pandoraPixActive10Watcher); } catch {}
              try { win.webContents.removeListener("did-navigate", win.__pandoraPixActive10Watcher); } catch {}
              try { win.webContents.removeListener("did-navigate-in-page", win.__pandoraPixActive10Watcher); } catch {}
              try { win.webContents.removeListener("dom-ready", win.__pandoraPixActive10Watcher); } catch {}
              try { win.webContents.removeListener("did-stop-loading", win.__pandoraPixActive10Watcher); } catch {}
            }
            win.__pandoraPixActive10Scheduled = false;
            win.__pandoraPixOrchestrating = false;
            win.__pandoraPixClickDone = false; // nova tentativa de cadastro — libera um clique novo
            const onNavActive10 = (reason = "nav") => {
              try {
                const u = new URL(win.webContents.getURL());
                if (!/\/home\/withdraw/i.test(u.pathname)) return;
                if (u.searchParams.get("active") !== "10") return;
                if (win.__pandoraPixActive10Scheduled) return;
                win.__pandoraPixActive10Scheduled = true;
                try { console.log(`[PIX] active=10 detectado (${reason}) — abrindo cadastro e orquestrando PHONE`); } catch {}
                try { appendSecDiag(`[PIX] active=10 detectado (${reason}) — disparando orquestração PHONE`); } catch {}
                win.webContents.removeListener("did-finish-load", onNavActive10);
                win.webContents.removeListener("did-navigate", onNavActive10);
                win.webContents.removeListener("did-navigate-in-page", onNavActive10);
                win.webContents.removeListener("dom-ready", onNavActive10);
                win.webContents.removeListener("did-stop-loading", onNavActive10);
                if (win.__pandoraPixActive10Watcher === onNavActive10) win.__pandoraPixActive10Watcher = null;
                setTimeout(runFill, 800);
                setTimeout(runFill, 4000);
                setTimeout(runFill, 12000);
                setTimeout(() => { orchestratePixForm(win, chave); }, 1500);
                setTimeout(() => { orchestratePixForm(win, chave); }, 6000);
                setTimeout(() => { orchestratePixForm(win, chave); }, 14000);
              } catch {}
            };
            win.__pandoraPixActive10Watcher = onNavActive10;
            win.webContents.on("did-finish-load", onNavActive10);
            win.webContents.on("did-navigate", onNavActive10);
            win.webContents.on("did-navigate-in-page", onNavActive10);
            win.webContents.on("dom-ready", onNavActive10);
            win.webContents.on("did-stop-loading", onNavActive10);
            for (const ms of [1500, 3500, 7000, 11000, 17000, 25000]) {
              setTimeout(() => onNavActive10("poll" + ms), ms);
            }
          } else {
            const onLoaded = () => {
              win.webContents.removeListener("did-finish-load", onLoaded);
              win.__pandoraPixClickDone = false; // nova tentativa de cadastro — libera um clique novo
              setTimeout(runFill, 250);
              setTimeout(runFill, 4000);
              setTimeout(runFill, 12000);
              setTimeout(runFill, 25000);
              setTimeout(runFill, 40000);
              setTimeout(() => { orchestratePixForm(win, chave); }, 600);
            };
            win.webContents.on("did-finish-load", onLoaded);
          }
          try { win.loadURL(target); } catch {}
        } else {
          setTimeout(runFill, 100);
          setTimeout(() => { orchestratePixForm(win, chave); }, 600);
        }
        n++;
      } catch {}
    }
    // Exclui automaticamente as chaves que foram utilizadas
    try {
      const arr = Array.from(usadas).filter(Boolean);
      if (arr.length) {
        const placeholders = arr.map(() => "?").join(",");
        const stmt = state.db.prepare(`DELETE FROM pix_keys WHERE key_value IN (${placeholders})`);
        stmt.run(arr);
        stmt.free();
        await saveDB(state.db, state.dbPath);
      }
    } catch (e) { try { console.warn("[pix] falha ao excluir chaves usadas:", e?.message || e); } catch {} }
    return { ok: true, windows: n, keys: list.length };
  });
}

module.exports = { registerPixHandler };
