// ============================================================================
// IPC: dialog:openFile / dialog:saveFile — diálogos nativos de arquivo.
// ============================================================================
const { dialog } = require("electron");
const fs = require("fs");
const path = require("path");
const state = require("../state.cjs");

function registerDialogHandlers(ipcMain) {
  ipcMain.handle("dialog:openFile", async (_e, opts) => {
    const r = await dialog.showOpenDialog(state.mainWin, opts || {});
    if (r.canceled || !r.filePaths.length) return null;
    const filePath = r.filePaths[0];
    const buf = fs.readFileSync(filePath);
    return { path: filePath, name: path.basename(filePath), data: buf.toString("base64") };
  });
  ipcMain.handle("dialog:saveFile", async (_e, opts, contentBase64) => {
    const r = await dialog.showSaveDialog(state.mainWin, opts || {});
    if (r.canceled || !r.filePath) return null;
    fs.writeFileSync(r.filePath, Buffer.from(contentBase64, "base64"));
    return r.filePath;
  });
}

module.exports = { registerDialogHandlers };
