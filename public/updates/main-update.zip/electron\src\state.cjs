// ============================================================================
// Estado compartilhado do processo principal.
//
// O main.cjs original mantinha dezenas de variáveis `let`/`const` soltas no
// escopo do módulo (db, chromeWins, mainWin, flags de mirror mode, etc.) e
// praticamente toda função do arquivo lia/escrevia nelas diretamente. Ao
// dividir o código em vários arquivos precisamos de UM único objeto mutável
// compartilhado — closures continuam mudando os MESMOS campos que todo mundo
// enxerga, exatamente como quando tudo vivia no mesmo escopo de módulo.
//
// Import em qualquer módulo com `const state = require("../state.cjs")` e
// leia/escreva `state.campo` normalmente.
// ============================================================================

const state = {
  // ---- Banco de dados (settingsStore.cjs) ----
  db: null,
  dbPath: null,

  // ---- Janelas ----
  mainWin: null,
  // Janelas Chromium controladas — mistura BrowserWindow do Electron (legado)
  // e shims de Chrome real via CDP (realchrome/realChromeManager.cjs, marcados
  // com _realChrome=true); todo o resto do app trata os dois tipos igual.
  chromeWins: [],
  workerWins: [],

  // ---- Proxy (proxyManager.cjs) ----
  activeLocalProxies: [],
  proxyBridgeCache: new Map(), // upstreamKey -> localUrl
  ipRotationInFlight: new WeakSet(),

  // ---- Bloqueio de domínios (domainBlocker.cjs) ----
  blockedDomains: [],
  sessionsWithBlock: new WeakSet(),

  // ---- Update (updater.cjs) ----
  updateInProgress: false,
  restartSplashWin: null,
  startupSplashWin: null,
  startupSplashShownAt: 0,

  // ---- Modo espelho (mirrorMode.cjs) ----
  mirrorEnabled: false,
  mirrorMaster: null,

  // ---- Seleção manual de janelas (chromiumWindowsManager.cjs) ----
  janelasOverride: null,

  // ---- Encerramento ----
  quitCleanupDone: false,
};

module.exports = state;
