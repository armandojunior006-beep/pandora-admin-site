// ============================================================================
// Ação do botão "Relatório de Apostas" (aba Operação). Arquivo PRÓPRIO,
// separado do navMap genérico de Operacao.tsx — regra do usuário 2026-08-09:
// cada botão/ação nova entra em arquivo dedicado.
//
// Chama window.api.reportChromium() (preload.cjs -> "chrome:report" ->
// src/ipc/reportHandler.cjs), que navega cada janela selecionada pra
// "<origin da janela>/home/report?reportCurrent=1" e lê "Apostas Válidas".
//
// Pedido do usuário 2026-08-19: "em operação oculta quando clicar em
// relatório de apostas ele identificar a quantidade de apostas válidas...
// e mostrar ali no log" — o handler agora devolve um resultado por tela em
// vez de só a contagem; ver src/ipc/reportHandler.cjs.
// ============================================================================
export type RelatorioApostasResult = { telaNum: number; ok: boolean; apostasValidas: number | null; reason: string | null };

export async function clicarRelatorioDeApostas(): Promise<RelatorioApostasResult[]> {
  const r = await (window as any).api?.reportChromium?.();
  return Array.isArray(r) ? r : [];
}
